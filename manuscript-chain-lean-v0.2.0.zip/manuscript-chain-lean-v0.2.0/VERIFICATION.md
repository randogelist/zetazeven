# Verification of the reduced layout

All six ITEMS modules and MAIN_CHAIN compiled successfully with Lean 4.33.0
and pinned Mathlib v4.33.0 on Linux. The optional native replay also passed.
Compiler logs are in verification/main and verification/native. The main log
prints the final theorem types and their axiom dependencies.

The sources contain no admitted proofs, custom axioms, native_decide, or unsafe
code. The endpoint axiom audits contain only propext, Classical.choice, and
Quot.sound. Explicit theorem hypotheses remain unproved inputs.

The independent refactor review found no changed retained declaration
signatures or forward ITEMS imports. The old convenience endpoint wrappers
are replaced by the statements in MAIN_CHAIN. The full catalog/provenance
validator passed. Windows CMD scripts are supplied but were not executed.
