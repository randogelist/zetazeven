import ManuscriptChain.Certificates
import ManuscriptChain.Inventory

/-! Audit of every proved declaration in the native finite layer and inventory.
No analytic bridge is introduced by this audit. -/

#print axioms ManuscriptChain.Exact.Poly.eval_nil
#print axioms ManuscriptChain.Exact.Poly.eval_cons
#print axioms ManuscriptChain.Exact.rat_mul_left_comm
#print axioms ManuscriptChain.Exact.rat_pow_add
#print axioms ManuscriptChain.Exact.Poly.eval_add
#print axioms ManuscriptChain.Exact.Poly.eval_scale
#print axioms ManuscriptChain.Exact.Poly.eval_sub
#print axioms ManuscriptChain.Exact.Poly.eval_mul
#print axioms ManuscriptChain.Exact.Poly.eval_pow
#print axioms ManuscriptChain.Exact.Poly.eval_shift
#print axioms ManuscriptChain.Exact.Affine.toPoly_eval
#print axioms ManuscriptChain.Exact.determinantTwo_eval
#print axioms ManuscriptChain.Exact.pencilM_eq_vandermonde_sum
#print axioms ManuscriptChain.Exact.numerator_symmetric
#print axioms ManuscriptChain.Exact.residue_symmetric
#print axioms ManuscriptChain.Exact.hankelEntry_symmetric
#print axioms ManuscriptChain.Certificates.bernoulli_convention
#print axioms ManuscriptChain.Certificates.zeta_three_constant_moment
#print axioms ManuscriptChain.Certificates.one_dimensional_pencil
#print axioms ManuscriptChain.Certificates.principal_derivative_can_vanish
#print axioms ManuscriptChain.Certificates.two_dimensional_pencil_00
#print axioms ManuscriptChain.Certificates.two_dimensional_pencil_01
#print axioms ManuscriptChain.Certificates.two_dimensional_pencil_11
#print axioms ManuscriptChain.Certificates.two_dimensional_determinant
#print axioms ManuscriptChain.Certificates.two_dimensional_determinant_at_one
#print axioms ManuscriptChain.Certificates.one_dimensional_root
#print axioms ManuscriptChain.Certificates.tail_division_example
#print axioms ManuscriptChain.Certificates.formal_beta_four_constant_moment
#print axioms ManuscriptChain.Certificates.formal_beta_four_constant_moment_ne_one
#print axioms ManuscriptChain.Certificates.corrected_transfer_threshold
#print axioms ManuscriptChain.Certificates.corrected_integer_exponent
#print axioms ManuscriptChain.Certificates.original_rate_optimized_threshold
#print axioms ManuscriptChain.Inventory.numbered_count
#print axioms ManuscriptChain.Inventory.complete_numbered_coverage
#print axioms ManuscriptChain.Inventory.unique_numbered_ids
#print axioms ManuscriptChain.Inventory.subclaim_count
#print axioms ManuscriptChain.Inventory.unique_subclaim_ids
#print axioms ManuscriptChain.Inventory.subclaim_counts_match
#print axioms ManuscriptChain.Inventory.no_refuted_active_hypothesis
#print axioms ManuscriptChain.Inventory.no_refuted_hole_tags
#print axioms ManuscriptChain.Inventory.active_hypotheses_are_mathematical_holes
#print axioms ManuscriptChain.Inventory.registered_subclaim_hole_tags
