import ManuscriptChain.Exact

/-! Kernel-checked rational certificates for the manuscript's finite formulas.
These do not certify an analytic realization, a global arithmetic multiplier,
or the parameter-specific asymptotic decay input. -/

namespace ManuscriptChain.Certificates

open Exact

set_option maxRecDepth 100000
set_option maxHeartbeats 10000000

-- Kernel reduction unfolds the rational arithmetic definitions directly.

theorem bernoulli_convention : bernoulli 1 = (-1 : Rat) / 2 := by decide +kernel

theorem zeta_three_constant_moment : monomialMoment 1 0 = (1 : Rat) / 4 := by decide +kernel

/-- `s=3, m=1, N=1, K=2` gives the genuine one-dimensional pencil. -/
theorem one_dimensional_pencil :
    hankelEntry 1 1 1 2 0 0 = ⟨(29 : Rat) / 2, -12⟩ := by decide +kernel

/-- A leading principal derivative block can vanish even for a valid full pencil. -/
theorem principal_derivative_can_vanish : pencilM 1 1 1 5 0 0 = 0 := by decide +kernel

theorem two_dimensional_pencil_00 :
    hankelEntry 1 1 1 3 0 0 = ⟨(-173 : Rat) / 12, 12⟩ := by decide +kernel

theorem two_dimensional_pencil_01 :
    hankelEntry 1 1 1 3 0 1 = ⟨(577 : Rat) / 4, -120⟩ := by decide +kernel

theorem two_dimensional_pencil_11 :
    hankelEntry 1 1 1 3 1 1 = ⟨(-16271 : Rat) / 12, 1128⟩ := by decide +kernel

/-- The exact determinant coefficients, in ascending order. -/
theorem two_dimensional_determinant :
    (hankelDetTwo 1 1 1 3).trim = [(-90739 : Rat) / 72, 2087, -864] := by decide +kernel

theorem two_dimensional_determinant_at_one :
    (hankelDetTwo 1 1 1 3).eval 1 = (-2683 : Rat) / 72 := by decide +kernel

theorem one_dimensional_root :
    (hankelEntry 1 1 1 2 0 0).eval ((29 : Rat) / 24) = 0 := by decide +kernel

theorem tail_division_example :
    (Poly.divMod (D 1) (tailDenominator 1 2)).1 = [1] ∧
    (Poly.divMod (D 1) (tailDenominator 1 2)).2 = [-3] := by decide +kernel

theorem formal_beta_four_constant_moment : betaFourMoment 0 = (1 : Rat) / 4 := by decide +kernel

theorem formal_beta_four_constant_moment_ne_one : betaFourMoment 0 ≠ 1 := by decide +kernel

/-- These are arithmetic calculations of transfer thresholds only.  Applying
them requires the analytic and arithmetic hypotheses in the dependency chain. -/
theorem corrected_transfer_threshold :
    (9 / 10 : Rat) * (11407 / 1000) / (1 / 2500) = 102663 / 4 := by decide +kernel

theorem corrected_integer_exponent :
    (9 / 10 : Rat) * (11407 / 1000) / (1 / 2500) < 25666 := by decide +kernel

theorem original_rate_optimized_threshold :
    (9 / 10 : Rat) * (11411 / 1000) / (1 / 2500) < 25675 := by decide +kernel

end ManuscriptChain.Certificates
