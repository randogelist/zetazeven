import Std

/-!
# Finite manuscript inventory — metadata certificates only

Generated from catalog.json. The declarations below encode strings and audit tags.
The proved theorems certify enumeration and exclusion checks on those finite data.
They do not formalize, prove, or assume the mathematical statements in the manuscript.
In particular, `activeHypothesis` means a named *candidate* bridge in this manifest;
it creates no Lean proposition, axiom, instance, or proof of that bridge.
-/

namespace ManuscriptChain.Inventory

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

inductive AuditStatus where
  | verifiedOnPaper | repair | openBridge | refutedAsWritten | conjecture
  deriving DecidableEq, Repr

inductive DebtClass where
  | mathematicalHole | formalizationDebt | refutedNoObligation
  deriving DecidableEq, Repr

structure NumberedItem where
  id : String
  status : AuditStatus
  subclaimCount : Nat
  sourcePages : List Nat
  dependencyIds : List String
  holeTags : List String
  deriving DecidableEq, Repr

structure Subclaim where
  id : String
  parentId : String
  status : AuditStatus
  debt : DebtClass
  dependencyIds : List String
  holeTags : List String
  activeHypothesis : Bool
  deriving DecidableEq, Repr

def catalogSha256 : String := "0eab0fa1c03cd6b98300e26a0b8ce69b9769ac9061cbf1049977b34b5169394a"
def sourceSha256 : String := "935767c0cda7468f376cd8eadc374077caf6c8a060351d3bea26ac3f838a9d0c"
def numberedItems : List NumberedItem := [
  ⟨"2.1", .verifiedOnPaper, 2, [3, 4], [], []⟩,
  ⟨"2.2", .verifiedOnPaper, 2, [4], ["2.1"], []⟩,
  ⟨"2.3", .repair, 2, [5], ["2.2"], []⟩,
  ⟨"2.4", .verifiedOnPaper, 2, [6], ["2.1"], []⟩,
  ⟨"2.5", .verifiedOnPaper, 3, [6, 7], ["2.1"], []⟩,
  ⟨"3.1", .verifiedOnPaper, 4, [7, 8], ["2.1", "2.5"], []⟩,
  ⟨"3.2", .repair, 2, [8], ["3.1"], []⟩,
  ⟨"3.3", .repair, 4, [8, 9], ["2.5", "3.1"], []⟩,
  ⟨"3.4", .repair, 5, [9, 10], ["2.5", "3.1"], []⟩,
  ⟨"3.5", .refutedAsWritten, 4, [10, 11], ["3.1", "3.4", "4.7"], ["FullFamilyLanczosCyclicity"]⟩,
  ⟨"3.6", .refutedAsWritten, 5, [11], ["3.1"], []⟩,
  ⟨"3.7", .repair, 4, [11, 12], ["3.1", "3.3"], ["ShiftedCoefficientNonvanishing"]⟩,
  ⟨"3.8", .repair, 2, [12, 13], ["2.5", "3.1"], []⟩,
  ⟨"3.9", .repair, 3, [13, 14], ["2.1", "2.5", "3.1"], ["DirichletCoefficientRationalization"]⟩,
  ⟨"3.10", .openBridge, 5, [14], ["3.4", "4.7"], ["VaryingKNonclassicality"]⟩,
  ⟨"4.1", .repair, 2, [14, 15], [], ["H4_EFFECTIVE_ONSET"]⟩,
  ⟨"4.2", .verifiedOnPaper, 1, [15], ["4.1.transfer"], []⟩,
  ⟨"4.3", .verifiedOnPaper, 1, [15], [], []⟩,
  ⟨"4.4", .openBridge, 4, [16, 17, 18], ["3.1", "4.1.effectivity", "4.1.transfer", "4.4.integer_decay", "4.4.irrationality", "4.4.spectral"], ["H4_K30_INTEGER_DECAY"]⟩,
  ⟨"4.5", .openBridge, 4, [18, 19], ["3.1", "4.1.effectivity", "4.1.transfer", "4.5.arithmetic", "4.5.weight"], ["H4_MIXED_INTEGER_DECAY"]⟩,
  ⟨"4.6", .openBridge, 6, [19, 20, 21], ["3.1", "4.4.integer_decay", "4.4.spectral", "4.6.derivative_rate", "4.6.det_upper"], ["H4_K30_ARCHIMEDEAN_UPPER", "H4_NORMALIZATION_RATE_LOWER"]⟩,
  ⟨"4.7", .openBridge, 4, [21], ["3.1", "4.4.integer_decay", "4.4.spectral", "4.6.det_lower", "4.6.height_upper"], []⟩,
  ⟨"4.8", .openBridge, 4, [21, 22], ["4.4.irrationality", "4.4.spectral"], ["H4_GLOBAL_RATIONAL_ROOT_EXCLUSION"]⟩,
  ⟨"4.9", .openBridge, 4, [22], ["4.4.spectral", "4.6.det_lower"], ["H4_VARIATIONAL_COMPARISON", "H4_VARIATIONAL_NUMERIC_LOWER"]⟩,
  ⟨"4.10", .refutedAsWritten, 3, [22], [], ["H4_FREE_ENERGY_REGULARITY"]⟩,
  ⟨"4.11", .conjecture, 1, [22], ["4.9.variational"], []⟩,
  ⟨"5.1", .verifiedOnPaper, 1, [22, 23], [], []⟩,
  ⟨"5.2", .refutedAsWritten, 6, [23, 24], ["5.1.moments", "5.2.2"], ["H5_DEFINITE_SUBSPACES_GROWING_DEGREE"]⟩,
  ⟨"5.3", .verifiedOnPaper, 2, [24, 25], ["5.2.1", "5.3.moments"], []⟩,
  ⟨"5.4", .repair, 2, [25], ["2.2"], []⟩,
  ⟨"5.5", .verifiedOnPaper, 1, [25], ["5.4.cancellation"], []⟩,
  ⟨"5.6", .refutedAsWritten, 7, [26, 27], ["5.6.2.expansion"], ["H5_CLASS_DEPENDENT_POLE_REFINEMENT"]⟩,
  ⟨"5.7", .refutedAsWritten, 7, [28, 29], ["5.7.2.rank"], ["H5_CORRECT_MULTIPOLE_REPRESENTATION"]⟩,
  ⟨"6.1", .refutedAsWritten, 5, [29, 30, 31], ["5.1", "6.1.divided_difference", "6.1.local_matrix"], []⟩,
  ⟨"6.2", .verifiedOnPaper, 2, [31, 32], ["5.1", "6.2.moments"], []⟩,
  ⟨"6.3", .refutedAsWritten, 6, [32, 33], ["5.1", "5.2", "6.3.dimension", "6.3.local_nonvanishing"], ["H.zeta7_compatible_small_forms"]⟩,
  ⟨"6.4", .refutedAsWritten, 5, [33, 34], ["6.4.derivative", "6.4.integral", "6.4.odd_formal_definition"], []⟩,
  ⟨"6.5", .verifiedOnPaper, 1, [34, 35], ["6.4.odd_formal_definition"], []⟩,
  ⟨"6.6", .openBridge, 6, [35, 36], ["2.1", "2.2", "3.1", "6.6.collapse", "6.6.pullback", "6.6.spectral"], ["H.multiweight_multiplier_rate"]⟩,
  ⟨"6.7", .repair, 6, [37, 38], ["5.1", "5.2", "6.7.hyperbolicity", "6.7.krein"], ["H.multiweight_polynomial_inertia"]⟩,
  ⟨"6.8", .openBridge, 2, [38], ["4.5"], []⟩,
  ⟨"6.9", .refutedAsWritten, 6, [38, 39], ["5.7", "6.9.triple_laurent"], ["H.consistent_triple_pole_architecture"]⟩,
  ⟨"6.10", .refutedAsWritten, 7, [39, 40], ["3.1", "5.2", "6.10.equilibrium_limits", "6.10.finite_identity", "6.10.rate_identity"], ["H.corrected_family_potential_gap", "H.kernel_energy_limits"]⟩,
  ⟨"6.11", .refutedAsWritten, 6, [40, 41, 42], ["6.11.local_count", "6.4.odd_formal_definition"], ["H.beta_multiplier_active_regimes"]⟩,
  ⟨"6.12", .openBridge, 4, [42, 43], ["3.1", "6.12.model", "6.12.sign_flip", "6.4.odd_formal_definition"], ["H.beta_integer_lattice_local_blocks", "H.consistent_integer_square_beta_model"]⟩,
  ⟨"6.13", .repair, 4, [43, 44], ["3.1", "3.7", "6.12.model", "6.13.differential_identity"], ["H.central_factorial_beta_identification"]⟩,
  ⟨"6.14", .refutedAsWritten, 5, [45, 46], ["4.4", "6.12.model", "6.14.new_model", "6.4.odd_formal_definition"], []⟩,
  ⟨"6.15", .repair, 6, [46, 47], ["6.15.moments", "6.15.rank_one", "6.15.transcendence"], []⟩,
  ⟨"6.16", .refutedAsWritten, 5, [47, 48], ["3.1", "6.12.model", "6.16.formal_collapse", "6.16.harmonic_valuation", "6.16.large_prime_bound"], ["H.mixed_beta_distribution_multiplier"]⟩,
  ⟨"6.17", .repair, 7, [48, 49], ["5.1", "5.3", "6.10.derivative_growth", "6.17.moments", "6.7.local_nonvanishing"], ["H.even_beta_local_nonvanishing", "H.mixed_polynomial_inertia"]⟩,
  ⟨"6.18", .openBridge, 6, [49, 50], ["3.4", "4.5", "6.12.model", "6.16.comparison", "6.16.distribution", "6.16.formal_collapse", "6.18.dyadic_residues", "6.18.explicit_degree", "6.18.quotient_threshold", "6.6.multiplier_rate"], ["H.mixed_beta_dyadic_residues"]⟩
]

def subclaims : List Subclaim := [
  ⟨"2.1.domain", "2.1", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"2.1.moments", "2.1", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"2.2.pullback", "2.2", .verifiedOnPaper, .formalizationDebt, ["2.1"], [], false⟩,
  ⟨"2.2.zeroPoles", "2.2", .verifiedOnPaper, .formalizationDebt, ["2.1"], [], false⟩,
  ⟨"2.3.reflection", "2.3", .repair, .formalizationDebt, ["2.2"], [], false⟩,
  ⟨"2.3.difference", "2.3", .repair, .formalizationDebt, ["2.2"], [], false⟩,
  ⟨"2.4.invariance", "2.4", .verifiedOnPaper, .formalizationDebt, ["2.1"], [], false⟩,
  ⟨"2.4.scope", "2.4", .repair, .formalizationDebt, ["2.4.invariance"], [], false⟩,
  ⟨"2.5.offDiagonal", "2.5", .verifiedOnPaper, .formalizationDebt, ["2.1"], [], false⟩,
  ⟨"2.5.diagonal", "2.5", .verifiedOnPaper, .formalizationDebt, ["2.1"], [], false⟩,
  ⟨"2.5.factorization", "2.5", .verifiedOnPaper, .formalizationDebt, ["2.5.diagonal", "2.5.offDiagonal"], [], false⟩,
  ⟨"3.1.momentRepresentation", "3.1", .verifiedOnPaper, .formalizationDebt, ["2.1"], [], false⟩,
  ⟨"3.1.positivity", "3.1", .verifiedOnPaper, .formalizationDebt, ["3.1.momentRepresentation"], [], false⟩,
  ⟨"3.1.hyperbolicity", "3.1", .verifiedOnPaper, .formalizationDebt, ["2.5.factorization", "3.1.positivity"], [], false⟩,
  ⟨"3.1.zeroFree", "3.1", .verifiedOnPaper, .formalizationDebt, ["3.1.hyperbolicity"], [], false⟩,
  ⟨"3.2.hyperbolicity", "3.2", .verifiedOnPaper, .formalizationDebt, ["3.1.hyperbolicity"], [], false⟩,
  ⟨"3.2.oddAgreement", "3.2", .refutedAsWritten, .refutedNoObligation, ["3.1.momentRepresentation"], [], false⟩,
  ⟨"3.3.totalPositivity", "3.3", .verifiedOnPaper, .formalizationDebt, ["3.1.momentRepresentation"], [], false⟩,
  ⟨"3.3.determinacy", "3.3", .repair, .formalizationDebt, ["3.1.momentRepresentation"], [], false⟩,
  ⟨"3.3.leadingSign", "3.3", .verifiedOnPaper, .formalizationDebt, ["2.5.factorization"], [], false⟩,
  ⟨"3.3.signature", "3.3", .verifiedOnPaper, .formalizationDebt, ["2.5.factorization", "3.1.hyperbolicity"], [], false⟩,
  ⟨"3.4.eigenInterlacing", "3.4", .verifiedOnPaper, .formalizationDebt, ["3.1.positivity"], [], false⟩,
  ⟨"3.4.finiteRootCount", "3.4", .refutedAsWritten, .refutedNoObligation, ["2.5.factorization"], [], false⟩,
  ⟨"3.4.distanceMonotonicity", "3.4", .repair, .formalizationDebt, ["3.4.eigenInterlacing"], [], false⟩,
  ⟨"3.4.condensation", "3.4", .verifiedOnPaper, .formalizationDebt, ["2.1"], [], false⟩,
  ⟨"3.4.rankCorrection", "3.4", .verifiedOnPaper, .formalizationDebt, ["2.5.factorization"], [], false⟩,
  ⟨"3.5.resolvent", "3.5", .refutedAsWritten, .refutedNoObligation, ["3.1.positivity"], [], false⟩,
  ⟨"3.5.fullLength", "3.5", .openBridge, .mathematicalHole, ["3.4.eigenInterlacing"], ["FullFamilyLanczosCyclicity"], true⟩,
  ⟨"3.5.rationalRatio", "3.5", .repair, .formalizationDebt, ["2.1"], [], false⟩,
  ⟨"3.5.universalEdge", "3.5", .refutedAsWritten, .refutedNoObligation, ["4.7"], [], false⟩,
  ⟨"3.6.logDerivative", "3.6", .repair, .formalizationDebt, ["3.1.hyperbolicity"], [], false⟩,
  ⟨"3.6.evenMoments", "3.6", .verifiedOnPaper, .formalizationDebt, ["3.1.hyperbolicity"], [], false⟩,
  ⟨"3.6.allOrderStrictness", "3.6", .refutedAsWritten, .refutedNoObligation, ["3.6.evenMoments"], [], false⟩,
  ⟨"3.6.finitePowerBounds", "3.6", .refutedAsWritten, .refutedNoObligation, ["3.6.evenMoments"], [], false⟩,
  ⟨"3.6.limit", "3.6", .verifiedOnPaper, .formalizationDebt, ["3.6.evenMoments"], [], false⟩,
  ⟨"3.7.turan", "3.7", .verifiedOnPaper, .formalizationDebt, ["3.1.hyperbolicity", "3.3.signature"], [], false⟩,
  ⟨"3.7.newton", "3.7", .verifiedOnPaper, .formalizationDebt, ["3.1.hyperbolicity"], [], false⟩,
  ⟨"3.7.shiftedStrictness", "3.7", .repair, .formalizationDebt, ["3.7.newton", "3.7.turan"], [], false⟩,
  ⟨"3.7.coefficientNonvanishing", "3.7", .openBridge, .mathematicalHole, ["3.1.hyperbolicity"], ["ShiftedCoefficientNonvanishing"], true⟩,
  ⟨"3.8.poleKernel", "3.8", .verifiedOnPaper, .formalizationDebt, ["2.5.factorization", "3.1.positivity"], [], false⟩,
  ⟨"3.8.deformation", "3.8", .repair, .formalizationDebt, ["3.1.momentRepresentation", "3.8.poleKernel"], [], false⟩,
  ⟨"3.9.hurwitz", "3.9", .repair, .formalizationDebt, ["2.5.factorization", "3.1.momentRepresentation"], [], false⟩,
  ⟨"3.9.dirichletReal", "3.9", .repair, .formalizationDebt, ["2.5.factorization", "3.1.hyperbolicity"], [], false⟩,
  ⟨"3.9.arithmeticApplicability", "3.9", .openBridge, .mathematicalHole, ["3.9.dirichletReal"], ["DirichletCoefficientRationalization"], true⟩,
  ⟨"3.10.nonclassicality", "3.10", .openBridge, .mathematicalHole, ["3.4", "4.7"], ["VaryingKNonclassicality"], true⟩,
  ⟨"3.10.rootBirth", "3.10", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"3.10.bandwidthEquivalence", "3.10", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"3.10.offBandNonzero", "3.10", .refutedAsWritten, .refutedNoObligation, ["2.5.factorization"], [], false⟩,
  ⟨"3.10.fixedChainObstruction", "3.10", .verifiedOnPaper, .formalizationDebt, ["3.4.rankCorrection"], [], false⟩,
  ⟨"4.1.transfer", "4.1", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"4.1.effectivity", "4.1", .openBridge, .mathematicalHole, [], ["H4_EFFECTIVE_ONSET"], true⟩,
  ⟨"4.2.resultant", "4.2", .verifiedOnPaper, .formalizationDebt, ["4.1.transfer"], [], false⟩,
  ⟨"4.3.disk", "4.3", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"4.4.spectral", "4.4", .repair, .formalizationDebt, ["3.1"], [], false⟩,
  ⟨"4.4.integer_decay", "4.4", .openBridge, .mathematicalHole, [], ["H4_K30_INTEGER_DECAY"], true⟩,
  ⟨"4.4.irrationality", "4.4", .openBridge, .mathematicalHole, ["4.1.transfer", "4.4.integer_decay", "4.4.spectral"], [], false⟩,
  ⟨"4.4.effective", "4.4", .openBridge, .mathematicalHole, ["4.1.effectivity", "4.4.irrationality"], [], false⟩,
  ⟨"4.5.weight", "4.5", .verifiedOnPaper, .formalizationDebt, ["3.1"], [], false⟩,
  ⟨"4.5.rank14", "4.5", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"4.5.arithmetic", "4.5", .openBridge, .mathematicalHole, ["4.5.weight"], ["H4_MIXED_INTEGER_DECAY"], true⟩,
  ⟨"4.5.endpoint", "4.5", .openBridge, .mathematicalHole, ["4.1.effectivity", "4.1.transfer", "4.5.arithmetic", "4.5.weight"], [], false⟩,
  ⟨"4.6.derivative_rate", "4.6", .repair, .formalizationDebt, ["3.1"], [], false⟩,
  ⟨"4.6.det_upper", "4.6", .repair, .formalizationDebt, ["3.1", "4.6.derivative_rate"], [], false⟩,
  ⟨"4.6.det_lower", "4.6", .openBridge, .mathematicalHole, ["4.6.derivative_rate"], ["H4_K30_ARCHIMEDEAN_UPPER"], true⟩,
  ⟨"4.6.height_upper", "4.6", .openBridge, .mathematicalHole, ["4.4.integer_decay", "4.4.spectral", "4.6.det_upper"], [], false⟩,
  ⟨"4.6.lower_height_inference", "4.6", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"4.6.height_lower", "4.6", .openBridge, .mathematicalHole, ["4.6.derivative_rate"], ["H4_NORMALIZATION_RATE_LOWER"], true⟩,
  ⟨"4.7.cluster", "4.7", .openBridge, .mathematicalHole, ["4.4.spectral", "4.6.det_lower"], [], false⟩,
  ⟨"4.7.nearest", "4.7", .openBridge, .mathematicalHole, ["3.1", "4.4.integer_decay", "4.4.spectral", "4.6.det_lower"], [], false⟩,
  ⟨"4.7.straddling", "4.7", .verifiedOnPaper, .formalizationDebt, ["4.4.spectral"], [], false⟩,
  ⟨"4.7.factor_sep", "4.7", .repair, .formalizationDebt, ["4.6.height_upper"], [], false⟩,
  ⟨"4.8.local", "4.8", .openBridge, .mathematicalHole, ["4.4.irrationality"], [], false⟩,
  ⟨"4.8.reversed_gap", "4.8", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"4.8.global", "4.8", .openBridge, .mathematicalHole, [], ["H4_GLOBAL_RATIONAL_ROOT_EXCLUSION"], true⟩,
  ⟨"4.8.degree", "4.8", .verifiedOnPaper, .formalizationDebt, ["4.4.spectral"], [], false⟩,
  ⟨"4.9.direct", "4.9", .openBridge, .mathematicalHole, ["4.4.spectral", "4.6.det_lower"], [], false⟩,
  ⟨"4.9.variational", "4.9", .openBridge, .mathematicalHole, [], ["H4_VARIATIONAL_COMPARISON"], true⟩,
  ⟨"4.9.numeric_lower", "4.9", .openBridge, .mathematicalHole, [], ["H4_VARIATIONAL_NUMERIC_LOWER"], true⟩,
  ⟨"4.9.barrier", "4.9", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"4.10.analogy", "4.10", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"4.10.inference", "4.10", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"4.10.actual_limit", "4.10", .openBridge, .mathematicalHole, [], ["H4_FREE_ENERGY_REGULARITY"], true⟩,
  ⟨"4.11.limit_equality", "4.11", .conjecture, .mathematicalHole, ["4.9.variational"], [], false⟩,
  ⟨"5.1.moments", "5.1", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"5.2.1", "5.2", .verifiedOnPaper, .formalizationDebt, ["5.1.moments"], [], false⟩,
  ⟨"5.2.2", "5.2", .verifiedOnPaper, .formalizationDebt, ["5.1.moments"], [], false⟩,
  ⟨"5.2.3.fixed_degree", "5.2", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"5.2.3.tail_drop", "5.2", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"5.2.3.existence", "5.2", .openBridge, .mathematicalHole, [], ["H5_DEFINITE_SUBSPACES_GROWING_DEGREE"], true⟩,
  ⟨"5.2.tail_certificate", "5.2", .verifiedOnPaper, .formalizationDebt, ["5.2.2"], [], false⟩,
  ⟨"5.3.moments", "5.3", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"5.3.hyperbolicity", "5.3", .verifiedOnPaper, .formalizationDebt, ["5.2.1", "5.3.moments"], [], false⟩,
  ⟨"5.4.cancellation", "5.4", .repair, .formalizationDebt, ["2.2"], [], false⟩,
  ⟨"5.4.printed_proof", "5.4", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"5.5.scope", "5.5", .verifiedOnPaper, .formalizationDebt, ["5.4.cancellation"], [], false⟩,
  ⟨"5.6.1.integral", "5.6", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"5.6.1.endpoints", "5.6", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"5.6.2.expansion", "5.6", .repair, .formalizationDebt, [], [], false⟩,
  ⟨"5.6.2.bound", "5.6", .repair, .formalizationDebt, ["5.6.2.expansion"], [], false⟩,
  ⟨"5.6.3.basis", "5.6", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"5.6.3.gain", "5.6", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"5.6.3.replacement", "5.6", .openBridge, .mathematicalHole, [], ["H5_CLASS_DEPENDENT_POLE_REFINEMENT"], true⟩,
  ⟨"5.7.degree", "5.7", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"5.7.coefficients", "5.7", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"5.7.1.formal", "5.7", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"5.7.2.rank", "5.7", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"5.7.2.printed_bound_mechanism", "5.7", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"5.7.2.corrected", "5.7", .repair, .formalizationDebt, ["5.7.2.rank"], [], false⟩,
  ⟨"5.7.representation", "5.7", .openBridge, .mathematicalHole, [], ["H5_CORRECT_MULTIPOLE_REPRESENTATION"], true⟩,
  ⟨"6.1.fiber", "6.1", .verifiedOnPaper, .formalizationDebt, ["5.1"], [], false⟩,
  ⟨"6.1.divided_difference", "6.1", .verifiedOnPaper, .formalizationDebt, ["5.1"], [], false⟩,
  ⟨"6.1.local_matrix", "6.1", .repair, .formalizationDebt, ["6.1.divided_difference"], [], false⟩,
  ⟨"6.1.all_nonzero_vectors", "6.1", .refutedAsWritten, .refutedNoObligation, ["6.1.local_matrix"], [], false⟩,
  ⟨"6.1.universal_barrier", "6.1", .refutedAsWritten, .refutedNoObligation, ["6.1.local_matrix"], [], false⟩,
  ⟨"6.2.moments", "6.2", .verifiedOnPaper, .formalizationDebt, ["5.1"], [], false⟩,
  ⟨"6.2.functional", "6.2", .verifiedOnPaper, .formalizationDebt, ["6.2.moments"], [], false⟩,
  ⟨"6.3.local_nonvanishing", "6.3", .verifiedOnPaper, .formalizationDebt, ["5.1"], [], false⟩,
  ⟨"6.3.rational_root_restriction", "6.3", .verifiedOnPaper, .formalizationDebt, ["6.3.local_nonvanishing"], [], false⟩,
  ⟨"6.3.dimension", "6.3", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"6.3.positive_cone", "6.3", .refutedAsWritten, .refutedNoObligation, ["6.3.dimension"], [], false⟩,
  ⟨"6.3.absolute_decay", "6.3", .repair, .formalizationDebt, ["6.3.dimension"], [], false⟩,
  ⟨"6.3.new_arithmetic_construction", "6.3", .openBridge, .mathematicalHole, [], ["H.zeta7_compatible_small_forms"], true⟩,
  ⟨"6.4.odd_formal_definition", "6.4", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"6.4.integral", "6.4", .refutedAsWritten, .refutedNoObligation, ["6.4.odd_formal_definition"], [], false⟩,
  ⟨"6.4.positive_operator", "6.4", .refutedAsWritten, .refutedNoObligation, ["6.4.integral"], [], false⟩,
  ⟨"6.4.derivative", "6.4", .verifiedOnPaper, .formalizationDebt, ["6.4.odd_formal_definition"], [], false⟩,
  ⟨"6.4.hyperbolicity", "6.4", .verifiedOnPaper, .formalizationDebt, ["6.4.derivative"], [], false⟩,
  ⟨"6.5.valuation", "6.5", .verifiedOnPaper, .formalizationDebt, ["6.4.odd_formal_definition"], [], false⟩,
  ⟨"6.6.collapse", "6.6", .verifiedOnPaper, .formalizationDebt, ["2.1"], [], false⟩,
  ⟨"6.6.spectral", "6.6", .verifiedOnPaper, .formalizationDebt, ["3.1", "6.6.collapse"], [], false⟩,
  ⟨"6.6.open_cone", "6.6", .repair, .formalizationDebt, ["6.6.spectral"], [], false⟩,
  ⟨"6.6.pullback", "6.6", .verifiedOnPaper, .formalizationDebt, ["2.2", "6.6.collapse"], [], false⟩,
  ⟨"6.6.bounded_rank_argument", "6.6", .refutedAsWritten, .refutedNoObligation, ["6.6.pullback"], [], false⟩,
  ⟨"6.6.multiplier_rate", "6.6", .openBridge, .mathematicalHole, ["6.6.pullback"], ["H.multiweight_multiplier_rate"], true⟩,
  ⟨"6.7.hyperbolicity", "6.7", .verifiedOnPaper, .formalizationDebt, ["5.1"], [], false⟩,
  ⟨"6.7.krein", "6.7", .verifiedOnPaper, .formalizationDebt, ["5.2.2"], [], false⟩,
  ⟨"6.7.independence", "6.7", .refutedAsWritten, .refutedNoObligation, ["6.7.krein"], [], false⟩,
  ⟨"6.7.fixed_dimension", "6.7", .refutedAsWritten, .refutedNoObligation, ["6.7.krein"], [], false⟩,
  ⟨"6.7.definite_subspaces", "6.7", .openBridge, .mathematicalHole, ["6.7.krein"], ["H.multiweight_polynomial_inertia"], true⟩,
  ⟨"6.7.local_nonvanishing", "6.7", .verifiedOnPaper, .formalizationDebt, ["6.7.hyperbolicity"], [], false⟩,
  ⟨"6.8.conditional_deduction", "6.8", .verifiedOnPaper, .formalizationDebt, ["4.5"], [], false⟩,
  ⟨"6.8.unconditional_endpoint", "6.8", .openBridge, .mathematicalHole, ["4.5"], [], false⟩,
  ⟨"6.9.triple_laurent", "6.9", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"6.9.lowest_weight", "6.9", .refutedAsWritten, .refutedNoObligation, ["6.9.triple_laurent"], [], false⟩,
  ⟨"6.9.triple_block", "6.9", .refutedAsWritten, .refutedNoObligation, ["6.9.triple_laurent"], [], false⟩,
  ⟨"6.9.triple_replacement", "6.9", .openBridge, .mathematicalHole, [], ["H.consistent_triple_pole_architecture"], true⟩,
  ⟨"6.9.low_pole_integrality", "6.9", .refutedAsWritten, .refutedNoObligation, ["5.7.1.formal"], [], false⟩,
  ⟨"6.9.formal_double_pole", "6.9", .repair, .formalizationDebt, ["5.7.1.formal"], [], false⟩,
  ⟨"6.10.finite_identity", "6.10", .verifiedOnPaper, .formalizationDebt, ["3.1"], [], false⟩,
  ⟨"6.10.rate_identity", "6.10", .verifiedOnPaper, .formalizationDebt, ["6.10.finite_identity"], [], false⟩,
  ⟨"6.10.equilibrium_limits", "6.10", .openBridge, .mathematicalHole, ["6.10.rate_identity"], ["H.kernel_energy_limits"], true⟩,
  ⟨"6.10.variational_direction", "6.10", .refutedAsWritten, .refutedNoObligation, ["6.10.rate_identity"], [], false⟩,
  ⟨"6.10.replacement_gap", "6.10", .openBridge, .mathematicalHole, ["6.10.equilibrium_limits"], ["H.corrected_family_potential_gap"], true⟩,
  ⟨"6.10.integer_multiple_ratio", "6.10", .refutedAsWritten, .refutedNoObligation, ["6.10.rate_identity"], [], false⟩,
  ⟨"6.10.derivative_growth", "6.10", .verifiedOnPaper, .formalizationDebt, ["5.2.1"], [], false⟩,
  ⟨"6.11.local_count", "6.11", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"6.11.fixed_weight_scaling", "6.11", .repair, .formalizationDebt, ["6.11.local_count"], [], false⟩,
  ⟨"6.11.strict_all_k", "6.11", .refutedAsWritten, .refutedNoObligation, ["6.11.local_count"], [], false⟩,
  ⟨"6.11.exact_multiplier_growth", "6.11", .openBridge, .mathematicalHole, ["6.11.local_count"], ["H.beta_multiplier_active_regimes"], true⟩,
  ⟨"6.11.quotient_algebra", "6.11", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"6.11.beta_moment_parity", "6.11", .refutedAsWritten, .refutedNoObligation, ["6.4.odd_formal_definition"], [], false⟩,
  ⟨"6.12.model", "6.12", .openBridge, .mathematicalHole, ["6.4.odd_formal_definition"], ["H.consistent_integer_square_beta_model"], true⟩,
  ⟨"6.12.sign_flip", "6.12", .verifiedOnPaper, .formalizationDebt, ["3.1"], [], false⟩,
  ⟨"6.12.continuity", "6.12", .repair, .formalizationDebt, ["6.12.sign_flip"], [], false⟩,
  ⟨"6.12.local_units", "6.12", .openBridge, .mathematicalHole, ["6.12.model", "6.12.sign_flip"], ["H.beta_integer_lattice_local_blocks"], true⟩,
  ⟨"6.13.differential_identity", "6.13", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"6.13.series_sign", "6.13", .refutedAsWritten, .refutedNoObligation, ["6.13.differential_identity"], [], false⟩,
  ⟨"6.13.functional_identification", "6.13", .openBridge, .mathematicalHole, ["6.12.model", "6.13.differential_identity"], ["H.central_factorial_beta_identification"], true⟩,
  ⟨"6.13.spectral_implications", "6.13", .repair, .formalizationDebt, ["3.1", "3.7.newton"], [], false⟩,
  ⟨"6.14.scaling", "6.14", .refutedAsWritten, .refutedNoObligation, ["6.4.odd_formal_definition"], [], false⟩,
  ⟨"6.14.odd_prime_units", "6.14", .refutedAsWritten, .refutedNoObligation, [], [], false⟩,
  ⟨"6.14.new_model", "6.14", .openBridge, .mathematicalHole, ["6.12.model"], [], false⟩,
  ⟨"6.14.weight_sign", "6.14", .refutedAsWritten, .refutedNoObligation, ["6.14.new_model"], [], false⟩,
  ⟨"6.14.abstract_comparison", "6.14", .repair, .formalizationDebt, ["4.4", "6.14.new_model"], [], false⟩,
  ⟨"6.15.transcendence", "6.15", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"6.15.effective_measure", "6.15", .repair, .formalizationDebt, ["6.15.transcendence"], [], false⟩,
  ⟨"6.15.moments", "6.15", .verifiedOnPaper, .formalizationDebt, [], [], false⟩,
  ⟨"6.15.rank_one", "6.15", .verifiedOnPaper, .formalizationDebt, ["6.15.moments"], [], false⟩,
  ⟨"6.15.prefactor", "6.15", .refutedAsWritten, .refutedNoObligation, ["6.15.rank_one"], [], false⟩,
  ⟨"6.15.correct_rate", "6.15", .repair, .formalizationDebt, ["6.15.rank_one"], [], false⟩,
  ⟨"6.16.formal_collapse", "6.16", .repair, .formalizationDebt, ["6.12.model"], [], false⟩,
  ⟨"6.16.comparison", "6.16", .repair, .formalizationDebt, ["3.1", "6.16.formal_collapse"], [], false⟩,
  ⟨"6.16.harmonic_valuation", "6.16", .refutedAsWritten, .refutedNoObligation, ["6.16.formal_collapse"], [], false⟩,
  ⟨"6.16.large_prime_bound", "6.16", .repair, .formalizationDebt, ["6.16.harmonic_valuation"], [], false⟩,
  ⟨"6.16.distribution", "6.16", .openBridge, .mathematicalHole, ["6.12.model", "6.16.large_prime_bound"], ["H.mixed_beta_distribution_multiplier"], true⟩,
  ⟨"6.17.moments", "6.17", .verifiedOnPaper, .formalizationDebt, ["5.1", "5.3"], [], false⟩,
  ⟨"6.17.hyperbolicity", "6.17", .verifiedOnPaper, .formalizationDebt, ["6.10.derivative_growth", "6.17.moments"], [], false⟩,
  ⟨"6.17.fixed_dimension", "6.17", .refutedAsWritten, .refutedNoObligation, ["6.17.moments"], [], false⟩,
  ⟨"6.17.inertia", "6.17", .openBridge, .mathematicalHole, ["6.17.moments"], ["H.mixed_polynomial_inertia"], true⟩,
  ⟨"6.17.odd_top_block", "6.17", .verifiedOnPaper, .formalizationDebt, ["6.17.moments", "6.7.local_nonvanishing"], [], false⟩,
  ⟨"6.17.even_top_calculation", "6.17", .refutedAsWritten, .refutedNoObligation, ["6.17.moments"], [], false⟩,
  ⟨"6.17.even_top_replacement", "6.17", .openBridge, .mathematicalHole, ["6.17.moments"], ["H.even_beta_local_nonvanishing"], true⟩,
  ⟨"6.18.quotient_threshold", "6.18", .verifiedOnPaper, .formalizationDebt, ["6.16.formal_collapse"], [], false⟩,
  ⟨"6.18.dyadic_residues", "6.18", .openBridge, .mathematicalHole, ["6.12.model", "6.18.quotient_threshold"], ["H.mixed_beta_dyadic_residues"], true⟩,
  ⟨"6.18.spectral", "6.18", .openBridge, .mathematicalHole, ["3.4.eigenInterlacing", "6.16.comparison"], [], false⟩,
  ⟨"6.18.explicit_degree", "6.18", .verifiedOnPaper, .formalizationDebt, ["6.18.quotient_threshold"], [], false⟩,
  ⟨"6.18.full_multiplier", "6.18", .openBridge, .mathematicalHole, ["6.16.distribution", "6.18.dyadic_residues", "6.18.explicit_degree"], [], false⟩,
  ⟨"6.18.measure", "6.18", .openBridge, .mathematicalHole, ["4.5", "6.6.multiplier_rate"], [], false⟩
]

def namedHoleTags : List String := ["DirichletCoefficientRationalization", "FullFamilyLanczosCyclicity", "H.beta_integer_lattice_local_blocks", "H.beta_multiplier_active_regimes", "H.central_factorial_beta_identification", "H.consistent_integer_square_beta_model", "H.consistent_triple_pole_architecture", "H.corrected_family_potential_gap", "H.even_beta_local_nonvanishing", "H.kernel_energy_limits", "H.mixed_beta_distribution_multiplier", "H.mixed_beta_dyadic_residues", "H.mixed_polynomial_inertia", "H.multiweight_multiplier_rate", "H.multiweight_polynomial_inertia", "H.zeta7_compatible_small_forms", "H4_EFFECTIVE_ONSET", "H4_FREE_ENERGY_REGULARITY", "H4_GLOBAL_RATIONAL_ROOT_EXCLUSION", "H4_K30_ARCHIMEDEAN_UPPER", "H4_K30_INTEGER_DECAY", "H4_MIXED_INTEGER_DECAY", "H4_NORMALIZATION_RATE_LOWER", "H4_VARIATIONAL_COMPARISON", "H4_VARIATIONAL_NUMERIC_LOWER", "H5_CLASS_DEPENDENT_POLE_REFINEMENT", "H5_CORRECT_MULTIPOLE_REPRESENTATION", "H5_DEFINITE_SUBSPACES_GROWING_DEGREE", "ShiftedCoefficientNonvanishing", "VaryingKNonclassicality"]

def expectedNumberedIds : List String := ["2.1", "2.2", "2.3", "2.4", "2.5", "3.1", "3.2", "3.3", "3.4", "3.5", "3.6", "3.7", "3.8", "3.9", "3.10", "4.1", "4.2", "4.3", "4.4", "4.5", "4.6", "4.7", "4.8", "4.9", "4.10", "4.11", "5.1", "5.2", "5.3", "5.4", "5.5", "5.6", "5.7", "6.1", "6.2", "6.3", "6.4", "6.5", "6.6", "6.7", "6.8", "6.9", "6.10", "6.11", "6.12", "6.13", "6.14", "6.15", "6.16", "6.17", "6.18"]

/-- There are exactly 51 numbered items in this manifest. -/
theorem numbered_count : numberedItems.length = 51 := by decide +kernel

/-- The finite ID list agrees with the explicitly enumerated manuscript scope. -/
theorem complete_numbered_coverage : numberedItems.map NumberedItem.id = expectedNumberedIds := by decide +kernel

/-- No numbered item ID is repeated. -/
theorem unique_numbered_ids : (numberedItems.map NumberedItem.id).Nodup := by decide +kernel

/-- The split claim inventory contains every generated subclaim exactly once. -/
theorem subclaim_count : subclaims.length = 198 := by decide +kernel

theorem unique_subclaim_ids : (subclaims.map Subclaim.id).Nodup := by decide +kernel

/-- Counts in numbered entries match their generated subclaim records. -/
theorem subclaim_counts_match : numberedItems.all (fun item =>
    item.subclaimCount == (subclaims.filter (fun s => s.parentId == item.id)).length) = true := by decide +kernel

/-- A refuted entry is never an active named bridge candidate. Metadata only. -/
theorem no_refuted_active_hypothesis : subclaims.all (fun s =>
    if s.status == .refutedAsWritten then !s.activeHypothesis else true) = true := by decide +kernel

/-- Refuted entries are assigned no bridge tags. -/
theorem no_refuted_hole_tags : subclaims.all (fun s =>
    if s.status == .refutedAsWritten then s.holeTags.isEmpty else true) = true := by decide +kernel

/-- Every candidate bridge is classified as a mathematical hole, not formalization debt. -/
theorem active_hypotheses_are_mathematical_holes : subclaims.all (fun s =>
    if s.activeHypothesis then (s.status == .openBridge && s.debt == .mathematicalHole && !s.holeTags.isEmpty) else true) = true := by decide +kernel

/-- Every referenced hole tag is present in the manifest registry. -/
theorem registered_subclaim_hole_tags : subclaims.all (fun s =>
    s.holeTags.all (fun tag => namedHoleTags.contains tag)) = true := by decide +kernel

end ManuscriptChain.Inventory
