import Std

/-!
# Exact finite data for the manuscript

This module computes the rational affine Hankel pencil from Section 2.  A
polynomial is a list of coefficients in ascending order.  No analytic value is
identified with a rational number here.  The analytic realization and the
general correctness bridge from these finite algorithms are separate inputs.
-/

namespace ManuscriptChain.Exact

abbrev Poly := List Rat

structure Affine where
  constant : Rat
  slope : Rat
  deriving DecidableEq, Repr

def Affine.eval (p : Affine) (x : Rat) : Rat := p.constant + p.slope * x

def ratSum (xs : List Rat) : Rat := xs.foldl (· + ·) 0

def factorial : Nat → Nat
  | 0 => 1
  | n + 1 => (n + 1) * factorial n

def binomial (n r : Nat) : Nat :=
  if r ≤ n then factorial n / (factorial r * factorial (n - r)) else 0

/-- The convention is `B₁ = -1/2`. -/
def bernoulliList : Nat → List Rat
  | 0 => [1]
  | n + 1 =>
      let bs := bernoulliList n
      let b := -ratSum ((List.range (n + 1)).map fun r =>
        (binomial (n + 2) r : Rat) * bs[r]!) / (n + 2 : Rat)
      bs ++ [b]

def bernoulli (n : Nat) : Rat := (bernoulliList n)[n]!

def Poly.trim (p : Poly) : Poly := (p.reverse.dropWhile (· == 0)).reverse

def Poly.add : Poly → Poly → Poly
  | [], q => q
  | p, [] => p
  | a :: p, b :: q => (a + b) :: Poly.add p q

def Poly.scale (c : Rat) (p : Poly) : Poly := p.map (c * ·)

def Poly.sub (p q : Poly) : Poly := Poly.add p (Poly.scale (-1) q)

def Poly.mul : Poly → Poly → Poly
  | [], _ => []
  | a :: p, q => Poly.add (Poly.scale a q) (0 :: Poly.mul p q)

def Poly.pow (p : Poly) : Nat → Poly
  | 0 => [1]
  | n + 1 => Poly.mul p (Poly.pow p n)

def Poly.eval (p : Poly) (x : Rat) : Rat := p.foldr (fun a b => a + x * b) 0

def Poly.shift (p : Poly) (n : Nat) : Poly := List.replicate n 0 ++ p

@[simp] theorem Poly.eval_nil (x : Rat) : Poly.eval [] x = 0 := rfl

@[simp] theorem Poly.eval_cons (a : Rat) (p : Poly) (x : Rat) :
    Poly.eval (a :: p) x = a + x * Poly.eval p x := rfl

theorem rat_mul_left_comm (a b c : Rat) : a * (b * c) = b * (a * c) := by
  rw [← Rat.mul_assoc, Rat.mul_comm a b, Rat.mul_assoc]

theorem rat_pow_add (a : Rat) (i j : Nat) : a ^ (i + j) = a ^ i * a ^ j := by
  induction j with
  | zero => simp
  | succ j ih => rw [Nat.add_succ, Rat.pow_succ, ih, Rat.pow_succ, Rat.mul_assoc]

theorem Poly.eval_add (p q : Poly) (x : Rat) :
    (Poly.add p q).eval x = p.eval x + q.eval x := by
  induction p generalizing q with
  | nil => simp [Poly.add, Rat.zero_add]
  | cons a p ih =>
      cases q with
      | nil => simp [Poly.add, Rat.add_zero]
      | cons b q =>
          simp only [Poly.add, Poly.eval_cons, ih, Rat.mul_add]
          simp only [Rat.add_assoc, Rat.add_left_comm]

theorem Poly.eval_scale (c : Rat) (p : Poly) (x : Rat) :
    (Poly.scale c p).eval x = c * p.eval x := by
  induction p with
  | nil => simp [Poly.scale]
  | cons a p ih =>
      change c * a + x * (Poly.scale c p).eval x = c * (a + x * Poly.eval p x)
      rw [ih, Rat.mul_add, rat_mul_left_comm x c]

theorem Poly.eval_sub (p q : Poly) (x : Rat) :
    (Poly.sub p q).eval x = p.eval x - q.eval x := by
  rw [Poly.sub, Poly.eval_add, Poly.eval_scale, Rat.neg_mul, Rat.one_mul,
    Rat.sub_eq_add_neg]

theorem Poly.eval_mul (p q : Poly) (x : Rat) :
    (Poly.mul p q).eval x = p.eval x * q.eval x := by
  induction p with
  | nil => simp [Poly.mul]
  | cons a p ih =>
      rw [Poly.mul, Poly.eval_add, Poly.eval_scale, Poly.eval_cons,
        Rat.zero_add, ih, Poly.eval_cons, Rat.add_mul, Rat.mul_assoc]

theorem Poly.eval_pow (p : Poly) (n : Nat) (x : Rat) :
    (Poly.pow p n).eval x = p.eval x ^ n := by
  induction n with
  | zero => simp [Poly.pow, Rat.add_zero]
  | succ n ih => rw [Poly.pow, Poly.eval_mul, ih, Rat.pow_succ, Rat.mul_comm]

theorem Poly.eval_shift (p : Poly) (n : Nat) (x : Rat) :
    (Poly.shift p n).eval x = x ^ n * p.eval x := by
  induction n with
  | zero => simp [Poly.shift]
  | succ n ih =>
      change Poly.eval (0 :: Poly.shift p n) x = x ^ (n + 1) * p.eval x
      rw [Poly.eval_cons, Rat.zero_add, ih, Rat.pow_succ]
      simp only [Rat.mul_assoc, Rat.mul_comm]

def Affine.toPoly (p : Affine) : Poly := [p.constant, p.slope]

theorem Affine.toPoly_eval (p : Affine) (x : Rat) : p.toPoly.eval x = p.eval x := by
  simp [Affine.toPoly, Affine.eval, Rat.add_zero, Rat.mul_comm]

def determinantTwo (a b c d : Affine) : Poly :=
  Poly.sub (Poly.mul a.toPoly d.toPoly) (Poly.mul b.toPoly c.toPoly)

theorem determinantTwo_eval (a b c d : Affine) (x : Rat) :
    (determinantTwo a b c d).eval x = a.eval x * d.eval x - b.eval x * c.eval x := by
  simp only [determinantTwo, Poly.eval_sub, Poly.eval_mul, Affine.toPoly_eval]

/-- Fuel-bounded long division; callers supply the numerator length as fuel.
The zero-divisor convention returns quotient zero and the original remainder.
The manuscript always uses a nonzero monic tail denominator. -/
def Poly.divModAux : Nat → Poly → Poly → Poly × Poly
  | 0, p, _ => ([], p.trim)
  | fuel + 1, p, q =>
      let p := p.trim
      let q := q.trim
      if q.isEmpty || p.isEmpty || p.length < q.length then ([], p)
      else
        let d := p.length - q.length
        let c := p.getLast! / q.getLast!
        let term := Poly.shift [c] d
        let rem := Poly.sub p (Poly.mul term q)
        let next := Poly.divModAux fuel rem q
        (Poly.add term next.1, next.2)

def Poly.divMod (p q : Poly) : Poly × Poly := Poly.divModAux p.length p q

/-- `D_n(t) = ∏_{j=1}^n (t+j²)`. -/
def D : Nat → Poly
  | 0 => [1]
  | n + 1 => Poly.mul (D n) [((n + 1 : Nat) : Rat)^2, 1]

def tailNodes (N K : Nat) : List Nat :=
  (List.range (K - N)).map (fun a => N + 1 + a)

def tailDenominator (N K : Nat) : Poly :=
  (tailNodes N K).foldl (fun p (a : Nat) => Poly.mul p [(a : Rat)^2, 1]) [1]

def harmonic (s j : Nat) : Rat :=
  ratSum ((List.range j).map fun r => 1 / ((r + 1 : Nat) : Rat)^s)

/-- The rational value of the formal functional on a monomial. -/
def monomialMoment (k e : Nat) : Rat :=
  (-1 : Rat)^e * bernoulli (2 * e + 2) * (factorial (2 * e + 2 * k + 1) : Rat) /
    ((factorial (2 * k) : Rat) * (factorial (2 * e + 2) : Rat))

/-- The affine value on `1/(t+j²)`; the intended domain has `k,j ≥ 1`. -/
def poleMoment (k j : Nat) : Affine where
  constant := -(j : Rat)^(2 * k) * harmonic (2 * k + 1) j +
    1 / (2 * (j : Rat)) - 1 / (2 * (k : Rat))
  slope := (j : Rat)^(2 * k)

def polynomialMoment (k : Nat) (p : Poly) : Rat :=
  ratSum ((List.range p.length).map fun e => p[e]! * monomialMoment k e)

/-- The derivative of the tail denominator at `-a²`, computed as a product. -/
def tailDerivativeAt (N K a : Nat) : Rat :=
  ((tailNodes N K).filter (· != a)).foldl
    (fun r (b : Nat) => r * ((b : Rat)^2 - (a : Rat)^2)) 1

def numerator (m N i j : Nat) : Poly :=
  Poly.shift (Poly.pow (D N) (2 * m - 1)) (i + j)

def residue (m N K i j a : Nat) : Rat :=
  Poly.eval (numerator m N i j) (-(a : Rat)^2) / tailDerivativeAt N K a

/-- Exact `Aᵢⱼ + X Mᵢⱼ`, from the polynomial part and simple tail residues. -/
def hankelEntry (k m N K i j : Nat) : Affine where
  constant := polynomialMoment k ((numerator m N i j).divMod (tailDenominator N K)).1 +
    ratSum ((tailNodes N K).map fun a =>
      residue m N K i j a * (poleMoment k a).constant)
  slope := ratSum ((tailNodes N K).map fun a =>
    residue m N K i j a * (poleMoment k a).slope)

def pencilA (k m N K i j : Nat) : Rat := (hankelEntry k m N K i j).constant
def pencilM (k m N K i j : Nat) : Rat := (hankelEntry k m N K i j).slope

def hankelDetTwo (k m N K : Nat) : Poly :=
  determinantTwo (hankelEntry k m N K 0 0) (hankelEntry k m N K 0 1)
    (hankelEntry k m N K 1 0) (hankelEntry k m N K 1 1)

/-- The exact tail weight in Theorem 2.5. -/
def gamma (k m N K a : Nat) : Rat :=
  (a : Rat)^(2 * k) * (D N).eval (-(a : Rat)^2) ^ (2 * m - 1) /
    tailDerivativeAt N K a

/-- The algebraic Vandermonde factorization, stated entrywise.  This theorem
does not assume positivity, integral representation, or analytic decay. -/
theorem pencilM_eq_vandermonde_sum (k m N K i j : Nat) :
    pencilM k m N K i j = ratSum ((tailNodes N K).map fun (a : Nat) =>
      (-(a : Rat)^2)^i * gamma k m N K a * (-(a : Rat)^2)^j) := by
  unfold pencilM hankelEntry
  apply congrArg ratSum
  apply List.map_congr_left
  intro a _
  simp only [residue, numerator, Poly.eval_shift, Poly.eval_pow, poleMoment, gamma,
    rat_pow_add, Rat.div_def]
  simp only [Rat.mul_assoc, Rat.mul_comm, rat_mul_left_comm]

theorem numerator_symmetric (m N i j : Nat) :
    numerator m N i j = numerator m N j i := by
  simp only [numerator, Nat.add_comm i j]

theorem residue_symmetric (m N K i j a : Nat) :
    residue m N K i j a = residue m N K j i a := by
  simp only [residue, numerator_symmetric m N i j]

theorem hankelEntry_symmetric (k m N K i j : Nat) :
    hankelEntry k m N K i j = hankelEntry k m N K j i := by
  simp only [hankelEntry, numerator_symmetric m N i j, residue_symmetric m N K i j]

/-- `E₀, E₂, ...`, defined by the formal identity `cosh(z) sech(z) = 1`. -/
def eulerEvenList : Nat → List Rat
  | 0 => [1]
  | n + 1 =>
      let es := eulerEvenList n
      let e := -ratSum ((List.range (n + 1)).map fun r =>
        (binomial (2 * (n + 1)) (2 * r) : Rat) * es[r]!)
      es ++ [e]

def eulerEven (n : Nat) : Rat := (eulerEvenList n)[n]!

/-- Equation (6.3), as a formal rational functional only.  No integral identity
is asserted: the manuscript's proposed beta weight has different moments. -/
def betaFourMoment (e : Nat) : Rat :=
  (-1 : Rat)^e * eulerEven e / (4 : Rat)^(e + 1) * (binomial (2 * e + 3) 3 : Rat)

end ManuscriptChain.Exact
