import ManuscriptChain.Exact
import ManuscriptChain.Certificates
import ManuscriptChain.Inventory

/-! Native finite algebra and audit metadata.  This umbrella does not import
Mathlib and does not claim the manuscript's analytic hypotheses. -/
