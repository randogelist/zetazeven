@echo off
setlocal EnableDelayedExpansion
rem Replay cached Mathlib modules directly: no download, Lake, Python, or PowerShell.
cd /d "%~dp0"
if not defined LEAN_EXE set "LEAN_EXE=lean"
if not exist ".build\main\logs" mkdir ".build\main\logs"
"%LEAN_EXE%" --version > ".build\main\logs\version.log" 2>&1
if errorlevel 1 (
  type ".build\main\logs\version.log"
  echo Lean failed. Install Lean 4.33.0 or set LEAN_EXE.
  exit /b 1
)
findstr /C:"version 4.33.0," ".build\main\logs\version.log" >nul
if errorlevel 1 (
  type ".build\main\logs\version.log"
  echo Expected Lean 4.33.0.
  exit /b 1
)
if not defined MATHLIB_DIR set "MATHLIB_DIR=%CD%\.lake\packages\mathlib"
for %%I in ("%MATHLIB_DIR%") do set "MATHLIB_DIR=%%~fI"
if not exist "%MATHLIB_DIR%\.lake\build\lib\lean\Mathlib\NumberTheory\Bernoulli.olean" (
  echo The Mathlib cache is missing. Follow README.md or set MATHLIB_DIR.
  exit /b 1
)
git -C "%MATHLIB_DIR%" rev-parse HEAD > ".build\main\logs\revision.log" 2>&1
if errorlevel 1 (
  type ".build\main\logs\revision.log"
  echo Git could not identify the pinned Mathlib checkout.
  exit /b 1
)
set /p MATHLIB_REVISION=<".build\main\logs\revision.log"
if not "%MATHLIB_REVISION%"=="db584cd6d46c92f209a44c0f1c829460d327499d" (
  echo Unexpected Mathlib revision: %MATHLIB_REVISION%
  exit /b 1
)
set "SAVED_LEAN_PATH=%LEAN_PATH%"
set "LEAN_PATH=%CD%\.build\main;%CD%\.build\native;%MATHLIB_DIR%\.lake\build\lib\lean"
for /d %%D in ("%CD%\.lake\packages\*") do (
  if exist "%%~fD\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;%%~fD\.lake\build\lib\lean"
)
for /d %%D in ("%MATHLIB_DIR%\.lake\packages\*") do (
  if exist "%%~fD\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;%%~fD\.lake\build\lib\lean"
)
if defined SAVED_LEAN_PATH set "LEAN_PATH=%LEAN_PATH%;%SAVED_LEAN_PATH%"
type ".build\main\logs\version.log"
echo Mathlib: %MATHLIB_REVISION%
for %%M in (ITEMS_01_DEFINITIONS ITEMS_02_PENCIL ITEMS_03_SPECTRAL ITEMS_04_TRANSFER ITEMS_05_MAIN_INPUTS ITEMS_06_EXTENSIONS MAIN_CHAIN) do (
  call :compile %%M
  if errorlevel 1 exit /b 1
)
echo MAIN_CHAIN checked; its six named inputs remain hypotheses.
exit /b 0

:compile
"%LEAN_EXE%" -j 1 -o ".build\main\%~1.olean" "%~1.lean" > ".build\main\logs\%~1.log" 2>&1
if errorlevel 1 (
  type ".build\main\logs\%~1.log"
  echo FAILED: %~1
  exit /b 1
)
echo PASS: %~1
type ".build\main\logs\%~1.log"
exit /b 0
