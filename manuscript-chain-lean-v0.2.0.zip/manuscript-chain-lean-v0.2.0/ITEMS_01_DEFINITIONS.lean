import Mathlib.NumberTheory.Bernoulli
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Topology.Algebra.InfiniteSum.Real

/-!
# ITEMS 01 — Section 2.1: constructions

Actual rational moments, residues, Hankel pencil, determinant, and real zeta series.
CONSTRUCTIONS: the definitions below.
HYPOTHESES: `Admissible` states parameter restrictions; no proof is fabricated.
The general analytic realization and quotient/residue correctness remain proof debt.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChain.Real

structure Parameters where
  k : ℕ
  m : ℕ
  N : ℕ
  K : ℕ
  deriving DecidableEq, Repr

def Parameters.h (p : Parameters) : ℕ := p.K - p.N
def Parameters.weight (p : Parameters) : ℕ := 2 * p.k + 1

structure Admissible (p : Parameters) : Prop where
  k_pos : 0 < p.k
  m_pos : 0 < p.m
  N_pos : 0 < p.N
  N_lt_K : p.N < p.K

/-- The usual real zeta series at the positive integer weights used here.
At weights at least two this is the classical zeta value. -/
def zeta (s : ℕ) : ℝ := ∑' n : ℕ, 1 / ((n + 1 : ℕ) : ℝ) ^ s

def harmonic (s n : ℕ) : ℚ :=
  ∑ j ∈ Finset.range n, 1 / ((j + 1 : ℕ) : ℚ) ^ s

def D (n : ℕ) : ℚ[X] :=
  ∏ j ∈ Finset.range n, (X + C (((j + 1 : ℕ) : ℚ) ^ 2))

def tailD (p : Parameters) : ℚ[X] :=
  ∏ a ∈ Finset.Icc (p.N + 1) p.K, (X + C ((a : ℚ) ^ 2))

def numerator (p : Parameters) (i j : ℕ) : ℚ[X] :=
  D p.N ^ (2 * p.m - 1) * X ^ (i + j)

def quotient (p : Parameters) (i j : ℕ) : ℚ[X] :=
  numerator p i j / tailD p

def monomialMoment (k e : ℕ) : ℚ :=
  (-1 : ℚ) ^ e * bernoulli (2 * e + 2) * (Nat.factorial (2 * e + 2 * k + 1) : ℚ) /
    ((Nat.factorial (2 * k) : ℚ) * (Nat.factorial (2 * e + 2) : ℚ))

def polynomialMoment (k : ℕ) (q : ℚ[X]) : ℚ :=
  ∑ e ∈ q.support, q.coeff e * monomialMoment k e

def residue (p : Parameters) (i j a : ℕ) : ℚ :=
  (numerator p i j).eval (-(a : ℚ) ^ 2) /
    (derivative (tailD p)).eval (-(a : ℚ) ^ 2)

def poleConstant (k a : ℕ) : ℚ :=
  -(a : ℚ) ^ (2 * k) * harmonic (2 * k + 1) a +
    1 / (2 * (a : ℚ)) - 1 / (2 * (k : ℚ))

def entryA (p : Parameters) (i j : ℕ) : ℚ :=
  polynomialMoment p.k (quotient p i j) +
    ∑ a ∈ Finset.Icc (p.N + 1) p.K, residue p i j a * poleConstant p.k a

def entryM (p : Parameters) (i j : ℕ) : ℚ :=
  ∑ a ∈ Finset.Icc (p.N + 1) p.K, residue p i j a * (a : ℚ) ^ (2 * p.k)

def pencil (p : Parameters) : Matrix (Fin p.h) (Fin p.h) ℚ[X] :=
  fun i j => C (entryA p i.val j.val) + C (entryM p i.val j.val) * X

def delta (p : Parameters) : ℚ[X] := Matrix.det (pencil p)

def realPolynomial (q : ℚ[X]) : ℝ[X] := q.map (Rat.castHom ℝ)
def evalQ (q : ℚ[X]) (x : ℝ) : ℝ := (realPolynomial q).eval x
def gram (p : Parameters) (x : ℝ) : Matrix (Fin p.h) (Fin p.h) ℝ :=
  fun i j => evalQ (pencil p i j) x
def derivativeMatrix (p : Parameters) : Matrix (Fin p.h) (Fin p.h) ℝ :=
  fun i j => (entryM p i.val j.val : ℝ)


end ManuscriptChain.Real
