"""Generate finite Lean metadata from catalog.json; no mathematical claim is axiomatized."""
import json,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
catalog=HERE/'catalog.json'
d=json.loads(catalog.read_text())
q=lambda s:json.dumps(s,ensure_ascii=False)
lst=lambda ss:'['+', '.join(q(s) for s in ss)+']'
status={'verified-on-paper':'verifiedOnPaper','repair':'repair','open-bridge':'openBridge','refuted-as-written':'refutedAsWritten','conjecture':'conjecture'}
debt={'mathematical-hole':'mathematicalHole','formalization-debt':'formalizationDebt','refuted-no-admissible-proof-obligation':'refutedNoObligation'}
lines=['import Std','','/-!',
'# Finite manuscript inventory — metadata certificates only',
'',
'Generated from catalog.json. The declarations below encode strings and audit tags.',
'The proved theorems certify enumeration and exclusion checks on those finite data.',
'They do not formalize, prove, or assume the mathematical statements in the manuscript.',
'In particular, `activeHypothesis` means a named *candidate* bridge in this manifest;',
'it creates no Lean proposition, axiom, instance, or proof of that bridge.',
'-/','','namespace ManuscriptChain.Inventory','','set_option maxRecDepth 100000','set_option maxHeartbeats 4000000','',
'inductive AuditStatus where',
'  | verifiedOnPaper | repair | openBridge | refutedAsWritten | conjecture',
'  deriving DecidableEq, Repr','',
'inductive DebtClass where',
'  | mathematicalHole | formalizationDebt | refutedNoObligation',
'  deriving DecidableEq, Repr','',
'structure NumberedItem where',
'  id : String',
'  status : AuditStatus',
'  subclaimCount : Nat',
'  sourcePages : List Nat',
'  dependencyIds : List String',
'  holeTags : List String',
'  deriving DecidableEq, Repr','',
'structure Subclaim where',
'  id : String',
'  parentId : String',
'  status : AuditStatus',
'  debt : DebtClass',
'  dependencyIds : List String',
'  holeTags : List String',
'  activeHypothesis : Bool',
'  deriving DecidableEq, Repr','',
'def catalogSha256 : String := '+q(hashlib.sha256(catalog.read_bytes()).hexdigest()),
'def sourceSha256 : String := '+q(d['source']['manuscript']['sha256']),
'def numberedItems : List NumberedItem := [']
for n,c in enumerate(d['claims']):
    lines.append('  ⟨'+', '.join([q(c['id']),'.'+status[c['status']],str(len(c['subclaims'])),str(c['source_pages']),lst(c['dependencies']),lst(c['holes'])])+'⟩'+(',' if n<len(d['claims'])-1 else ''))
lines+= [']','','def subclaims : List Subclaim := [']
subs=[(c,s)for c in d['claims']for s in c['subclaims']]
for n,(c,s) in enumerate(subs):
    active=s['status']=='open-bridge' and bool(s['holes'])
    lines.append('  ⟨'+', '.join([q(s['id']),q(c['id']),'.'+status[s['status']],'.'+debt[s['debt_classification']],lst(s['dependencies']),lst(s['holes']),str(active).lower()])+'⟩'+(',' if n<len(subs)-1 else ''))
lines+= [']','','def namedHoleTags : List String := '+lst([h['id'] for h in d['hole_catalog']]),'','def expectedNumberedIds : List String := '+lst([c['id']for c in d['claims']]),'',
'/-- There are exactly 51 numbered items in this manifest. -/',
'theorem numbered_count : numberedItems.length = 51 := by decide +kernel','',
'/-- The finite ID list agrees with the explicitly enumerated manuscript scope. -/',
'theorem complete_numbered_coverage : numberedItems.map NumberedItem.id = expectedNumberedIds := by decide +kernel','',
'/-- No numbered item ID is repeated. -/',
'theorem unique_numbered_ids : (numberedItems.map NumberedItem.id).Nodup := by decide +kernel','',
'/-- The split claim inventory contains every generated subclaim exactly once. -/',
'theorem subclaim_count : subclaims.length = '+str(len(subs))+' := by decide +kernel','',
'theorem unique_subclaim_ids : (subclaims.map Subclaim.id).Nodup := by decide +kernel','',
'/-- Counts in numbered entries match their generated subclaim records. -/',
'theorem subclaim_counts_match : numberedItems.all (fun item =>',
'    item.subclaimCount == (subclaims.filter (fun s => s.parentId == item.id)).length) = true := by decide +kernel','',
'/-- A refuted entry is never an active named bridge candidate. Metadata only. -/',
'theorem no_refuted_active_hypothesis : subclaims.all (fun s =>',
'    if s.status == .refutedAsWritten then !s.activeHypothesis else true) = true := by decide +kernel','',
'/-- Refuted entries are assigned no bridge tags. -/',
'theorem no_refuted_hole_tags : subclaims.all (fun s =>',
'    if s.status == .refutedAsWritten then s.holeTags.isEmpty else true) = true := by decide +kernel','',
'/-- Every candidate bridge is classified as a mathematical hole, not formalization debt. -/',
'theorem active_hypotheses_are_mathematical_holes : subclaims.all (fun s =>',
'    if s.activeHypothesis then (s.status == .openBridge && s.debt == .mathematicalHole && !s.holeTags.isEmpty) else true) = true := by decide +kernel','',
'/-- Every referenced hole tag is present in the manifest registry. -/',
'theorem registered_subclaim_hole_tags : subclaims.all (fun s =>',
'    s.holeTags.all (fun tag => namedHoleTags.contains tag)) = true := by decide +kernel','',
'end ManuscriptChain.Inventory','']
target=HERE/'ManuscriptChain/Inventory.lean';target.parent.mkdir(exist_ok=True)
target.write_text('\n'.join(lines))
print(target)
