#!/bin/sh
# Native Lean replay: no Lake, network, Mathlib, Python, or package installation.
set -eu

cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ -z "${LEAN_EXE:-}" ]; then
  LEAN_EXE=$(command -v lean || true)
fi
if [ -z "$LEAN_EXE" ]; then
  printf '%s\n' 'Lean was not found. Install Lean 4.33.0 or set LEAN_EXE to its executable.' >&2
  exit 1
fi
if ! lean_version=$("$LEAN_EXE" --version 2>&1); then
  printf '%s\n' "$lean_version" >&2
  exit 1
fi
case "$lean_version" in
  *'version 4.33.0,'*) ;;
  *) printf '%s\n' "Expected Lean 4.33.0; received: $lean_version" >&2; exit 1 ;;
esac

mkdir -p .build/native/ManuscriptChain .build/native/logs
LEAN_PATH="$PWD/.build/native${LEAN_PATH:+:$LEAN_PATH}"
export LEAN_PATH
printf '%s\n' "$lean_version"
for module in Exact Certificates Inventory Audit; do
  log_file=".build/native/logs/$module.log"
  if ! "$LEAN_EXE" -j 1 -o ".build/native/ManuscriptChain/$module.olean" \
      "ManuscriptChain/$module.lean" >"$log_file" 2>&1; then
    cat "$log_file" >&2
    printf '%s\n' "FAILED: $module" >&2
    exit 1
  fi
  printf '%s\n' "PASS: $module"
  cat "$log_file"
done
printf '%s\n' 'Native finite algebra and audit inventory checked successfully.'
printf '%s\n' 'This does not discharge the separate mathematical hypotheses.'
