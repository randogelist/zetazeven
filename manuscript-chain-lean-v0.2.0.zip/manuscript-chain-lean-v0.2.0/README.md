# Manuscript chain — Lean package 0.2.0

**Open `MAIN_CHAIN.lean` first.** It imports the six implementation files in order and states the final conditional theorems, `ManuscriptChain.MAIN_CHAIN` and `ManuscriptChain.MAIN_CHAIN_MEASURE`. The implementation lives directly in the `ITEMS_*.lean` files; this package has no `MathlibChain/` implementation folder.

| File | Contents |
|---|---|
| `ITEMS_01_DEFINITIONS.lean` | Actual real series, rational polynomials, moments, and manuscript parameters. |
| `ITEMS_02_PENCIL.lean` | Symmetric affine pencils and their determinant connection. |
| `ITEMS_03_SPECTRAL.lean` | Spectral factorization consequences: degree, real roots, and root exclusion. |
| `ITEMS_04_TRANSFER.lean` | Proved local comparison, integer denominator clearing, and rational-approximation transfer. |
| `ITEMS_05_MAIN_INPUTS.lean` | The actual `K=30n` family, explicit outstanding inputs, and the connected conditional chain. |
| `ITEMS_06_EXTENSIONS.lean` | Selected finite-tail positivity and normalization implications. |
| `MAIN_CHAIN.lean` | Chronological imports, final proof statements, and axiom reports. |

The optional `ManuscriptChain/` folder contains native rational computations, exact examples, and audit-inventory checks. It is evidence alongside the main chain, not a substitute for its real-number and polynomial semantics.

## The six inputs

The final theorem is conditional. Its six named inputs do not assume irrationality or the final approximation bound.

| Input | What remains to be supplied |
|---|---|
| `MainNormalization` | An exact identity connecting the actual rational determinant to integer polynomials using positive rational multipliers. Generic denominator clearing alone does not give the required multiplier rate. |
| `BaseValuePositive` | Positivity for the exact evaluated family, via its intended integral representation. This is formalization debt for the valid positive-Gram argument. |
| `MultiplierUpper` | The required small-multiplier estimate for the same `K=30n` family, with a valid onset. This is a missing manuscript-specific arithmetic input. |
| `ArchimedeanUpper` | The matching determinant estimate for `K=30n`, with a valid onset. This is a missing manuscript-specific estimate. |
| `MainSpectralData` | Spectral factorization and the explicit bound on its parameters. Existence and the audited spectral estimate still need Lean proofs. |
| `IndexBudget` | A valid index-selection and exponent budget, including the denominator onset. This is a generic analytic proof obligation. |

Local comparison is derived from the spectral data. The multiplier is a positive rational number and may be exponentially small. It is not replaced by a natural-number denominator multiplier. The cited `K=40n` source does not discharge the changed `K=30n` arithmetic inputs.

There is **no unconditional ζ(5) irrationality claim** here. The native list-polynomial algorithms also have no general equivalence theorem connecting them to the Mathlib polynomial definitions; their long-division algorithm has exact example checks but no general correctness proof in this package.

The catalog covers **51 numbered items and 198 subclaims** as audit metadata. It records **30 mathematical holes** and excludes **46 refuted subclaims** from hypothesis candidates. This is not full semantic formalization of all 198 subclaims. The main spectral/Diophantine route and selected extension implications are encoded; remaining branches are represented in the catalog. A refuted assertion is never restored merely by naming it as a hypothesis.

## Build the main chain

Pinned versions: **Lean 4.33.0** and Mathlib commit **`db584cd6d46c92f209a44c0f1c829460d327499d`** (`v4.33.0`). Install Lean/Lake and Git. From this directory, perform the one-time network setup:

```sh
lake update
lake exe cache get
```

Then run the offline, sequential replay:

```sh
./run.sh
```

Windows Command Prompt:

```bat
run.cmd
```

The runner compiles all six `ITEMS` modules and then `MAIN_CHAIN.lean`, stops on any error, and prints the axiom reports. It uses the existing Mathlib cache and makes no network, Lake, Python, or PowerShell calls. Git is used only to verify the pinned Mathlib revision. Objects and logs are written under `.build/main/`.

Set `LEAN_EXE` to select the Lean executable and `MATHLIB_DIR` to select an existing cached checkout of the pinned Mathlib revision. Defaults are `lean` on `PATH` and `.lake/packages/mathlib`. For example:

```sh
LEAN_EXE=/path/to/lean MATHLIB_DIR=/path/to/mathlib ./run.sh
```

The ordinary Lake alternative, after setup, is `lake build MainChain`. The offline runner is the explicit sequential replay and includes the printed audits. The Windows `.cmd` files have not been executed on the Linux verification host.

## Optional native evidence

With Lean 4.33.0 installed, run `./run_native.sh` or `run_native.cmd`. This checks the native finite algebra, exact certificates, inventory, and their axiom reports without Mathlib, Lake, Git, Python, or network access. Logs are written under `.build/native/`.

`catalog.json` and `catalog.schema.json` describe the manuscript audit. Optional metadata validation is `python3 scripts/validate_catalog.py` when the validator is included. It checks counts, references, exclusions, and embedded hashes, not mathematical truth. The catalog's original source paths are provenance, not runtime dependencies.

The source manuscript is the supplied 52-page document dated 21 October 2026. Its SHA-256 is `935767c0cda7468f376cd8eadc374077caf6c8a060351d3bea26ac3f838a9d0c`.

No admitted proofs, custom axioms, or `native_decide` certificates are used. Standard Lean axioms may appear through library dependencies. The six mathematical inputs remain visible theorem parameters; a successful build proves the stated conditional implications without constructing those inputs.
