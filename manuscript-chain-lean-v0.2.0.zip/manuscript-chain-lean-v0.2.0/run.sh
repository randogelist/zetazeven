#!/bin/sh
# Replay cached Mathlib modules directly: no download, Lake, or Python invocation.
set -eu

cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ -z "${LEAN_EXE:-}" ]; then LEAN_EXE=$(command -v lean || true); fi
if [ -z "$LEAN_EXE" ]; then
  printf '%s\n' 'Lean was not found. Install Lean 4.33.0 or set LEAN_EXE.' >&2
  exit 1
fi
if ! lean_version=$("$LEAN_EXE" --version 2>&1); then
  printf '%s\n' "$lean_version" >&2
  exit 1
fi
case "$lean_version" in
  *'version 4.33.0,'*) ;;
  *) printf '%s\n' "Expected Lean 4.33.0; received: $lean_version" >&2; exit 1 ;;
esac

MATHLIB_DIR=${MATHLIB_DIR:-"$PWD/.lake/packages/mathlib"}
if [ ! -f "$MATHLIB_DIR/.lake/build/lib/lean/Mathlib/NumberTheory/Bernoulli.olean" ]; then
  printf '%s\n' 'The Mathlib cache is missing. Follow the README setup, or set MATHLIB_DIR to a cached checkout.' >&2
  exit 1
fi
MATHLIB_DIR=$(CDPATH= cd -- "$MATHLIB_DIR" && pwd)
if ! mathlib_revision=$(git -C "$MATHLIB_DIR" rev-parse HEAD 2>/dev/null); then
  printf '%s\n' 'Git could not identify the Mathlib checkout. Use the pinned checkout described in README.md.' >&2
  exit 1
fi
if [ "$mathlib_revision" != db584cd6d46c92f209a44c0f1c829460d327499d ]; then
  printf '%s\n' "Unexpected Mathlib revision: $mathlib_revision" >&2
  exit 1
fi

mkdir -p .build/main/logs
lean_search_path="$PWD/.build/main:$PWD/.build/native:$MATHLIB_DIR/.lake/build/lib/lean"
for dependency in "$PWD"/.lake/packages/* "$MATHLIB_DIR"/.lake/packages/*; do
  if [ -d "$dependency/.lake/build/lib/lean" ]; then
    lean_search_path="$lean_search_path:$dependency/.lake/build/lib/lean"
  fi
done
LEAN_PATH="$lean_search_path${LEAN_PATH:+:$LEAN_PATH}"
export LEAN_PATH
printf '%s\n' "$lean_version" "Mathlib: $mathlib_revision"
for module in ITEMS_01_DEFINITIONS ITEMS_02_PENCIL ITEMS_03_SPECTRAL ITEMS_04_TRANSFER ITEMS_05_MAIN_INPUTS ITEMS_06_EXTENSIONS MAIN_CHAIN; do
  log_file=".build/main/logs/$module.log"
  if ! "$LEAN_EXE" -j 1 -o ".build/main/$module.olean" \
      "$module.lean" >"$log_file" 2>&1; then
    cat "$log_file" >&2
    printf '%s\n' "FAILED: $module" >&2
    exit 1
  fi
  printf '%s\n' "PASS: $module"
  cat "$log_file"
done
printf '%s\n' 'MAIN_CHAIN checked; its six named inputs remain hypotheses.'
