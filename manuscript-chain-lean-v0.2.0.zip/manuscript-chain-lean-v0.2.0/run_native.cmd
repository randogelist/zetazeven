@echo off
setlocal
rem Native Lean replay: no Lake, network, Mathlib, Python, or PowerShell.
cd /d "%~dp0"
if not defined LEAN_EXE set "LEAN_EXE=lean"
if not exist ".build\native\ManuscriptChain" mkdir ".build\native\ManuscriptChain"
if not exist ".build\native\logs" mkdir ".build\native\logs"
"%LEAN_EXE%" --version > ".build\native\logs\version.log" 2>&1
if errorlevel 1 (
  type ".build\native\logs\version.log"
  echo Lean failed. Install Lean 4.33.0 or set LEAN_EXE to its executable.
  exit /b 1
)
findstr /C:"version 4.33.0," ".build\native\logs\version.log" >nul
if errorlevel 1 (
  type ".build\native\logs\version.log"
  echo Expected Lean 4.33.0.
  exit /b 1
)
type ".build\native\logs\version.log"
if defined LEAN_PATH (
  set "LEAN_PATH=%CD%\.build\native;%LEAN_PATH%"
) else (
  set "LEAN_PATH=%CD%\.build\native"
)
call :compile Exact
if errorlevel 1 exit /b 1
call :compile Certificates
if errorlevel 1 exit /b 1
call :compile Inventory
if errorlevel 1 exit /b 1
call :compile Audit
if errorlevel 1 exit /b 1
echo Native finite algebra and audit inventory checked successfully.
echo This does not discharge the separate mathematical hypotheses.
exit /b 0

:compile
"%LEAN_EXE%" -j 1 -o ".build\native\ManuscriptChain\%~1.olean" "ManuscriptChain\%~1.lean" > ".build\native\logs\%~1.log" 2>&1
if errorlevel 1 (
  type ".build\native\logs\%~1.log"
  echo FAILED: %~1
  exit /b 1
)
echo PASS: %~1
type ".build\native\logs\%~1.log"
exit /b 0
