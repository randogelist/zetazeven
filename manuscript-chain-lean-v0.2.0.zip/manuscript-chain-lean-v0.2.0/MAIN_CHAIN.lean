-- Section 2.1: actual moments, residues, pencil, and target.
import ITEMS_01_DEFINITIONS
-- Section 2: centered pencil and exact Gram/determinant identification.
import ITEMS_02_PENCIL
-- Section 3: spectral certificate, real roots, degree, and exclusion.
import ITEMS_03_SPECTRAL
-- Section 4.1: local comparison, denominator clearing, and transfer.
import ITEMS_04_TRANSFER
-- Section 4.2–4.4: K=30n family, explicit inputs, and proved estimates.
import ITEMS_05_MAIN_INPUTS
-- Sections 5–6: selected extension constructions and corrected interfaces.
import ITEMS_06_EXTENSIONS

/-!
# MAIN_CHAIN

Read the six imports in order. Each item contains the actual definitions,
proofs, or explicit input structures needed at that stage.

The main endpoint uses the actual real ζ(5) series and actual K=30n determinant.
The last import records the later branches; those branches are not extra
premises of the main endpoint. Full chronological audit coverage lives in
catalog.json; only the retained chain and selected extensions are encoded here.

Remaining inputs are displayed below rather than hidden in an aggregate:
  normalization — integer family with its exact rational-polynomial identity;
  positive      — positive-Gram analytic proof debt;
  multiplier    — missing K=30n arithmetic rate;
  archimedean   — missing K=30n archimedean rate;
  spectral      — actual spectral certificate and bound, Lean proof debt;
  index         — generic choice-of-index proof debt, including the onset.

Local comparison, degree 27n, rate combination, and integer squeeze are proved
inside the items. No input assumes irrationality or the final approximation
inequality. Refuted manuscript assertions are not premises.
-/

namespace ManuscriptChain

open MainChain RealTransfer

/-- The main rational-approximation statement, with every input explicit.
The body shows how the chronological components are composed. -/
theorem MAIN_CHAIN_MEASURE
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset)
    {b₀ : ℕ}
    (index : IndexBudget normalization.Q mainSpectralRadius decayBudget
      normalization.onset 25687 b₀) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b → b₀ ≤ b →
      1 / (b : ℝ) ^ 25687 < |Real.zeta 5 - (a : ℝ) / (b : ℝ)| := by
  -- Section 3 spectral data + Section 4 normalization give local comparison.
  have comparison := main_localComparison normalization spectral
  -- The two actual-family rate inputs give nonzero evaluated decay.
  have decay := main_decay normalization positive multiplier archimedean
  -- Section 4.1 chooses an index and applies the integer squeeze.
  exact conditional_measure comparison decay index

/-- The main conditional irrationality statement for the actual ζ(5).
This theorem does not assert that the six required inputs have been proved. -/
theorem MAIN_CHAIN
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset)
    {b₀ : ℕ}
    (index : IndexBudget normalization.Q mainSpectralRadius decayBudget
      normalization.onset 25687 b₀) :
    Irrational (Real.zeta 5) := by
  have measure : RationalMeasure (Real.zeta 5) 25687 b₀ :=
    MAIN_CHAIN_MEASURE normalization positive multiplier archimedean spectral index
  exact measure.irrational

/-- A separate later-branch endpoint: a valid whole-tail bound and finite
certificate prove positivity. It is not a ζ(7) irrationality assertion. -/
theorem MAIN_EXTENSION_POSITIVITY {h K M : ℕ}
    (coefficients : Fin h → Fin (K + 1) → ℚ)
    (tail : Extensions.WeightSevenTailBound coefficients M)
    (certificate : Extensions.FinitePositiveCertificate coefficients M) :
    Extensions.PositiveQForm (Extensions.weightSevenGram coefficients) :=
  Extensions.weight_seven_positive_from_finite_certificate coefficients tail certificate

end ManuscriptChain

-- Show the proof statements with their complete remaining hypotheses.
#check ManuscriptChain.MAIN_CHAIN_MEASURE
#check ManuscriptChain.MAIN_CHAIN
#check ManuscriptChain.MAIN_EXTENSION_POSITIVITY

-- Trust audit: ordinary theorem parameters are not discharged by these lists.
#print axioms ManuscriptChain.MAIN_CHAIN_MEASURE
#print axioms ManuscriptChain.MAIN_CHAIN
#print axioms ManuscriptChain.MAIN_EXTENSION_POSITIVITY
