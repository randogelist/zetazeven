import ITEMS_05_MAIN_INPUTS
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.MeasureTheory.Integral.IntegrableOn
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-!
# ITEMS 06 — Sections 5–6: retained extension constructions and repairs

CONSTRUCTIONS: two-variable pencil, full signed truncation, L² Gram matrix,
and explicitly specified new beta data.
PROOFS: finite certificate + whole-tail bound implies positivity/negativity;
realization forces consistent constant mass; normalization gives integrality.
HYPOTHESES: `WeightSevenTailBound` is analytic proof debt; a suitable new basis
is a mathematical existence input; beta realization concerns fresh consistent
data only. The refuted cone and incompatible printed beta formulas are excluded.
This is selected extension coverage, not a formalization of every Section 5–6 item.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChain.Real

def beta (s : ℕ) : ℝ :=
  ∑' n : ℕ, (-1 : ℝ) ^ n / ((2 * n + 1 : ℕ) : ℝ) ^ s

/-- Exact affine coefficient assembly in the two-variable odd-weight branch.
The off-diagonal subtraction is in ℚ, not truncated subtraction in ℕ. -/
def dualConstant (s r t : ℕ) : ℚ :=
  if r = t then -harmonic s r
  else (harmonic (s - 1) r - harmonic (s - 1) t) /
    ((s - 1 : ℕ) * ((r : ℚ) - (t : ℚ)))

def dualEntry {h K : ℕ} (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ)
    (i j : Fin h) : ℚ[X] :=
  C (∑ r, ∑ t, c i r * c j t * dualConstant s r.val t.val) +
    C (∑ r, c i r * c j r) * X

def dualDelta {h K : ℕ} (s : ℕ) (c : Fin h → Fin (K + 1) → ℚ) : ℚ[X] :=
  Matrix.det (fun i j => dualEntry s c i j)

/-- Formal beta repair candidates must specify fresh data. No false integral
identity from 6.4 or incompatible scale change from 6.14 is assumed here. -/
structure BetaRepairData where
  moment : ℕ → ℚ
  poleConstant : ℕ → ℚ
  poleSlope : ℕ → ℚ
  poleLocation : ℕ → ℚ

end ManuscriptChain.Real

open MeasureTheory Set

namespace ManuscriptChain.Extensions
open ManuscriptChain.Real

/-- The actual quadratic form of a finite real matrix. -/
def qform {h : ℕ} (A : Matrix (Fin h) (Fin h) ℝ) (v : Fin h → ℝ) : ℝ :=
  ∑ i, ∑ j, v i * A i j * v j

def PositiveQForm {h : ℕ} (A : Matrix (Fin h) (Fin h) ℝ) : Prop :=
  ∀ v : Fin h → ℝ, v ≠ 0 → 0 < qform A v

def NegativeQForm {h : ℕ} (A : Matrix (Fin h) (Fin h) ℝ) : Prop :=
  ∀ v : Fin h → ℝ, v ≠ 0 → qform A v < 0

/-- Connect the explicit double-sum convention to Mathlib's matrix predicate. -/
theorem posDef_of_symmetric_positive_qform {h : ℕ}
    (A : Matrix (Fin h) (Fin h) ℝ) (symmetric : A.IsSymm)
    (positive : PositiveQForm A) : A.PosDef := by
  apply Matrix.posDef_iff_dotProduct_mulVec.mpr
  refine ⟨Matrix.isHermitian_iff_isSymm.mpr symmetric, ?_⟩
  intro v hv
  simpa [qform, dotProduct, Matrix.mulVec, Finset.mul_sum, mul_assoc] using positive v hv

theorem qform_sub {h : ℕ} (A B : Matrix (Fin h) (Fin h) ℝ) (v : Fin h → ℝ) :
    qform (A - B) v = qform A v - qform B v := by
  simp [qform, mul_sub, sub_mul, Finset.sum_sub_distrib]

theorem qform_add {h : ℕ} (A B : Matrix (Fin h) (Fin h) ℝ) (v : Fin h → ℝ) :
    qform (A + B) v = qform A v + qform B v := by
  simp [qform, mul_add, add_mul, Finset.sum_add_distrib]

theorem qform_smul {h : ℕ} (a : ℝ) (A : Matrix (Fin h) (Fin h) ℝ)
    (v : Fin h → ℝ) : qform (a • A) v = a * qform A v := by
  unfold qform
  simp only [Matrix.smul_apply, smul_eq_mul]
  calc
    (∑ i, ∑ j, v i * (a * A i j) * v j) =
        ∑ i, ∑ j, a * (v i * A i j * v j) := by
          apply Finset.sum_congr rfl
          intro i _
          apply Finset.sum_congr rfl
          intro j _
          ring
    _ = a * ∑ i, ∑ j, v i * A i j * v j := by
      simp only [Finset.mul_sum]

/-- A finite lower certificate controls the full form once its whole tail is
bounded. No tail terms are discarded. -/
theorem positive_of_tail_certificate {h : ℕ}
    (G H L : Matrix (Fin h) (Fin h) ℝ) (e : ℝ)
    (tail : ∀ v, |qform G v - qform H v| ≤ e * qform L v)
    (certificate : PositiveQForm (H - e • L)) : PositiveQForm G := by
  intro v hv
  have lower := (abs_le.mp (tail v)).1
  have margin := certificate v hv
  rw [qform_sub, qform_smul] at margin
  linarith

/-- The upper certificate gives the corresponding strict negative form. -/
theorem negative_of_tail_certificate {h : ℕ}
    (G H L : Matrix (Fin h) (Fin h) ℝ) (e : ℝ)
    (tail : ∀ v, |qform G v - qform H v| ≤ e * qform L v)
    (certificate : NegativeQForm (H + e • L)) : NegativeQForm G := by
  intro v hv
  have upper := (abs_le.mp (tail v)).2
  have margin := certificate v hv
  rw [qform_add, qform_smul] at margin
  linarith

/-- Exact polynomial logarithmic moment
`∫_0^1 P(x) x^m (-log x)^ν dx`, given by its rational coefficient formula.
Identification with that integral is not asserted by the definition. -/
def integralMom {K : ℕ} (c : Fin (K + 1) → ℚ) (m ν : ℕ) : ℚ :=
  ∑ r, c r * (Nat.factorial ν : ℚ) /
    (((r.val + m + 1 : ℕ) : ℚ) ^ (ν + 1))

/-- Full signed weight-seven truncation through `m=M`, not only its positive
square terms. -/
def weightSevenTruncation {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) :
    Matrix (Fin h) (Fin h) ℚ :=
  fun i j => ∑ m ∈ Finset.range (M + 1), ∑ ν ∈ Finset.range 6,
    (Nat.choose 5 ν : ℚ) / 720 * integralMom (c i) m ν *
      integralMom (c j) m (5 - ν)

/-- Rational `L²(0,1)` Gram matrix of the polynomial coefficient rows. -/
def l2Gram {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) :
    Matrix (Fin h) (Fin h) ℚ :=
  fun i j => ∑ r, ∑ t, c i r * c j t / ((r.val + t.val + 1 : ℕ) : ℚ)

def matrixToReal {h : ℕ} (A : Matrix (Fin h) (Fin h) ℚ) :
    Matrix (Fin h) (Fin h) ℝ := fun i j => (A i j : ℝ)

def tailError (M : ℕ) : ℚ := 13 / (10 * ((2 * M + 1 : ℕ) : ℚ) ^ 5)

/-- The manuscript's actual two-variable rational pencil, evaluated at the
genuine real zeta series. -/
def weightSevenGram {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) :
    Matrix (Fin h) (Fin h) ℝ :=
  fun i j => evalQ (dualEntry 7 c i j) (zeta 7)

/-- Analytic formalization debt: this is the quantitative *whole-tail* estimate
proved on paper in the audit. It is an explicit input, not an axiom. -/
def WeightSevenTailBound {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) : Prop :=
  ∀ v, |qform (weightSevenGram c) v -
    qform (matrixToReal (weightSevenTruncation c M)) v| ≤
      (tailError M : ℝ) * qform (matrixToReal (l2Gram c)) v

def FinitePositiveCertificate {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) : Prop :=
  PositiveQForm (matrixToReal (weightSevenTruncation c M) -
    (tailError M : ℝ) • matrixToReal (l2Gram c))

def FiniteNegativeCertificate {h K : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ) (M : ℕ) : Prop :=
  NegativeQForm (matrixToReal (weightSevenTruncation c M) +
    (tailError M : ℝ) • matrixToReal (l2Gram c))

theorem weight_seven_positive_from_finite_certificate {h K M : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ)
    (tail : WeightSevenTailBound c M)
    (certificate : FinitePositiveCertificate c M) : PositiveQForm (weightSevenGram c) :=
  positive_of_tail_certificate _ _ _ _ tail certificate

theorem weight_seven_negative_from_finite_certificate {h K M : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ)
    (tail : WeightSevenTailBound c M)
    (certificate : FiniteNegativeCertificate c M) : NegativeQForm (weightSevenGram c) :=
  negative_of_tail_certificate _ _ _ _ tail certificate

theorem weight_seven_posDef_from_finite_certificate {h K M : ℕ}
    (c : Fin h → Fin (K + 1) → ℚ)
    (symmetric : (weightSevenGram c).IsSymm)
    (tail : WeightSevenTailBound c M)
    (certificate : FinitePositiveCertificate c M) : (weightSevenGram c).PosDef :=
  posDef_of_symmetric_positive_qform _ symmetric
    (weight_seven_positive_from_finite_certificate c tail certificate)

def IndependentRows {h K : ℕ} (c : Fin h → Fin (K + 1) → ℚ) : Prop :=
  ∀ a : Fin h → ℚ, (∀ r, ∑ i, a i * c i r = 0) → a = 0

/-- Genuine mathematical hole: existence of a new basis with a sufficient
finite certificate. This is not the old claimed explicit cone. -/
def PositiveBasisExistence (h : ℕ) : Prop :=
  ∃ K M : ℕ, ∃ c : Fin h → Fin (K + 1) → ℚ,
    IndependentRows c ∧ FinitePositiveCertificate c M

theorem positive_basis_from_explicit_inputs (h : ℕ)
    (analyticTail : ∀ (K M : ℕ) (c : Fin h → Fin (K + 1) → ℚ),
      WeightSevenTailBound c M)
    (existence : PositiveBasisExistence h) :
    ∃ K : ℕ, ∃ c : Fin h → Fin (K + 1) → ℚ,
      IndependentRows c ∧ PositiveQForm (weightSevenGram c) := by
  obtain ⟨K, M, c, independent, certificate⟩ := existence
  exact ⟨K, c, independent,
    weight_seven_positive_from_finite_certificate c (analyticTail K M c) certificate⟩

/-- A possible analytic realization of newly specified beta data. This record
contains raw integral equalities, not a proof that such data/weight exist. -/
structure BetaCandidateRealization (d : BetaRepairData) (target : ℝ)
    (w : ℝ → ℝ) : Prop where
  poles_negative : ∀ j, d.poleLocation j < 0
  monomial_integrable : ∀ e, IntegrableOn (fun y : ℝ => y ^ (2 * e) * w y) (Ioi 0)
  monomial_eq : ∀ e, (∫ y in Ioi (0 : ℝ), y ^ (2 * e) * w y) = (d.moment e : ℝ)
  pole_integrable : ∀ j, IntegrableOn
    (fun y : ℝ => w y / (y ^ 2 - (d.poleLocation j : ℝ))) (Ioi 0)
  pole_eq : ∀ j, (∫ y in Ioi (0 : ℝ), w y / (y ^ 2 - (d.poleLocation j : ℝ))) =
    (d.poleConstant j : ℝ) + (d.poleSlope j : ℝ) * target

/-- A real normalization consistency condition forced by any realization. -/
theorem beta_constant_mass {d : BetaRepairData} {target : ℝ} {w : ℝ → ℝ}
    (realization : BetaCandidateRealization d target w) :
    (∫ y in Ioi (0 : ℝ), w y) = (d.moment 0 : ℝ) := by
  simpa using realization.monomial_eq 0

theorem beta_same_weight_same_constant {d₁ d₂ : BetaRepairData}
    {target₁ target₂ : ℝ} {w : ℝ → ℝ}
    (r₁ : BetaCandidateRealization d₁ target₁ w)
    (r₂ : BetaCandidateRealization d₂ target₂ w) :
    (d₁.moment 0 : ℝ) = (d₂.moment 0 : ℝ) := by
  rw [← beta_constant_mass r₁, ← beta_constant_mass r₂]

/-- Concrete denominator-clearing data. Existence, size, and primitive content
are separate arithmetic obligations; the definition supplies no rate bound. -/
structure IntegerNormalization (q : ℚ[X]) where
  multiplier : ℕ
  multiplier_pos : 0 < multiplier
  integerPolynomial : ℤ[X]
  identity : integerPolynomial.map (Int.castRingHom ℚ) = C (multiplier : ℚ) * q

theorem normalization_coeff {q : ℚ[X]} (w : IntegerNormalization q) (n : ℕ) :
    (w.integerPolynomial.coeff n : ℚ) = (w.multiplier : ℚ) * q.coeff n := by
  have h := congrArg (fun p : ℚ[X] => p.coeff n) w.identity
  simpa using h

/-- Arithmetic witness for the actual rational dual determinant, rather than
an arbitrary unnamed polynomial surrogate. -/
abbrev DualIntegerNormalization {h K : ℕ} (s : ℕ)
    (c : Fin h → Fin (K + 1) → ℚ) := IntegerNormalization (dualDelta s c)

end ManuscriptChain.Extensions
