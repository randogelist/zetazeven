# Read MAIN_CHAIN, then its numbered items

`MAIN_CHAIN.lean` imports the six implementation files in the paper's order
and states the final measure and irrationality theorems with every input
visible. The source itself contains the proof composition.

| File | Paper position | Contents |
| --- | --- | --- |
| `ITEMS_01_DEFINITIONS.lean` | Section 2.1 | Actual parameters, moments, residues, rational pencil, determinant, real zeta series. |
| `ITEMS_02_PENCIL.lean` | Section 2 foundation | Centered real pencil, symmetry, exact determinant identification, positivity-to-nonvanishing. Selected foundation, not every Section 2 statement. |
| `ITEMS_03_SPECTRAL.lean` | Section 3 | Explicit factorization input; proved full degree, complex-root reality, root location and exclusion. |
| `ITEMS_04_TRANSFER.lean` | Section 4.1 | Integer squeeze, generic transfer, proved local comparison; explicit index-budget input. |
| `ITEMS_05_MAIN_INPUTS.lean` | Section 4.2–4.4 | Actual K=30n family, normalization and rate hypotheses, proved degree 27n, normalization transport, decay and comparison. |
| `ITEMS_06_EXTENSIONS.lean` | Sections 5–6 | Selected dual-form constructions, finite-tail certificates and fresh beta realization interfaces. |

The final main route is:

1. Actual pencil plus spectral certificate gives root/product control.
2. Exact normalization transfers that control to the integer polynomial.
3. The two explicit rate estimates and positivity give nonzero evaluated decay.
4. The index budget selects a suitable polynomial for each large denominator.
5. Integer denominator clearing gives the approximation inequality.
6. The inequality excludes every rational representation of the real ζ(5) series.

The six endpoint inputs are `MainNormalization`, `BaseValuePositive`,
`MultiplierUpper`, `ArchimedeanUpper`, `MainSpectralData`, and `IndexBudget`.
Their mathematical meaning and proof status are in `HYPOTHESES.md` and
in the relevant Lean declarations. Local comparison is proved, not an additional
final input. An effective numerical threshold has not been supplied.

These are actual implementation files, not wrappers around the previous
layout. The mathematical definitions and retained proof bodies have been moved
without strengthening the assumptions. The final public names are now
`ManuscriptChain.MAIN_CHAIN_MEASURE`, `ManuscriptChain.MAIN_CHAIN`, and
`ManuscriptChain.MAIN_EXTENSION_POSITIVITY`.

The separate `ManuscriptChain/` folder retains the optional native arithmetic
examples and catalog metadata checks. Its list-polynomial representation has
not been identified with the semantic Mathlib representation. The catalog
covers all 51 numbered items; that does not mean all 51 statements have Lean
proofs or semantic encodings.

`#print axioms` checks kernel constants, not the existence of theorem inputs.
Read the displayed theorem types together with those axiom reports.
