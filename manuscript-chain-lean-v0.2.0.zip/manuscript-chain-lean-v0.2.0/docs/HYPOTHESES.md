# Mathematical holes and formalization debt

This is a work register, not a list of assumed truths. A hole in the mathematical manuscript and a missing Lean proof of a valid mathematical step are different tasks. Refuted printed assertions are excluded from the active assumptions. Their corrections and counterexamples remain in `catalog.json` and the audit.

## Inputs to the implemented main chain

| Input | Meaning | Status |
| --- | --- | --- |
| `MainNormalization` | Integer polynomial family tied exactly to the manuscript’s rational determinant by a positive rational multiplier, with onset at least 1. | Concrete arithmetic witness. Clearing some denominator is elementary; obtaining this witness together with the stated small multiplier rate is the substantive task. |
| `BaseValuePositive` | The actual scaled determinant at the actual real ζ(5) series is positive. | Valid on-paper positive-integral argument; Lean formalization debt. |
| `MultiplierUpper` | The multiplier is at most `exp((-2.32425 + 0.00001) K²)` for the supplied onset. | Actual K=30n arithmetic estimate is a mathematical hole. |
| `ArchimedeanUpper` | The actual scaled determinant is at most `exp((2.32380 + 0.00001) K²)`. | Actual K=30n archimedean estimate is a mathematical hole. |
| Spectral certificate and quantitative bound | A real factorization of the actual full pencil, with nonzero spectral parameters and their exponential bound. | The corrected on-paper spectral route exists; constructing its Lean certificates is formalization debt. No simplicity or full degree of principal minors is assumed. |
| `IndexBudget` | For every large denominator b, choose an index satisfying both the local-radius condition and `2 b^degree budget < 1`. | Generic analytic choice-of-index formalization debt. A concrete computable onset is separately needed for a numerical effective threshold. |

Theorems derive normalization transport, local comparison, combined decay, integer squeeze, the conditional rational-approximation inequality, and irrationality. None of these interfaces assumes irrationality or the final approximation inequality. The package does not construct all input records.

## Extension interfaces

`WeightSevenTailBound` records the rigorous whole-tail analytic estimate; its Lean proof remains debt. `FinitePositiveCertificate` is a finite matrix inequality whose verification implies positivity of the full form. `PositiveBasisExistence` is the separate mathematical task of finding a suitable new basis. `BetaCandidateRealization` concerns explicitly supplied replacement data and actual integrals; it asserts no existence and never imports the incompatible printed beta formulas. `DualIntegerNormalization` records exact coefficient integrality without claiming a decay rate.

## Complete mathematical-hole register

The following 30 entries are the chronological audit’s mathematical work items. They are not all semantic Lean structures in this version. Optional branches do not become assumptions of the main ζ(5) theorem merely by appearing in this register.

| Hole ID | Required mathematical work |
| --- | --- |
| `DirichletCoefficientRationalization` | For a precisely specified Dirichlet family, express needed moments rationally and affinely in the target L(s,chi), with denominator control. |
| `FullFamilyLanczosCyclicity` | For each intended parameter tuple, e_h is cyclic for the Cholesky-conjugated full derivative matrix. |
| `H.beta_integer_lattice_local_blocks` | For the replacement integer-square beta functional, prove the local diagonal-block valuation theorem including polynomial moments and all congruence/unit hypotheses. |
| `H.beta_multiplier_active_regimes` | For a consistently defined beta family, identify the actual integer multiplier, prove all clipping regimes and prime sums, and track k,M,K uniformity before asserting an exact or strict growth law. |
| `H.central_factorial_beta_identification` | For a consistent beta model, compute all substitution signs and constants and show exactly which real or rational coefficient pencil is represented by the positive central-factorial weight. |
| `H.consistent_integer_square_beta_model` | Specify a replacement beta functional on every required integer-square pole, with one consistent normalization, actual rational moments/residues, and a proved analytic representation. All downstream formulas must be re-derived for this replacement; none of the refuted 6.4 or 6.14 identities is assumed. |
| `H.consistent_triple_pole_architecture` | Define a new explicit triple-pole kernel and rational polynomial functional; prove that its residue coefficient vectors match any assumed constant relation and that all local poles are covered by a nonvanishing determinant argument. |
| `H.corrected_family_potential_gap` | For an explicitly specified positive-mass perturbation family, control the new equilibrium and prove a correctly directed strict potential-gap estimate. |
| `H.even_beta_local_nonvanishing` | For a specified even-top-weight mixed pencil, produce a corrected basis or local block analysis proving nonzero determinant under explicit congruence and degree hypotheses; do not assume the refuted valuation -2rh. |
| `H.kernel_energy_limits` | For a specified kernel family, prove regularity/scaling hypotheses, existence of both determinant logarithmic limits, and their normalized weighted-energy representations. |
| `H.mixed_beta_distribution_multiplier` | For the consistent mixed zeta-beta model, establish full local matrix/minor cancellation, small-prime bounds, and an integer multiplier with the asserted quadratic rate. |
| `H.mixed_beta_dyadic_residues` | For the replacement mixed model, prove a uniform dyadic denominator bound for the complete quotient-free pole contribution, including partial-fraction residues and all correction terms. |
| `H.mixed_polynomial_inertia` | For every specified admissible mixed tuple and h, construct sufficiently high-degree positive and negative h-dimensional polynomial subspaces, controlling the entire infinite form. |
| `H.multiweight_multiplier_rate` | For the explicitly specified coupled odd-zeta family, construct an integer multiplier and prove its claimed quadratic logarithmic rate, with all primes and content accounted for. |
| `H.multiweight_polynomial_inertia` | For every h and specified nonzero tuple a, prove that some sufficiently large polynomial degree contains positive and negative h-dimensional subspaces for the full infinite form, with no discarded tail. |
| `H.zeta7_compatible_small_forms` | Construct a specified rational or integer coefficient family with proved nonvanishing, quantitative primitive coefficient bounds, and sufficiently small nonzero evaluated determinants. |
| `H4_EFFECTIVE_ONSET` | Supply computable constants and an explicit computable onset K0 for the spectral and integer-decay inequalities used in the transfer theorem. |
| `H4_FREE_ENERGY_REGULARITY` | For the actual family prove existence and neighborhood regularity of the normalized free-energy limit and the proposed one-sided derivative behavior. |
| `H4_GLOBAL_RATIONAL_ROOT_EXCLUSION` | For the specific primitive determinant family, prove the global rational-root exclusion by an independent factorization or arithmetic argument; do not assume all roots are close to zeta(5). |
| `H4_K30_ARCHIMEDEAN_UPPER` | For the actual K=30n,N=3n normalized analytic determinant F_K, prove limsup K^-2 log F_K(zeta(5))<=2.32380; the cited K=40n result does not supply this. |
| `H4_K30_INTEGER_DECAY` | For K=30n,N=3n,h=27n, construct the exact integer polynomial Q_K from the manuscript determinant and prove 0<\|Q_K(zeta(5))\|<=exp(-0.0004 K^2) eventually, with the multiplier coefficient integrality and compatible arithmetic/archimedean estimates. |
| `H4_MIXED_INTEGER_DECAY` | For each fixed admissible integer pair a,b, prove integer normalization and positive quadratic decay for the actual mixed-weight family using a valid valuation argument, without the false rank<=14 shortcut. |
| `H4_NORMALIZATION_RATE_LOWER` | Prove a lower bound or a certified two-sided evaluation for the actual K=30n arithmetic normalization rate A_M sufficient for A_M+C_*+C_M>0.23. |
| `H4_VARIATIONAL_COMPARISON` | For a precisely defined admissible logarithmic-potential class, prove limsup K^-1 log\|\|B_K\|\|<=rho_var and the stated upper bound on rho_var. |
| `H4_VARIATIONAL_NUMERIC_LOWER` | Define the equilibrium constants and rigorously certify the asserted lower bound on rho_var for the admissible measure class. |
| `H5_CLASS_DEPENDENT_POLE_REFINEMENT` | Derive valid class-dependent local valuation improvements and rigorously aggregate them; no uniform +6 or 1/3 gain is prescribed. |
| `H5_CORRECT_MULTIPOLE_REPRESENTATION` | Construct and prove a corrected rational-function/functional identity whose true Laurent coefficient vectors give the required simultaneous-zeta linear forms, then recheck its local arithmetic estimates. |
| `H5_DEFINITE_SUBSPACES_GROWING_DEGREE` | For each h prove existence of a sufficiently large K and rational polynomial subspaces of dimension h on which the full Beukers form is respectively positive and negative definite. |
| `ShiftedCoefficientNonvanishing` | All intermediate shifted coefficients e_m are nonzero for every intended manuscript parameter tuple. This is unnecessary for strict Newton inequalities. |
| `VaryingKNonclassicality` | Prove the varying-K primitive family's nonclassicality by a valid invariant of that same family, rather than a distinct fixed-K principal chain. |

## Replacing an input with a proof

1. Keep the exact object definitions and parameter family fixed.
2. Prove the fields of the relevant input record in a new module.
3. Pass the resulting record into the existing endpoint theorem.
4. Run both replay scripts and the axiom audit.
5. Update the documented boundary. Do not delete a parameter until the replacement proof compiles.

A proposed correction that changes the object family needs its own definition and transport theorem. A proved counterexample is a reason to replace a statement, not to add it as a hypothesis.
