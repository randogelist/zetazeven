---
title: "Chronological manuscript audit"
subtitle: "Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values"
date: "23 October 2026"
lang: en-GB
---

# Scope and reading guide

This audit concerns the supplied **52-page manuscript dated 21 October 2026**, by Prince Anand, uploaded as `Zetahyperbolic (3)(2).pdf`. It does not purport to audit an unseen repository revision. Source SHA-256:

`935767c0cda7468f376cd8eadc374077caf6c8a060351d3bea26ac3f838a9d0c`

The manuscript was assessed on its own objectives: spectral identities, rational and integer polynomial constructions, Diophantine transfer, and structural obstructions. A failure to prove the irrationality of zeta(7) is **not** counted as a defect. The earlier Lean package was a separate formalization of related constructions; it does not certify this paper. No further Lean work was performed for this audit.

The review used two section-by-section passes (proof reconstruction, then adversarial testing), followed by a cross-check of proposed corrections and dependencies. All **51 numbered items** from 2.1 through 6.18, together with the introduction and discussion, are covered below. Relevant ambiguous formulas were checked against rendered PDF pages. The recent external arithmetic source used in Section 4 was retrieved and compared with the parameter family in this manuscript. Exact rational checks supplement the mathematical arguments; they are not substitutes for proofs of universal statements.

**Classification.** “Correct” means the stated argument has been checked on paper, or the stated conditional consequence follows after explicitly identified inputs. “Repairable” includes a supplied correction and an explanation of what it restores. “False as stated” means a counterexample or exact contradiction prevents retaining that statement unchanged. “Gap / unresolved” means the supplied proof does not establish the claim. A gap is not a proof that the claim is false. No general claim that a research direction is mathematically irreparable is made. This is a comprehensive audit of the supplied text, not a guarantee that no further error exists.

# Principal findings, in manuscript order

1. **Introduction:** the claimed linear-form transfer with only upper bounds is false. A Liouville number satisfies those hypotheses via Dirichlet approximation. Add adjacent nonvanishing or appropriate two-sided error bounds.
2. **Section 2:** the functional definitions, pullback, basis invariance, and pole diagonalization survive. Lemma 2.3 has proof errors that admit short explicit replacements. The pole signs give a useful exact parity-dependent inertia formula.
3. **Section 3:** the basic hyperbolicity theorem survives. The continuous extension has a normalization error. Principal-minor degrees can drop systematically; in the principal weight-five family the first 6n−1 determinants are constant. Corollary 3.5's continued fraction is false as written. Corollary 3.6 requires sign, finite-rank, and inequality corrections. The Newton and Christoffel–Darboux arguments largely survive. The non-classicality claim is not established.
4. **Section 4:** the qualitative spectral transfer is valid with an effectiveness qualification. The spectral constant 11.411 can be retained and improved to 11.407 after correcting the calculation. The claimed decay input for K=30n is not supplied by the cited K=40n source. A rank-14 perturbation assertion is contradicted by an exact rank-27 example. Height and rational-root arguments contain reversed inequalities. Consequently the advertised measure and related unconditional arithmetic conclusions are not established by this manuscript as it stands.
5. **Section 5:** the two-variable moments and real-rooted pencils survive, and the signed expansion admits a rigorous finite-tail certificate. The definite-subspace proof omits its tail. The outer scalar integral is correct, and the inner scalar bound can be strengthened after a coefficient correction. The uniform pole-ordering gain is false. The double-pole rational function has different Laurent coefficients from those printed; some formal-functional valuation results can nevertheless be retained separately.
6. **Section 6.1–6.10:** several local nonvanishing and matrix identities survive. The universal interpretation of the local weight-seven barrier is too strong. The explicit positive cone fails already at h=4. The beta functional and its asserted integral weight disagree. Multi-weight arithmetic arguments require more than a count of exceptional moments. The potential perturbation inequality is reversed, while the raw derivative-determinant estimate is valid under its coefficient-height hypothesis.
7. **Section 6.11–6.18:** polynomial-division identities and the central-factorial differential identity contain useful valid content. They are combined with inconsistent beta normalizations and undefined changes of pole lattice. The odd-beta rank-one construction survives, with a corrected exterior asymptotic. A q=41 exact modular calculation invalidates the proposed even-beta leading-block valuation calculation. The final dyadic/arithmetic claims inherit earlier unresolved inputs.

# What can be retained and strengthened

These are mathematical components worth preserving after the indicated corrections; no novelty claim is implied.

- The rational functional, pullback, exact same-basis invariance of the primitive determinant, and Vandermonde diagonalization. Strengthen the reflection/difference discussion using the formal generating function and Laurent coefficient formulation.
- The full-pencil hyperbolicity theorem, exact degree, target exclusion, and parity-dependent root counts. Add an explicit degree/rank formula for principal minors instead of assuming their degrees.
- Corrected finite resolvents and finite-support moment sequences; signed-coefficient Newton inequalities; the Christoffel–Darboux pole representation and strict monotonicity under the indicated weight deformation.
- The abstract zero-free-disk transfer, with effective thresholds made hypotheses. The algebraic transfer admits a sharper exponent as detailed in Section 4's audit.
- The exact two-variable moment identities, positive derivative matrix, and real-rootedness, independently of whether the target evaluation is definite.
- A finite rational certificate controlling the missing tail: for the weight-seven form and full truncation H_M, positivity follows from H_M−[13/(10(2M+1)^5)]L being positive definite, where L is the L2 Gram matrix.
- The correct scalar prime-sum integral and an improved corrected scalar tail bound. Retain these separately from the disproved uniform arithmetic gain.
- Several local nonvanishing results for the explicitly defined formal pencils, often for every integral evaluation without assuming any relation among constants.
- The central-factorial differential identity with the corrected mode sign, and the odd-beta positive moment/rank-one pencil with its corrected geometric asymptotic.
- Quotient-free degree thresholds and the raw integer Gram-determinant bound, with their scope kept separate from primitive arithmetic height.

# Revision order and dependency boundaries

First freeze the domains, pole lattices, normalization constants, and parameter families. Then repair the local identities and retain only conclusions whose dependencies have been rechecked. In particular:

| Input requiring repair or a new proof | Later claims affected |
|---|---|
| Principal-minor degree/interlacing formulation (3.4) | 3.5, 3.6, 3.10, and later principal-minor claims |
| Parameter-specific integer decay input (Section 4 setup) | Arithmetic conclusion of 4.4, then 4.5, 4.8, 6.8, 6.18(3) |
| Multi-weight local perturbation argument (4.5 / 6.6) | Claimed shared arithmetic multiplier and linear-independence cones |
| Infinite-tail/quantifier gap (5.2(3)) and false cone (6.3(2)) | Definite-subspace constructions in 6.7 and 6.17; proposed cone-based routes |
| False uniform pole-ordering gain (5.6(3)) | Any prime-sum exponent using the advertised universal 1/3 saving |
| Incorrect Laurent coefficients (5.7 / 6.9) | Claimed rational-function origins and simultaneous-value interpretations; formal definitions must be separated |
| Beta moment/integral mismatch (6.4) and scaling/lattice change (6.14) | Analytic positivity and coupled beta conclusions in 6.11–6.14, 6.16, 6.18 |
| Height inequality and potential perturbation gaps (4.6 / 6.10(1)) | Claimed universal height barriers and several discussion claims |

The detailed audit below is chronological. It gives exact counterexamples where available, explicit replacements where justified, and distinguishes statements needing a new proof from those refuted outright. The companion check archive contains the reproducible arithmetic certificates and a record of their scope.

\newpage


# Introduction and Section 2: algebraic foundation

Source: `upload/Zetahyperbolic (3)(2).pdf`, 52 pages, dated 21 October 2026. This audit covers the abstract and introduction on pp. 1–3, and Section 2 on pp. 3–7. Page numbers below are the printed page numbers, which agree with PDF page indices. It does not certify the later theorems merely because the introduction announces them.

Two passes were completed. The first reconstructed the algebra, domains, changes of basis, and constants. The second tested boundary cases, exceptional Bernoulli indices, pole shifts, sign parities, and the introduction's claimed transfer principle. Rendered pages 4–6 and enlarged crops of pp. 1 and 4 were checked to resolve signs and denominators. The calculations below are mathematical checks, not Lean certification. An independent standard-library Python script supplies exact rational regression checks; finite checks supplement, rather than replace, the general proofs given here.

## Coverage and principal verdicts

| Item | Pages | Classification | Verdict |
|---|---:|---|---|
| Abstract and introductory previews | 1–3 | Mixed: wording repair; later claims remain dependencies | Do not treat previews as established until the corresponding later arguments pass. “Symmetrically” must not mean equal root distances from ζ(s). |
| Introductory linear-form implication | 1–2 | **False as stated; explicit counterexample** | Exponential upper bounds for linear forms and their coefficients alone do not imply a finite irrationality measure. A Liouville number meets these hypotheses by Dirichlet approximation. |
| Setup and equation (2.1) | 3 | **Correct, checked on paper** | Parameters, products, harmonic numbers, and Bernoulli convention are consistent. |
| Definition 2.1; equations (2.2), (2.3) | 3–4 | **Correct, checked on paper** | A unique Q-linear, affine-in-X functional is defined by the partial-fraction basis. |
| Lemma 2.2; equations (2.4), (2.5) | 4 | **Correct, checked on paper** | Both the monomial and simple-pole pullback calculations are correct, including the constant −1/(2k). |
| Lemma 2.3(1); equation (2.6) | 5 | **Repairable proof; statement is correct** | The polynomial part of the printed proof contains false intermediate identities. A short formal generating-function proof repairs it without changing the lemma. |
| Lemma 2.3(2); equation (2.7) | 5 | **Repairable proof/explanation; stated formula is correct** | There is a derivative-sign error for negative poles and a false domain explanation. The statement can be strengthened to include r=1. |
| Hankel and primitive definitions; (2.8), (2.9) | 5 | **Correct with a forward nonvanishing dependency** | All entries belong to the functional's domain. Nonzero determinant, required in (2.9), follows algebraically from Theorem 2.5; move or explicitly anticipate that observation. |
| Theorem 2.4 | 6 | **Correct, checked on paper** | Rational basis changes preserve the primitive determinant up to sign. For the same basis on both sides, preservation is exact. |
| Commentary following Theorem 2.4 | 6 | **Repairable scope qualification** | The theorem concerns bases of one fixed Q-polynomial space; it does not authorize arbitrary rational-function or X-dependent basis substitutions. |
| Theorem 2.5(1), (2); equations (2.10), (2.11), derivative factorization | 6–7 | **Correct, checked on paper** | The Vandermonde orientation, residues, cancellation, and nonzero weights check. A useful strengthening is sgn γ_a = (−1)^(a−1). |

There are exactly five numbered Definition/Lemma/Theorem items in Section 2: Definition 2.1, Lemmas 2.2 and 2.3, and Theorems 2.4 and 2.5. All are covered. Every numbered equation (2.1)–(2.11) is covered. None of the five result statements has been disproved. The substantive counterexample in this scope is to the introduction's unnumbered linear-form implication, while Lemma 2.3 has genuine but repairable proof defects.

## 1. Abstract and introduction, in manuscript order

### 1.1 Historical claims and primary-reference dependencies, p. 1

The classical Apéry/Beukers/Ball–Rivoal/Zudilin history is background rather than a proof supplied by this manuscript. It should remain attributed to the cited sources. I did not reconstruct those classical proofs in this audit.

The particularly recent references were checked against their primary repository pages on 23 October 2026. They are not nonexistent or automatically refuted by older statements about the status of ζ(5):

- Brown–Zudilin, arXiv:2210.03391v3, dated 29 January 2026, explicitly states an effective infinite sequence with `0 < |ζ(5) − p/q| < q^(-0.86)`. The introduction's approximation-exponent attribution is supported. This exponent concerns approximation error relative to denominator; it is not itself an irrationality measure or an irrationality proof.
- Lai, arXiv:2610.06838, submitted 5 October and revised 15 October 2026, explicitly announces Q-linear independence of `1, ζ(3), ζ(4)` and attributes the determinant method to Fauzan. This verifies the attribution and existence of the source, not every step of its proof.
- Lai–Lupu–Sprang, arXiv:2505.23088, exists and concerns p-adic irrationality. Its primary abstract gives a p-adic analogue of the familiar odd-zeta result. The manuscript's more detailed methodological description requires reading the cited paper, not merely its metadata.
- Fauzan's Zenodo record 22826419 exists and announces a determinant proof of irrationality of ζ(5). The record describes degree `37n`, decay `exp(−139 n²/5)`, and a measure exponent `260`; it also describes the posted material as an initial presentation and says a full manuscript is in preparation. These metadata support the attribution but **do not independently certify the exact prime-sum estimates or numerical constants imported later by the present manuscript**. Different parameters here need an explicit bridge to the exact version/theorem being cited.

Primary URLs consulted:

1. https://arxiv.org/abs/2210.03391
2. https://arxiv.org/abs/2610.06838
3. https://arxiv.org/abs/2505.23088
4. https://zenodo.org/records/22826419

Classification: **source-supported attribution, with external proof dependencies**. Do not call the recent claims false merely because they were open before these cited preprints. Conversely, source existence is not a substitute for checking an imported estimate.

### 1.2 The claimed immediate linear-form irrationality measure, pp. 1–2

The manuscript claims that constructing integer linear forms

`L_n(X) = a_n X − b_n`,

with

`0 < |L_n(ξ)| ≤ exp(−γ n)` and `log |a_n| ≤ τ n`

immediately gives an effective finite irrationality measure by the triangle inequality.

**This implication is false as stated.** The omitted nonvanishing issue occurs already in degree one.

Here is a counterexample using the classical Liouville number

`ξ = Σ_{j≥1} 10^(−j!)`.

For each positive integer n, put `Q = ceil(exp(n))`. Dirichlet's elementary pigeonhole argument gives integers `1 ≤ a_n ≤ Q` and `b_n` with

`0 < |a_n ξ − b_n| ≤ 1/Q ≤ exp(−n)`.

The strict inequality on the left follows from irrationality of ξ. For n≥1, `Q ≤ exp(2n)`, hence `log a_n ≤ 2n`. Thus the printed hypotheses hold with `γ=1`, `τ=2`.

Yet the truncation at index J is a rational with denominator `q_J = 10^(J!)`, and its positive tail satisfies

`0 < ξ − p_J/q_J < 2 · 10^(−(J+1)!) = 2 q_J^(−(J+1))`.

The fraction is in fact reduced (the numerator ends in 1); even without that observation its displayed denominator already supplies the contradiction. For every finite μ, sufficiently large J gives error below `q_J^(−μ)`. There is therefore no finite irrationality measure of the stated kind.

**Where the triangle-inequality argument fails.** If `L_n(a/b) ≠ 0`, then `|L_n(a/b)| ≥ 1/b`, which is useful. But the smallness assumption at ξ does not ensure `L_n(a/b) ≠ 0`. Many successive forms can have the same rational zero. The bounds supplied in the introduction do not control those plateaux.

**Explicit repairs.** Either of the following standard additional hypotheses is sufficient for the intended comparison:

1. Require `a_n b_(n+1) − a_(n+1) b_n ≠ 0` eventually, together with the displayed bounds at every sufficiently large index. Then a rational cannot be a zero of both neighboring forms. Choose n with both errors below `1/(2b)` and apply the integer lower bound to one of them. With effective hypotheses, every exponent `μ > 1 + τ/γ` is effective after absorbing constants.
2. Supply a matching exponential lower bound for `|L_n(ξ)|` as well as the upper bound. If the chosen form vanishes at `a/b`, the lower bound for its value at ξ, divided by its coefficient bound, controls the approximation. The exact resulting exponent depends on the stated lower and upper rates.

Suggested replacement: “For suitably regular sequences of linear forms, with a nonvanishing condition at nearby rationals or appropriate two-sided size bounds, the usual integer lower bound yields an irrationality measure. For growing-degree determinant polynomials one must establish an analogous nonvanishing and perturbation estimate.”

**Downstream effect.** This does not by itself disprove the later zero-free-disk transfer theorem. A zero-free disk is precisely a possible remedy for rational vanishing. It does invalidate the introduction's assertion that the difficulty is absent merely because degree is one.

### 1.3 Growing-degree barrier, p. 2

The observation that `b^h Q_K(a/b)` is an integer, but may be zero, is correct for `Q_K ∈ Z[X]` of degree at most h. A quantitative root-free neighborhood gives nonvanishing there and controls the product

`Q_K(x)/Q_K(ξ) = ∏_j (1 + (x−ξ)/(ξ−r_j))`.

This part of the motivation is sound. Root reality is not needed for that product estimate: a complex zero-free disk also suffices. Hyperbolicity can still be valuable for obtaining or interpreting a root bound, but it should not be conflated with the precise hypothesis of the transfer argument.

### 1.4 Abstract wording “interlace symmetrically across ζ(2k+1),” p. 1

If “symmetrically” means reflection symmetry, or equal distances on the two sides, it is false. It is at best ambiguous if it only means a two-sided interlacing/counting pattern.

An exact example within the printed definitions is `s=3, K=3, N=1, m=1, h=2`. Direct calculation gives

```
G(X) = [[12X − 173/12,       −120X + 577/4],
        [−120X + 577/4,     1128X − 16271/12]],

det G(X) = −864X² + 2087X − 90739/72.
```

The two roots are

`(2087 ± sqrt(97))/1728`.

Their midpoint is `2087/1728`, not ζ(3). This inequivalence needs no high-precision computation: the integral test gives

`ζ(3) < H_5^(3) + 1/50 = 260423/216000 < 260875/216000 = 2087/1728`.

Replace “symmetrically” by the exact, proved count/interlacing formulation. The parity dependence of the general pole signature, derived below, also needs to be respected.

### 1.5 Outline and advertised results, pp. 2–3

The Section 2 preview is supported by the checked algebra below, with the precise basis-space restriction noted under Theorem 2.4. The following later announcements are **not established by the introduction or by Section 2** and must receive their verdict from their own audits: universal hyperbolicity; positive moment realization; total positivity; bilateral root counts; interlacing/pinching; the claimed finite continued fraction and spectral-edge convergence; Newton inequalities and equality cases; Christoffel–Darboux identification; Hurwitz/Dirichlet extensions; the asserted non-classical-family exclusion; quantitative transfer and all numerical exponents; multi-weight irrationality; root-collapse/height claims; and the two-variable/Krein/prime-sum/multiple-pole results.

Two editorial corrections are already definite: the introduction ends with “Section ??” instead of the actual discussion section; and its outline does not adequately describe the substantial Section 6. Renumbered or expanded manuscript content needs a full cross-reference pass.

## 2. Setup and Definition 2.1, pp. 3–4

### 2.1 Equation (2.1), harmonic numbers, and Bernoulli convention

The setup `K>N≥1`, `h=K−N`, `α=N/K`, `λ=h/K=1−α` is consistent. The products

`D_m(t)=∏_{j=1}^m(t+j²)`, `D_0=1`

are monic of degree m with distinct negative-square roots. The harmonic-number and Bernoulli recurrences give the stated values, with the important convention `B_1=−1/2`. There is no sign error here. Reusing m later for the exponent parameter is legal but using a different letter for the index in this preliminary definition would improve readability.

### 2.2 Definition 2.1 and equation (2.2)

Make the domain explicitly

`V = {R ∈ Q(t): all finite poles are simple and belong to {−j²:j≥1}}`.

Every element has a unique finite decomposition

`R(t)=Q(t)+Σ_j c_j/(t+j²)`, with `Q ∈ Q[t]`, `c_j ∈ Q`.

Consequently the given values determine a unique Q-linear map `V → Q[X]`, indeed with image in `Q+QX`. There is no compatibility obstruction from choosing the values independently on monomials and poles. This is a vector space, not an algebra closed under arbitrary multiplication; later uses must continue checking simple-pole membership.

The two forms of (2.2) agree because

`∏_{r=3}^{2k+1}(2e+r) = (2e+2k+1)!/(2e+2)!`.

For k=1 this is one factor, `2e+3`, not an empty product. Some useful low-degree values are `μ_X^(3)(1)=1/4`, `μ_X^(5)(1)=5/12`, and `μ_X^(7)(1)=7/12`. These check the factorial offsets.

### 2.3 Equation (2.3)

The pole value

`μ_X^s((t+j²)^(-1)) = j^(2k)(X−H_j^s)+1/(2j)−1/(2k)`

is well-defined for j≥1, k≥1. All three specializations printed for s=3,5,7 are correct. At this point this is a definition; positivity at X=ζ(s) is a separate analytic claim, not a consequence of its being a rational functional.

A useful immediate coefficient formula is

`[X] μ_X^s(R) = Σ_j j^(2k)c_j`

for the unique partial-fraction decomposition above. This formula already contains the derivative-matrix mechanism of Theorem 2.5.

## 3. Lemma 2.2, p. 4

### 3.1 Definition of τ and equation (2.4)

The analogous domain in `Q(x)` has polynomial part plus finitely many simple integer poles, including the poles at 0 and −1. With `d(r)=r` for r≥0 and `d(r)=−r−1` for r<0, the assignment

`τ_X^s((x−r)^(-1)) = H_(d(r))^s − X`

is well-defined for every integer r. In particular,

`τ_X^s(1/x) = τ_X^s(1/(x+1)) = −X`.

This fact matters for the incorrect domain explanation in Lemma 2.3.

The polynomial prescription (2.4) is also consistent. Its first two nonzero values are

`τ(x^(2k−1))=1/(2k)` and `τ(x^(2k))=−1/2`.

The second is the exceptional even degree overlooked by the printed reflection proof.

### 3.2 Pullback identity (2.5)

For a monomial R(t)=t^e, substitution gives `x^(2k+1)R(−x²)=(-1)^e x^(2e+2k+1)`. Applying (2.4) gives exactly (2.2).

For R(t)=1/(t+j²), the printed rational identity is correct:

`x^(2k+1)/(j²−x²) = −Σ_(r=1)^k j^(2r−2)x^(2k+1−2r) − (j^(2k)/2)(1/(x−j)+1/(x+j))`.

It can be verified by multiplication by `j²−x²`. The r=1 polynomial term maps to `−1/(2k)`; every remaining polynomial term has degree below `2k−1` and maps to zero. The pole pair maps to

`−(j^(2k)/2)(H_j^s+H_(j−1)^s−2X) = j^(2k)(X−H_j^s)+1/(2j)`.

Adding the polynomial contribution recovers (2.3), including both rational correction terms. The enlarged rendering confirms the manuscript really prints the minus sign before `1/(2k)` in this proof.

The domain check also passes: each original negative-square pole produces distinct simple poles at ±j, and j≥1 prevents a collision at x=0. Thus the linear-extension argument covers every R in Definition 2.1.

**Verdict: correct, with a complete valid proof.** No p-adic integral interpretation follows merely from this algebraic identity; any such interpretation is an additional downstream theorem.

## 4. Lemma 2.3, p. 5

### 4.1 Reflection identity (2.6): true statement, incorrect polynomial proof

The simple-pole proof is correct because `d(−1−r)=d(r)` and

`1/(−1−x−r) = −1/(x−(−1−r))`.

The polynomial proof contains two distinct false assertions:

1. It claims `τ((1+x)^d)=τ(x^d)` throughout the range d≥2k−1. At d=2k,

   `τ(x^(2k))=−1/2`, whereas `τ((1+x)^(2k))=−1/2+2k·(1/(2k))=+1/2`.

   The exceptional Bernoulli index 1 does not disappear in the way claimed.
2. It says Bernoulli numbers with even index greater than 1 vanish. The vanishing indices are odd indices greater than 1. In addition, the degree d=2k contributes despite being even.

These errors invalidate that argument, **not the reflection identity itself**.

A complete replacement is obtained from the formal exponential generating function

`T(z)=Σ_(d≥0) τ(x^d) z^d/d! = z^(2k)/((2k)!(e^z−1))`.

This is a formal power series (its lowest exponent is 2k−1). Then

`Σ_(d≥0) τ((-1−x)^d) z^d/d! = e^(−z)T(−z) = −T(z)`.

Coefficient comparison proves the polynomial identity for every d, including d=2k. Together with the correct pole calculation, this proves (2.6) for the entire stated domain.

**Downstream impact:** reflection-based deductions need not be discarded, but they should cite this repaired proof rather than repeat the false parity reasoning.

### 4.2 Difference identity (2.7): true on the stated domain and stronger than stated

For r≥1,

`τ((x−(r−1))^(-1)−(x−r)^(-1)) = H_(r−1)^s−H_r^s = −r^(−s)`.

For r≤−1,

`τ((x−(r−1))^(-1)−(x−r)^(-1)) = H_(−r)^s−H_(−r−1)^s = (−r)^(−s) = −r^(−s)`.

The derivative is uniformly

`h^(2k)(0) = (2k)! (−r)^(−(2k+1)) = −(2k)! r^(−(2k+1))`.

In the negative-r paragraph the manuscript instead first writes `(2k)!(-1)^(2k)r^(−(2k+1))`; that expression has the wrong sign. For k=1,r=−1 it is −2, while the actual second derivative of 1/(x+1) at 0 is +2. Replace that step with the uniform derivative formula above.

The explanation for excluding r=0 and r=1 is also false: τ was expressly defined at poles at 0. The actual distinction is:

- r=0 must be excluded from an ordinary derivative-at-zero statement because h is singular at 0. The τ-values themselves remain defined; their difference is 0.
- r=1 is permitted. Its shifted function is 1/x, which belongs to the domain of τ. The left side is `−X−(1−X)=−1`, exactly the derivative expression.

The lemma can therefore be strengthened by replacing `r ∈ Z \ {0,1}` with `r ∈ Z \ {0}`.

There is a further useful rigorous extension. For every g in the τ-domain that is regular at 0,

`τ(g(x+1)−g(x)) = g^(2k)(0)/(2k)!`.

The polynomial part follows from `(e^z−1)T(z)=z^(2k)/(2k)!`; the pole part follows from the calculation just given. For the entire τ-domain, including a simple pole at 0, the same formula holds if the right side is read as the coefficient of x^(2k) in the Laurent expansion of g at 0. The 1/x basis element has coefficient zero and τ-difference zero.

**Downstream impact:** any p-adic or shift argument should state regularity at the evaluation point, or explicitly use the Laurent coefficient. Treating τ as undefined at pole 0 is inconsistent with Lemma 2.2 and can cause spurious exclusions later.

## 5. Equations (2.8) and (2.9), p. 5

For m≥1,

`D_N(t)^(2m)t^(i+j)/D_K(t) = D_N(t)^(2m−1)t^(i+j)/D_tail(t)`.

All remaining poles lie at −a² with N<a≤K, and are simple. Thus every matrix entry lies in the domain of Definition 2.1, for all i,j<h. No additional inequality such as `2mN≤K` is needed merely to define the functional; polynomial quotients are explicitly allowed.

Each entry is affine in X and the matrix is symmetric/Hankel, so its determinant belongs to Q[X] and has degree at most h. The content definition is the usual unique positive rational content for a nonzero rational polynomial. Dividing by it produces a primitive integer polynomial without changing the leading sign.

Equation (2.9) is introduced before nonvanishing of Δ has been proved. This is a presentation dependency, not a counterexample: Theorem 2.5 immediately gives an invertible derivative matrix and hence a nonzero leading coefficient. Move (2.9) after that observation, or state explicitly here that nonvanishing will follow from Theorem 2.5. No analytic positivity is needed for this particular issue.

## 6. Theorem 2.4 and its scope, p. 6

Let M_A and M_B be the coefficient matrices of the two Q-bases in the monomial basis. The displayed relation

`G_(A,B)(X)=M_A G_K(X) M_B^T`

has the correct orientation. Its determinant is `c Δ_K(X)` with nonzero rational `c=det(M_A)det(M_B)`. The content identity

`cont_Q(c Δ)=|c| cont_Q(Δ)`

then gives `P_(A,B)=sgn(c) P_K`. This is a complete proof under the stated nonvanishing hypothesis.

**Strengthening.** If the same basis is used on both sides, `c=(det M_A)^2>0`, so the primitive polynomial is exactly unchanged, without a sign ambiguity. More generally the argument works for any bilinear form on any fixed finite-dimensional Q-vector space whose values lie in Q[X]; the special form of W is unnecessary for the invariance theorem itself.

**Scope correction in the following prose.** Pochhammer or Jacobi families are covered only when their members form a Q-basis of the stated space (in particular, rational parameters/coefficient conditions and nonzero degrees must be respected). “Cauchy-type rational bases over the common denominator” require an explicit identification with the same fixed polynomial numerator space and the same bilinear form. Arbitrary rational-function substitutions need not lie in Q[t]_<h and may create higher-order poles outside the domain. Arbitrary X-dependent changes are excluded as well: even in dimension one, multiplying a basis vector by X multiplies the determinant by X and changes its primitive polynomial.

This is a genuine basis-invariance statement, not a proof that changing the subspace, denominator, weight, pole multiplicities, or moment functional can never improve an arithmetic construction.

## 7. Theorem 2.5, pp. 6–7

### 7.1 Interpolation and equation (2.10)

The nodes `v_a=−a²`, N<a≤K, are distinct. The matrix `V_(i,a)=v_a^i` is h×h and invertible. The Lagrange polynomials in (2.10) satisfy `L_a(v_b)=δ_(a,b)`; the denominator is exactly

`D_tail'(v_a)=∏_(N<b≤K,b≠a)(b²−a²)`.

If C is their coefficient matrix, `CV=I`, hence C=V^(-1). Therefore the transformed Gram matrix is correctly

`G_tilde=V^(-1)G(V^T)^(-1)`.

There is no transpose error here.

### 7.2 Off-diagonal assertion

Using `D_K=D_N D_tail`, the argument of μ in the transformed (a,b) entry is

`R_(a,b)(t)=D_N(t)^(2m−1)D_tail(t) / [D_tail'(v_a)D_tail'(v_b)(t+a²)(t+b²)]`.

For a≠b both denominator factors cancel. The result is a polynomial with rational coefficients, so its μ-value is independent of X. This proves Theorem 2.5(1).

### 7.3 Diagonal assertion and equation (2.11)

For a=b a single simple pole remains at v_a. Its residue is

`c_a=D_N(v_a)^(2m−1)/D_tail'(v_a)`.

Write `R_(a,a)=P_a+c_a/(t+a²)`. Applying (2.3) gives

`G_tilde_(a,a)=γ_a(X−H_a^s)+r_a`,

where

`γ_a=a^(2k)c_a`,

`r_a=μ(P_a)+c_a(1/(2a)−1/(2k)) ∈ Q`.

This both proves (2.11) and makes the previously unspecified rational constant explicit. Nonvanishing holds because a>N, so no factor in `D_N(−a²)` vanishes, and every node difference in the denominator is nonzero.

Taking the X coefficient and reversing the congruence gives exactly

`M_K=V diag(γ_a) V^T`.

All assertions of Theorem 2.5 pass.

### 7.4 Strengthenings and downstream parity constraints

The sign is especially simple. The numerator `D_N(−a²)^(2m−1)` has sign (−1)^N. Among the factors of `D_tail'(−a²)`, exactly a−N−1 are negative. Hence

`sgn γ_a = (−1)^(a−1)`.

Thus positive weights occur at odd a and negative weights at even a, independently of k and m. By real congruence, the inertia of M is the count of odd and even integers in `{N+1,…,K}`:

- h even: `(h/2,h/2)`;
- h odd and N even: `((h+1)/2,(h−1)/2)`;
- h odd and N odd: `((h−1)/2,(h+1)/2)`.

A claimed general signature `(floor(h/2),ceil(h/2))` therefore needs the appropriate parity condition. The specialized weight-five choice N=3n,h=27n does have that signature: for n odd the interval starts at an even integer, and for n even h is even. This distinction should not be lost when generalizing the statement to arbitrary N,K.

An exact one-dimensional check makes the issue transparent: for s=3,m=1,

`N=1,K=2: G(X)=29/2−12X`,

`N=2,K=3: G(X)=360X−5191/12`.

Their derivative signs are opposite.

The determinant identity also gives

`det M = (−1)^(h(h−1)/2) ∏_(a=N+1)^K a^(2k)D_N(−a²)^(2m−1) ≠ 0`.

Consequently Δ has **exact degree h** already by algebra, before any positivity argument, and (2.9) is legitimate. Its leading sign is `(−1)^(hN+h(h−1)/2)`, unchanged by positive rational-content normalization. The factorization itself does not prove that G(ζ(s)) is positive definite or that the roots are real; those remain the next section's analytic responsibilities.

## 8. Exact reproducibility and limits of these checks

Reproducible files in the companion archive:

- `check_section2.py`: Python standard library only; exact rational polynomial arithmetic, no floating-point assertions.
- `check_section2_verified.txt`: captured successful output.

Rendered source pages and enlarged crops were used to resolve signs and the exact introductory hypotheses.

Run:

`python3 check_section2.py`

The script passed 160 polynomial reflection checks, 260 difference checks, 85 pullback checks, and 54 matrix parameter sets (`1≤N≤3`, `1≤h≤3`, `1≤m≤2`, `1≤k≤3`). It verifies the derivative factorization, nonzero leading coefficient, degree, sign parity, and the exact 2×2 example. It also prints the reflection-proof and derivative-sign counterexamples.

These finite checks are deliberately not presented as proofs for all parameters. The universal arguments are the partial-fraction uniqueness, formal generating-function identities, and Vandermonde/residue calculations supplied above. The introduction's Liouville counterexample is proved mathematically and does not depend on a finite numerical search.


\newpage

# Section 3: spectral statements

Source: *Spectral Theory and Diophantine Bounds for Hankel Determinants of Odd Zeta Values*, uploaded file `Zetahyperbolic (3)(2).pdf`, 52 pages. This report audits printed pages 7–14, including Remark 3.10. Page numbers below are both printed and PDF page numbers. Ambiguous displayed formulas were checked against rendered pages, especially Proposition 3.2, Corollaries 3.5–3.6, Theorem 3.7, and Theorem 3.9.

This is an on-paper mathematical audit, supplemented by exact rational calculations for stated counterexamples. It is not a Lean verification. The work had two passes: reconstruct the arguments from the definitions, then test their assumptions and conclusions independently. Theorem 4.7 is cited below only to identify its stated scope; its proof and constants are outside this report.

## Executive assessment

The basic odd-weight integral representation, positive Gram matrix, full-pencil hyperbolicity, exact degree, and universal inertia are sound. The errors are concentrated in the claimed consequences of those facts and in the normalization of one extension. In particular:

* Proposition 3.2's weight differs by a factor of π/2 from the odd-weight weight, so its claimed agreement with the original pencil is false. One coefficient correction repairs it.
* Principal pencils need not have their nominal matrix size as degree. There is a systematic initial zero pattern in the derivative matrix. In the paper's main weight-five family, the first **6n−1** principal determinant polynomials are constant. The interlacing theorem needs to accommodate zero eigenvalues and roots at infinity.
* Corollary 3.5's continued fraction is false even in dimension one. It uses the wrong resolvent, omits a positive normalization, and reverses the endpoint convention. Its full-length strict Lanczos assertion additionally needs a cyclic-vector proof. Its exponential root bound is stated far beyond Theorem 4.7's scope and has an exact counterexample.
* Corollary 3.6 has an odd-power sign error, a reversed finite-power inequality, and an impossible claim of strictly positive Hankel determinants at all orders for a finite atomic measure. Its even-power limit is valid.
* Theorem 3.7's Turán and Newton inequalities survive. Its claimed universal nonvanishing of shifted coefficients is unsupported, and its argument about zero blocks is false. A short real-rootedness argument proves the desired strict shifted Newton inequalities without that claim.
* Theorem 3.8 is sound once the deformation is explicitly defined. The Hurwitz extension in Theorem 3.9 is sound after completing the functional definition. The Dirichlet extension is a valid real-pencil construction, but supplies no demonstrated rational/integer coefficient structure for later arithmetic applications.
* Remark 3.10 does not prove the stated non-classicality. Several of its proposed obstructions are false as general statements; its fixed-principal-chain argument also does not identify the varying-K family.

## Status ledger

“Repairable” means a stated correction or replacement proof is supplied below. “Unresolved” means this audit does not establish the claimed conclusion or a counterexample in the actual parameter family; this is not an impossibility claim.

| Claim | Pages | Status |
|---|---:|---|
| (3.1), monomial integral, and (3.2) | 7 | Checked on paper for all stated odd weights and all rational functions in the functional's domain |
| Theorem 3.1: positivity, degree h, real roots, no root at ξ, zero-free bound | 7–8 | Checked on paper; root simplicity is not asserted or proved |
| Proposition 3.2: hyperbolicity for real s>1 | 8 | Checked on paper |
| Proposition 3.2: agreement at odd integers | 8 | False as printed; explicit factor correction repairs it |
| Theorem 3.3(1): strict total positivity and determinacy | 8–9 | Conclusion checked; near-zero estimate in proof needs repair; condition 2mN≤K is unnecessary |
| Theorem 3.3(2): leading sign in weight five | 9 | Checked on paper |
| Theorem 3.3(3): universal signature | 9 | Checked on paper; unified counting formula supplied |
| Theorem 3.4(1): eigenvalue interlacing | 9–10 | Checked on paper |
| Theorem 3.4(1): r finite roots and minimum over r roots | 9–10 | False presupposition in general; repair using rank, zero eigenvalues, and infinity |
| Theorem 3.4(2), equation (3.5) | 9–10 | Checked on paper |
| Corollary 3.5(1), equation (3.6) | 10 | False as stated, with dimension-one counterexample; corrected resolvent formula supplied |
| Corollary 3.5: full Lanczos length and all bᵢ>0 | 10 | Unproved in this family; quoted general justification is false without cyclicity |
| Corollary 3.5(2): rational ratio at zero | 10–11 | Correct if denominator is nonzero; the explanation omits rational pole contributions |
| Corollary 3.5(2): universal exponential edge bound | 10–11 | False as stated; exact permitted-parameter counterexample supplied |
| Corollary 3.6: logarithmic derivative identity | 11 | Odd-power sign error; explicit correction supplied |
| Corollary 3.6: even-power moment representation and limit | 11 | Checked on paper |
| Corollary 3.6: all-order strict Hankel positivity | 11 | False; finite rank is an exact obstruction |
| Corollary 3.6: displayed finite-power factor bounds | 11 | Reversed; proof itself contains the correct bounds |
| Theorem 3.7(1) | 11–12 | Checked on paper |
| Theorem 3.7(2) | 11–12 | Checked on paper, including the stated equality criterion |
| Theorem 3.7(3): strict shifted Newton inequalities | 11–12 | Correct with a replacement proof |
| Theorem 3.7(3): all intermediate eₘ are nonzero | 11–12 | Unresolved in this actual family; supplied reasoning is false and the claim is unnecessary |
| Theorem 3.8(1) | 12–13 | Checked on paper |
| Theorem 3.8(2), equation (3.8) | 12–13 | Checked after explicitly defining the deformed Gram matrix |
| Theorem 3.9(1) | 13 | Checked after specifying monomial values as well as pole values |
| Theorem 3.9(2): positive kernels and hyperbolicity | 13–14 | Checked as a real-pencil statement after resolving the undefined-center/parity wording |
| Theorem 3.9(2): implicit arithmetic applicability | 13–14 | Not established; no rationality theorem for the coefficients is supplied |
| Remark 3.10 | 14 | Conclusion unresolved; several proposed proof steps are false |

## Notation and the foundational integral

Write s=2k+1≥3, h=K−N, ξ=ζ(s),

\[
D_N(t)=\prod_{\nu=1}^N(t+\nu^2),\qquad
D_{\rm tail}(t)=D_K(t)/D_N(t),\qquad
R(t)=D_N(t)^{2m}/D_K(t).
\]

The Section 2 functional is defined on polynomials and simple negative-square poles. Its relevant values are

\[
\mu_X(t^e)=\frac{(-1)^eB_{2e+2}(2e+2k+1)!}{(2k)!(2e+2)!},
\quad
\mu_X((t+j^2)^{-1})=j^{2k}(X-H_j^{(s)})+\frac1{2j}-\frac1{2k}.
\]

Let G(X) have entries μ_X(R(t)t^{i+j}), 0≤i,j<h, and let M=[X]G(X). The factorization from Theorem 2.5 is

\[
M=V\Gamma V^T,\quad V_{ia}=(-a^2)^i,\quad
\gamma_a=\frac{a^{2k}D_N(-a^2)^{2m-1}}{D_{\rm tail}'(-a^2)},
\quad N<a\le K.
\]

### Equations (3.1)–(3.2), page 7

The weight

\[
w_s(y)=\frac{2(2\pi)^{2k}}{(2k)!}y^{2k+1}
\sum_{\ell\ge1}\ell^{2k}e^{-2\pi\ell y}
\]

is strictly positive. Termwise Gamma integration gives the displayed monomial formula and Euler's even-zeta formula gives exactly μ_X(t^e). Tonelli applies to the positive series.

For completeness, the pole identity has a useful form valid for every real a>0:

\[
\boxed{\displaystyle
\int_0^\infty\frac{w_s(y)}{y^2+a^2}\,dy
=a^{2k}\zeta(2k+1,a)-\frac1{2a}-\frac1{2k}.}
\]

To obtain it, write w_s=2y^{2k+1}(d/dy)^{2k}(e^{2πy}−1)^{-1}/(2k)!, divide y^{2k+1}/(y²+a²) into its polynomial part plus (−1)^k a^{2k}y/(y²+a²), and integrate by parts 2k times. The polynomial part disappears after differentiation. Hermite's integral formula yields the boxed expression. The boundary terms vanish: near zero, the products of derivatives in each boundary term are O(y), and at infinity the Bose factor and its derivatives decay exponentially. For integer a=j, the relation ζ(s,j)=ζ(s)−H_j^(s)+j^−s recovers the manuscript's pole value exactly.

Consequently (3.2) is valid by linearity for the stated domain. All such rational functions are integrable against the weight. In fact w_s(y)→1/π as y↓0, while at infinity it is polynomial times an exponential. The condition 2mN≤K is not required for this integral identity or the positivity of G(ξ).

## Theorem 3.1, pages 7–8

The proof is sound. For every nonzero complex coefficient vector v and its polynomial q,

\[
v^*G(\xi)v=\int_0^\infty R(y^2)|q(y^2)|^2w_s(y)\,dy>0.
\]

The integrand is positive except at finitely many polynomial zeros. Thus G(ξ) is positive definite. Since V is invertible and every γ_a is nonzero, M is invertible. Multiplying the residue denominators gives precisely

\[
\det M=(-1)^{h(h-1)/2}\prod_{a=N+1}^K a^{2k}D_N(-a^2)^{2m-1}\ne0.
\]

This establishes exact degree h. With B=G(ξ)^−1/2 M G(ξ)^−1/2,

\[
\Delta(X)=\Delta(\xi)\det(I+(X-\xi)B).
\]

B is real symmetric and nonsingular, so its eigenvalues β_j are real and nonzero, and the roots, counted with multiplicity, are r_j=ξ−β_j^−1. The primitive normalization divides by a positive scalar and changes no roots.

The phrase “all roots are real and distinct from ξ” is correct. It does **not** mean the roots are pairwise distinct. No simplicity conclusion follows from this proof.

For the Euclidean operator norm the zero-free estimate can be sharpened to an equality for the nearest root:

\[
\min_j|r_j-\xi|=\|B\|_2^{-1}.
\]

## Proposition 3.2, page 8

The printed continuous weight is

\[
w_s^{\rm printed}(y)=\frac{(2\pi)^s}{2\Gamma(s)}y^s
\sum_{\ell\ge1}\ell^{s-1}e^{-2\pi\ell y}.
\]

At s=2k+1 it equals (π/2)w_{2k+1}(y), not w_{2k+1}(y). This is also visible at the origin: its limit is 1/2 rather than 1/π. Thus the assertion that this pencil coincides with (2.8) at odd integers is false.

Replace its coefficient by

\[
\boxed{\frac{2(2\pi)^{s-1}}{\Gamma(s)}}.
\]

The claimed continuous extension then agrees exactly at odd integers. Its hyperbolicity argument is otherwise valid for every real s>1. Indeed the integral matrix is positive definite and its proposed derivative is symmetric and nonsingular. Even the incorrectly normalized pencil is hyperbolic; only the agreement fails. At odd integers its roots are related to the original roots by

\[
r_j^{\rm printed}=\xi+\frac\pi2(r_j^{\rm original}-\xi).
\]

The signature and total-positivity arguments below extend to the corrected continuous family as well.

## Theorem 3.3, pages 8–9

### Part (1): strict total positivity and determinacy

The conclusion is correct. The measure

\[
d\mu(t)=R(t)\frac{w_s(\sqrt t)}{2\sqrt t}\,dt
\]

has a strictly positive density on (0,∞), finite moments of every order, and infinite support. Andréief's determinant identity expresses every Hankel minor with strictly increasing row and column exponents as an integral of two generalized Vandermonde determinants. Both have the same strict sign on 0<t₁<…<t_r. Their product is strictly positive on a set of positive measure. Hence all such minors are strictly positive.

The proof's global estimate w_s(y)≤C y^s e^−2πy is false near zero: its right side tends to zero while w_s(y)→1/π. This does not invalidate determinacy. Split the integral at y=1. Put d=max(2mN−K,0). For suitable positive constants independent of r,

\[
\mu_r\le C_0+C_1\frac{\Gamma(2r+s+2d+1)}{(2\pi)^{2r+s+2d+1}}.
\]

Stirling's estimate gives μ_r^−1/(2r)≥c/r for all sufficiently large r. Thus the Stieltjes Carleman sum diverges. This argument proves determinacy without the restriction 2mN≤K.

### Part (2): leading sign

For the main family s=5, K=30n, N=3n, 2m=6, the sign of the leading coefficient is

\[
(-1)^{h(h-1)/2+5Nh}=(-1)^{n(n-1)/2}.
\]

Here h=27n; direct reduction of the exponent modulo 2 confirms the manuscript's expression. Positive-content normalization preserves this sign.

### Part (3): universal signature

Each D_N(−a²) has sign (−1)^N. The tail derivative has a−N−1 negative factors. Thus

\[
\operatorname{sgn}\gamma_a=(-1)^{(2m-1)N+a-N-1}=(-1)^{a-1}.
\]

Sylvester's inertia theorem transfers these signs to M and B. A uniform count is

\[
n_+=\left\lfloor\frac{K+1}2\right\rfloor-\left\lfloor\frac{N+1}2\right\rfloor,
\qquad
n_-=\left\lfloor\frac K2\right\rfloor-\left\lfloor\frac N2\right\rfloor.
\]

There are n_+ roots below ξ and n_- above ξ, with multiplicities. These counts include all parity cases and verify the special weight-five counts in the text. For h≥2 both signs occur. The signature is independent of s and m.

## Theorem 3.4, pages 9–10

### Part (1): correct matrix interlacing, missing degree qualification

The Cholesky argument is correct. If G(ξ)=LLᵀ, then

\[
\widehat B_r=L_r^{-1}M_rL_r^{-T}
\]

is orthogonally similar to G_r^−1/2 M_r G_r^−1/2, and the matrices \(\widehat B_r\) are nested leading principal blocks. Cauchy interlacing therefore applies.

However M_r can be singular or zero. The full derivative M is invertible, but this does not imply its leading principal blocks are invertible. The exact statement is

\[
\Delta_r(X)=\Delta_r(\xi)\prod_{j=1}^r(1+(X-\xi)\beta_j^{(r)}),
\quad
\deg\Delta_r=\operatorname{rank}M_r.
\]

Only nonzero β_j correspond to finite roots. The map β↦ξ−β^−1 preserves order on each open half-line but is undefined at zero. Consequently the branchwise interlacing conclusion requires omitting zero modes, or adding roots at infinity. The displayed minimum over 1≤j≤r is not always defined as a minimum of r finite roots.

A clean corrected distance statement is

\[
\delta_r:=\begin{cases}
\min\{|r-\xi|:\Delta_r(r)=0\},&\Delta_r\text{ nonconstant},\\
+\infty,&\Delta_r\text{ constant},
\end{cases}
\quad
\delta_r=\|\widehat B_r\|_2^{-1},
\]

with 1/0=∞. The operator norms of nested symmetric principal blocks are nondecreasing, so δ_r is nonincreasing.

An exact small counterexample to the implicit degree-r assumption is s=3, N=1, K=5, m=1. Here

\[
M_{00}=-\frac1{105}+\frac9{70}-\frac{20}{63}+\frac{25}{126}=0.
\]

Thus Δ₁(X)=G₀₀(ξ)>0 is a constant and has no finite root.

### Stronger structural finding: a forced zero triangle

This is not an isolated cancellation. Define

\[
T=h-1-k-(2m-1)N=K-2mN-k-1.
\]

At the tail nodes v_a=−a², let

\[
f_{ij}(t)=(-1)^k t^{i+j+k}D_N(t)^{2m-1}.
\]

Then M_{ij}=Σ_a f_{ij}(v_a)/D_tail'(v_a). The Lagrange leading-coefficient identity says that this sum is zero for a polynomial of degree below h−1 and equals its leading coefficient when its degree is h−1. Therefore

\[
\boxed{M_{ij}=0\quad(i+j<T),\qquad M_{ij}=(-1)^k\quad(i+j=T).}
\]

When T≥0, lower-triangular Cholesky conjugation preserves the zero triangle and gives

\[
\widehat B_{ij}=0\quad(i+j<T),\qquad
\widehat B_{ij}=\frac{(-1)^k}{L_{ii}L_{jj}}\quad(i+j=T).
\]

Moreover, for 1≤r≤T+1,

\[
\boxed{\operatorname{rank}M_r=\max(0,2r-T-1).}
\]

If 2r≤T+1 the block is zero. Otherwise its first T−r+1 rows and columns are zero, and the remaining block has a nonzero first antidiagonal and zeros before it, so is invertible. This proves the rank formula exactly.

For the manuscript's main family k=2, m=3, N=3n, K=30n,

\[
T=12n-3,\qquad \Delta_r(X)\text{ is constant for every }r\le6n-1.
\]

The first nonconstant principal determinant, at r=6n, has degree 2. Any discussion of the entire principal-minor hierarchy as degree 0,1,2,… needs to be rewritten around this fact.

### Part (2): Dodgson condensation

The symmetric Desnanot–Jacobi identity gives the stated polynomial identity. At a root of Δ_{r−1}, its first product term vanishes and the remaining term is −Σ_{r−1}²≤0. This is correct, even when the condition is vacuous because Δ_{r−1} is constant. No nonsingularity assumption is needed to invoke the determinant identity.

## Corollary 3.5, pages 10–11

### Part (1): the displayed fraction is false

The error can be certified in the smallest allowed dimension. Take s=3, N=1, K=2, m=1, so h=1. Then

\[
\frac{D_1(t)^2}{D_2(t)}=\frac{t+1}{t+4}=1-\frac3{t+4},
\quad
G(X)=\frac{29}{2}-12X.
\]

Set g=G(ζ(3))>0, as follows already from the valid integral identity. The single Lanczos diagonal is a₁=β=−12/g. At X=ξ, the manuscript's (3.6) says

\[
\frac1g=\frac1{a_1}=-\frac g{12},
\]

which is impossible because the two sides have opposite signs. Thus this is a genuine false equality, not merely an unproved theorem.

### Exact correction

Put t=X−ξ and κ=Δ_{h−1}(ξ)/Δ_h(ξ)=L_{hh}^{−2}, using 1-based matrix indices. Cramer's rule and the Cholesky factorization give

\[
\boxed{\frac{\Delta_{h-1}(X)}{\Delta_h(X)}
=\kappa\,e_h^T(I+t\widehat B_h)^{-1}e_h.}
\]

The missing κ is positive but usually not 1. The resolvent is I+tB, whereas the printed J-fraction uses B+tI. Thus, with a Lanczos basis convention Qe₁=e_h and a full h-step reduction, the right formula is

\[
\frac{\kappa}{\displaystyle 1+t a_1-
\frac{t^2b_1^2}{\displaystyle 1+t a_2-
\frac{t^2b_2^2}{\displaystyle\ddots-
\frac{t^2b_{h-1}^2}{1+t a_h}}}}.
\]

If the manuscript retains Qe_h=e_h instead, the expansion begins at a_h and proceeds backwards. A polynomial identity or rational-function interpretation handles intermediate denominators that vanish away from zeros of Δ_h.

### Cyclicity and spectral visibility

The text additionally asserts that Lanczos supplies h−1 strictly positive off-diagonal entries because the symmetric matrix has distinct eigenvalues. First, simplicity has not been proved. Second, simplicity alone is insufficient: diag(1,2) has simple spectrum, but Lanczos started at e₂ terminates immediately.

The necessary condition is that the starting vector be cyclic: it must have nonzero projection onto every eigenspace and there must be no repeated eigenvalues if a single starting vector is to generate all h dimensions. Without that condition the algorithm terminates at a length d≤h, giving positive bᵢ only before termination. The correct continued fraction represents the spectral measure seen by e_h, which can omit eigenvalues of the full matrix. Such omitted eigenvalues cancel between numerator and denominator of the ratio.

This audit has not found an actual-parameter counterexample to cyclicity of e_h, nor established cyclicity for the whole family. Therefore the full-length assertion should be classified as unproved in this construction, not impossible. Any claim that the fraction's spectral edge tracks the closest root of the full determinant needs this visibility issue resolved.

The spectral measure is a positive measure on the real β-axis, generally with support on both signs. “Finite Jacobi fraction” avoids suggesting support on [0,∞), as the term “Stieltjes” can do.

### Part (2): rationality and the overbroad root bound

The ratio Δ_{h−1}(0)/Δ_h(0) is rational **if Δ_h(0)≠0** because both polynomials have rational coefficients. The proof's assertion that only Bernoulli monomial moments occur is inaccurate: pole values at X=0 also occur and are rational. Rationality does not require the erroneous fraction.

The exponential estimate |r_min−ξ|≤e^−K/2250 is not a general consequence of the stated parameters. Theorem 4.7 concerns the specific weight-five family, with sufficiently large K divisible by 30, N=K/10, and m=3. Corollary 3.5 is stated for arbitrary allowed K,N,m,s.

There is an exact counterexample within that broad scope. Take s=3, N=1, K=2, m=7, so again h=1. Exact polynomial division and the functional values give

\[
G(X)=\frac{5783933697}{143}-6377292X,
\quad
r=\frac{1927977899}{303984252}>6.
\]

Since ζ(3)<3/2, its only root is more than 9/2 from ξ. This exceeds 1, whereas e^−2/2250<1. All hypotheses explicitly stated in Corollary 3.5 are met. The occasional restriction 2mN≤K in Theorem 3.3(1) is not a standing assumption in Corollary 3.5.

The displayed root bound must be restricted to the precise separately established scope of Theorem 4.7, and that theorem must itself survive its own audit. β_max also needs to mean an eigenvalue of maximum **absolute value**, not merely the largest algebraic eigenvalue.

## Corollary 3.6, page 11

There are three independent corrections.

### Odd-power sign

For any real nonzero evaluation of P, use log|P| or equivalently its formal logarithmic derivatives. Direct differentiation gives

\[
\frac{(-1)^{m-1}}{(m-1)!}(\log|P|)^{(m)}(q_0)
=\sum_j(q_0-r_j)^{-m}.
\]

The printed right side Σ(r_j−q₀)^−m is wrong for odd m. To retain that right side the prefactor must be −1/(m−1)!, independent of m. Every even-power assertion is unaffected.

### Finite-rank Hankel positivity

For u_j=(r_j−q₀)^−2>0,

\[
S_{2r}(q_0)=\sum_{j=1}^h u_j^r.
\]

Thus these numbers form the moments of a positive finite atomic measure. They are rational, since the logarithmic derivatives of a rational-coefficient polynomial at a rational point are rational when the denominator is nonzero.

If d is the number of distinct values among u₁,…,u_h, its Hankel matrices have rank d. Leading Hankel determinants are strictly positive up to size d and are zero above size d. In particular, every determinant of size h+1 is zero. Already at h=1,

\[
\det\begin{pmatrix}1&u\\u&u^2\end{pmatrix}=0.
\]

The claim of all-order strict Hankel positivity is therefore false. Positive semidefiniteness and this exact finite-rank description are the correct replacements.

### Correct finite-power estimate and valid limit

Let d_min=min_j|r_j−q₀|. Since max_j u_j=d_min^−2,

\[
d_{\min}^{-2r}\le S_{2r}(q_0)\le h\,d_{\min}^{-2r}.
\]

Taking negative powers gives

\[
\boxed{h^{-1/(2r)}\le
\frac{S_{2r}(q_0)^{-1/(2r)}}{d_{\min}}
\le1.}
\]

The theorem statement reverses this interval; its proof prints the correct version. For h≥2 the stated lower bound ≥1 is strictly false, because the sum contains more than its largest positive summand. The limit as r→∞ is d_min, as claimed.

## Theorem 3.7, pages 11–12

### Part (1): checked

Let Q=P^(m−1), of degree at least two. Away from its roots,

\[
\frac{(Q')^2-QQ''}{Q^2}=\sum_j\frac1{(X-r_j(Q))^2}>0.
\]

Continuity gives nonnegativity on the whole real axis. At a simple root of Q the expression equals Q'²>0; at a multiple root it vanishes. This proves the stated claim and its possible equality locations.

At ξ,

\[
\frac{P''(\xi)}{P(\xi)}=\left(\sum_j\beta_j\right)^2-\sum_j\beta_j^2
<\left(1-\frac1h\right)\left(\sum_j\beta_j\right)^2.
\]

Strictness is justified because h≥2 and Theorem 3.3 gives both positive and negative β_j, so equality in Cauchy–Schwarz is impossible.

### Part (2): checked, including signs and equality

Normalized Newton inequalities hold for the coefficient sequence of an arbitrary real-rooted polynomial, not just a polynomial with positive coefficients. One direct route is the strengthened Laguerre inequality

\[
(Q')^2\ge\frac{d}{d-1}QQ'',\qquad d=\deg Q,
\]

applied to Q=P^(m−1) at zero. This gives exactly \(\widetilde a_m^2\ge\widetilde a_{m-1}\widetilde a_{m+1}\).

If the neighboring product is negative, strictness is immediate. If it is positive, equality forces all roots of Q to coincide. Because P is real-rooted and its roots are not all equal, this is impossible: a derivative of degree at least two with all roots equal forces, by Rolle/interlacing and the multiplicity relations, the original real-rooted polynomial to have all roots equal. If the neighboring product is zero, equality is equivalent to the middle coefficient being zero. This yields exactly the criterion in part (2).

### Part (3): strict conclusion survives; the nonvanishing argument does not

The shifted polynomial Φ(Y)=P(ξ+Y)/P(ξ) is real-rooted, has Φ(0)=1, and its roots are nonzero and not all equal. The strict Newton inequalities claimed at the end are true, but do not require every intermediate coefficient to be nonzero.

A useful elementary fact is that a real-rooted polynomial with nonzero constant term cannot have two adjacent coefficients equal to zero. If P^(j)(0)=P^(j+1)(0)=0, apply part (1) to Q=P^(j−1). Its Turán expression is zero at zero, so Q(0) must also be zero. Repeating descends to P(0)=0, a contradiction. Applying part (2)'s equality criterion to Φ now rules out every equality case. Therefore

\[
\boxed{\widetilde e_m^2>\widetilde e_{m-1}\widetilde e_{m+1}
\quad(1\le m\le h-1).}
\]

This proves the desired strictness even when an individual e_m is zero.

The manuscript instead claims that a Hankel spectrum is generically distinct and therefore all e_m are nonzero. This implication is false. For example, the real symmetric Hankel matrix

\[
H=\begin{pmatrix}
0&1&0&0\\1&0&0&0\\0&0&0&2\\0&0&2&0
\end{pmatrix}
\]

has the distinct eigenvalues −2,−1,1,2, yet

\[
\det(I+YH)=1-5Y^2+4Y^4,
\]

so e₁=e₃=0. This also disproves the asserted reasoning that two zero neighbors of a coefficient force a block of consecutive zeros or a structure g(Y^q) with q≥3. At m=2 the neighbors vanish while the middle coefficient is −5. Moreover, \(G^{-1/2}MG^{-1/2}\) need not itself be Hankel even though G and M are.

The example is a counterexample to the proposed general structural justification, not a certified counterexample to e_m≠0 for a specific allowed manuscript parameter tuple. Universal nonvanishing in that exact family remains unresolved in this audit. It should be removed unless separately proved; it contributes nothing to the valid strict Newton theorem. Genericity cannot prove a claim for every integer parameter tuple in any event.

## Theorem 3.8, pages 12–13

### Part (1): checked

The measure has all moments and a positive density, so the monic orthogonal polynomials and their positive squared norms exist. The kernel formula in the statement is the standard basis-independent reproducing-kernel identity.

Let A=G^−1/2V, an invertible matrix. Then

\[
B=A\Gamma A^T,\qquad A^{-1}BA=\Gamma A^TA=\Gamma V^TG^{-1}V.
\]

The latter matrix has entries γ_a K_h(−a²,−b²). This is an exact similarity, so it preserves eigenvalues with multiplicities. The pole-kernel matrix is not generally symmetric, but is similar to a real symmetric matrix. All its eigenvalues are real and nonzero.

### Part (2): checked after an explicit deformation definition

The intended definition should be written directly:

\[
G_{ij}(\xi;\tau)=\int_0^\infty
y^{2(i+j)}R(y^2)w_s(y;\tau)\,dy,
\quad
w_s(y;\tau)=\frac{2(2\pi)^{2k}}{(2k)!}y^{2k+1}
\sum_{\ell\ge1}\ell^{2k}e^{-2\pi\ell\tau y}.
\]

It is positive definite for τ>0. Differentiating under the integral is justified locally uniformly for τ in any compact subinterval of (0,∞): the differentiated weight remains bounded near zero and decays exponentially at infinity. Jacobi's determinant identity and the reproducing-kernel formula give exactly (3.8).

If a full deformed pencil is wanted, one may define G(X;τ)=G(ξ;τ)+(X−ξ)M. The paper's phrase about a μ_X-evaluated contribution having no τ-dependence should not replace this definition; the original rational functional at τ=1 does not automatically supply the deformed integrals at τ≠1.

A useful strengthening follows immediately: ∂_τw_s(y;τ)<0 for every y>0, so G'(ξ;τ) is negative definite and

\[
\frac{\partial}{\partial\tau}\log\det G(\xi;\tau)<0.
\]

## Theorem 3.9, pages 13–14

### Part (1): Hurwitz extension

The boxed general pole integral above gives, for a=j+θ,

\[
\int_0^\infty\frac{w_s(y)}{y^2+(j+\theta)^2}\,dy
=(j+\theta)^{2k}\left(\zeta(s,\theta)-
\sum_{\nu=0}^{j-1}(\nu+\theta)^{-s}\right)
-\frac1{2(j+\theta)}-\frac1{2k}.
\]

Thus r_{j,θ}=−1/[2(j+θ)]−1/(2k), which is rational for rational θ. The displayed identity is correct.

The functional must also be defined on monomials by the same Bernoulli values as (2.2). Defining it only on simple poles is insufficient because the entries D_{N,θ}^{2m}t^{i+j}/D_{K,θ} can have polynomial parts. With this explicit completion, the functional is rational-coefficient, its value at X=ζ(s,θ) is a positive integral, and its derivative has the stated nonsingular Vandermonde diagonal factorization. Exact degree h, real-rootedness, and no root at ζ(s,θ) follow.

The same inertia counts hold after aligning the tail-node indexing; the signs alternate. The zero-free spectral formula also applies. Real θ>0 suffices for the analytic/hyperbolic conclusion; rational θ is needed for coefficients in Q[X].

### Part (2): Dirichlet extension

The listed character-polynomial factorizations are correct:

\[
\begin{aligned}
F_{\chi_{-3}}(z)&=z(1-z),&
F_{\chi_{-4}}(z)&=z(1-z^2),\\
F_{\chi_5}(z)&=z(1-z)^2(1+z),&
F_{\chi_8}(z)&=z(1-z^2)(1-z^4),\\
F_{\chi_{-8}}(z)&=z(1+z^2)(1-z^4).
\end{aligned}
\]

They are positive for 0<z<1, so g_χ=F_χ/(1−z^q)>0 and Ω_{s,χ}(y)=y^{s−1}g_χ(y)>0. The integrals converge at zero and infinity, with all polynomial moments finite. The construction therefore yields a positive Gram matrix at the chosen center and an invertible symmetric derivative matrix. In its proof, the undefined coefficient c_{r,χ} should simply be j_r^{s−1}>0. Hyperbolicity and exact degree follow.

The statement says “any integer s≥2” but only defines ξ_χ when χ(−1)=(−1)^{s−1}. Either restrict s to that parity or define ξ_χ=L(s,χ) for every s under discussion. The real-pencil argument works with any real center, so no parity condition is needed for the pure hyperbolicity assertion. Likewise χ(a₀)=+1 is not needed for that assertion once the artificial positive derivative j_r^{s−1} has been chosen.

The arithmetic scope needs an explicit boundary. The monomial constants are

\[
\int_0^\infty y^{2e+s-1}g_\chi(y)\,dy
=\Gamma(2e+s)\left(\frac q{2\pi}\right)^{2e+s}L(2e+s,\chi).
\]

The text proves neither their rationality nor a rational affine expression in the single target L(s,χ). Under the selected parity, these include higher noncritical L-values. The result is a valid real-pencil construction, but it does not, by itself, produce rational determinant polynomials, primitive integer normalizations, or the arithmetic input used in Section 4. That would require an additional rationalization theorem. The theorem's literal real-rootedness claim is not false for failing to establish an arithmetic property it does not explicitly state.

A modest analytic extension is available: positivity also holds, for example, for the primitive characters of discriminants −7 and 12, since

\[
F_{\chi_{-7}}(z)=z(1-z)(1+2z+z^2+2z^3+z^4),
\quad
F_{\chi_{12}}(z)=z(1-z^4)(1-z^6).
\]

More generally, any periodic real coefficient sequence with its finite generating polynomial positive on (0,1) supplies such a positive analytic kernel. This is an extension of the real-pencil statement only.

## Remark 3.10, page 14

The claimed non-classicality of the varying-K primitive family is not established by the two proposed obstructions.

1. **The proposed root-birth criterion is false.** Orthogonal-polynomial interlacing does not say that all new roots are born only at outer edges or that distance to a fixed interior point cannot decrease. Legendre polynomials already give a counterexample: P₂ has roots ±1/√3, while P₃ has a root at zero. Thus approach to an interior point does not contradict Favard theory.

2. **The reciprocal characteristic polynomial needs normalization.** The exact relation is

   \[
   Y^r\Delta_r(\xi-Y^{-1})=\Delta_r(\xi)\det(YI-\widehat B_r).
   \]

   The scalar Δ_r(ξ)>0 does not affect zeros but matters when claiming equality to a monic characteristic polynomial.

3. **The stated “if and only if” is false.** A symmetric matrix need not be tridiagonal in the given basis for its leading characteristic polynomials to agree with an orthogonal-polynomial segment. The nontridiagonal symmetric matrix

   \[
   A=\begin{pmatrix}0&1&1\\1&0&0\\1&0&0\end{pmatrix}
   \]

   has successive leading characteristic polynomials 1, Y, Y²−1, Y³−2Y. These obey the positive Favard recurrence q_{r+1}=Yq_r−q_{r−1} and extend to a positive orthogonal-polynomial family, despite A₁₃≠0. The determinant sequence does not uniquely determine the original matrix in its given basis.

4. **Disjoint support does not imply the claimed entrywise nonvanishing.** The forced zero triangle above gives actual counterexamples. With s=3, N=1, m=1, K=7, one has T=3, so \(\widehat B_{02}=0\) despite |0−2|=2, while \(\widehat B_{03}\ne0\). Thus the parenthetical claim that every off-tridiagonal entry is nonzero is false in the paper's own family. For T≥2 the nonzero entry \(\widehat B_{0T}\) does prove nontridiagonality, including the main weight-five family, but nontridiagonality does not repair the false “if and only if.”

5. **Two distinct families are being conflated.** The theorem about principal minors fixes K and varies r. The claim of non-classicality concerns P_K as K varies. Changing K changes the denominator and all the moments. In general Δ_{K,r} is not a scalar multiple of P_{N+r}; a property of the former chain cannot be transferred to the latter without proof.

A narrower true statement is available for the main family: the normalized reciprocal characteristic polynomials of the fixed-K principal chain begin q₁(Y)=Y and q₂(Y)=Y², because the initial derivative blocks vanish. They cannot be the first terms of a positive Favard recurrence, which would require a strictly positive coefficient b₁ in q₂=(Y−a₁)q₁−b₁. This establishes a precise obstruction for that **fixed-K principal chain**, but not the manuscript's broad non-classicality statement for the varying-K family.

## Downstream propagation and recommended repair order

1. Preserve the valid foundation: the odd-weight integral identity, full positive Gram matrix, exact degree, symmetric spectral factorization, and inertia. They require no irrationality assumption and no simple-spectrum assumption.
2. Correct Proposition 3.2 before using it as an extension agreeing with the original family.
3. Replace nominal principal-minor degree by rank and explicitly accommodate zero eigenvalues. The main-family constant-minor phenomenon is large enough to require revising any principal-chain narrative, not merely adding a footnote.
4. Replace Corollary 3.5's formula by the normalized I+tB resolvent identity. Prove cyclicity if full spectral visibility is needed; otherwise state the shorter fraction for the visible spectral measure. Restrict quantitative root-collapse claims to the independently justified parameter regime.
5. Correct Corollary 3.6 to finite-rank positive semidefinite moment matrices and the correctly oriented bounds. Its useful limit remains available.
6. Retain the strict Newton theorem using the adjacent-zero argument; remove the unsupported coefficient-nonvanishing claim and genericity language.
7. Define the deformation in Theorem 3.8 and complete the Hurwitz functional. Keep the Dirichlet real-pencil result separate from rational/integer arithmetic claims until those are proved.
8. Remove or substantially reprove Remark 3.10. Its present proof does not establish non-classicality.

The positive Gram integral in Section 3 is a one-variable form involving |q(y²)|². It should not be conflated with a later two-variable kernel form involving P(x)P(y): pointwise positivity of a two-variable kernel alone does not imply positive semidefiniteness of that bilinear form. This report certifies (3.2), including for use in later sections, but does not certify such a transfer without its own argument.

## Exact arithmetic reproducibility for the m=7 counterexample

For k=1, N=1, K=2 and m=7, divide (t+1)^13 by t+4. The remainder is (−3)^13. Apply

\[
\mu_X(t^e)=(-1)^e B_{2e+2}(2e+3)/2,
\qquad \mu_X((t+4)^{-1})=4X-19/4.
\]

This gives the displayed affine polynomial exactly. A standard-library rational calculation is:

\Needspace{26\baselineskip}

```python
from fractions import Fraction
from math import comb

B = [Fraction(1)]
for n in range(1, 52):
    B.append(-sum(Fraction(comb(n + 1, j)) * B[j]
                  for j in range(n)) / Fraction(n + 1))
d = 13
c = [Fraction(comb(d, i)) for i in range(d + 1)]
q = [Fraction(0)] * d
for i in range(d, 0, -1):
    q[i - 1] = c[i]
    c[i - 1] -= 4 * c[i]
remainder = c[0]
constant = sum(q[e] * (-1)**e * B[2*e + 2] * Fraction(2*e + 3, 2)
               for e in range(d)) - Fraction(19, 4) * remainder
slope = 4 * remainder
root = -constant / slope
assert constant == Fraction(5783933697, 143)
assert slope == -6377292
assert root == Fraction(1927977899, 303984252)
assert root > 6
```

This is a reproducibility appendix for one exact counterexample, not a numerical approximation to ζ(3).


\newpage

# Section 4: Diophantine transfer and quantitative claims

**Audited document:** `upload/Zetahyperbolic (3)(2).pdf`, printed pages 14–22, using the corresponding `paper.txt`. This report audits Theorem 4.1 through Conjecture 4.11 and the arithmetic specialization immediately before Theorem 4.4. It does not assume conclusions from an earlier version. The section was read in order, then checked again by reconstructing each proof and tracing dependencies backwards. The preceding integral and derivative identities are identified as inputs rather than independently certified here. No Lean claims are made.

## Overall finding

The generic real, algebraic, and ultrametric transfer arguments are substantially sound. The analytic spectral estimate can be repaired explicitly: the displayed numerical calculations contain several errors, but rigorous rational interval calculations actually give enough margin for the stronger eventual bound `||B_K|| ≤ exp(11.407 K)`. That is a useful result independent of the arithmetic normalization.

The asserted arithmetic applications are not established by this section as written. The cited source uses a different parameter sequence and does not provide the stated `K=30n` normalization/decay certificate. The mixed-weight argument additionally contains an exactly false rank bound. The lower height estimate uses an upper bound in the wrong direction. The global rational-root exclusion reverses a zero-free lower bound into a clustering upper bound. Later variational and phase-transition claims require additional arguments that are not present.

These findings do **not** disprove the irrationality statements themselves. They distinguish a valid conditional theorem, a repairable proof, a false intermediate assertion, and an unsupported conclusion.

## Result-by-result status

| Item and printed pages | Status | Precise qualification |
|---|---|---|
| Theorem 4.1, pp. 14–15 | Correct qualitative transfer; effectivity requires an explicit additional hypothesis | Eventual hypotheses imply the claimed irrationality exponent. An effectively computable onset is not supplied by the bare words “for all sufficiently large K.” |
| Proposition 4.2, p. 15 | Correct; quantitatively improvable | The factor `d` in the numerator of the exponent is unnecessary. The resultant argument gives `λρ/(ε−(d−1)Λ_height)`. |
| Proposition 4.3, p. 15 | Correct on paper | This is the integral-coefficient ultrametric Lipschitz estimate. Its open-disk boundary is essential. |
| Arithmetic setup (4.2)–(4.3), p. 16 | Missing external input | The actual cited Fauzan PDF uses `K=40n, N=3n, h=37n`, not `K=30n, N=3n, h=27n`. The manuscript's new constants and multiplier require a separate certificate. |
| Theorem 4.4, pp. 16–18 | Spectral part repairable; arithmetic conclusion conditional | Corrected concavity and numerical bounds prove the spectral claim, even with `11.407`. The irrationality measure and its effectivity still depend on the missing arithmetic certificate. |
| Theorem 4.5, pp. 18–19 | Claimed unconditional theorem unproved; rank lemma false | The weight comparison is sound. The claimed outer-prime correction rank `≤14` fails: the actual construction gives rank `27` for `K=30, N=3, p=17`. |
| Theorem 4.6(1), pp. 19–20 | Numerical proof repairable, with a separate external dependency for its lower bound | The determinant upper bound survives corrected arithmetic. The lower bound needs the unverified `K=30n` estimate `U≤2.32380`. |
| Theorem 4.6(2), pp. 20–21 | Mixed: conditional upper bounds sound; lower height claim unproved | Upper heights and the primitive decay interval follow conditionally. The lower height proof reverses `A_M≤−2.32425`; it needs a lower bound on `A_M`. |
| Theorem 4.7, p. 21 | Correct conditional consequences, with a repair to the quoted separation formula | The root-count argument is sound. Mahler's separation inequality uses Mahler measure, not the naive coefficient height as printed. The loose final estimate survives. |
| Proposition 4.8, pp. 21–22 | Local assertion and degree inequalities correct conditionally; global exclusion unproved | The proof of “no rational root with denominator ≤ exp(K/2251)” reverses the root-gap inequality and also has a numerical mismatch. |
| Remark 4.9, p. 22 | Partly correct, partly unproved | The direct norm sandwich follows conditionally. Inserting `ρ_var` requires an additional asymptotic variational theorem. The numerical lower certificate and the claimed exponent barrier are not established. |
| Remark 4.10, p. 22 | Unsupported implication; claimed inference admits counterexamples | Real roots and exponential collapse do not prove existence of the proposed free-energy limit or a first-order transition. Lee–Yang's circle theorem does not apply merely from real-rootedness. |
| Conjecture 4.11, p. 22 | Properly a conjecture, unresolved | The existence/equality assertion is not established. The admissible measure class in `ρ_var` needs specification. |

## 1. Theorem 4.1: the transfer mechanism and the effectivity issue

Let `D_K=deg Q_K≤λK`, and suppose the two eventual bounds in the statement hold. Choose

`λ/ε < c < μ/ρ`, and `K=d₀ floor(c log b/d₀)`.

If `|a/b−ξ|≤b^(−μ)`, set `δ=a/b−ξ`. For every root,

`|δ/(ξ−r_j)| ≤ b^(−μ+ρc) = o(1/K)`.

Consequently the product

`Q_K(a/b)/Q_K(ξ) = ∏_j (1+δ/(ξ−r_j))`

has absolute value between `1/2` and `2` for sufficiently large `b`. This applies to complex roots as well; real-rootedness is not required. In particular `Q_K(a/b)≠0`. Integrality gives

`1 ≤ |b^D_K Q_K(a/b)| ≤ 2 exp(D_K log b−εK²)`.

Since `log b=(K+O(1))/c`, the exponent is at most

`(λ/c−ε)K²+O(K)`,

which is negative for all sufficiently large `K`. This is a contradiction. The strict final inequality and the floor in `K` cause no difficulty. Constant integer polynomials cannot satisfy the nonzero decay hypothesis eventually, so the zero-degree case is harmless.

The qualifier **“effectively computable”** is not justified by the abstract assumptions alone. To compute a threshold, one needs a computable onset `K₀` for both inequalities, together with effective descriptions/bounds for the constants. The theorem can be repaired in either of two explicit ways:

1. State the qualitative existence of `b₀`; or
2. Add a supplied effective `K₀` and effective constants, then compute a threshold using `K≥K₀`, `λK b^(−μ+ρc)` small enough for the product estimate, and `2 exp(λK log b−εK²)<1`.

For the manuscript's stated constants,

`λρ/ε = (0.9)(11.411)/(0.0004) = 25674.75`.

Thus, **if** the normalization and decay hypotheses are established, Theorem 4.1 already yields every exponent strictly exceeding `25674.75`; the integer exponent `25675` is available. The printed `25687` comes from the convenient but nonoptimal choice `c=2251`, for which `ρc=25686.161`. No change to the spectral proof is needed for this first improvement.

## 2. Proposition 4.2: correct algebraic transfer and a stronger exponent

Write `Λ=Λ_height`, let an approximant `α=α₁` have degree `m≤d` and naive height `B`, and let its primitive minimal polynomial be

`f(X)=b_m ∏_{s=1}^m (X−α_s)`.

Take the leading coefficient positive without loss of generality. The root-gap argument of Theorem 4.1 gives

`0<|Q_K(α₁)|≤2 exp(−εK²)`.

Since `f` is irreducible and does not divide `Q_K`, the resultant is a nonzero integer. For `s≥2`,

`|Q_K(α_s)|≤(D_K+1)H(Q_K) max(1,|α_s|)^D_K`.

Using the Mahler-measure bound

`b_m ∏_{s=1}^m max(1,|α_s|) ≤ sqrt(m+1) B`,

one obtains directly

`1 ≤ |Res(Q_K,f)|`

`≤ 2 exp(−εK²) [(D_K+1)H(Q_K)]^(m−1) [sqrt(m+1)B]^D_K`.

For `K=c log B+O(1)`, its logarithm is at most

`[(m−1)Λ−ε+λ/c]K²+o(K²)`.

The manuscript replaces the final `λ/c` by the larger `λm/c`. This weakens the result but does not invalidate it. A stronger theorem under exactly the stated assumptions is therefore:

> If `ε>(d−1)Λ`, then every exponent `μ_d>λρ/(ε−(d−1)Λ)` excludes sufficiently close algebraic approximations of degree at most `d` and sufficiently large naive height.

The assumption itself also excludes `ξ` being algebraic of degree at most `d`: apply the same resultant argument to its fixed minimal polynomial, where the height factor contributes only `O(K)`.

No effective threshold is claimed in this theorem, and a mere limsup height hypothesis would not by itself supply one. For an application to the height bound `Λ=10.27` later in this section and the conservative `ε=0.0004`, the strict condition fails for every `d≥2`; Proposition 4.2 does not yield a nontrivial higher-degree approximation result from those particular constants.

## 3. Proposition 4.3: the p-adic disk is valid and sharp at the boundary

Taylor coefficients of `Q(ξ_p+W)` lie in `Z_p` because `Q∈Z[X]` and `ξ_p∈Z_p`. Since `|Q(ξ_p)|_p≤1`, every `α` in the specified open disk also satisfies `|α−ξ_p|_p<1`, and

`|Q(α)−Q(ξ_p)|_p≤|α−ξ_p|_p<|Q(ξ_p)|_p`.

The ultrametric equality gives the conclusion. The argument works unchanged for `Q∈Z_p[X]`. The strict inequality cannot generally be replaced by a closed disk: for `Q(X)=X` and `ξ_p=p^m`, the root zero is exactly on the boundary `|0−ξ_p|_p=|Q(ξ_p)|_p`.

This proposition is a local algebraic fact. It supplies no integer normalization or archimedean decay by itself.

## 4. The external arithmetic specialization on p. 16 is not verified by the citation

The actual PDF linked by the cited Zenodo record was downloaded and its advertised MD5 matched:

- Record: <https://zenodo.org/records/22826419>
- PDF: <https://zenodo.org/records/22826419/files/ZETA5_IS_IRRATIONAL.pdf?download=1>
- MD5: `30dafe4adbb13a79f202e94a046c8c8d`
- Local copy: `fauzan_reference.pdf`

The source fixes `K=40n, N=3n, h=37n` (`α=3/40`) in (2.1), p. 3. Its Theorem 2.1, p. 4, gives degree `37n`, with different decay certificates for cutoffs 200 and 100000. Its prime-sum statement is a limsup bound, not the equality of a limit asserted in the present manuscript. Its displayed arithmetic and archimedean constants also differ from those on p. 16 here. Its stated irrationality exponent is 260.

The present manuscript instead uses `K=30n, N=3n, h=27n`, hence `α=1/10`, and asserts

`A_M≤−2.32425`, `U≤2.32380`, `A_M+U≤−0.00045`,

leading to `ε=0.0004`. A change in `α` changes both the prime valuation profiles and the logarithmic energy problem. The reference is not a certificate for these new numerical inputs merely because the same type of construction is used.

The missing input should be supplied as a separate lemma with:

- the exact `L_p(K,M)` definition for the new parameters;
- proof that the resulting multiplier makes every coefficient integral;
- a certified prime-sum bound for that multiplier;
- an archimedean estimate for the same new parameter sequence;
- effective remainders/onsets if effective irrationality thresholds are claimed.

This is a gap in sourcing and derivation, **not a disproof of the proposed constants**. A full independent proof of the cited paper is outside this Section 4 audit.

## 5. Theorem 4.4: reconstructing and repairing the spectral estimate

### 5.1 The structural estimate

Assuming the preceding integral and residue identities, the comparison argument works. Put `p(t)=q(K²t)` and keep the first positive exponential term of the weight on `y=K sqrt(t)`, `t∈[a,b]`. Then

`cᵀG_K c ≥ A_K c_a exp(−K F₅(a,b)) ∫_a^b p(t)² dt`,

where `A_K=K^(12N−2K+6)` and

`F₅(a,b)=2π sqrt(b)+log(1+b)−6α log a`.

The signed residues have the exact factorial form

`r_j=(−1)^(j−1) 2 K^(2h−6−10N) ((j+N)!)^6 / [((j−N−1)!)^6 (K−j)! (K+j)!]`.

Cancellation of the `K log K` terms gives, uniformly at the discrete nodes including the ends,

`log|r_j|=K Φ(j/K)+O(log K)`,

with the displayed `Φ`. Uniformity follows from factorial bounds with `0 log 0=0`; the shifted factorial endpoint contributes only logarithmic errors. Thus the endpoint does not create an unaccounted exponential factor.

The orthonormal Legendre expansion on `[a,b]`, exterior estimate `|P_m(s)|≤(|s|+sqrt(s²−1))^m`, and Cauchy–Schwarz give the claimed exponential rate

`F₅(a,b)+max_{u∈[α,1]} [Φ(u)+2λ log R(u)]`,

up to a polynomial factor in `K`. The Legendre bound is supported by the classical Laplace integral; see DLMF 18.10.5, <https://dlmf.nist.gov/18.10.E5>.

### 5.2 The printed concavity calculation is wrong, but admits a short repair

For `a=1/18`, `b=1/3`, let `Ψ=Φ+1.8 log R`. The displayed derivative formulas are correct. Write the third term of `Ψ''` as

`T(u)=3.6(1/54−u⁴)/[(u²+1/18)(u²+1/3)]^(3/2)`.

The manuscript says `T(0.1)=5.318`; actually

`19.6367 < T(0.1) < 19.6368`.

Its bound `−2/(1−u²)<−2.31` throughout the small interval is also false near `u=0.1`.

Here is an explicit replacement proof. Let `r₀=(1/54)^(1/4)<0.37`. On `(0.1,r₀)`, `T` decreases, because its positive numerator decreases and its positive denominator increases.

- For `0.1<u≤0.25`, `T(u)<19.637`, while `−1.2/(u²−0.01)≤−22.857` and `−2/(1−u²)<−2`.
- For `0.25≤u<r₀`, `T(u)≤T(0.25)<5.208`, while `−1.2/(u²−0.01)<−9.45` and the other negative term is below `−2`.
- For `r₀≤u<1`, `T(u)≤0` and the other two terms are strictly negative.

Therefore `Ψ''<0` throughout `(0.1,1)`.

### 5.3 Corrected certified numerical values

The derivative signs used to bracket the maximum survive, but their printed decimal values do not:

| Quantity | Certified corrected interval | Manuscript value |
|---|---:|---:|
| `Ψ'(0.973)` | `(0.03865,0.03866)` | `+0.0259` |
| `Ψ'(0.974)` | `(−0.00305,−0.00304)` | `−0.0125` |
| `Φ(0.973)` | `(0.721794,0.721795)` | `0.725325…` |
| `Y(0.974)` | exactly `8.2304672` | `8.2297472` |
| `1.8 log R(0.974)` | `(5.035101,5.035102)` | `5.035267…` |
| `F₅(1/18,1/3)` | `(5.649503,5.649504)` | approximately correct |

Strict concavity and these derivative signs put the unique maximum in `(0.973,0.974)`. Since `Φ` decreases and `R` increases on that bracket,

`F₅+max Ψ ≤ F₅+Φ(0.973)+1.8 log R(0.974) < 11.406401`.

A fixed positive margin therefore absorbs the polynomial factor and proves

`||B_K||≤exp(11.407K)`

for all sufficiently large `K`. In particular the printed `11.411` is repairable. The stronger value would, conditionally on `ε=0.0004`, give the transfer threshold `25665.75` and hence integer exponent `25666`.

These are rigorous interval calculations, not just floating-point evidence. The accompanying pure-Python checker uses `Fraction`, integer square-root bounds, an atanh series with an analytic remainder for logarithms, and Machin's formula with alternating-series bounds for π. It passed all checks; files and raw output are listed below.

### 5.4 What this does and does not establish

The spectral estimate is an analytic result. Multiplication of a determinant polynomial by a nonzero rational scalar does not change its roots or its relative matrix. Thus this repair does not solve the missing integer normalization or decay bound on p. 16. The numerical irrationality measure in (4.5) remains conditional on that arithmetic input, and its effectivity additionally requires an effective onset.

## 6. Theorem 4.5: valid weight comparison, false outer-prime rank bound

### 6.1 The archimedean construction is sound

The pole terms in

`b μ_X^(5)(R) − a μ_Y^(3)(tR)`

depend on `Z=bX+aY`, with `Z`-derivative equal to the weight-five derivative matrix. At `Z=bζ(5)+aζ(3)`, the positive weight is

`W_{a,b}(y)=b w₅(y)−a y² w₃(y)`.

For `b>0` and `a<π²b/3`, the stated constants satisfy

`0<c₁ w₅≤W_{a,b}≤c₂ w₅`,

where `c₁=b−3max(0,a)/π²` and `c₂=b+3|a|/π²`. Consequently fixed `a,b` affect logarithmic determinant rates only by `O(K)` and relative-matrix norms by a fixed factor. The spectral margin above absorbs that factor.

If the only extra arithmetic loss really were `exp(O(K))`, one should apply Theorem 4.1 with a slightly smaller decay constant, rather than literally with the same `ε`. For example `ε'=0.0003999` still has `0.9·11.411/ε'<25687`. This bookkeeping is repairable.

### 6.2 Exact counterexample to “rank at most 14”

The proof claims that at most seven exceptional moment degrees contribute an outer-prime correction matrix of rank at most 14. A Hankel matrix supported on a small number of antidiagonals can have large rank. More decisively, the actual family here gives an exact counterexample.

Take `K=30`, `N=3`, `h=27`, and the outer prime `p=17` (`K/3<p≤K`). Let `Q_s(t)` be the polynomial quotient in division of

`t D₃(t)^6 t^s` by `D₃₀(t)`, for `0≤s≤52`.

The numerator and denominator are monic integer polynomials. Hence `Q_s∈Z[t]`, and when nonzero its degree is `s−11`. The weight-three polynomial moments are

`μ^(3)(t^m)=(−1)^m B_(2m+2)(2m+3)/2`.

For `0≤m<15`, these moments are 17-integral: the possible Bernoulli pole at `m=7` is canceled by `2m+3=17`. The first nonintegral moment is `m=15`, and

`17 μ^(3)(t^15) ≡ 8 (mod 17)`.

Define the actual correction matrix modulo 17 by

`L_{ij}=17 μ^(3)(Q_(i+j)) mod 17`, `0≤i,j≤26`.

All entries with `i+j<26` vanish, while all entries with `i+j=26` equal 8, because `Q_26` is monic of degree 15 and its lower-degree moments are integral. Reversing the columns therefore gives a triangular matrix with diagonal 8. Thus

`det L = (−1)^(27·26/2) 8^27 ≡ 15 (mod 17)`,

so **`rank L=27`, not at most 14**. This uses the permitted case `a=b=1` if a concrete mixed-weight pair is desired.

This is not an isolated small-index issue. For `K=30n`, `N=3n`, the quotient degree is `s−12n+1`. At a sufficiently large outer prime, the first nonintegral moment is `m=p−2`; the first nonzero correction antidiagonal is

`i+j=p+12n−3`,

with value `−1/2 mod p`. A suitable square submatrix has rank at least

`min(p+12n−2, 42n+2−p)`,

when that antidiagonal lies in range. This is of order `n`, not bounded independently of `K`.

The claimed `exp(O(K))` determinant loss therefore has no support from the given rank argument. Replacing a constant rank bound by an `O(K)` bound may cost `exp(O(K²))` over outer primes, which can consume the very small asserted decay margin. A new determinant-valuation argument is necessary. This counterexample refutes the stated intermediate assertion; it does not logically refute the final irrationality claim.

## 7. Theorem 4.6: determinant bounds, heights, and normalization

### 7.1 The derivative determinant and a typographical/algebraic correction

The Vandermonde cancellation yields

`|det M_K| = ∏_{a=N+1}^K a⁴ [ (a+N)! / (a (a−N−1)!) ]^5`.

After subtracting `10αλ K² log K`, the limiting constant is

`C_M=(5/2)[(1+α)²log(1+α)−(1−α)²log(1−α)−(2α)²log(2α)]−15αλ`.

The manuscript prints `−15α`; this must be **`−15αλ`**. Its numerical subtraction of `1.35` already corresponds to `αλ=0.09`.

At `α=0.1, λ=0.9`, rigorous intervals give

- `C_M∈(−0.6873879,−0.6873878)`;
- `C_*∈(3.2445775,3.2445776)`;
- `C_*+C_M∈(2.5571896,2.5571897)`.

The manuscript's `C_*=3.244587…` and total `2.557199…` are numerically inaccurate, but the corrected total still exceeds `2.32380+0.23310`. Thus the determinant lower bound survives **if** the independently needed `U≤2.32380` is supplied for this parameter sequence. With that input one gets the stronger lower rate `0.2333896…`.

### 7.2 The Jensen upper bound can be repaired without the missing arithmetic input

Restrict the Andréief integral to `(0,L)^h`, use the first positive exponential term of the weight, and apply Jensen under the arcsine probability measure. Its logarithmic energy and averages are finite. The omitted density, factorial and entropy terms are `O(K log K)` and disappear after division by `K²`; the scaled product sums can be controlled by integral comparison with the same order of error. This gives the stated structural lower bound

`liminf K^(−2) log F_K(ξ) ≥ λ² log(L/4) − λ∫V₅ dρ̃_L + C_*`.

At `L=1/4`, the closed-form average of `J_a` printed in the manuscript is correct. Its numerical evaluations are not all correct. In particular,

`∫J₁ dρ̃≈−1.1213857494`,

`−6∫J_0.1 dρ̃≈1.5439485172`,

`∫V₅ dρ̃≈2.4225627679`.

The certified results are

`liminf K^(−2)log F_K(ξ) ≥ −1.181525853…`,

and hence

`limsup K^(−2)log|det B_K| ≤ 3.738715486… < 3.73980`.

Thus the displayed upper endpoint `3.73980` remains valid after correcting the calculations, conditional only on the preceding integral architecture, not on the external `U` or integer normalization. The proof should state enough error control for the limiting Jensen step rather than presenting its numerical value as self-certifying.

### 7.3 Upper heights and primitive decay: valid conditional consequences

The factorization

`Q_K(X)=Q_K(ξ)∏_j[1+(X−ξ)β_j]`

and `|ξ|<2` give

`H(P_K)≤H(Q_K)≤exp(−0.0004K²)(1+3 exp(11.411K))^(0.9K)`.

Thus the upper bound `exp(10.27K²)` follows from the stated integer decay and spectral estimates. The factor `3` is a harmless bound for the coefficient norm of a linear factor. For `Q_K=c_K P_K`, positive integral content gives

`log P_K(ξ)≤−(ε+δ_K)K²`, `δ_K=K^(−2)log c_K≥0`.

Also

`|lead(P_K)|=P_K(ξ)|det B_K|≥1`,

so the determinant upper bound controls the primitive decay exponent from above. Therefore `0.0004≤ε_P≤3.73980` is a correct conditional consequence.

Content removal can **improve** the decay rate. The conservative input `0.0004` is not an upper bound on the actual primitive decay and should not be treated as such in optimization claims.

### 7.4 The lower height estimate uses the arithmetic inequality backwards

The final line of the proof reads, in substance,

`lim K^(−2)log|lead Q_K| = A_M + 2.557199 ≥ −2.32425 + 2.55690`.

But the only preceding hypothesis is **`A_M≤−2.32425`**. This does not provide the required lower bound. The inference is invalid independently of the small numerical errors. A value of `A_M` substantially more negative would be compatible with that upper bound and would give a much smaller leading coefficient rate.

To prove `log H(Q_K)≥0.23K²` by this route requires, for example, a lower estimate on the actual normalization rate satisfying `A_M+C_*+C_M>0.23`. A certified equality or two-sided evaluation of `A_M` could repair it; none is provided. The same gap affects the claimed primitive lower estimate

`log H(P_K)≥(0.23265−δ_K−o(1))K²`.

These specific lower bounds are unproved for the actual family, not disproved merely by this invalid inference.

## 8. Theorem 4.7: root count, nearest root, and factor separation

Let `s_j=K^(−1)log|β_j|`. The spectral bound gives `s_j≤11.411`, and the asserted determinant lower bound gives

`(1/h)∑s_j≥0.23310/0.9−o(1)>0.2589`.

If `S_+={j:s_j≥0.10}`, then

`0.2589h ≤ 11.411|S_+|+0.10(h−|S_+|)`.

Therefore `|S_+|/h≥0.1589/11.311>0.0140`, and `0.014h=0.0126K>0.012K`. Negative or unbounded-below values of the other `s_j` cause no problem: only their upper bound `0.10` is used. This part of the proof is correct conditional on the determinant lower input.

The nearest-root lower bound follows from the norm. The upper bound follows from the integer leading coefficient and polynomial value. It is far from optimal even using the section's own information: the determinant lower bound implies some `s_j≥0.259−o(1)`, so the nearest gap is at most `exp(−cK)` for every fixed `c<0.259`, much stronger than `exp(−K/2250)`. With the corrected determinant constant and the stated `U`, one can take any `c<0.2593218…`.

The trace identity follows from `r_j−ξ=−β_j^(−1)` and similarity of `B_K^(−1)` to `M_K^(−1)G_K`. The sum of opposite-side distances gives `r_+−r_-≥2 exp(−11.411K)`. The macroscopic cluster need not have a positive proportion on **both** sides; that is not established by this averaging argument.

The factor-separation proof quotes Mahler's inequality with the wrong height. The classical formula uses **Mahler measure** `M(f)`:

`sep(f) > sqrt(3|disc(f)|) d^(−(d+2)/2) M(f)^(−(d−1))`.

Replacing `M(f)` directly by naive height `H(f)` omits a factor; `M(f)≤sqrt(d+1)H(f)` is the appropriate elementary comparison. Nevertheless the manuscript's final loose asymptotic bound survives. An especially clean repair avoids a separate factor-height loss:

`M(f)≤M(P_K)≤sqrt(h+1)H(P_K)`,

because the complementary integer factor has Mahler measure at least one. This yields the stronger bound

`sep(f)≥exp(−10.27(d−1)K²−O(K log K))`,

which implies the printed estimate. A primary source explicitly giving Mahler's formula is Knapp–Yip, Theorem 1.1, <https://arxiv.org/html/2410.01126v1>.

## 9. Proposition 4.8: distinguish local exclusion from the unsupported global claim

For a rational root **already known** to lie in `|X−ξ|≤exp(−τK)`, the irrationality estimate gives

`b^(−25687)<|a/b−ξ|≤exp(−τK)`,

hence `b>exp(τK/25687)`. The finitely many denominators below the irrationality threshold are excluded from shrinking disks for large `K`. This local statement is correct conditional on Theorem 4.4's arithmetic conclusion.

The proof then takes `τ=11.411`, asserting that this closeness condition holds for all roots. Theorem 4.4 gives exactly the opposite inequality:

`|r_j−ξ|≥exp(−11.411K)`.

It is a zero-free disk, not an upper bound on root distances. Thus the global assertion that **no** rational root has denominator at most `exp(K/2251)` is not proved.

There is also a numerical problem even if the incorrect closeness premise were granted:

`11.411·2251=25686.161<25687`,

so `11.411/25687<1/2251`. The quoted local estimate would not imply the displayed denominator threshold.

Root-gap and small-value hypotheses do not exclude fixed rational roots far from `ξ`: multiplying a hypothetical small-value family by a fixed integer linear factor with such a root preserves the relevant exponential estimates, with harmless margins and a degree increase of one. This is a counterexample to the **general inference**, not an explicit rational root of the manuscript's particular determinants. The actual global exclusion remains unresolved without another arithmetic or factorization argument.

Part (2) is valid: from `|F(ξ)|=|c_F|∏|ξ−r_j|`, lower bounds on all gaps give the lower degree estimate, and an assumed cluster upper bound on all gaps gives the upper degree estimate. The integer condition `|c_F|≥1` justifies the second lower inequality.

## 10. Remark 4.9: what the section actually proves about the variational quantity

Conditionally on the earlier determinant lower bound and spectral upper bound, one has

`0.2590 ≤ liminf K^(−1)log||B_K|| ≤ limsup K^(−1)log||B_K|| ≤ 11.411`.

This follows immediately from `|det B_K|≤||B_K||^h`. Neither Theorem 4.4 nor Theorem 4.6 by itself inserts the new number `ρ_var` between the limsup and `11.411`. To do so requires an asymptotic comparison between weighted polynomial norms, their logarithmic potentials, and the relevant extremal problem. Such a lemma is neither proved nor precisely cited at this point.

The supremum over all positive Borel measures on `C` of mass at most `λ` also needs an admissibility definition. Without a logarithmic moment condition or an equivalent normalization, expressions may contain infinities or `∞−∞`. Restricting initially to compactly supported measures with finite relevant potentials would make the formula more meaningful, but extension and approximation still require proof.

There is a plausible route to the upper bound on the variational expression. A potential version of Bernstein–Walsh would give

`U^ν(−u²)≤sup_[a,b] U^ν + λ log R(u)`.

Since `V₅≤F₅(a,b)` on the interval,

`sup_{t≥0}(2U^ν(t)−V₅(t))≥2sup_[a,b]U^ν−F₅(a,b)`.

The expression would then be bounded by `Φ(u)+2λlog R(u)+F₅`, the same one used in Theorem 4.4. This outlines an explicit missing lemma and its connection to the spectral proof; it is not a substitute for establishing it for the stated measure class, nor does it prove the separate finite-`K` asymptotic comparison.

The assertion `−M_eq≥4.274` has no supplied definition/certified computation in this section from which that number can be checked. Even granting `ρ_var≥4.8823`, the conclusion that the **actual** spectral rate cannot give an irrationality exponent below 10985 does not follow from an inequality `ρ_actual≤ρ_var`: a lower bound on an upper bound is not a lower bound on the quantity bounded. Equality with the actual limit is precisely what Conjecture 4.11 proposes. At most, a lower bound on `ρ_var` constrains estimates that deliberately use this variational number itself, after its validity is proved.

The stated `ε=0.0004` is a conservative certified lower decay rate, not the actual best decay rate. Content normalization and stronger archimedean/arithmetic analysis can change the optimization. Therefore no universal barrier for the determinant method is established here.

## 11. Remark 4.10: the Lee–Yang and first-order claims do not follow

Lee–Yang's circle theorem is a theorem for particular partition functions with specified hypotheses. Arbitrary real-rooted integer polynomials do not become instances merely by calling them partition functions and adapting the axis. The source theorem is Lee–Yang, *Physical Review* 87 (1952), 410: <https://journals.aps.org/pr/abstract/10.1103/PhysRev.87.410>.

The manuscript supplies no proof that

`f(X)=lim_K [log|P_K(X)|/(hK)]`

exists, no neighborhood regularity of that limit, and no one-sided derivative analysis. A first-order transition conventionally requires the corresponding derivative discontinuity of a well-defined free energy. Real-root collapse alone proves none of these.

Here is an explicit primitive integer-polynomial counterexample to the proposed inference. Let `t=3+2sqrt(2)` and write

`p_j+q_j sqrt(2)=t^j`, so `p_j²−2q_j²=1`.

Define, for `n≥1`,

`R_n(X)=∏_{j=n}^{2n−1}(q_jX−p_j)(p_jX−2q_j)`.

Each factor is primitive, because `gcd(p_j,q_j)=1` and `p_j` is odd, so `R_n` is primitive by Gauss's lemma. Its `2n` roots are real, distinct, occur on both sides of `ξ=sqrt(2)`, and approach `ξ` at exponential rates comparable to `t^(−2j)`. At `ξ`, each pair has value

`(q_jξ−p_j)(p_jξ−2q_j)=−sqrt(2)t^(−2j)`.

Consequently

`lim_n [log|R_n(ξ)|/(2n²)] = −(3/2)log t`.

For every fixed `X≠ξ`, the same normalized limit is instead

`lim_n [log|R_n(X)|/(2n²)] = +(3/2)log t`.

Thus even with primitive integer coefficients, real simple roots on both sides, exponential root collapse, exponential zero-free scales, and quadratic small values, the normalized logarithm can have an isolated downward discontinuity rather than a first-order free-energy transition. Taking the even subsequence makes `R_n(ξ)>0` if positivity is desired. Alternating the starting index scales gives examples where the analogous limit fails to exist.

This does not determine the actual limiting behavior of the manuscript's particular family. It shows that the claimed implication is invalid. The remark should presently be described as a physical analogy or a conjectural program, not an established first-order transition. The “exact two-sided spectral gap” is also an overstatement: the displayed formula is a lower bound, not an exact value or two-sided asymptotic equivalence.

## 12. Conjecture 4.11 and the dependency consequences

The limit-existence/equality statement is explicitly labeled a conjecture and should remain so. A correct formulation must specify the admissible potentials and the meaning of the supremum in `ρ_var`. Its truth would require an asymptotic spectral/extremal-polynomial argument not provided by the finite interval estimate.

The section's dependencies can be separated as follows:

| Input or repair | Consequences it can support | Consequences it does not automatically support |
|---|---|---|
| Integral/derivative identities plus corrected spectral proof | Eventual norm bound `11.407`, exponential zero-free disk | Integer polynomial decay, irrationality |
| New `K=30n` integer normalization and certified decay | Theorem 4.4's irrationality exponent, upper heights, local rational-root exclusion | Effective onset unless error bounds are effective; global rational-root exclusion |
| New `K=30n` archimedean `U≤2.32380` | Positive determinant lower rate, macroscopic cluster, norm lower rate | Lower height of the normalized polynomial without a lower arithmetic normalization bound |
| Corrected Jensen estimate | Determinant upper rate, upper primitive-decay rate once primitive integrality is available | Integer decay or content growth |
| A replacement mixed-weight valuation theorem | Potential repair of Theorem 4.5 | Cannot be replaced by the false rank-14 assertion |
| A lower bound or certified value for `A_M` | Possible repair of lower coefficient-height estimates | Not supplied by the existing upper bound |
| Variational asymptotic theorem and numerical certificate | Possible repair of the `ρ_var` sandwich | Equality remains conjectural unless separately proved |
| Free-energy limit and derivative analysis | Possible phase-transition theorem | Not implied just by root collapse |

## 13. Reproducible checks and limits of this audit

The exact interval checker is `audit_section4_numeric.py`. Running it exited successfully. Its output, stored in `audit_section4_numeric.txt`, is:

```text
third(.1) : 196367/10000 < value < 12273/625
third(.25) : 26037/5000 < value < 2083/400
Psi prime(.973) : 773/20000 < value < 1933/50000
Psi prime(.974) : -61/20000 < value < -19/6250
Phi(.973) : 360897/500000 < value < 144359/200000
1.8 log R(.974) : 5035101/1000000 < value < 2517551/500000
F5 : 5649503/1000000 < value < 176547/31250
spectral split upper expression : 7129/625 < value < 11406401/1000000
Cstar : 1297831/400000 < value < 2027861/625000
correct Cm : -6873879/10000000 < value < -3436939/5000000
scaled derivative determinant rate : 3196487/1250000 < value < 25571897/10000000
arcsine average V : 24225627/10000000 < value < 6056407/2500000
Jensen lower F rate : -11815259/10000000 < value < -5907629/5000000
upper B determinant rate : 18693577/5000000 < value < 9346789/2500000
All comparisons proved with exact Fraction arithmetic and analytic series remainder bounds.
```

The rank counterexample was independently checked with exact rational Bernoulli moments and modular polynomial division. The reproducer is `audit_section4_rank.py`, with raw output in `audit_section4_rank.txt`. It exited successfully and reported:

```text
K=30, N=3, h=27, p=17
Nonzero p*mu3(t^m) modulo p: [(15, 8), (23, 16), (31, 7), (39, 15)]
Rank over F_17: 27
Determinant modulo 17: 15
PASS: actual correction rank 27 exceeds claimed bound 14.
```

The triangular proof given above is a compact exact certificate and does not depend on trusting floating-point rank detection.

This audit does not certify every theorem in Sections 2–3, the full Fauzan manuscript, any unknown `K=30n` arithmetic certificate, or the open asymptotic conjecture. Claims described as conditional remain conditional. The strongest immediate manuscript repairs are: retain the generic transfer results, correct the numerical spectral/determinant calculations, state the new arithmetic hypotheses explicitly, replace the mixed-weight rank argument, remove the unsupported global rational-root exclusion and height lower bound pending new proofs, and recast the variational/phase assertions at their actually established level.


\newpage

# Section 5: two-variable and residue constructions

Source: the supplied manuscript.
Physical PDF pages and printed pages agree. Section 5 occupies pp.22–29. Formulas on pp.24, 27, and 28 were also checked against rendered pages. This assesses the manuscript's structural claims on their own terms. No Lean compilation was performed.

Method: first reconstruct the proofs from their stated definitions; then attack the exact quantifiers, omitted terms, endpoint values, local valuations, and coefficient formulas. Numerical checks below use exact rational arithmetic.

## Status register

| Claim | Status | Finding |
|---|---|---|
| 5.1, (5.1)–(5.2), pp.22–23 | Correct | Both moment formulas follow from the product substitution. |
| 5.2(1), pp.23–24 | Correct | The coefficient Gram matrix is positive definite; congruence gives exact degree and real roots. |
| 5.2(2), (5.4), pp.23–24 | Correct; omitted convergence justification supplied below | The signed expansion is absolutely convergent for real \(L^2\) functions. |
| 5.2(3), literal fixed-\(K\) statement | False | At \(K=h=2\), a three-dimensional form cannot have both positive and negative index at least two. |
| 5.2(3), intended growing-\(K\) statement | Not established by its proof | The proof deletes the full infinite tail. |
| 5.3, pp.24–25 | Correct | The \(x^{4k}\) restriction supplies the correct alternating-tail phase and rational off-diagonal moments. |
| 5.4, (5.5), p.25 | Correct conclusion; replace proof | The pole definition proves the result immediately. The printed reflection sign and special-case division identity are wrong. |
| 5.5, p.25 | Correct domain qualification | An extension is needed before discussing higher-order poles. |
| 5.6(1): integral, pp.26–27 | Correct | Eleven affine-piece integrals sum to \(453803/288000\). |
| 5.6(1): continuity/endpoints | False as written; finite-point repair | Right continuity fails at \(1/3\) and \(1/2\). The integral is unaffected. |
| 5.6(2), pp.26–27 | Correct conclusion after explicit repair | Replace \(25\) by \(16\) in \(Q\). The stated tail bound survives; a stronger bound is available. |
| 5.6(3), pp.26–27 | False local refinement | The two smallest surviving tail poles need not be \(a,p-a\). Exact local valuation \(3\) occurs where the upgrade requires \(9\). |
| 5.7: degree statement for (5.7), p.28 | Correct | The polynomial part and residue at infinity vanish. |
| 5.7: identifying (5.8) with the partial fractions of (5.7) | False | The function has no pole at zero, but the displayed \(A_{n,0}=n!\ne0\). |
| 5.7(1), interpreting (5.8) as an independent definition | Correct, with scaling clarification | The Hermite-block proof works. Its zeta-relation hypothesis is unused. |
| 5.7(2), interpreting (5.8) as an independent definition | Requires explicit correction | There is an extra loss at \(p=5\); another intermediate valuation claim fails when \(n+k\ge p^2\), but factorial valuations repair that issue. |

For 5.7(2), arbitrary integer test parameters do not satisfy the unproved zeta relation. They refute the relation-independent valuation mechanism, not literally the conditional theorem under its full hypothesis. A corrected unconditional algebraic statement is proved below.

## 5.1: reconstruction and adversarial check (pp.22–23)

Write
\[
B(P,Q)=\frac1{720}\int_0^1\int_0^1P(x)Q(y)
\frac{[-\log(xy)]^5}{1-xy}\,dx\,dy.
\]
With \(u=xy\), integration over \(x\in(u,1)\) contributes \(-\log u\) for equal exponents. Thus
\[
B(x^r,x^r)=\frac1{720}\int_0^1\frac{u^r(-\log u)^6}{1-u}\,du
=\sum_{n=r+1}^{\infty}n^{-7}.
\]
For \(r>s\), the inner integral is \((1-u^{r-s})/(r-s)\). Its quotient by \(1-u\) is a finite geometric sum, giving
\[
B(x^r,x^s)=\frac{H_r^{(6)}-H_s^{(6)}}{6(r-s)}.
\]
Tonelli justifies the nonnegative series; the other calculation is finite. The formulas and positivity of the measure are correct.

Positivity of the measure is distinct from positivity of \(B(P,P)\), whose integrand contains \(P(x)P(y)\). For example,
\[
B(1,1)=\zeta(7)>0,\qquad B(1-6x,1-6x)=37\zeta(7)-38<0.
\]
The last inequality follows, for example, from the elementary estimate \(\zeta(7)<97/96\). This is consistent with the intended indefinite dual-pencil architecture.

## 5.2(1): reconstruction and verdict (pp.23–24)

The independent coefficient rows give \(CC^T\succ0\). If \(CC^T=LL^T\), then
\[
G_A(X)=L\left[L^{-1}G_A(\zeta(7))L^{-T}+(X-\zeta(7))I\right]L^T.
\]
The constant middle matrix is real symmetric. Hence the leading coefficient is \(\det(CC^T)>0\), the degree is exactly \(h\), and the roots are \(\zeta(7)-\gamma_j\), counted with multiplicity. No definiteness of \(G_A(\zeta(7))\) is required. The hypothesis can harmlessly be weakened from \(K\ge h\) to \(K+1\ge h\).

## 5.2(2): reconstruction and convergence (pp.23–24)

Define
\[
I_{m,\nu}(f)=\int_0^1 f(x)x^m(-\log x)^\nu\,dx.
\]
Expanding the kernel gives
\[
B(f,f)=\frac1{720}\sum_{m\ge0}\sum_{\nu=0}^5
\binom5\nu I_{m,\nu}(f)I_{m,5-\nu}(f).
\]
Pairing \(\nu\) with \(5-\nu\) gives exactly the paper's \(1/1440\) prefactor and (5.4).

Here is a full convergence justification and a quantitative strengthening. Cauchy–Schwarz gives
\[
|I_{m,\nu}(f)|\le \|f\|_2
\sqrt{\frac{(2\nu)!}{(2m+1)^{2\nu+1}}},
\]
so
\[
|I_{m,\nu}(f)I_{m,5-\nu}(f)|
\le \|f\|_2^2\frac{\sqrt{(2\nu)!(10-2\nu)!}}{(2m+1)^6}.
\]
Furthermore,
\[
C_5:=\frac1{720}\sum_{\nu=0}^5\binom5\nu
\sqrt{(2\nu)!(10-2\nu)!}<13.
\]
Pair symmetric terms and use \(\sqrt{10!}<1905\), \(\sqrt{80640}<284\), and \(\sqrt{17280}<132\). This proves absolute convergence of the paired series and continuity of the quadratic form on real \(L^2(0,1)\). Applying the estimate to \(|f|\) justifies interchange of the kernel expansion and integration.

If “Krein decomposition” is intended to assert separate finiteness of the positive and negative square sums, that also holds. For \(\nu\ge1\), the displayed estimate makes \(\sum_m I_{m,\nu}^2\) summable. For \(\nu=0\), apply the Schur test to \(1/(1-xy)\), with weight \((1-x)^{-1/2}\). Its weighted row integral is at most \(\pi(1-x)^{-1/2}\), giving \(\sum_m I_{m,0}^2\le\pi\|f\|_2^2\). Thus both signed square sums in (5.4) are finite.

## 5.2(3): two independent failures (pp.23–24)

### Quantifiers

The theorem starts with fixed \(K\ge h\), and part (3) claims both \(h\)-dimensional definite subspaces in \(\mathbf Q[x]_{\le K}\). Literally this is false: at \(K=h=2\), the ambient dimension is three, while positive and negative indices cannot both be at least two.

The intended theorem presumably allows a new \(K=K(h,M)\), as suggested by “taking \(K\) sufficiently large” in the proof. This needs an explicit correction. It is separate from the tail problem.

### The missing tail

The finite exponential-logarithmic family is linearly independent. Its Gram system does produce the stated \(f_i\). But their orthogonality conditions only remove negative coordinates for \(m\le M\). The displayed equality on p.24 beginning “reduces by the exact Krein decomposition (5.4) to” must include the additional term
\[
R_M(i,j)=\frac1{1440}\sum_{m>M}\sum_{\nu=0}^2\binom5\nu
\left[
\langle f_i,\psi^+_{m,\nu}\rangle\langle f_j,\psi^+_{m,\nu}\rangle
-\langle f_i,\psi^-_{m,\nu}\rangle\langle f_j,\psi^-_{m,\nu}\rangle
\right].
\]
No sign or sufficiently small norm for \(R_M\) is proved. Membership in the finite span \(W\) does not remove later moments. Thus neither the positive matrix nor its negative analogue has been established. Polynomial density preserves a previously proved strict margin; it cannot supply the missing margin.

Other correctable defects: the statement requests every \(M\ge h\), whereas the proof sets \(M=h-1\); the \(m=0\) exponential-polynomials are not in unweighted \(L^2(0,\infty)\), though their pointwise independence is valid; and the displayed expression for \(u_i^{(0,0)}\) does not match its definition. The finite positive truncation does contain the required identity contribution from all \(m=0,\ldots,h-1,\nu=0\), so that last normalization error is not the central problem.

### A valid explicit finite-tail repair

Let \(H_M\) be the full signed truncation through \(m=M\). The preceding estimate gives, for every \(M\ge0\),
\[
|B(f,f)-H_M(f,f)|
\le13\|f\|_2^2\sum_{m=M+1}^{\infty}(2m+1)^{-6}
\le\frac{13}{10(2M+1)^5}\|f\|_2^2.
\]
The last step is the decreasing-function integral comparison over \([M,\infty)\).

For a rational polynomial basis, its truncated matrix \(H_M\) and \(L^2\) Gram matrix \(L\) are rational. Consequently
\[
H_M-\frac{13}{10(2M+1)^5}L\succ0
\]
is a finite exact sufficient positivity certificate, and
\[
H_M+\frac{13}{10(2M+1)^5}L\prec0
\]
is a negativity certificate. This repairs checking a given proposed basis. It does not prove that the paper's specific construction succeeds for every dimension; that existence claim needs a separate argument.

## 5.3: beta(4) (pp.24–25)

The proof is correct. On the diagonal, \(u^{4k}/(1+u^2)\) is the alternating tail starting at \(2k\), with positive phase. The product substitution supplies another logarithm, giving exactly \(\beta(4)-H_{2k}^{(\beta,4)}\).

Off the diagonal, \(1+u^2\) divides \(1-u^{4(k_1-k_2)}\), and its finite alternating quotient gives the factor \(1/[12(k_1-k_2)]\). Hence the derivative is \(CC^T\), and the valid proof of 5.2(1) gives real-rootedness. This proposition does not depend on 5.2(3).

## 5.4–5.5: simple-pole cancellation (p.25)

The conclusion is immediate from Lemma 2.2's actual pole definition:
\[
\tau_X((x-j)^{-1}-(x+j)^{-1})
=(H_j^{(s)}-X)-(H_{j-1}^{(s)}-X)=j^{-s}.
\]
It holds for every \(j\ge1\), with no special argument at \(j=1\).

The printed proof has two errors:

1. Reflection gives \(\tau_X((x+j)^{-1})=\tau_X((x-(j-1))^{-1})\), with a **plus** sign. Two minus signs cancel. The following line then proceeds as though the corrected sign had been used.
2. The special-case division identity for \(x^{2k+1}/(1-x^2)\) wrongly uses the even difference \(E_1\). Its residual pole expression should be \(-\tfrac12[(x-1)^{-1}+(x+1)^{-1}]\). Thus the printed calculation does not force \(\tau(E_1)=1\).

The one-line calculation from the pole definition completely repairs 5.4. It avoids broader reflection assertions. The introductory sentence asserting the difference identity for every rational \(h\) regular at zero is broader than the earlier specified domain theorem and is unnecessary here.

Remark 5.5 correctly restricts the result to simple poles in the specified domain; a higher-order extension must be defined before making corresponding statements.

## 5.6(1): exact scalar integral, incorrect endpoint claims (pp.26–27)

All eleven affine expressions hold on the interiors of their table intervals; all eleven listed integrals check exactly. Their sum is \(453803/288000\).

Direct substitution at the floor jumps gives instead
\[
T(1/3)=23/6,\qquad T(1/3+)=113/24,
\]
\[
T(1/2)=67/20,\qquad T(1/2+)=4.
\]
At \(y=1\), the definition gives \(-1\), while the final affine piece extends to \(17/20\). Thus the continuity assertions on the half-closed intervals are false, and the table uses one-sided endpoint extensions rather than the actual values. Replace these continuity intervals by open intervals and label the jump entries as limits, or redefine the function at the finitely many exceptional points. The integral is unchanged.

The scalar integration alone does not verify that the function correctly encodes all arithmetic prime valuations; that interpretation additionally needs the local valuation arguments.

## 5.6(2): explicit correction and stronger conclusion (pp.26–27)

Put \(e=l(x,z)-2x\), \(e_\alpha=l(\alpha x,z)-2\alpha x\). Both have mean zero, and
\[
\int_0^{1/2}e_\alpha^2\,dz=d(g)(1-2d(g))\le1/8.
\]
This is the **squared** \(L^2\) norm, not the norm. Because \(b=4l(\alpha x,z)\), the \(-b^2\) term in \(\Gamma\), after changing sign in \(R=-\Gamma-N\), contributes \(+16\int e_\alpha^2\), not \(25\int e_\alpha^2\). The correct identity is
\[
R=xF+Q_{\rm corr},
\]
\[
Q_{\rm corr}=
\frac{\tau(\tau-\sigma)-(\tau-\sigma)_++\eta(1-\eta)}2
+16d(g)(1-2d(g))-4\int_0^{1/2}e e_\alpha\,dz.
\]
An exact test at \(x=3\) gives \(R-3F=199/100\); the printed expression gives \(2483/800\); the corrected expression gives \(199/100\).

The remaining periodic-primitive calculation is valid. Moreover
\[
Q_{\rm corr}\le1/8+2+1/2=21/8:
\]
the \(\tau\) expression is nonpositive, \(\eta(1-\eta)\le1/4\), and Cauchy–Schwarz bounds the covariance by \(1/8\).

The stated \(P,C\), derivatives, means, \(P(20)=74/3\), \(C(20)=0\), and \(|C|<22\) all check. Two integrations by parts give the stronger bound
\[
\int_{20}^{\infty}\frac{R(x)}{x^3}\,dx
\le-\frac{37}{800}
-\frac{74/3-11729/720}{400}
+\frac{44}{8000}+\frac{21}{6400}
=-\frac{8411}{144000}.
\]
This is smaller than the claimed \(-33104/576000=-2069/36000\). Thus the theorem's advertised bound remains valid after correcting the false expansion.

## 5.6(3): exact failure of the local gain (pp.26–27)

The replacement factors are monic of the same degree and congruent modulo \(p\) to the old factors; the basis-change observation is valid. The error is claiming the two smallest **tail** poles are always \(a,p-a\), regardless of \(N\).

Take \(n=1,K=40,N=3,p=11,a=1\). The prime lies in the stated inner range for any \(M>40/11\). The tail poles in the square class \(\pm1\bmod11\) are
\[
10,12,21,23,32,34.
\]
The prescribed top index \(i=s_a-2=4\) cancels \(34,32,23,21\), leaving **10 and 12**. The pole 1 is absent because it is at most \(N\). The surviving pole 12 is above \(p\); its harmonic number retains an \(11^{-7}\) term.

This yields a precise failure of the claimed local valuation. Up to a prefix which is a unit at the two surviving poles, put
\[
E(t)=\prod_{k\in\{34,32,23,21\}}(t+k^2).
\]
The proposed full prefix can be \(t^3E(t)\); it does not affect valuations in this class. At \(k=10,12\), the residue of \(D_N^7E^2/D_{\rm tail}\) has valuation
\[
7+2\cdot4-5=10.
\]
These count respectively one 11-factor in \(D_N(-k^2)\), four in \(E(-k^2)\), and five in \(D_{\rm tail}'(-k^2)\). At \(k=12\),
\[
v_{11}\left(-12^6H_{12}^{(7)}+1/24-1/6\right)=-7,
\]
whereas the moment at 10 is 11-integral. Therefore the local constant sum has valuation exactly \(10-7=3\): its other summand has valuation at least 10, so no cancellation can raise it.

Here \(l_N(1)=1,l_K(1)=7\). The original half-weight is \(4+4-(7+6)/2=3/2\), correctly giving diagonal lower bound 3. The proposed half-weight \(4+4-7/2=9/2\) requires diagonal valuation at least 9, which is false by six powers of 11. The other top index has the analogous discrepancy.

The uniform gain \(6(p-1)\), limiting increase \(+6\) in \(\Gamma\), and universal integral reduction \(1/3\) are thus invalid as claimed. A limited improvement may be available for classes with both \(a,p-a>N\), but the manuscript does not calculate a valid class-dependent gain. For \(p\le N\), neither alleged surviving pole belongs to the tail at all.

## 5.7: the rational function and the functional must be separated (pp.28–29)

### Valid degree statement; false coefficient identification

The degree is \(-7n-2\); multiplication by a polynomial of degree at most \(6n-1\) gives degree at most \(-n-3\le-4\). The polynomial part and residue at infinity vanish.

But the numerator of (5.7) contains \(t^5\), and its denominator only \(t^2\); \(R_n\) has a zero of order three at zero. The printed \(A_{n,0}=n!\ne0\) is impossible as a pole coefficient.

For \(k\ge1\), the actual coefficients are
\[
A^{\rm true}_{n,k}=(-1)^n\binom{6n}{k}^2
\left(\frac{(k+n-1)!}{(k-1)!}\right)^5,
\]
\[
\frac{B^{\rm true}_{n,k}}{A^{\rm true}_{n,k}}
=2H_k-2H_{6n-k}-5(H_{k+n-1}-H_{k-1}).
\]
Both coefficients at \(k=0\) vanish. The discrepancies include sign, shift, and normalization, not a single global scalar. For \(n=1,k=1\), the true double-pole coefficient is \(-36\), whereas the printed formula gives \(-1152\).

Consequently the derivation of (5.8) from (5.7) is false. The correct rational-function construction must be redone. Nevertheless, (5.8) may independently define a rational functional using the printed coefficients; its algebraic valuation properties can still be assessed.

### Part (1) for the independently defined functional

This proof works. At \(q=9m+1,n=2m\), the \(3m\) nodes \(k=q,\ldots,6n\) are distinct modulo \(q\), so their Hermite basis is unimodular. At each node, \(A/n!\) is a unit and \(U_k\equiv-bq^{-6}\pmod{q^{-5}\mathbf Z_q}\). The block is
\[
\begin{pmatrix}(AV+BU)/n!&AU/n!\\AU/n!&0\end{pmatrix}.
\]
Its diagonal has valuation at least \(-7\), and its off-diagonal has valuation exactly \(-6\). The low-node contributions are integral: denominators from \(H_{6n-k}\) or \(H_{n+k}\) are offset by binomial valuations in \(A\). The scaled determinant is a unit, yielding \(v_q(J_{2m})=-36m=-18n\).

To avoid treating \(q^{1/2}\) as an element of \(\mathbf Q_q\), use left block scaling \(\operatorname{diag}(q^7,q^6)\) and right block scaling \(\operatorname{diag}(1,q^{-1})\). This gives the same integer entry exponents \(7,6,6,5\) and determinant factor \(q^{12}\) per block.

The zeta relation is unused. The valid algebraic result holds for arbitrary integers \(a,b,c\), with \(q>11\), \(q\equiv1\bmod9\), and \(q\nmid b\). What is not justified is transferring it to the displayed rational function or a claimed simultaneous-zeta representation.

### Part (2): valid rank mechanism, two coefficient defects

Each local pole contribution has image in the span of its evaluation and derivative vectors, hence rank at most two. The sum over \(L_\rho\) poles has rank at most \(2L_\rho\). The Taylor-basis minor argument and the determinant expansion over residue classes are valid in principle.

The first defect is the printed formula, checked visually:
\[
V_k=a/k^6+b/(5k^7).
\]
It is not \(a/k^6+5b/k^7\). At \(p=5\), \(v_5(V_5)=-8\) when \(5\nmid b\), contradicting the printed bound \(-7\). The stated prime range allows \(p=5\) for \(n=1,2,3,4\).

The second defect is that \(p^2>6n\) does not imply \(p^2>n+k\). In the latter exceptional case \(H_{n+k}\) can have valuation \(-2\), so the printed inequality \(v_p((B/A)U)\ge-7\) fails. However, the same event gives at least five extra powers of \(p\) in \(A/n!\), which repairs the combined term.

Precisely, put \(e=\mathbf1_{n+k\ge p^2}\). Legendre's formula gives
\[
v_p(A/n!)\ge\omega_p(\rho)+5e,\qquad
v_p(B/A)\ge-1-e.
\]
With \(v_p(U_k)\ge-6\), the combined \(BU/n!\) contribution has valuation at least \(\omega_p(\rho)-7+4e\). The \(AV/n!\) term has valuation at least \(\omega_p(\rho)-7-v_p(5)\). After extracting Taylor row/column powers, the derivative term has the same adequate bound. Thus a valid replacement for (5.9), for arbitrary integer parameters, is
\[
v_p(J_n)\ge
\min_{\substack{0\le m_\rho\le2L_\rho\\\sum m_\rho=3n}}
\sum_\rho m_\rho\bigl(m_\rho-1+\omega_p(\rho)-7-v_p(5)\bigr).
\]
Equivalently subtract \(3n\,v_p(5)\) from the printed right-hand side. For \(p\ne5\), the printed bound is restored by the corrected proof. Restricting the theorem to \(p\ne5\) and treating 5 separately is another valid option.

For an exact test of the relation-independent coefficient argument, take \(n=1,a=0,b=1,c=0\) in (5.8). Then
\[
J_1=
-\frac{21036421776477502103541322265419483469081705335403}
{23509249228800000000000000000000}.
\]
Hence \(v_5(J_1)=-20\) and \(5^{20}J_1\equiv4\bmod5\). The printed optimization has \(\omega=(0,0,2,2,7)\), \(L=(2,2,1,1,1)\), and minimum \(-19\). This refutes the universal valuation mechanism asserted in the proof. It does **not** satisfy the assumed zeta relation, and must not be presented as a literal counterexample to that conditional hypothesis. The corrected inequality above avoids that logical issue by being proved for all integer parameters.

## Dependency propagation and retained structural results

1. The moments, positive derivative, and real-rootedness in 5.1, 5.2(1), and 5.3 survive independently of the cone and valuation errors.
2. The signed decomposition survives and gives an explicit finite-tail certificate. Infinitely many plus and minus coordinates alone do not prove infinite positive and negative indices.
3. The fixed-degree version of 5.2(3) must be withdrawn. The growing-degree existence version needs another proof. Later invocations of its construction, including 6.7 and analogous assertions, inherit that gap unless separately justified.
4. The explicit cone in 6.3(2), pp.32–33, does not repair the gap. Its finite-annihilation/concentration argument fails; an independent exact \(h=4\) calculation for the unchanged space and constraints gives a rational vector with \(B(P,P)<-10^{-53}\). The constraint matrix has rank 12 and nullity 4, and all twelve constraints vanish exactly. This refutes that specified universal cone.
5. Simple-pole cancellation (5.5) is retained after replacing its proof with the direct pole-definition calculation.
6. The exact outer integral and the stronger corrected inner tail bound remain available as scalar facts. The uniform pole-ordering improvement does not. Arithmetic exponents using its \(1/3\) gain must be recomputed from a valid class-dependent estimate.
7. The printed functional in 5.7 has a valid independent \(q\)-adic nonvanishing theorem and an explicitly repairable local minor bound. Its claimed rational-function origin is false. Later multi-pole analogues require their own coefficient checks.

These distinctions preserve the section's valid structural content while identifying which results need small corrections, new proofs, or withdrawal.


\newpage

# Section 6.1–6.10: extensions and obstructions

Source: **Zetahyperbolic (3)(2).pdf**, 52 pages, uploaded in this session. All page numbers below are both PDF and printed page numbers. Scope is the numbered results 6.1–6.10, pp.29–40, not the later results 6.11–6.18. No Lean was used for this audit.

Two passes were performed: first reconstruct the displayed formulas and their actual hypotheses; then attack the proof steps, boundary cases, normalizations, and claimed consequences. A false proof is not automatically classified as a false theorem. Formal rational functionals are distinguished from their claimed analytic integral realizations.

## Verdict map

| Result | Status after both passes | Essential reason |
|---|---|---|
| 6.1(1) | Correct | Exact change of variables and fiber integral. |
| 6.1(2) | Correct | One harmonic summand contributes the unique \(p^{-6}\) pole, and division by \(p\) produces \(p^{-7}\). |
| 6.1(3) local matrix | Correct after wording repair | Invertibility modulo \(p\) excludes **primitive** vectors in the kernel, not all nonzero \(\mathbb Z_p\)-vectors. |
| 6.1 advertised universal barrier | Not established; broad interpretation false | Primitive isotropic compression \(3x^\rho+x^{\rho+p}\) cancels the leading quadratic pole. |
| 6.2(1),(2) | Correct | Exact moments and a common clearing denominator; “exact same denominator” must mean an available bound, not minimal denominator. |
| 6.3(1) | Correct, strengthen-able | Scalar leading reduction modulo \(q\); no irrationality assumption needed. |
| 6.3(2) dimension and pointwise bounds | Correct | Rank-nullity and coefficient \(\ell^1\) control. |
| 6.3(2) positive definiteness | **False** | Exact normalized \(h=4\) counterexample below. |
| 6.4(1) analytic realization | **False** | Constant moment mismatch, pole asymptotics mismatch, and wrong sign in the “positive” differential expression. |
| 6.4(2),(3) formal factorization/hyperbolicity | Correct | Character–Vandermonde sign cancellation is valid for the explicitly defined odd-pole formal functional. |
| 6.5 | Correct for that formal functional | Integral off-diagonals and strictly negative diagonal valuations; exact checks at \(q=17,41\). |
| 6.6(1), main spectral assertions of (2) | Correct | Follows from the valid odd-zeta moment representation and coefficient comparison, with \(a_k>0\). |
| 6.6 “open cone” wording | Repairable | The displayed set without \(a_k>0\) is not open; intersect with that half-space. |
| 6.6(3) pullback identity | Correct | All weights pull back to the same \(x^{2k+1}R(-x^2)\). |
| 6.6(3) exact multiplier rate | Unresolved by the proof | A bounded number of exceptional Hankel moments does **not** imply bounded-rank perturbation. |
| 6.7(1) | Correct | Positive coefficient Gram matrix. |
| 6.7(2) decomposition | Correct | Direct binomial expansion, with the displayed factorials and factor \(1/2\). |
| 6.7(2) explicit definite subspaces | Unresolved after quantifier repair; false for arbitrary fixed \(K\) | Inherited finite-truncation proof drops the infinite tail; inactive top weights also break the asserted independence. |
| 6.7(3) | Correct, strengthen-able | Top active weight dominates; the assumed zeta relation is unnecessary for the local determinant identity. |
| 6.8 | Correct deduction **conditional on 4.5**, not an independent proof | Its unresolved input is the claimed irrationality theorem in Section 4. |
| 6.9(1) as a triple-pole architecture | **False/incompletely defined** | Wrong Laurent coefficient, missing definition of the rational functional, and an incomplete local-node decomposition. |
| 6.9(2) formal double-pole determinant | Repairable to a correct local theorem | The low-pole integrality statement is false, but Hermite vanishing repairs it; this does not repair the separate identification with the printed rational kernel. |
| 6.10(1) finite determinant identity | Correct | Exact leading-coefficient identity. |
| 6.10(1) universal potential comparison | Not proved; displayed variational inequality has the wrong direction | The old equilibrium gives a lower, not upper, bound on the new log-Gram-determinant rate. |
| 6.10(1) “any integer multiple” ratio | False without preserving positive decay | Large multiples make the proposed decay exponent nonpositive. |
| 6.10(2) | Correct | Integral positive Gram determinant and Hadamard; it concerns raw derivative growth, not total primitive arithmetic height. |

## 6.1 — fiber reduction, local poles, and the scope of the barrier (pp.29–31)

### Reconstruction

With \(x_1=u^y,x_2=u^{1-y}\), the Jacobian is \(-\log u\). For \(r\ne s\),

\[
\int_0^1u^{ry+s(1-y)}\,dy=\frac{u^r-u^s}{(r-s)\log u}.
\]

Thus (6.1), including its diagonal term, is correct. The fiber function need not be a polynomial, and for sign-changing \(A\), \(M_{A,A}(u)\) need not be positive. This is a bilinear reduction, not an automatic positive one-variable moment representation.

For \(K/2<p\le K\), a congruent pair crossing \(p\) is necessarily \(r_2=r_1+p\). The difference \(H_{r_2}^{(6)}-H_{r_1}^{(6)}\) has exactly one nonintegral term \(p^{-6}\). Since \(p\nmid6\), the off-diagonal moment has valuation \(-7\). The leading local matrix at \(X\in\mathbb Z_p\) is

\[
p^{-7}L,\qquad L=\begin{pmatrix}0&1/6\\1/6&-1\end{pmatrix},\qquad \det L=-1/36.
\]

This reconstruction is sound. The restriction \(p\ge11\) is stronger than needed for this particular local calculation; \(p>3\) suffices.

### Adversarial check and correction

The phrase “no non-zero \(\mathbb Z_p\)-linear combination” is too strong: multiplying any column by \(p\) removes its \(p^{-7}\) leading term. The proof establishes only that a combination whose coefficient vector is nonzero modulo \(p\) cannot vanish modulo \(p^{-6}\mathbb Z_p^2\).

More importantly, vector-kernel nondegeneracy does not exclude isotropic **quadratic** compression. The primitive vector \((3,1)\) satisfies

\[
(3,1)L(3,1)^T=0.
\]

Consequently \(P_\rho(x)=3x^\rho+x^{\rho+p}\) cancels the \(p^{-7}\) pole in its scalar quadratic value. At \(X=0\), direct substitution gives

\[
B_0(P_\rho,P_\rho)=-9H_\rho^{(7)}-H_{\rho+p}^{(7)}+
\frac{H_{\rho+p}^{(6)}-H_\rho^{(6)}}p.
\]

The two \(p^{-7}\) contributions cancel exactly. The remainder is at least \(p^{-1}\mathbb Z_p\); for \(p\ge11\) the complete nonzero-residue sixth-power sum improves this to \(\mathbb Z_p\).

For the entire compression basis \(\{3x^\rho+x^{\rho+p}:0\le\rho<p\}\), the off-diagonal \(p^{-6}\) contributions cancel as well. If \(d=s-r\ne0\), their sum is exactly

\[
\frac{p^{-6}}2\left(\frac1{p+d}+\frac1{p-d}\right)
=\frac{p^{-5}}{p^2-d^2},
\]

up to a \(p\)-integral remainder. Thus every off-diagonal entry has valuation exactly \(-5\). An exact check at \(p=11\) additionally gives diagonal valuations in \({0,1}\). This does not prove a new denominator asymptotic for arbitrary constructions, but it decisively prevents the local nonsingularity result from being advertised as a universal prohibition on pole cancellation or denominator improvement.

**Downstream:** retain the local matrix lemma; remove the universal-barrier conclusion unless its class of allowed transformations is precisely restricted and a separate proof is supplied.

## 6.2 — simultaneous weight-six and weight-seven functional (pp.31–32)

Both moment identities are correct:

\[
\iint x_1^m x_2^{m+1}d\Omega_7=\frac1{6(m+1)^6},\qquad
\iint\frac{(x_1x_2)^r x_2}{1-x_1x_2}d\Omega_7=
\frac16(\zeta(6)-H_r^{(6)}).
\]

The geometric-series calculation is monotone for the individual monomials; the finite polynomial extension is then justified by linearity. Expanding \(A\) gives exactly the displayed coefficients \(\alpha\sum c_r^2\) of \(\zeta(7)\), \(\beta\sum c_r\) of \(\zeta(6)\), and the stated rational part, including the off-diagonal sign.

For \(K\ge1\), \(6d_K^7\) clears the rational part because every \(m^6|r-s|\) divides \(d_K^7\). This is an available common denominator; it is not a proof that the reduced denominator is exactly \(6d_K^7\), nor that it is optimal.

**Useful limitation:** the coefficient of \(\zeta(6)\) is \(\beta A(1)\). Every polynomial in the later space \(x^{2h}(1-x)^hQ(x)\) has \(A(1)=0\). Thus directly feeding those polynomials into this simultaneous functional kills the weight-six term. Combining the two proposed advantages requires an additional construction.

## 6.3 — unconditional nonvanishing and the false explicit positive cone (pp.32–33)

### Part (1): sound and stronger than stated

For \(A_\rho=x^\rho+x^{\rho+q}\), the coefficient Gram matrix is \(2I_q\). At \(X=0\),

\[
q^7G_{A_q}(0)\equiv-\frac23I_q\pmod q.
\]

Off-diagonal entries before scaling have valuation at least \(-6\). Hence \(v_q\det G_{A_q}(0)=-7q\), and the same holds for every \(X\in\mathbb Z_q\). Exact rational checks give \(-35,-49,-77\) for \(q=5,7,11\), respectively.

The proof actually works whenever \(v_q(X)>-7\). If \(v_q(X)<-7\), \(2XI_q\) dominates and the determinant cannot vanish either. Thus a rational root, if one exists, must have valuation exactly \(-7\), and its leading residue must satisfy \(q^7X\equiv1/3\pmod q\). The stated condition \(q\nmid b\) is only a weak sufficient exclusion. This remains a local fact about a family of determinant polynomials, not an irrationality argument by itself.

### Part (2): correct dimension count, false positivity

The \(3h\) displayed orthogonality constraints are rational linear equations in \(4h\) coefficients, so the dimension bound is correct. At \(h=4\), the exact matrix below has rank 12, so the dimension is exactly 4.

Define the \(12\times16\) rational matrix

\[
C_{(m,\nu),j}=\sum_{k=0}^4(-1)^k\binom4k
\left(\frac{\nu!}{(9+j+k+m)^{\nu+1}}-
\frac{(5-\nu)!}{(9+j+k+m)^{6-\nu}}\right),
\]

where \(m=0,\ldots,3\), \(\nu=0,1,2\), \(j=0,\ldots,15\). Its first twelve columns are invertible. Let \(q\) be the unique vector satisfying \(Cq=0\) and

\[
(q_{12},q_{13},q_{14},q_{15})=
\left(-\frac{1619679775589}{250000000000},1,0,0\right).
\]

Set

\[
P(x)=\frac{x^8(1-x)^4}{150}\sum_{j=0}^{15}q_jx^j.
\]

Every constraint holds exactly, \(P\ne0\), and the normalized coefficient norm is **strictly less than \(99/100\)**. Thus this is inside the theorem's normalized space, not merely near it.

Using Theorem 5.1's moment formula and a directly certified rational upper bound

\[
U=\frac{252087319345480706709949387462449189899965890141309676604321}
{250000000000000000000000000000000000000000000000000000000000}
>\zeta(7),
\]

exact rational arithmetic gives

\[
B_{\zeta(7)}(P,P)<B_U(P,P)<-\frac5{10^{53}}<0.
\]

The display value is \(B_U(P,P)\approx-5.3835676066865585455\cdot10^{-53}\). The proof of \(U>\zeta(7)\) uses only 240 rational Euler-transform terms: \(a_k=\sum_{j=0}^k(-1)^j\binom kj/(j+1)^7\in[0,1]\), \(\eta(7)=\sum a_k/2^{k+1}\), and the tail is at most \(2^{-240}\). No numerical zeta oracle is used.

The reproducible script is `h4_counterexample.py`; `--full` prints every coefficient and the full exact negative fraction. This certificate is independent of the prior Lean project.

The invalid step on p.33 is the assertion that “concentration” of \(x^{2h+m}(1-x)^h\) makes the entire remaining Krein tail positive for every sign-changing \(Q\). It does not. Finite orthogonality eliminates only the specified finitely many negative terms.

### What remains salvageable

The pointwise estimate \(|A_i(x)|\le4^{-h}x^h\) is correct. Therefore every matrix entry, in absolute value, is at most

\[
M_h=4^{-2h}(\zeta(7)-H_h^{(7)})\le\frac{4^{-2h}}{6h^6}.
\]

Without positive definiteness one can still conclude \(|\det G|\le h^{h/2}M_h^h\) by row-norm Hadamard. This preserves strong analytic decay for normalized bases, but supplies neither nonvanishing nor a primitive arithmetic-height estimate.

Rational row scaling \(A_i\mapsto\lambda_iA_i\) multiplies the determinant polynomial by \((\prod_i\lambda_i)^2\). Removing rational content leaves its primitive polynomial unchanged. Thus the \(\ell^1\le1\) normalization itself gives no control of primitive determinant height or denominators.

## 6.4 — beta-four analytic failure, formal algebraic success (pp.33–34)

### The definition is an odd-square formal functional

The domain on p.33 has simple poles only at \(-(2j+1)^2\). It is not a functional on all integer-square poles. Its constant moment is

\[
\mu_X^{(\beta(4))}(1)=\frac14.
\]

No legitimate extension to every negative integer square is defined in 6.1–6.10. A later switch to a full integer-square \(D_K\) must supply a new definition and prove its compatibility; odd-square sign cancellation does not automatically transfer.

### Part (1) is false in multiple independent ways

The displayed weight is

\[
w(y)=-\frac{y^4}{6\pi^2}\frac{d^3}{dy^3}
\frac{\pi}{2\cosh(\pi y/2)}.
\]

Three integrations by parts give

\[
\int_0^\infty w(y)\,dy=\frac{16\beta(2)}{\pi^3}>\frac49>\frac14.
\]

The strict inequality follows from \(\beta(2)>1-1/9=8/9\) and \(\pi^3<32\). Thus even \(R=1\) contradicts the asserted representation. More generally the actual moments of this weight are

\[
\int_0^\infty y^{2e}w(y)\,dy=
\frac{2^{2e+2}(2e+4)!}{6\pi^{2e+3}}\beta(2e+2),
\]

not the rational Euler-number moments in (6.3). The stated auxiliary Euler integral is also mis-scaled: \(\int_0^\infty y^{2e}\operatorname{sech}(\pi y/2)dy=|E_{2e}|\), not \(|E_{2e}|/2^{2e}\).

There is a second incompatibility that cannot be fixed by changing only the weight's scalar prefactor. At \(X=\beta(4)\), the formal pole values (6.4) tend to \(-1/6\) as \(j\to\infty\): the beta tail times \((2j+1)^3\) is \(O(1/j)\). Any integrable signed weight has

\[
\int_0^\infty\frac{w(y)}{y^2+(2j+1)^2}\,dy\longrightarrow0.
\]

Finally, put \(z=\pi y/2\). The claimed “positive” expression on p.34 actually equals

\[
\frac{y^4}{24}\left(-\frac4{\pi^2}D_y^3+D_y\right)
\frac1{2\cosh z}
=-\frac{\pi y^4\sinh z}{16\cosh^4z}<0.
\]

The proof differentiates with the opposite sign. Its printed positive right-hand side also has a different power of \(\pi\). Correcting this operator alone would still not repair the incompatible functional.

### Parts (2),(3) remain correct for the formal pencil

For the odd nodes \(v_j=-(2j+1)^2\), polynomial terms are independent of \(X\), and partial fractions give precisely the displayed derivative factorization. The signs are

\[
(-1)^j\cdot(-1)^N\cdot(-1)^{j-N}=+1.
\]

Hence every \(\gamma_j>0\), the derivative matrix is positive definite, and the formal determinant polynomial has exact degree \(h\) and real roots. This proof does not require the false beta integral representation or positivity at \(X=\beta(4)\). It gives no unilateral root location relative to that value.

## 6.5 — formal beta-four q-adic nonvanishing (pp.34–35)

This result survives for the functional defined by (6.3),(6.4). With \(q=8m+1\), \(N=4m\), \(K=5m\), the remaining poles are \(q+2r\), \(0\le r<m\). Their squared residues are distinct modulo \(q\), so the evaluation Vandermonde is unimodular.

In the Lagrange basis the off-diagonal rational functions are polynomials with coefficients in \(\mathbb Z_q\); all polynomial moments have only powers of 2 as denominators. At \(r=0\), the pole value has valuation \(-1\) and the numerator factor is a unit. At \(r>0\), the pole value has valuation \(-4\) and the numerator has exactly one \(q\)-factor. Thus diagonal valuations are \(-1,-3,\ldots,-3\), while off-diagonal entries are integral.

The identity permutation uniquely has lowest determinant valuation; equivalently scale rows to make the diagonal units and all off-diagonal terms vanish modulo \(q\). This proves

\[
v_q\Delta_K(0)=-(3m-2).
\]

Exact checks in `section6a_checks.py` give \(-4\) at \(q=17\) and \(-13\) at \(q=41\). These checks supplement, rather than replace, the general proof. The theorem is a result about the formal odd-lattice pencil and does not rescue its claimed analytic realization.

## 6.6 — multi-weight positive pencils (pp.35–36)

### Parts (1),(2): substantial valid content

At the pole \(-j^2\), multiplying by \((-t)^{k-m}\) multiplies the \(X_m\)-residue by \(j^{2k-2m}\), so all variable coefficients become \(j^{2k}\). Thus the pencil depends only on \(Z=\sum a_mX_m\), and its derivative is exactly the pure top-weight derivative matrix.

The odd-zeta integral formula (3.2), independently checked in the Section 3 audit, is valid. Substitution therefore gives exactly

\[
W_a(y)=2y^{2k+1}\sum_{\ell\ge1}P_a(\ell)e^{-2\pi\ell y},\quad
P_a(\ell)=\sum_m(-1)^{k-m}a_m\frac{(2\pi\ell)^{2m}}{(2m)!}.
\]

If \(a_k>0\) and all \(P_a(\ell)>0\), the ratios \((2k)!P_a(\ell)/(2\pi\ell)^{2k}\) tend to \(a_k>0\); their infimum is positive and their supremum finite. The weight comparison, Loewner comparison, positive definiteness, real-rootedness, inertia-based signature, and stated zero-free disk follow. For an indefinite derivative matrix the norm comparison is still valid, using

\[
\|G^{-1/2}MG^{-1/2}\|=\sup_{v\ne0}\frac{|v^TMv|}{v^TGv}.
\]

The displayed set called an “open cone” omits \(a_k>0\). Taken literally in \(\mathbb R^k\), it is not open: for \(k=2\), \((-1,0)\) belongs to it, while arbitrarily small negative perturbations of its top coordinate fail positivity for large \(\ell\). Intersecting with \(a_k>0\), as the theorem's initial hypotheses already require, repairs the terminology and comparison statement.

### Part (3): split the identity from the arithmetic assertion

The pullback identity is exact. The assertion about an **exact same quadratic multiplier rate**, up to \(e^{O_a(K)}\), is not established by the supplied argument.

The critical claimed implication is false: having only \(O_k(1)\) exceptional moment indices \(e=i+j+\text{constant}\) does not imply a rank-\(O_k(1)\) perturbation. A Hankel perturbation supported at the single moment \(e=h-1\) is the reverse-identity matrix and has rank \(h\). An exceptional anti-diagonal in the actual index range can similarly have rank proportional to \(K\).

Top-weight domination can plausibly preserve suitable local **integrality upper bounds**, but the manuscript must give the relevant lattices/minor estimates and separately control small primes and actual content. It cannot replace that work by counting exceptional moments. No counterexample to every possible corrected multiplier theorem is asserted here; the present exact-rate conclusion is unresolved.

## 6.7 — universal multi-weight Beukers pencil (pp.37–38)

### Part (1): correct without a cone restriction

The derivative \(CC^T\) is positive definite because the rows of \(C\) are independent. Congruence by its positive square root turns the pencil into \(ZI+H\) with \(H\) real symmetric. Real-rootedness and exact degree follow for every nonzero tuple \(a\), without any sign assumption on the coupled measure.

### Part (2): identity correct; definite-subspace conclusion not proved

For each \(m\), the binomial coefficient divided by \((2m)!\) is \(1/[2m\nu!(2m-1-\nu)!]\). Pairing complementary exponents gives the stated \(\Phi^\pm\) and the factor \(1/2\). Thus the Krein identity is correct. Polynomial test functions require only elementary dominated convergence; the \(L^2\) extension can be justified with the bounded Hilbert moment operator and the extra logarithmic decay in the paired factors.

Two problems remain in the construction claimed after that identity:

1. If the top active index \(m_*<k\), the asserted family is not linearly independent. For \(k=2,a=(1,0)\), at every \(n\), \(\Phi^+_{n,0}-\Phi^-_{n,0}-\Phi^-_{n,1}=0\). Replacing \(k\) by the top active index fixes this particular defect.
2. The projection argument imported from Theorem 5.2(3) discards all \(n>M\) terms of an infinite Krein series after imposing orthogonality only for \(n\le M\). No sign or norm control of the omitted tail is proved. The exact \(h=4\) failure of 6.3(2) shows that this issue is substantive.

If the statement is read as promising both \(h\)-dimensional definite subspaces inside an arbitrary already fixed \(\mathbb Q[x]_{\le K}\), it is false by dimension alone whenever \(K+1<2h\), for example \(K=h=2\). Positive and negative indices cannot both be at least \(h\) in dimension \(K+1\). The intended statement must quantify “for sufficiently large \(K\) depending on \(h,a\)”. Even after that repair, the supplied proof does not establish existence or explicitness. This audit leaves that repaired existence theorem unresolved, rather than calling it false.

### Part (3): correct and can drop the zeta-relation assumption

Let \(s_*=2m_*+1\). For the stated two-monomial basis, the leading diagonal scalar is

\[
a_{m_*}(\kappa/m_*-\kappa^2)q^{-s_*}.
\]

It is a \(q\)-adic unit times \(q^{-s_*}\): use \(\kappa=1\) for \(m_*\ge2\), and \(\kappa=2\) for \(m_*=1\). All off-diagonal entries have valuation at least \(-(s_*-1)\); all lower-weight diagonal contributions are less singular. Reduction modulo \(q\) proves the displayed valuation.

Nothing in this argument requires \(\sum a_m\zeta(2m+1)=c\). It works for **any** \(Z\in\mathbb Z_q\) substituted into the formal pencil, and more generally \(v_q(Z)>-s_*\). This is useful unconditional local nonvanishing, but is not by itself a contradiction to any hypothesized rational relation.

## 6.8 — three-term linear-independence cone (p.38)

The deduction from Theorem 4.5 is formally correct: after changing signs to make \(b>0\), irrationality of \(b\zeta(5)+a\zeta(3)\) rules out equality to an integer. The case \(a=b=0,c\ne0\) is immediate; the \(b=0,a\ne0\) case uses Apéry's theorem.

Likewise, multiplying a fixed-direction rational-approximation bound by \(q\) reduces its exponent by one. The extra reference to a strict numerical margin is not needed if the stated bound \(q^{-25687}\) is already available.

This result adds no independent justification of the crucial irrationality input. In particular the choice \(a=0,b=1\) is already a major specialization of the Section 4 claim. Its unconditional status must follow the verdict on 4.5; it cannot be certified from Section 6 alone. No numerical counterexample to the irrationality assertion is claimed.

## 6.9 — triple poles and formal multi-weight double poles (pp.38–39)

### Part (1): the printed rational architecture fails an exact local test

The printed rational function has numerator \(\prod_{j=1}^n(t-j+1)^6\). At \(t=0\) it has a zero of order 6 against a denominator zero of order 3, so it has **no pole at all**. Nevertheless the printed leading Laurent coefficient gives \(C^{(3)}_{n,0}=n!\ne0\).

For \(k\ge1\), direct evaluation gives the true leading coefficient

\[
C^{(3),\mathrm{true}}_{n,k}=(-1)^k\binom{6n}{k}^3
\left(\prod_{j=0}^{n-1}(k+j)\right)^6.
\]

At \(n=1,k=1\), this is \(-216\), whereas the printed coefficient is \(-13824\). These are exact contradictions, not asymptotic concerns. Shifting the numerator roots and supplying factorial normalizations could define a different kernel with the advertised coefficients, but would require a new theorem and a recheck of all local claims.

There are further independent defects:

- Since \(R_n^{(3)}P=O(t^{-2})\) throughout the stated degree range, the sum of its simple-pole residues is zero. Under the displayed polylogarithmic functional, the coefficient of \(\zeta(s)\) therefore vanishes identically. The actual direct residue expression involves at most \(1,\zeta(s+1),\zeta(s+2)\), not three freely coupled zeta coefficients.
- A nonzero individual leading pole coefficient does not prove that the **sum** defining the \(\zeta(s+1)\)-coefficient is nonzero on the restricted polynomial space. There can be global residue identities. The specific middle coefficient does occur, for example at \(n=1,P=1\), where the sum of true double-pole coefficients is \(27243216/5\ne0\); this example is not a proof of the claimed all-\(n\) assertion.
- The rational functional \(L_n^{(3)}\) used in the determinant is not explicitly defined. One assumed relation \(a_0\zeta(s)+a_1\zeta(s+1)+a_2\zeta(s+2)=c\) does not turn arbitrary residue combinations of these numbers into rational values. Proportionality of every coefficient vector to \((a_0,a_1,a_2)\), or a different explicit rational functional, would have to be supplied.
- At \(n=2m,q=9m+1\), there are **\(3m\)** poles \(q,\ldots,12m\). The proof imposes three-jet conditions at only **\(m\)** of them, then treats the leading matrix as block diagonal. The other \(2m\) poles have not disappeared. The claimed determinant size and valuation therefore do not follow from the proposed Hermite argument.
- For the actual printed kernel, the leading coefficient at \(k=q\) also has a factor \(q^6\), contrary to the unit assertion based on the incorrect binomial formula.

Thus the specific triple-pole determinant theorem is not a valid established result. The generic observation that an order-three pole produces consecutive polylogarithmic weights is correct, but it is much weaker.

### Part (2): a salvageable formal theorem, with an explicit proof repair

Take (5.8), with its displayed \(A_{n,k},B_{n,k}\), as the **definition** of a rational polynomial functional, and make the stated substitutions for \(U_k,V_k\). Then the highest active weight \(s_d\) dominates \(U_{q+r}\), and \(A_{n,q+r}/n!\) is a unit. This supports the claimed block argument.

One inherited sentence is false: \(B_{n,k}/n!\) need not be integral for every \(k<q\). For example \(q=19,n=4,k=0\) gives valuation \(-1\). The correct repair uses the Hermite basis itself:

- The only low-pole \(q^{-1}\) contributions from \(B/n!\) occur at \(k=r<3m\). The potentially troublesome range \(n+k\ge q\) has enough \(q\)-factors in the binomial coefficient to compensate the harmonic denominator.
- The point \(-r\) is congruent modulo \(q\) to the high interpolation node \(-(q+r)\). Every derivative/odd Hermite basis polynomial vanishes modulo \(q\) there.
- Consequently the low-pole correction has even/odd block valuation bounds at least \(\begin{pmatrix}-1&0\\0&1\end{pmatrix}\), not merely an unsupported global integrality assertion.
- The displayed scaling multiplies even-even, even-odd, and odd-odd entries by \(q^{s_d+1},q^{s_d},q^{s_d-1}\), respectively. All low corrections then vanish modulo \(q\), even when \(s_d=2\).

The high-pole blocks reduce to \(\begin{pmatrix}*&-a_d A/n!\\-a_d A/n!&0\end{pmatrix}\), whose determinants are units. This proves \(v_qJ_{2m}=-6s_dm\) for the explicitly defined formal functional. Half-integer diagonal exponents can be avoided entirely by defining the resulting entrywise scalings, which have integer exponents, or by using asymmetric integral row/column scalings.

As in 6.7(3), the algebraic identity does not need the assumed equality among zeta values: \(c\in\mathbb Z_q\) suffices. However, this repair does **not** validate the separate identification of (5.8) with the printed double-pole rational kernel. That identification is audited in Section 5 and already has elementary Laurent-coefficient discrepancies.

## 6.10 — exact identity versus unsupported potential-theoretic universality (pp.39–40)

### The finite algebraic identity is correct

If \(G_K=G_K(\xi)\) is positive definite, \(M_K\) is nonsingular, and \(B_K=G_K^{-1/2}M_KG_K^{-1/2}\), then exactly

\[
|[X^h]Q_K|=Q_K(\xi)|\det B_K|.
\]

Therefore, whenever the displayed limits exist, \(\Lambda_{\rm lead}+\epsilon=I_B\). This is normalization invariant and is useful. It does not require equilibrium measures.

### The rest of part (1) needs major qualification

Arbitrary positive rational kernels \(W_K/D_K\) do not by themselves supply a limiting external field, an equilibrium measure, existence of both determinant limits, or the stated shared normalization constant. These regularity and scaling assumptions must be stated before identifying the limits with weighted energies. “Pole energy” must also include the actual residue weights, rather than merely an unweighted negative-lattice energy.

The claimed comparison after multiplication by \(P_K^2\) has a reversed variational step. Write the original energy as \(E(\mu)\), minimized at \(\mu_0\), and let \(U(t)\) be the logarithmic potential of the added roots, with the sign convention used in the manuscript's determinant increments. The new minimum satisfies

\[
E_{\rm new}=\min_\mu\{E(\mu)-2\!\int U\,d\mu\}
\le E(\mu_0)-2\!\int U\,d\mu_0.
\]

Hence the new **log Gram determinant** rate increases by **at least** \(2\int U\,d\mu_0\), not “at most” as p.40 states. Subtracting this rate from the explicitly changed derivative determinant gives an **upper** bound on the new \(I_B\) using the old equilibrium, opposite to the displayed lower bound. A lower bound instead involves control at the new equilibrium. No strict positive potential gap follows from the supplied argument.

The phrase “any polynomial family” also omits the degree/mass scaling needed for a nonzero quadratic perturbation. Fixed-degree Christoffel factors have zero root mass at the \(1/K\) normalization and cannot support a universal strictly positive quadratic increment. The claimed strictness requires a positive limiting root mass and a separate strict comparison.

For integer rescalings \(\widetilde Q_K=c_KQ_K\), if \(K^{-2}\log c_K\to\rho\), then

\[
\widetilde\Lambda_{\rm height}=\Lambda_{\rm height}+\rho,
\qquad \widetilde\epsilon=\epsilon-\rho.
\]

Thus their sum is exactly invariant where these limits exist. The stated height-to-decay ratio bound can only be asserted if \(\widetilde\epsilon>0\). Taking, for example, \(c_K=\lceil e^{K^2}\rceil\) destroys a decay exponent bounded above by \(0.0004\); the ratio conclusion for “any integer multiple” is then false or undefined. Even after repairing this hypothesis, the numerical \(0.23310\) and \(581\) bounds concern the particular Section 4 weight-five family and depend on that section's quantitative proof. They are not established universal constants for all kernels.

### Part (2): correct, with a broader useful hypothesis

For integral \(C_K\) of full row rank, \(C_KC_K^T\) is positive definite with a positive integer determinant. Hadamard gives exactly

\[
1\le\det(C_KC_K^T)\le(K+1)^hK^{2Ah},
\]

so its \(K^{-2}\log\)-rate is zero. Polynomial coefficient height can be weakened to \(\log\max(1,|C_{i,r}|)=o(K)\).

This eliminates quadratic growth of the **raw derivative Gram determinant** under those coefficient assumptions. It does not eliminate clearing-denominator growth, the intercept's arithmetic height, primitive content issues, or the need to construct small nonzero values with those same coefficient bounds. A pencil with derivative \(I_h\) can still have exponentially large rational denominators in its constant part, and hence a primitive leading coefficient of quadratic exponential size after clearing. The theorem is a useful structural distinction, not a completed height-to-decay argument.

## Reproducibility and retained results

Run:

```text
python3 h4_counterexample.py
python3 h4_counterexample.py --full
python3 section6a_checks.py
```

All scripts use Python's standard-library exact `Fraction` arithmetic. The only decimal output is a display of an already certified rational number. No Lean compilation, floating zeta oracle, or numerical eigenvalue sign is used in the certificates.

The strongest retained results are the fiber and simultaneous-weight identities; local nonvanishing of 6.3(1), 6.5, and 6.7(3); formal odd-beta hyperbolicity; the multi-weight positive-cone spectral comparison; the exact multi-weight Krein identity; the repaired formal double-pole nonvanishing; and the raw derivative-Gram growth estimate. None should be discarded merely because adjacent analytic or asymptotic claims fail.

The main blocked downstream steps are the explicit positive-cone decay construction, analytic use of the beta-four formal functional, the exact multi-weight multiplier rate, the asserted explicit infinite-dimensional definite-subspace construction, the triple-pole rational determinant, and the universal potential-gap inequality. Each needs the specific repair or missing theorem identified above.


\newpage

# Section 6.11–6.18 and discussion

Scope: the supplied 52-page PDF dated 21 October 2026. Two passes: reconstruct each displayed claim and then test signs, normalization, quantifiers, and local arithmetic. No Lean formalization. Exact scripts are separate from on-paper arguments. F means false displayed statement or calculation; G means proof gap or undefined object; R means explicit repair available; C means checked argument, sometimes conditional on corrected inputs. A false statement cannot be retained verbatim, but this is not a claim that the research direction is irreparable.

## Theorem 6.11 (pp.40–42)

**(1), local count and fixed-weight archimedean scaling: C at the indicated elementary level; global denominator rate: G.** Odd integers in an interval meet a nonzero square class with count 2K/p+O(1); the displayed Euler multiplication formula is correct. For fixed k, multiplying an exponentially decaying weight by a fixed power changes log determinants by at most the expected O(kK log K), provided a valid integral representation and bounds have first been established. The necessary beta integral representation is not valid as previously printed (see 6.4). A signed weight also does not automatically justify the positive-measure variational principle used here.

The claimed exact/strict growth of the denominator exponent is stronger than the calculation supplied. At k=1 the displayed difference is exactly zero, so its final strict inequality already needs k>1. Earlier gamma is a signed sum of half-weights. The actual clearing exponent involves max(0,-gamma), so subtracting the same constant from each half-weight does not, without an active-regime argument, imply the displayed change of the minimal clearing exponent. The O(k/M) term does not by itself establish strict positivity for every k and M. Fixed k then K→∞ also does not justify an assertion uniform as k→∞ without tracking constants. **Repair:** give the actual multiplier definition, prove its active regimes, specify the order of limits and uniform error constants; state a lower bound rather than an exact asymptotic if that is all the local estimate supplies.

**(2), polynomial quotient algebra: C.** Substitution t=4 w−1 gives t+(2 j+1)^2=4(w+j(j+1)); monic Euclidean division proves the displayed quotient expansion. This is useful and independent of the analytic representation.

**(2), claimed beta moments and valuation: F under the manuscript's definition.** Equation (6.3) defines the beta(4) constant moment as 1/4, whereas 6.11 uses mu(1)=±1 and v_2(mu(1))=0. The actual valuation of 1/4 is −2. Already the e=0 case contradicts the earlier definition; the general shifted-moment parity assertion is therefore not established. **Repair:** specify one functional consistently, recompute its shifted moments, then restate the obstruction. The quotient identity alone survives. A degree-zero quotient obstructs the specific proposed divisibility mechanism; it does not rule out every possible global content cancellation.

## Theorem 6.12 (pp.42–43)

**Definition and lattice: G/F dependency.** The earlier beta functional is defined on odd-square poles. This theorem silently uses the standard integer-square D_K and a different beta weight, with unresolved references to 'Theorem ??'. The positive derivative weights from the odd-square construction cannot be imported to this different lattice without a definition and calculation. Consequently the advertised unconditional beta conclusions are not established as written.

**(1), abstract sign-flip algebra: C conditionally.** If M=V diag(gamma_j)V^T with gamma_j>0 at poles −a_j^2, multiplying the numerator by t−r^2 replaces M by −V diag((a_j^2+r^2)gamma_j)V^T, which is negative definite. A symmetric pencil with definite derivative is real-rooted regardless of whether its value at the target is definite. This is a valid reusable lemma for any correctly defined lattice.

**(2), continuity repair: C conditionally, 'explicit' not supplied.** For a correctly identified weight w with exactly one simple sign change at u_0, (u^2−u_0^2)w(u)>0 except at u_0, so its finite Gram matrix A_0 is positive definite. Writing A(r)=H−r^2G, the explicit sufficient condition is

$$|r^2-u_0^2|\,\|G\|<\lambda_{\min}(A_0).$$

Rational density proves existence, not the claimed numerical construction or a height bound. A terminating search can be stated using certified interval bounds for the finitely many entries and Sylvester's criterion. With M(r) negative definite, all roots are above the target. This part is worth retaining as an abstract theorem, after the functional is repaired.

**(3), valuations: G.** Multiplication of already proved local diagonal blocks by units preserves their leading valuation. The cited underlying integer-lattice theorem is not identified, and its hypotheses/normalization must first be supplied. In addition, q-integrality of polynomial moments does not follow merely from E_{2 e} being integral when rational normalizing factorials/coefficients are left unspecified. The final 'unconditionally' must retain all stated congruence and unit hypotheses. A strengthening after repair is simultaneous real closeness and a prescribed q-adic unit condition, using rational density in a fixed congruence class; no global denominator bound follows from this.

## Theorem 6.13 (pp.43–44)

**(1), central-factorial differential identity: C.** For f_p(z)=cosh(z)^(−p),

$$f_p''=p^2 f_p-p(p+1)f_{p+2}.$$

Induction therefore proves exactly

$$\prod_{r=1}^{k-1}((2 r-1)^2-D^2)\frac 1{2\cosh z}
=\frac{(2 k-2)!}{2\cosh^{2 k-1}z},$$

and applying −D proves the positive closed form in (6.5). The first k−1 Laplace modes vanish and the rate e^{−(2 k−1)z} is correct.

**(1), series in (6.5): F, explicit sign repair.** The displayed product reverses all k−1 factors without compensating its sign. Replace (−1)^l by (−1)^(l+k−1), or retain (−1)^l and replace every factor by (2 r−1)^2−(2 l+1)^2. At k=2 the printed series has negative leading term −24 e^(−3 z), whereas the closed form has positive leading term +24 e^(−3 z).

**Weight identification and (2): G, then C as abstract matrix implications.** The asserted relation of this differential identity to the previously defined beta functionals is not proved with consistent constants or pole lattices. There is also a definite substitution-sign omission: the evaluated weight of the displayed pencil contains (−1)^(k−m) c-tilde_(k,m) u^(2 k−2 m) w_beta(2 m), not the unsigned sum in the proof. Coefficients c-tilde include powers of pi, so this coupled pencil is not automatically a rational/integer polynomial pencil. Once G(target) and M are both proved positive definite for the same pencil, real roots below the target and positive shifted coefficients follow immediately. Newton inequalities are non-strict in general; strictness requires M not proportional to G. On a valid positive negative-pole representation this follows from M_01<0 while G_01>0, for h≥2. Add that argument explicitly; do not rely on an unsupported assertion that the normalized matrix is nonscalar.

## Theorem 6.14 (pp.45–46)

**(1): F/G, multiple incompatible scale definitions.** The page is visibly clipped on the right and the proof contains unfinished text beginning 'Wait:'. It defines w-tilde(v)=−4 w(2 v), then changes the normalization in the proof. For any genuinely represented functional mu(R)=integral R(u^2)w(u)du, the first definition forces the exact identities

$$\widetilde\mu(R)=-2\mu(R(t/4)),\qquad
\widetilde\mu(t^e)=-2\,4^{-e}\mu(t^e),\qquad
\widetilde\mu((t+j^2)^{-1})=-8\mu((t+(2 j)^2)^{-1}).$$

These are the change-of-variables corrections; the displayed theorem formulas and the several later rescalings cannot all hold simultaneously. Further, evaluating the old functional at even-square poles is outside its stated odd-square domain. A complete repair needs a newly defined functional on the needed poles and a new moment calculation, not a cosmetic factor adjustment.

The claim 'v_p=0' for every odd prime must in any case be weakened to v_p≥0: integer Euler/binomial numerators may contain odd primes (e.g. E_4=5). Dyadic denominators imply odd-prime integrality, not unit valuation.

**(2)(i), weight sign: F, explicit correction conditional on repaired functional.** The functional contains mu-tilde(−tR), hence the combined weight is b w_5−(a/4)v^2 w-tilde_beta 4, not the printed plus sign. The symmetric sufficient cone |a|C_4/4<b would still imply positivity for either sign, but the identity must be corrected.

**(2)(ii), comparison argument: C conditionally.** Given a consistent negative w-tilde_beta 2 and finite ratio bound C_2, a>−b/C_2 yields positivity and two-sided comparison. The small-v limit of the zeta weight in (3.1) is 1/pi for every odd weight, not the printed pi^2/6. The derivative, signature and rate 11.411 then depend on the corrected residue calculation, the parity of N, and the Section 4 spectral estimate. They do not follow from the current inconsistent formulas.

## Theorem 6.15 (pp.46–47)

**(1), beta formula, transcendence and linear independence: C.** The Euler-number formula beta(2 k+1)=q_k pi^(2 k+1), q_k nonzero rational, proves these assertions from transcendence of pi. The collection of all odd beta values has transcendence degree one, not algebraic independence.

**(1), effective power-type measures: valid with a precise replacement citation.** A fixed-degree polynomial lower bound for pi applied to the integer polynomial corresponding to b q_k X^(2 k+1)−a gives a power-type rational-approximation bound for beta(2 k+1). The vague attribution to Mahler does not identify a theorem with the required strength. An explicit valid source is Waldschmidt, *Transcendence measures for exponentials and logarithms* (1978), Corollary 3.2, pp.451–452 of the article: for fixed degree its transcendence measure is linear in log H. Small finitely many denominators can be absorbed into a larger computable C_k, since the value is computable and irrational. For beta(1)=pi/4, the 7.10321 assertion follows from the bound 7.103205334137 for pi in Zeilberger–Zudilin (2019), together with invariance of the irrationality exponent under nonzero rational scaling; see https://arxiv.org/abs/1912.06345.

**(2), moments, strict total positivity, rank-one derivative, exact rational root and root side: C.** Expanding the geometric series and integrating proves the moments; the positive measure and Andreief identity give strict total positivity. The determinant lemma gives exact degree one and

$$|\beta(2 k+1)-r_K|=(v_-^TG^{-1}v_-)^{-1}.$$

For k=0 define eta(1)=log 2 directly: (1−2^{1−s})zeta(s) at s=1 must be interpreted by its removable limit, not literal multiplication by zeta(1).

**Claimed h^(−2 k) prefactor: F for k≥1; explicit asymptotic repair.** At fixed k,N, the correct two-sided order is

$$|\beta(2 k+1)-r_K|\asymp_{k,N}(3+2\sqrt 2)^{-2 h}.$$

The conformal map proves only the exponential rate; it does not introduce the printed algebraic factor. A rigorous comparison proof: after t=u^2 the measure has density proportional to t^(N−1/2)(−log t)^(2 k)/(1+t). It lies between positive constant multiples of the two Jacobi weights t^(N−1/2)(1−t)^(2 k) and t^(N−3/4)(1−t)^(2 k), because 1−t≤−log t and t^(1/(8 k))(−log t)/(1−t) is bounded (k≥1). Both exponents at zero exceed −1. Exterior Jacobi asymptotics imply their Christoffel functions at −1 are comparable to (3+2 sqrt 2)^(−2 h), and the extremal formula transfers both bounds. For k=0 the same conclusion follows directly by comparable Jacobi weights. Reference: DLMF18.15(i), exterior Jacobi asymptotics, citing Szego Theorem 8.21.7/Elliott 1971. Do not infer small primitive integer errors from the unnormalized rational root distance alone.

## Theorem 6.16 (pp.47–48)

**(1): G inherited from 6.14.** With the asserted formal pole coefficients taken as a new definition, the collapse to Z and derivative M is algebraically correct; the stated sign (−1)^(k+1−r) in the weight is the correct substitution sign. The integral interpretation remains unproved until the beta functional is repaired.

**(2): C conditionally, signature correction.** For valid weights with positive finite limits of W/w at 0 and infinity and W>0, compactness gives two-sided comparison. The actual small-v constant of the zeta weight is 1/pi, not the displayed Bernoulli-index expression; bk>0 supplies the positive endpoint limit of the ratio. The signature of M depends on the parity of N+1, not universally (floor(h/2),ceil(h/2)). The Loewner/root-gap argument survives with that correction.

**(3), harmonic valuation bound: F.** The fixed condition p>max(coefficients,2 k+3) does not exclude p^2 or higher powers among harmonic denominators. Example k=2,r=2,p=11,j=31: H_62^(beta,4) contains the unique denominator 121^4 and has valuation−8, not≥−4. This is checked by exact rational arithmetic in late_exact_checks.py. **Repair:** the local bound holds when p>2 sqrt(K), since the odd harmonic denominators are <4K. Small primes need a separate bound. Even the corrected pointwise bound does not establish preservation of the stronger determinant/distribution cancellation, which requires its own local matrix analysis. Thus 'zero quadratic odd-prime overhead' is not established by the supplied argument.

## Theorem 6.17 (pp.48–49)

**Moment formula and (1): C.** The x→x^4 substitution gives the zeta component exactly; the alternating geometric series gives the beta component with H_(2 n). The displayed rational symmetric pencil has derivative CC^T, which is positive definite for independent rows. Generalized symmetric eigenvalues give degree h and real roots. The subquadratic derivative-determinant bound follows under the stated integer polynomial-height assumption. These finite algebraic statements do not need any positivity of the evaluated signed form.

**(2): G/F quantifier, inherited tail gap.** An infinite difference-of-squares decomposition does not establish arbitrarily large positive and negative polynomial subspaces. Theorem 5.2's deletion of the tail is invalid here too. If K is fixed as written, simultaneous h-dimensional positive and negative spaces require K+1≥2 h; K=h=2 already violates this. State 'for every h there exists K' if intended, and then supply a genuine inertia/tail argument. This is not resolved by density.

**(3)(i), odd top-weight block: C at the algebraic level.** For n<2 q and the stated large q, lower beta weights cannot match the leading odd weight's q-adic order. The original zeta block is retained, with kappa_1=2 avoiding its exceptional cancellation. This can be strengthened to arbitrary c in Z_q; an actual integer relation among constants is not used to establish nonvanishing of the formal pencil.

**(3)(ii), even top-weight valuation calculation: F; theorem conditional conclusion remains unsupported.** The proof confuses the index 2 n in H_(2 n) with the odd denominator 2 nu+1. For upper rows the sums contain both q and 3 q, and some lower rows already contain q. A compact exact certificate is k=r=1,a_1=1,b_1=0,q=41,K=40,h=20. For the displayed basis and any integer c, the diagonal of 41^2G(c) modulo 41 is ten entries 37, then 1, then nine zeros; all off-diagonal entries are zero. Its rank is 11. Hence v_41(det G(c))≥−31 (or determinant zero), instead of the claimed−40. The vanishing diagonal factor is 5−4/3^2=41/9. Reproducer: late_exact_checks.py. **Logical boundary:** this refutes the algebraic valuation calculation for the formal pencil; it does not exhibit an integer value of beta(2), so it is not a literal counterexample satisfying the theorem's additional hypothetical integer-relation antecedent. Repair requires a differently designed basis/local block, or an explicit weaker valuation/nonvanishing lemma.

## Theorem 6.18 (pp.49–50)

**(1), degree threshold and vanishing quotient: C.** The inequality 2MN+2 r−2+k+1−r_min≤K−1 proves the claimed absence of polynomial quotient. Require some a_m nonzero to define r_min, and handle the pure-zeta case separately.

**(1), dyadic integrality and spectral consequences: G.** Odd harmonic denominators are 2-adic units, but partial-fraction residues and the undefined correction terms also require analysis; this observation alone does not prove that the full beta pole contribution has only a fixed dyadic loss. 'No 16^e quotient loss' is the precise structural conclusion currently supported. Hyperbolicity/positivity depend on repairing 6.14–6.16 and explicitly imposing the positivity-cone hypotheses of 6.16(2), which are not repeated here; leading-minor interlacing must handle degree drops/roots at infinity as in 3.4.

**(2), degree 42 n−1 and monomial lower bound−4 e: C for the displayed algebra.** At K=30 n,N=3 n,h=27 n,2M=6,k=r_min=2 the quotient-free threshold is 6 n and the largest quotient degree is 42 n−1. For the displayed dyadic moment formula v_2≥−4 e follows from integral Euler and binomial numerators. This is only the polynomial-quotient contribution. The assertion that the old odd-prime multiplier clears the full coupled determinant inherits the unresolved distribution claim of 6.16(3).

**(3): G inherited from 4.5, not a new proof.** The pure-zeta reduction and bounded Bernoulli 2-adic denominators are correct. The effective measure 25687 still requires the missing parameter-specific decay/input in 4.4–4.5 and effective thresholds. Repeating it here does not remove that dependency.

## Section 7 and manuscript-level revisions (pp.51–52)

The discussion correctly presents the weight-seven obstruction as a limitation and the later constructions as research directions; failure to prove zeta 7 irrational is not an audit defect. Revise the proposed routes to remove reliance on false 6.3(2), invalid 5.6(3), and unrepaired beta identities. Distinguish raw derivative determinants from denominator-cleared primitive coefficients. The statement that two-variable derivative determinants have zero quadratic growth requires the integer polynomial-height hypothesis and does not make the entire height barrier vanish. Bounds called universal potential-theoretic invariants need their own existence/scaling hypotheses and a validated normalization.

The supplied PDF contains numerous unresolved cross-references, clipped right-hand formulas (notably pp.33,39,41,45), undefined beta variants and an unfinished derivation onp.45. These obstruct reproducibility and must be corrected after mathematical normalization is settled. They are not merely copyediting when they hide which functional or theorem is intended.

Primary references consulted for this section: [Waldschmidt (1978), Corollary 3.2](https://webusers.imj-prg.fr/~michel.waldschmidt/articles/pdf/JAustralMS25-1978-445-465.pdf); [NIST DLMF 18.15](https://dlmf.nist.gov/18.15); [Zeilberger–Zudilin (2019)](https://arxiv.org/abs/1912.06345).


\newpage

# Reproducibility record

The companion archive contains eight standard-library Python scripts, their captured outputs, and a README mapping each check to the manuscript. Run them with ordinary `python3`, without optimization flags (assertions are part of the checks). The scripts use exact rational or finite-field arithmetic. Decimal displays are informational; certified inequalities use exact rational bounds and justified series remainders.

| Script | Scope |
|---|---|
| `check_section2.py` | Functional identities, basis/residue checks, and the asymmetric-root example |
| `section3_checks.py` | Principal-block degree examples, derivative zero triangle, and exact root-bound counterexample |
| `audit_section4_numeric.py` | Rational interval certificates for spectral and determinant constants |
| `audit_section4_rank.py` | Rank-27 counterexample to the outer-prime rank-14 claim |
| `section5_checks.py` | Pole-refinement, Laurent coefficients, and exceptional-prime checks |
| `h4_counterexample.py` | Exact negative vector in the claimed positive cone; certified upper bound for zeta(7) |
| `section6a_checks.py` | Local compression, formal beta valuations, and triple-pole checks |
| `late_exact_checks.py` | Harmonic valuation and even-beta leading-block counterexamples |

These certificates check the specified finite cases. The general proofs and proposed repairs are given in the preceding sections. The archive is not a Lean formalization and does not certify claims whose status is “unresolved.”
