# Manuscript-first audit: Theorems 6.1–6.10

Source: **Zetahyperbolic (3)(2).pdf**, 52 pages, uploaded in this session. All page numbers below are both PDF and printed page numbers. Scope is the numbered results 6.1–6.10, pp.29–40, not the later results 6.11–6.18. No Lean was used for this audit.

Two passes were performed: first reconstruct the displayed formulas and their actual hypotheses; then attack the proof steps, boundary cases, normalizations, and claimed consequences. A false proof is not automatically classified as a false theorem. Formal rational functionals are distinguished from their claimed analytic integral realizations.

## Verdict map

| Result | Status after both passes | Essential reason |
|---|---|---|
| 6.1(1) | Correct | Exact change of variables and fiber integral. |
| 6.1(2) | Correct | One harmonic summand contributes the unique \(p^{-6}\) pole, and division by \(p\) produces \(p^{-7}\). |
| 6.1(3) local matrix | Correct after wording repair | Invertibility modulo \(p\) excludes **primitive** vectors in the kernel, not all nonzero \(\mathbb Z_p\)-vectors. |
| 6.1 advertised universal barrier | Not established; broad interpretation false | Primitive isotropic compression \(3x^\rho+x^{\rho+p}\) cancels the leading quadratic pole. |
| 6.2(1),(2) | Correct | Exact moments and a common clearing denominator; “exact same denominator” must mean an available bound, not minimal denominator. |
| 6.3(1) | Correct, strengthen-able | Scalar leading reduction modulo \(q\); no irrationality assumption needed. |
| 6.3(2) dimension and pointwise bounds | Correct | Rank-nullity and coefficient \(\ell^1\) control. |
| 6.3(2) positive definiteness | **False** | Exact normalized \(h=4\) counterexample below. |
| 6.4(1) analytic realization | **False** | Constant moment mismatch, pole asymptotics mismatch, and wrong sign in the “positive” differential expression. |
| 6.4(2),(3) formal factorization/hyperbolicity | Correct | Character–Vandermonde sign cancellation is valid for the explicitly defined odd-pole formal functional. |
| 6.5 | Correct for that formal functional | Integral off-diagonals and strictly negative diagonal valuations; exact checks at \(q=17,41\). |
| 6.6(1), main spectral assertions of (2) | Correct | Follows from the valid odd-zeta moment representation and coefficient comparison, with \(a_k>0\). |
| 6.6 “open cone” wording | Repairable | The displayed set without \(a_k>0\) is not open; intersect with that half-space. |
| 6.6(3) pullback identity | Correct | All weights pull back to the same \(x^{2k+1}R(-x^2)\). |
| 6.6(3) exact multiplier rate | Unresolved by the proof | A bounded number of exceptional Hankel moments does **not** imply bounded-rank perturbation. |
| 6.7(1) | Correct | Positive coefficient Gram matrix. |
| 6.7(2) decomposition | Correct | Direct binomial expansion, with the displayed factorials and factor \(1/2\). |
| 6.7(2) explicit definite subspaces | Unresolved after quantifier repair; false for arbitrary fixed \(K\) | Inherited finite-truncation proof drops the infinite tail; inactive top weights also break the asserted independence. |
| 6.7(3) | Correct, strengthen-able | Top active weight dominates; the assumed zeta relation is unnecessary for the local determinant identity. |
| 6.8 | Correct deduction **conditional on 4.5**, not an independent proof | Its unresolved input is the claimed irrationality theorem in Section 4. |
| 6.9(1) as a triple-pole architecture | **False/incompletely defined** | Wrong Laurent coefficient, missing definition of the rational functional, and an incomplete local-node decomposition. |
| 6.9(2) formal double-pole determinant | Repairable to a correct local theorem | The low-pole integrality statement is false, but Hermite vanishing repairs it; this does not repair the separate identification with the printed rational kernel. |
| 6.10(1) finite determinant identity | Correct | Exact leading-coefficient identity. |
| 6.10(1) universal potential comparison | Not proved; displayed variational inequality has the wrong direction | The old equilibrium gives a lower, not upper, bound on the new log-Gram-determinant rate. |
| 6.10(1) “any integer multiple” ratio | False without preserving positive decay | Large multiples make the proposed decay exponent nonpositive. |
| 6.10(2) | Correct | Integral positive Gram determinant and Hadamard; it concerns raw derivative growth, not total primitive arithmetic height. |

## 6.1 — fiber reduction, local poles, and the scope of the barrier (pp.29–31)

### Reconstruction

With \(x_1=u^y,x_2=u^{1-y}\), the Jacobian is \(-\log u\). For \(r\ne s\),

\[
\int_0^1u^{ry+s(1-y)}\,dy=\frac{u^r-u^s}{(r-s)\log u}.
\]

Thus (6.1), including its diagonal term, is correct. The fiber function need not be a polynomial, and for sign-changing \(A\), \(M_{A,A}(u)\) need not be positive. This is a bilinear reduction, not an automatic positive one-variable moment representation.

For \(K/2<p\le K\), a congruent pair crossing \(p\) is necessarily \(r_2=r_1+p\). The difference \(H_{r_2}^{(6)}-H_{r_1}^{(6)}\) has exactly one nonintegral term \(p^{-6}\). Since \(p\nmid6\), the off-diagonal moment has valuation \(-7\). The leading local matrix at \(X\in\mathbb Z_p\) is

\[
p^{-7}L,\qquad L=\begin{pmatrix}0&1/6\\1/6&-1\end{pmatrix},\qquad \det L=-1/36.
\]

This reconstruction is sound. The restriction \(p\ge11\) is stronger than needed for this particular local calculation; \(p>3\) suffices.

### Adversarial check and correction

The phrase “no non-zero \(\mathbb Z_p\)-linear combination” is too strong: multiplying any column by \(p\) removes its \(p^{-7}\) leading term. The proof establishes only that a combination whose coefficient vector is nonzero modulo \(p\) cannot vanish modulo \(p^{-6}\mathbb Z_p^2\).

More importantly, vector-kernel nondegeneracy does not exclude isotropic **quadratic** compression. The primitive vector \((3,1)\) satisfies

\[
(3,1)L(3,1)^T=0.
\]

Consequently \(P_\rho(x)=3x^\rho+x^{\rho+p}\) cancels the \(p^{-7}\) pole in its scalar quadratic value. At \(X=0\), direct substitution gives

\[
B_0(P_\rho,P_\rho)=-9H_\rho^{(7)}-H_{\rho+p}^{(7)}+
\frac{H_{\rho+p}^{(6)}-H_\rho^{(6)}}p.
\]

The two \(p^{-7}\) contributions cancel exactly. The remainder is at least \(p^{-1}\mathbb Z_p\); for \(p\ge11\) the complete nonzero-residue sixth-power sum improves this to \(\mathbb Z_p\).

For the entire compression basis \(\{3x^\rho+x^{\rho+p}:0\le\rho<p\}\), the off-diagonal \(p^{-6}\) contributions cancel as well. If \(d=s-r\ne0\), their sum is exactly

\[
\frac{p^{-6}}2\left(\frac1{p+d}+\frac1{p-d}\right)
=\frac{p^{-5}}{p^2-d^2},
\]

up to a \(p\)-integral remainder. Thus every off-diagonal entry has valuation exactly \(-5\). An exact check at \(p=11\) additionally gives diagonal valuations in \({0,1}\). This does not prove a new denominator asymptotic for arbitrary constructions, but it decisively prevents the local nonsingularity result from being advertised as a universal prohibition on pole cancellation or denominator improvement.

**Downstream:** retain the local matrix lemma; remove the universal-barrier conclusion unless its class of allowed transformations is precisely restricted and a separate proof is supplied.

## 6.2 — simultaneous weight-six and weight-seven functional (pp.31–32)

Both moment identities are correct:

\[
\iint x_1^m x_2^{m+1}d\Omega_7=\frac1{6(m+1)^6},\qquad
\iint\frac{(x_1x_2)^r x_2}{1-x_1x_2}d\Omega_7=
\frac16(\zeta(6)-H_r^{(6)}).
\]

The geometric-series calculation is monotone for the individual monomials; the finite polynomial extension is then justified by linearity. Expanding \(A\) gives exactly the displayed coefficients \(\alpha\sum c_r^2\) of \(\zeta(7)\), \(\beta\sum c_r\) of \(\zeta(6)\), and the stated rational part, including the off-diagonal sign.

For \(K\ge1\), \(6d_K^7\) clears the rational part because every \(m^6|r-s|\) divides \(d_K^7\). This is an available common denominator; it is not a proof that the reduced denominator is exactly \(6d_K^7\), nor that it is optimal.

**Useful limitation:** the coefficient of \(\zeta(6)\) is \(\beta A(1)\). Every polynomial in the later space \(x^{2h}(1-x)^hQ(x)\) has \(A(1)=0\). Thus directly feeding those polynomials into this simultaneous functional kills the weight-six term. Combining the two proposed advantages requires an additional construction.

## 6.3 — unconditional nonvanishing and the false explicit positive cone (pp.32–33)

### Part (1): sound and stronger than stated

For \(A_\rho=x^\rho+x^{\rho+q}\), the coefficient Gram matrix is \(2I_q\). At \(X=0\),

\[
q^7G_{A_q}(0)\equiv-\frac23I_q\pmod q.
\]

Off-diagonal entries before scaling have valuation at least \(-6\). Hence \(v_q\det G_{A_q}(0)=-7q\), and the same holds for every \(X\in\mathbb Z_q\). Exact rational checks give \(-35,-49,-77\) for \(q=5,7,11\), respectively.

The proof actually works whenever \(v_q(X)>-7\). If \(v_q(X)<-7\), \(2XI_q\) dominates and the determinant cannot vanish either. Thus a rational root, if one exists, must have valuation exactly \(-7\), and its leading residue must satisfy \(q^7X\equiv1/3\pmod q\). The stated condition \(q\nmid b\) is only a weak sufficient exclusion. This remains a local fact about a family of determinant polynomials, not an irrationality argument by itself.

### Part (2): correct dimension count, false positivity

The \(3h\) displayed orthogonality constraints are rational linear equations in \(4h\) coefficients, so the dimension bound is correct. At \(h=4\), the exact matrix below has rank 12, so the dimension is exactly 4.

Define the \(12\times16\) rational matrix

\[
C_{(m,\nu),j}=\sum_{k=0}^4(-1)^k\binom4k
\left(\frac{\nu!}{(9+j+k+m)^{\nu+1}}-
\frac{(5-\nu)!}{(9+j+k+m)^{6-\nu}}\right),
\]

where \(m=0,\ldots,3\), \(\nu=0,1,2\), \(j=0,\ldots,15\). Its first twelve columns are invertible. Let \(q\) be the unique vector satisfying \(Cq=0\) and

\[
(q_{12},q_{13},q_{14},q_{15})=
\left(-\frac{1619679775589}{250000000000},1,0,0\right).
\]

Set

\[
P(x)=\frac{x^8(1-x)^4}{150}\sum_{j=0}^{15}q_jx^j.
\]

Every constraint holds exactly, \(P\ne0\), and the normalized coefficient norm is **strictly less than \(99/100\)**. Thus this is inside the theorem's normalized space, not merely near it.

Using Theorem 5.1's moment formula and a directly certified rational upper bound

\[
U=\frac{252087319345480706709949387462449189899965890141309676604321}
{250000000000000000000000000000000000000000000000000000000000}
>\zeta(7),
\]

exact rational arithmetic gives

\[
B_{\zeta(7)}(P,P)<B_U(P,P)<-\frac5{10^{53}}<0.
\]

The display value is \(B_U(P,P)\approx-5.3835676066865585455\cdot10^{-53}\). The proof of \(U>\zeta(7)\) uses only 240 rational Euler-transform terms: \(a_k=\sum_{j=0}^k(-1)^j\binom kj/(j+1)^7\in[0,1]\), \(\eta(7)=\sum a_k/2^{k+1}\), and the tail is at most \(2^{-240}\). No numerical zeta oracle is used.

The reproducible script is `h4_counterexample.py`; `--full` prints every coefficient and the full exact negative fraction. This certificate is independent of the prior Lean project.

The invalid step on p.33 is the assertion that “concentration” of \(x^{2h+m}(1-x)^h\) makes the entire remaining Krein tail positive for every sign-changing \(Q\). It does not. Finite orthogonality eliminates only the specified finitely many negative terms.

### What remains salvageable

The pointwise estimate \(|A_i(x)|\le4^{-h}x^h\) is correct. Therefore every matrix entry, in absolute value, is at most

\[
M_h=4^{-2h}(\zeta(7)-H_h^{(7)})\le\frac{4^{-2h}}{6h^6}.
\]

Without positive definiteness one can still conclude \(|\det G|\le h^{h/2}M_h^h\) by row-norm Hadamard. This preserves strong analytic decay for normalized bases, but supplies neither nonvanishing nor a primitive arithmetic-height estimate.

Rational row scaling \(A_i\mapsto\lambda_iA_i\) multiplies the determinant polynomial by \((\prod_i\lambda_i)^2\). Removing rational content leaves its primitive polynomial unchanged. Thus the \(\ell^1\le1\) normalization itself gives no control of primitive determinant height or denominators.

## 6.4 — beta-four analytic failure, formal algebraic success (pp.33–34)

### The definition is an odd-square formal functional

The domain on p.33 has simple poles only at \(-(2j+1)^2\). It is not a functional on all integer-square poles. Its constant moment is

\[
\mu_X^{(\beta(4))}(1)=\frac14.
\]

No legitimate extension to every negative integer square is defined in 6.1–6.10. A later switch to a full integer-square \(D_K\) must supply a new definition and prove its compatibility; odd-square sign cancellation does not automatically transfer.

### Part (1) is false in multiple independent ways

The displayed weight is

\[
w(y)=-\frac{y^4}{6\pi^2}\frac{d^3}{dy^3}
\frac{\pi}{2\cosh(\pi y/2)}.
\]

Three integrations by parts give

\[
\int_0^\infty w(y)\,dy=\frac{16\beta(2)}{\pi^3}>\frac49>\frac14.
\]

The strict inequality follows from \(\beta(2)>1-1/9=8/9\) and \(\pi^3<32\). Thus even \(R=1\) contradicts the asserted representation. More generally the actual moments of this weight are

\[
\int_0^\infty y^{2e}w(y)\,dy=
\frac{2^{2e+2}(2e+4)!}{6\pi^{2e+3}}\beta(2e+2),
\]

not the rational Euler-number moments in (6.3). The stated auxiliary Euler integral is also mis-scaled: \(\int_0^\infty y^{2e}\operatorname{sech}(\pi y/2)dy=|E_{2e}|\), not \(|E_{2e}|/2^{2e}\).

There is a second incompatibility that cannot be fixed by changing only the weight's scalar prefactor. At \(X=\beta(4)\), the formal pole values (6.4) tend to \(-1/6\) as \(j\to\infty\): the beta tail times \((2j+1)^3\) is \(O(1/j)\). Any integrable signed weight has

\[
\int_0^\infty\frac{w(y)}{y^2+(2j+1)^2}\,dy\longrightarrow0.
\]

Finally, put \(z=\pi y/2\). The claimed “positive” expression on p.34 actually equals

\[
\frac{y^4}{24}\left(-\frac4{\pi^2}D_y^3+D_y\right)
\frac1{2\cosh z}
=-\frac{\pi y^4\sinh z}{16\cosh^4z}<0.
\]

The proof differentiates with the opposite sign. Its printed positive right-hand side also has a different power of \(\pi\). Correcting this operator alone would still not repair the incompatible functional.

### Parts (2),(3) remain correct for the formal pencil

For the odd nodes \(v_j=-(2j+1)^2\), polynomial terms are independent of \(X\), and partial fractions give precisely the displayed derivative factorization. The signs are

\[
(-1)^j\cdot(-1)^N\cdot(-1)^{j-N}=+1.
\]

Hence every \(\gamma_j>0\), the derivative matrix is positive definite, and the formal determinant polynomial has exact degree \(h\) and real roots. This proof does not require the false beta integral representation or positivity at \(X=\beta(4)\). It gives no unilateral root location relative to that value.

## 6.5 — formal beta-four q-adic nonvanishing (pp.34–35)

This result survives for the functional defined by (6.3),(6.4). With \(q=8m+1\), \(N=4m\), \(K=5m\), the remaining poles are \(q+2r\), \(0\le r<m\). Their squared residues are distinct modulo \(q\), so the evaluation Vandermonde is unimodular.

In the Lagrange basis the off-diagonal rational functions are polynomials with coefficients in \(\mathbb Z_q\); all polynomial moments have only powers of 2 as denominators. At \(r=0\), the pole value has valuation \(-1\) and the numerator factor is a unit. At \(r>0\), the pole value has valuation \(-4\) and the numerator has exactly one \(q\)-factor. Thus diagonal valuations are \(-1,-3,\ldots,-3\), while off-diagonal entries are integral.

The identity permutation uniquely has lowest determinant valuation; equivalently scale rows to make the diagonal units and all off-diagonal terms vanish modulo \(q\). This proves

\[
v_q\Delta_K(0)=-(3m-2).
\]

Exact checks in `section6a_checks.py` give \(-4\) at \(q=17\) and \(-13\) at \(q=41\). These checks supplement, rather than replace, the general proof. The theorem is a result about the formal odd-lattice pencil and does not rescue its claimed analytic realization.

## 6.6 — multi-weight positive pencils (pp.35–36)

### Parts (1),(2): substantial valid content

At the pole \(-j^2\), multiplying by \((-t)^{k-m}\) multiplies the \(X_m\)-residue by \(j^{2k-2m}\), so all variable coefficients become \(j^{2k}\). Thus the pencil depends only on \(Z=\sum a_mX_m\), and its derivative is exactly the pure top-weight derivative matrix.

The odd-zeta integral formula (3.2), independently checked in the Section 3 audit, is valid. Substitution therefore gives exactly

\[
W_a(y)=2y^{2k+1}\sum_{\ell\ge1}P_a(\ell)e^{-2\pi\ell y},\quad
P_a(\ell)=\sum_m(-1)^{k-m}a_m\frac{(2\pi\ell)^{2m}}{(2m)!}.
\]

If \(a_k>0\) and all \(P_a(\ell)>0\), the ratios \((2k)!P_a(\ell)/(2\pi\ell)^{2k}\) tend to \(a_k>0\); their infimum is positive and their supremum finite. The weight comparison, Loewner comparison, positive definiteness, real-rootedness, inertia-based signature, and stated zero-free disk follow. For an indefinite derivative matrix the norm comparison is still valid, using

\[
\|G^{-1/2}MG^{-1/2}\|=\sup_{v\ne0}\frac{|v^TMv|}{v^TGv}.
\]

The displayed set called an “open cone” omits \(a_k>0\). Taken literally in \(\mathbb R^k\), it is not open: for \(k=2\), \((-1,0)\) belongs to it, while arbitrarily small negative perturbations of its top coordinate fail positivity for large \(\ell\). Intersecting with \(a_k>0\), as the theorem's initial hypotheses already require, repairs the terminology and comparison statement.

### Part (3): split the identity from the arithmetic assertion

The pullback identity is exact. The assertion about an **exact same quadratic multiplier rate**, up to \(e^{O_a(K)}\), is not established by the supplied argument.

The critical claimed implication is false: having only \(O_k(1)\) exceptional moment indices \(e=i+j+\text{constant}\) does not imply a rank-\(O_k(1)\) perturbation. A Hankel perturbation supported at the single moment \(e=h-1\) is the reverse-identity matrix and has rank \(h\). An exceptional anti-diagonal in the actual index range can similarly have rank proportional to \(K\).

Top-weight domination can plausibly preserve suitable local **integrality upper bounds**, but the manuscript must give the relevant lattices/minor estimates and separately control small primes and actual content. It cannot replace that work by counting exceptional moments. No counterexample to every possible corrected multiplier theorem is asserted here; the present exact-rate conclusion is unresolved.

## 6.7 — universal multi-weight Beukers pencil (pp.37–38)

### Part (1): correct without a cone restriction

The derivative \(CC^T\) is positive definite because the rows of \(C\) are independent. Congruence by its positive square root turns the pencil into \(ZI+H\) with \(H\) real symmetric. Real-rootedness and exact degree follow for every nonzero tuple \(a\), without any sign assumption on the coupled measure.

### Part (2): identity correct; definite-subspace conclusion not proved

For each \(m\), the binomial coefficient divided by \((2m)!\) is \(1/[2m\nu!(2m-1-\nu)!]\). Pairing complementary exponents gives the stated \(\Phi^\pm\) and the factor \(1/2\). Thus the Krein identity is correct. Polynomial test functions require only elementary dominated convergence; the \(L^2\) extension can be justified with the bounded Hilbert moment operator and the extra logarithmic decay in the paired factors.

Two problems remain in the construction claimed after that identity:

1. If the top active index \(m_*<k\), the asserted family is not linearly independent. For \(k=2,a=(1,0)\), at every \(n\), \(\Phi^+_{n,0}-\Phi^-_{n,0}-\Phi^-_{n,1}=0\). Replacing \(k\) by the top active index fixes this particular defect.
2. The projection argument imported from Theorem 5.2(3) discards all \(n>M\) terms of an infinite Krein series after imposing orthogonality only for \(n\le M\). No sign or norm control of the omitted tail is proved. The exact \(h=4\) failure of 6.3(2) shows that this issue is substantive.

If the statement is read as promising both \(h\)-dimensional definite subspaces inside an arbitrary already fixed \(\mathbb Q[x]_{\le K}\), it is false by dimension alone whenever \(K+1<2h\), for example \(K=h=2\). Positive and negative indices cannot both be at least \(h\) in dimension \(K+1\). The intended statement must quantify “for sufficiently large \(K\) depending on \(h,a\)”. Even after that repair, the supplied proof does not establish existence or explicitness. This audit leaves that repaired existence theorem unresolved, rather than calling it false.

### Part (3): correct and can drop the zeta-relation assumption

Let \(s_*=2m_*+1\). For the stated two-monomial basis, the leading diagonal scalar is

\[
a_{m_*}(\kappa/m_*-\kappa^2)q^{-s_*}.
\]

It is a \(q\)-adic unit times \(q^{-s_*}\): use \(\kappa=1\) for \(m_*\ge2\), and \(\kappa=2\) for \(m_*=1\). All off-diagonal entries have valuation at least \(-(s_*-1)\); all lower-weight diagonal contributions are less singular. Reduction modulo \(q\) proves the displayed valuation.

Nothing in this argument requires \(\sum a_m\zeta(2m+1)=c\). It works for **any** \(Z\in\mathbb Z_q\) substituted into the formal pencil, and more generally \(v_q(Z)>-s_*\). This is useful unconditional local nonvanishing, but is not by itself a contradiction to any hypothesized rational relation.

## 6.8 — three-term linear-independence cone (p.38)

The deduction from Theorem 4.5 is formally correct: after changing signs to make \(b>0\), irrationality of \(b\zeta(5)+a\zeta(3)\) rules out equality to an integer. The case \(a=b=0,c\ne0\) is immediate; the \(b=0,a\ne0\) case uses Apéry's theorem.

Likewise, multiplying a fixed-direction rational-approximation bound by \(q\) reduces its exponent by one. The extra reference to a strict numerical margin is not needed if the stated bound \(q^{-25687}\) is already available.

This result adds no independent justification of the crucial irrationality input. In particular the choice \(a=0,b=1\) is already a major specialization of the Section 4 claim. Its unconditional status must follow the verdict on 4.5; it cannot be certified from Section 6 alone. No numerical counterexample to the irrationality assertion is claimed.

## 6.9 — triple poles and formal multi-weight double poles (pp.38–39)

### Part (1): the printed rational architecture fails an exact local test

The printed rational function has numerator \(\prod_{j=1}^n(t-j+1)^6\). At \(t=0\) it has a zero of order 6 against a denominator zero of order 3, so it has **no pole at all**. Nevertheless the printed leading Laurent coefficient gives \(C^{(3)}_{n,0}=n!\ne0\).

For \(k\ge1\), direct evaluation gives the true leading coefficient

\[
C^{(3),\mathrm{true}}_{n,k}=(-1)^k\binom{6n}{k}^3
\left(\prod_{j=0}^{n-1}(k+j)\right)^6.
\]

At \(n=1,k=1\), this is \(-216\), whereas the printed coefficient is \(-13824\). These are exact contradictions, not asymptotic concerns. Shifting the numerator roots and supplying factorial normalizations could define a different kernel with the advertised coefficients, but would require a new theorem and a recheck of all local claims.

There are further independent defects:

- Since \(R_n^{(3)}P=O(t^{-2})\) throughout the stated degree range, the sum of its simple-pole residues is zero. Under the displayed polylogarithmic functional, the coefficient of \(\zeta(s)\) therefore vanishes identically. The actual direct residue expression involves at most \(1,\zeta(s+1),\zeta(s+2)\), not three freely coupled zeta coefficients.
- A nonzero individual leading pole coefficient does not prove that the **sum** defining the \(\zeta(s+1)\)-coefficient is nonzero on the restricted polynomial space. There can be global residue identities. The specific middle coefficient does occur, for example at \(n=1,P=1\), where the sum of true double-pole coefficients is \(27243216/5\ne0\); this example is not a proof of the claimed all-\(n\) assertion.
- The rational functional \(L_n^{(3)}\) used in the determinant is not explicitly defined. One assumed relation \(a_0\zeta(s)+a_1\zeta(s+1)+a_2\zeta(s+2)=c\) does not turn arbitrary residue combinations of these numbers into rational values. Proportionality of every coefficient vector to \((a_0,a_1,a_2)\), or a different explicit rational functional, would have to be supplied.
- At \(n=2m,q=9m+1\), there are **\(3m\)** poles \(q,\ldots,12m\). The proof imposes three-jet conditions at only **\(m\)** of them, then treats the leading matrix as block diagonal. The other \(2m\) poles have not disappeared. The claimed determinant size and valuation therefore do not follow from the proposed Hermite argument.
- For the actual printed kernel, the leading coefficient at \(k=q\) also has a factor \(q^6\), contrary to the unit assertion based on the incorrect binomial formula.

Thus the specific triple-pole determinant theorem is not a valid established result. The generic observation that an order-three pole produces consecutive polylogarithmic weights is correct, but it is much weaker.

### Part (2): a salvageable formal theorem, with an explicit proof repair

Take (5.8), with its displayed \(A_{n,k},B_{n,k}\), as the **definition** of a rational polynomial functional, and make the stated substitutions for \(U_k,V_k\). Then the highest active weight \(s_d\) dominates \(U_{q+r}\), and \(A_{n,q+r}/n!\) is a unit. This supports the claimed block argument.

One inherited sentence is false: \(B_{n,k}/n!\) need not be integral for every \(k<q\). For example \(q=19,n=4,k=0\) gives valuation \(-1\). The correct repair uses the Hermite basis itself:

- The only low-pole \(q^{-1}\) contributions from \(B/n!\) occur at \(k=r<3m\). The potentially troublesome range \(n+k\ge q\) has enough \(q\)-factors in the binomial coefficient to compensate the harmonic denominator.
- The point \(-r\) is congruent modulo \(q\) to the high interpolation node \(-(q+r)\). Every derivative/odd Hermite basis polynomial vanishes modulo \(q\) there.
- Consequently the low-pole correction has even/odd block valuation bounds at least \(\begin{pmatrix}-1&0\\0&1\end{pmatrix}\), not merely an unsupported global integrality assertion.
- The displayed scaling multiplies even-even, even-odd, and odd-odd entries by \(q^{s_d+1},q^{s_d},q^{s_d-1}\), respectively. All low corrections then vanish modulo \(q\), even when \(s_d=2\).

The high-pole blocks reduce to \(\begin{pmatrix}*&-a_d A/n!\\-a_d A/n!&0\end{pmatrix}\), whose determinants are units. This proves \(v_qJ_{2m}=-6s_dm\) for the explicitly defined formal functional. Half-integer diagonal exponents can be avoided entirely by defining the resulting entrywise scalings, which have integer exponents, or by using asymmetric integral row/column scalings.

As in 6.7(3), the algebraic identity does not need the assumed equality among zeta values: \(c\in\mathbb Z_q\) suffices. However, this repair does **not** validate the separate identification of (5.8) with the printed double-pole rational kernel. That identification is audited in Section 5 and already has elementary Laurent-coefficient discrepancies.

## 6.10 — exact identity versus unsupported potential-theoretic universality (pp.39–40)

### The finite algebraic identity is correct

If \(G_K=G_K(\xi)\) is positive definite, \(M_K\) is nonsingular, and \(B_K=G_K^{-1/2}M_KG_K^{-1/2}\), then exactly

\[
|[X^h]Q_K|=Q_K(\xi)|\det B_K|.
\]

Therefore, whenever the displayed limits exist, \(\Lambda_{\rm lead}+\epsilon=I_B\). This is normalization invariant and is useful. It does not require equilibrium measures.

### The rest of part (1) needs major qualification

Arbitrary positive rational kernels \(W_K/D_K\) do not by themselves supply a limiting external field, an equilibrium measure, existence of both determinant limits, or the stated shared normalization constant. These regularity and scaling assumptions must be stated before identifying the limits with weighted energies. “Pole energy” must also include the actual residue weights, rather than merely an unweighted negative-lattice energy.

The claimed comparison after multiplication by \(P_K^2\) has a reversed variational step. Write the original energy as \(E(\mu)\), minimized at \(\mu_0\), and let \(U(t)\) be the logarithmic potential of the added roots, with the sign convention used in the manuscript's determinant increments. The new minimum satisfies

\[
E_{\rm new}=\min_\mu\{E(\mu)-2\!\int U\,d\mu\}
\le E(\mu_0)-2\!\int U\,d\mu_0.
\]

Hence the new **log Gram determinant** rate increases by **at least** \(2\int U\,d\mu_0\), not “at most” as p.40 states. Subtracting this rate from the explicitly changed derivative determinant gives an **upper** bound on the new \(I_B\) using the old equilibrium, opposite to the displayed lower bound. A lower bound instead involves control at the new equilibrium. No strict positive potential gap follows from the supplied argument.

The phrase “any polynomial family” also omits the degree/mass scaling needed for a nonzero quadratic perturbation. Fixed-degree Christoffel factors have zero root mass at the \(1/K\) normalization and cannot support a universal strictly positive quadratic increment. The claimed strictness requires a positive limiting root mass and a separate strict comparison.

For integer rescalings \(\widetilde Q_K=c_KQ_K\), if \(K^{-2}\log c_K\to\rho\), then

\[
\widetilde\Lambda_{\rm height}=\Lambda_{\rm height}+\rho,
\qquad \widetilde\epsilon=\epsilon-\rho.
\]

Thus their sum is exactly invariant where these limits exist. The stated height-to-decay ratio bound can only be asserted if \(\widetilde\epsilon>0\). Taking, for example, \(c_K=\lceil e^{K^2}\rceil\) destroys a decay exponent bounded above by \(0.0004\); the ratio conclusion for “any integer multiple” is then false or undefined. Even after repairing this hypothesis, the numerical \(0.23310\) and \(581\) bounds concern the particular Section 4 weight-five family and depend on that section's quantitative proof. They are not established universal constants for all kernels.

### Part (2): correct, with a broader useful hypothesis

For integral \(C_K\) of full row rank, \(C_KC_K^T\) is positive definite with a positive integer determinant. Hadamard gives exactly

\[
1\le\det(C_KC_K^T)\le(K+1)^hK^{2Ah},
\]

so its \(K^{-2}\log\)-rate is zero. Polynomial coefficient height can be weakened to \(\log\max(1,|C_{i,r}|)=o(K)\).

This eliminates quadratic growth of the **raw derivative Gram determinant** under those coefficient assumptions. It does not eliminate clearing-denominator growth, the intercept's arithmetic height, primitive content issues, or the need to construct small nonzero values with those same coefficient bounds. A pencil with derivative \(I_h\) can still have exponentially large rational denominators in its constant part, and hence a primitive leading coefficient of quadratic exponential size after clearing. The theorem is a useful structural distinction, not a completed height-to-decay argument.

## Reproducibility and retained results

Run:

```text
python3 h4_counterexample.py
python3 h4_counterexample.py --full
python3 section6a_checks.py
```

All scripts use Python's standard-library exact `Fraction` arithmetic. The only decimal output is a display of an already certified rational number. No Lean compilation, floating zeta oracle, or numerical eigenvalue sign is used in the certificates.

The strongest retained results are the fiber and simultaneous-weight identities; local nonvanishing of 6.3(1), 6.5, and 6.7(3); formal odd-beta hyperbolicity; the multi-weight positive-cone spectral comparison; the exact multi-weight Krein identity; the repaired formal double-pole nonvanishing; and the raw derivative-Gram growth estimate. None should be discarded merely because adjacent analytic or asymptotic claims fail.

The main blocked downstream steps are the explicit positive-cone decay construction, analytic use of the beta-four formal functional, the exact multi-weight multiplier rate, the asserted explicit infinite-dimensional definite-subspace construction, the triple-pole rational determinant, and the universal potential-gap inequality. Each needs the specific repair or missing theorem identified above.
