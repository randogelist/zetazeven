# Independent audit of Section 4 of the 52-page manuscript

**Audited document:** `upload/Zetahyperbolic (3)(2).pdf`, printed pages 14–22, using the corresponding `tmp/pdfs/new_upload_review/paper.txt`. This report audits Theorem 4.1 through Conjecture 4.11 and the arithmetic specialization immediately before Theorem 4.4. It does not assume conclusions from an earlier version. The section was read in order, then checked again by reconstructing each proof and tracing dependencies backwards. The preceding integral and derivative identities are identified as inputs rather than independently certified here. No Lean claims are made.

## Overall finding

The generic real, algebraic, and ultrametric transfer arguments are substantially sound. The analytic spectral estimate can be repaired explicitly: the displayed numerical calculations contain several errors, but rigorous rational interval calculations actually give enough margin for the stronger eventual bound `||B_K|| ≤ exp(11.407 K)`. That is a useful result independent of the arithmetic normalization.

The asserted arithmetic applications are not established by this section as written. The cited source uses a different parameter sequence and does not provide the stated `K=30n` normalization/decay certificate. The mixed-weight argument additionally contains an exactly false rank bound. The lower height estimate uses an upper bound in the wrong direction. The global rational-root exclusion reverses a zero-free lower bound into a clustering upper bound. Later variational and phase-transition claims require additional arguments that are not present.

These findings do **not** disprove the irrationality statements themselves. They distinguish a valid conditional theorem, a repairable proof, a false intermediate assertion, and an unsupported conclusion.

## Result-by-result status

| Item and printed pages | Status | Precise qualification |
|---|---|---|
| Theorem 4.1, pp. 14–15 | Correct qualitative transfer; effectivity requires an explicit additional hypothesis | Eventual hypotheses imply the claimed irrationality exponent. An effectively computable onset is not supplied by the bare words “for all sufficiently large K.” |
| Proposition 4.2, p. 15 | Correct; quantitatively improvable | The factor `d` in the numerator of the exponent is unnecessary. The resultant argument gives `λρ/(ε−(d−1)Λ_height)`. |
| Proposition 4.3, p. 15 | Correct on paper | This is the integral-coefficient ultrametric Lipschitz estimate. Its open-disk boundary is essential. |
| Arithmetic setup (4.2)–(4.3), p. 16 | Missing external input | The actual cited Fauzan PDF uses `K=40n, N=3n, h=37n`, not `K=30n, N=3n, h=27n`. The manuscript's new constants and multiplier require a separate certificate. |
| Theorem 4.4, pp. 16–18 | Spectral part repairable; arithmetic conclusion conditional | Corrected concavity and numerical bounds prove the spectral claim, even with `11.407`. The irrationality measure and its effectivity still depend on the missing arithmetic certificate. |
| Theorem 4.5, pp. 18–19 | Claimed unconditional theorem unproved; rank lemma false | The weight comparison is sound. The claimed outer-prime correction rank `≤14` fails: the actual construction gives rank `27` for `K=30, N=3, p=17`. |
| Theorem 4.6(1), pp. 19–20 | Numerical proof repairable, with a separate external dependency for its lower bound | The determinant upper bound survives corrected arithmetic. The lower bound needs the unverified `K=30n` estimate `U≤2.32380`. |
| Theorem 4.6(2), pp. 20–21 | Mixed: conditional upper bounds sound; lower height claim unproved | Upper heights and the primitive decay interval follow conditionally. The lower height proof reverses `A_M≤−2.32425`; it needs a lower bound on `A_M`. |
| Theorem 4.7, p. 21 | Correct conditional consequences, with a repair to the quoted separation formula | The root-count argument is sound. Mahler's separation inequality uses Mahler measure, not the naive coefficient height as printed. The loose final estimate survives. |
| Proposition 4.8, pp. 21–22 | Local assertion and degree inequalities correct conditionally; global exclusion unproved | The proof of “no rational root with denominator ≤ exp(K/2251)” reverses the root-gap inequality and also has a numerical mismatch. |
| Remark 4.9, p. 22 | Partly correct, partly unproved | The direct norm sandwich follows conditionally. Inserting `ρ_var` requires an additional asymptotic variational theorem. The numerical lower certificate and the claimed exponent barrier are not established. |
| Remark 4.10, p. 22 | Unsupported implication; claimed inference admits counterexamples | Real roots and exponential collapse do not prove existence of the proposed free-energy limit or a first-order transition. Lee–Yang's circle theorem does not apply merely from real-rootedness. |
| Conjecture 4.11, p. 22 | Properly a conjecture, unresolved | The existence/equality assertion is not established. The admissible measure class in `ρ_var` needs specification. |

## 1. Theorem 4.1: the transfer mechanism and the effectivity issue

Let `D_K=deg Q_K≤λK`, and suppose the two eventual bounds in the statement hold. Choose

`λ/ε < c < μ/ρ`, and `K=d₀ floor(c log b/d₀)`.

If `|a/b−ξ|≤b^(−μ)`, set `δ=a/b−ξ`. For every root,

`|δ/(ξ−r_j)| ≤ b^(−μ+ρc) = o(1/K)`.

Consequently the product

`Q_K(a/b)/Q_K(ξ) = ∏_j (1+δ/(ξ−r_j))`

has absolute value between `1/2` and `2` for sufficiently large `b`. This applies to complex roots as well; real-rootedness is not required. In particular `Q_K(a/b)≠0`. Integrality gives

`1 ≤ |b^D_K Q_K(a/b)| ≤ 2 exp(D_K log b−εK²)`.

Since `log b=(K+O(1))/c`, the exponent is at most

`(λ/c−ε)K²+O(K)`,

which is negative for all sufficiently large `K`. This is a contradiction. The strict final inequality and the floor in `K` cause no difficulty. Constant integer polynomials cannot satisfy the nonzero decay hypothesis eventually, so the zero-degree case is harmless.

The qualifier **“effectively computable”** is not justified by the abstract assumptions alone. To compute a threshold, one needs a computable onset `K₀` for both inequalities, together with effective descriptions/bounds for the constants. The theorem can be repaired in either of two explicit ways:

1. State the qualitative existence of `b₀`; or
2. Add a supplied effective `K₀` and effective constants, then compute a threshold using `K≥K₀`, `λK b^(−μ+ρc)` small enough for the product estimate, and `2 exp(λK log b−εK²)<1`.

For the manuscript's stated constants,

`λρ/ε = (0.9)(11.411)/(0.0004) = 25674.75`.

Thus, **if** the normalization and decay hypotheses are established, Theorem 4.1 already yields every exponent strictly exceeding `25674.75`; the integer exponent `25675` is available. The printed `25687` comes from the convenient but nonoptimal choice `c=2251`, for which `ρc=25686.161`. No change to the spectral proof is needed for this first improvement.

## 2. Proposition 4.2: correct algebraic transfer and a stronger exponent

Write `Λ=Λ_height`, let an approximant `α=α₁` have degree `m≤d` and naive height `B`, and let its primitive minimal polynomial be

`f(X)=b_m ∏_{s=1}^m (X−α_s)`.

Take the leading coefficient positive without loss of generality. The root-gap argument of Theorem 4.1 gives

`0<|Q_K(α₁)|≤2 exp(−εK²)`.

Since `f` is irreducible and does not divide `Q_K`, the resultant is a nonzero integer. For `s≥2`,

`|Q_K(α_s)|≤(D_K+1)H(Q_K) max(1,|α_s|)^D_K`.

Using the Mahler-measure bound

`b_m ∏_{s=1}^m max(1,|α_s|) ≤ sqrt(m+1) B`,

one obtains directly

`1 ≤ |Res(Q_K,f)|`

`≤ 2 exp(−εK²) [(D_K+1)H(Q_K)]^(m−1) [sqrt(m+1)B]^D_K`.

For `K=c log B+O(1)`, its logarithm is at most

`[(m−1)Λ−ε+λ/c]K²+o(K²)`.

The manuscript replaces the final `λ/c` by the larger `λm/c`. This weakens the result but does not invalidate it. A stronger theorem under exactly the stated assumptions is therefore:

> If `ε>(d−1)Λ`, then every exponent `μ_d>λρ/(ε−(d−1)Λ)` excludes sufficiently close algebraic approximations of degree at most `d` and sufficiently large naive height.

The assumption itself also excludes `ξ` being algebraic of degree at most `d`: apply the same resultant argument to its fixed minimal polynomial, where the height factor contributes only `O(K)`.

No effective threshold is claimed in this theorem, and a mere limsup height hypothesis would not by itself supply one. For an application to the height bound `Λ=10.27` later in this section and the conservative `ε=0.0004`, the strict condition fails for every `d≥2`; Proposition 4.2 does not yield a nontrivial higher-degree approximation result from those particular constants.

## 3. Proposition 4.3: the p-adic disk is valid and sharp at the boundary

Taylor coefficients of `Q(ξ_p+W)` lie in `Z_p` because `Q∈Z[X]` and `ξ_p∈Z_p`. Since `|Q(ξ_p)|_p≤1`, every `α` in the specified open disk also satisfies `|α−ξ_p|_p<1`, and

`|Q(α)−Q(ξ_p)|_p≤|α−ξ_p|_p<|Q(ξ_p)|_p`.

The ultrametric equality gives the conclusion. The argument works unchanged for `Q∈Z_p[X]`. The strict inequality cannot generally be replaced by a closed disk: for `Q(X)=X` and `ξ_p=p^m`, the root zero is exactly on the boundary `|0−ξ_p|_p=|Q(ξ_p)|_p`.

This proposition is a local algebraic fact. It supplies no integer normalization or archimedean decay by itself.

## 4. The external arithmetic specialization on p. 16 is not verified by the citation

The actual PDF linked by the cited Zenodo record was downloaded and its advertised MD5 matched:

- Record: <https://zenodo.org/records/22826419>
- PDF: <https://zenodo.org/records/22826419/files/ZETA5_IS_IRRATIONAL.pdf?download=1>
- MD5: `30dafe4adbb13a79f202e94a046c8c8d`
- Local copy: `tmp/pdfs/new_upload_review/fauzan_reference.pdf`

The source fixes `K=40n, N=3n, h=37n` (`α=3/40`) in (2.1), p. 3. Its Theorem 2.1, p. 4, gives degree `37n`, with different decay certificates for cutoffs 200 and 100000. Its prime-sum statement is a limsup bound, not the equality of a limit asserted in the present manuscript. Its displayed arithmetic and archimedean constants also differ from those on p. 16 here. Its stated irrationality exponent is 260.

The present manuscript instead uses `K=30n, N=3n, h=27n`, hence `α=1/10`, and asserts

`A_M≤−2.32425`, `U≤2.32380`, `A_M+U≤−0.00045`,

leading to `ε=0.0004`. A change in `α` changes both the prime valuation profiles and the logarithmic energy problem. The reference is not a certificate for these new numerical inputs merely because the same type of construction is used.

The missing input should be supplied as a separate lemma with:

- the exact `L_p(K,M)` definition for the new parameters;
- proof that the resulting multiplier makes every coefficient integral;
- a certified prime-sum bound for that multiplier;
- an archimedean estimate for the same new parameter sequence;
- effective remainders/onsets if effective irrationality thresholds are claimed.

This is a gap in sourcing and derivation, **not a disproof of the proposed constants**. A full independent proof of the cited paper is outside this Section 4 audit.

## 5. Theorem 4.4: reconstructing and repairing the spectral estimate

### 5.1 The structural estimate

Assuming the preceding integral and residue identities, the comparison argument works. Put `p(t)=q(K²t)` and keep the first positive exponential term of the weight on `y=K sqrt(t)`, `t∈[a,b]`. Then

`cᵀG_K c ≥ A_K c_a exp(−K F₅(a,b)) ∫_a^b p(t)² dt`,

where `A_K=K^(12N−2K+6)` and

`F₅(a,b)=2π sqrt(b)+log(1+b)−6α log a`.

The signed residues have the exact factorial form

`r_j=(−1)^(j−1) 2 K^(2h−6−10N) ((j+N)!)^6 / [((j−N−1)!)^6 (K−j)! (K+j)!]`.

Cancellation of the `K log K` terms gives, uniformly at the discrete nodes including the ends,

`log|r_j|=K Φ(j/K)+O(log K)`,

with the displayed `Φ`. Uniformity follows from factorial bounds with `0 log 0=0`; the shifted factorial endpoint contributes only logarithmic errors. Thus the endpoint does not create an unaccounted exponential factor.

The orthonormal Legendre expansion on `[a,b]`, exterior estimate `|P_m(s)|≤(|s|+sqrt(s²−1))^m`, and Cauchy–Schwarz give the claimed exponential rate

`F₅(a,b)+max_{u∈[α,1]} [Φ(u)+2λ log R(u)]`,

up to a polynomial factor in `K`. The Legendre bound is supported by the classical Laplace integral; see DLMF 18.10.5, <https://dlmf.nist.gov/18.10.E5>.

### 5.2 The printed concavity calculation is wrong, but admits a short repair

For `a=1/18`, `b=1/3`, let `Ψ=Φ+1.8 log R`. The displayed derivative formulas are correct. Write the third term of `Ψ''` as

`T(u)=3.6(1/54−u⁴)/[(u²+1/18)(u²+1/3)]^(3/2)`.

The manuscript says `T(0.1)=5.318`; actually

`19.6367 < T(0.1) < 19.6368`.

Its bound `−2/(1−u²)<−2.31` throughout the small interval is also false near `u=0.1`.

Here is an explicit replacement proof. Let `r₀=(1/54)^(1/4)<0.37`. On `(0.1,r₀)`, `T` decreases, because its positive numerator decreases and its positive denominator increases.

- For `0.1<u≤0.25`, `T(u)<19.637`, while `−1.2/(u²−0.01)≤−22.857` and `−2/(1−u²)<−2`.
- For `0.25≤u<r₀`, `T(u)≤T(0.25)<5.208`, while `−1.2/(u²−0.01)<−9.45` and the other negative term is below `−2`.
- For `r₀≤u<1`, `T(u)≤0` and the other two terms are strictly negative.

Therefore `Ψ''<0` throughout `(0.1,1)`.

### 5.3 Corrected certified numerical values

The derivative signs used to bracket the maximum survive, but their printed decimal values do not:

| Quantity | Certified corrected interval | Manuscript value |
|---|---:|---:|
| `Ψ'(0.973)` | `(0.03865,0.03866)` | `+0.0259` |
| `Ψ'(0.974)` | `(−0.00305,−0.00304)` | `−0.0125` |
| `Φ(0.973)` | `(0.721794,0.721795)` | `0.725325…` |
| `Y(0.974)` | exactly `8.2304672` | `8.2297472` |
| `1.8 log R(0.974)` | `(5.035101,5.035102)` | `5.035267…` |
| `F₅(1/18,1/3)` | `(5.649503,5.649504)` | approximately correct |

Strict concavity and these derivative signs put the unique maximum in `(0.973,0.974)`. Since `Φ` decreases and `R` increases on that bracket,

`F₅+max Ψ ≤ F₅+Φ(0.973)+1.8 log R(0.974) < 11.406401`.

A fixed positive margin therefore absorbs the polynomial factor and proves

`||B_K||≤exp(11.407K)`

for all sufficiently large `K`. In particular the printed `11.411` is repairable. The stronger value would, conditionally on `ε=0.0004`, give the transfer threshold `25665.75` and hence integer exponent `25666`.

These are rigorous interval calculations, not just floating-point evidence. The accompanying pure-Python checker uses `Fraction`, integer square-root bounds, an atanh series with an analytic remainder for logarithms, and Machin's formula with alternating-series bounds for π. It passed all checks; files and raw output are listed below.

### 5.4 What this does and does not establish

The spectral estimate is an analytic result. Multiplication of a determinant polynomial by a nonzero rational scalar does not change its roots or its relative matrix. Thus this repair does not solve the missing integer normalization or decay bound on p. 16. The numerical irrationality measure in (4.5) remains conditional on that arithmetic input, and its effectivity additionally requires an effective onset.

## 6. Theorem 4.5: valid weight comparison, false outer-prime rank bound

### 6.1 The archimedean construction is sound

The pole terms in

`b μ_X^(5)(R) − a μ_Y^(3)(tR)`

depend on `Z=bX+aY`, with `Z`-derivative equal to the weight-five derivative matrix. At `Z=bζ(5)+aζ(3)`, the positive weight is

`W_{a,b}(y)=b w₅(y)−a y² w₃(y)`.

For `b>0` and `a<π²b/3`, the stated constants satisfy

`0<c₁ w₅≤W_{a,b}≤c₂ w₅`,

where `c₁=b−3max(0,a)/π²` and `c₂=b+3|a|/π²`. Consequently fixed `a,b` affect logarithmic determinant rates only by `O(K)` and relative-matrix norms by a fixed factor. The spectral margin above absorbs that factor.

If the only extra arithmetic loss really were `exp(O(K))`, one should apply Theorem 4.1 with a slightly smaller decay constant, rather than literally with the same `ε`. For example `ε'=0.0003999` still has `0.9·11.411/ε'<25687`. This bookkeeping is repairable.

### 6.2 Exact counterexample to “rank at most 14”

The proof claims that at most seven exceptional moment degrees contribute an outer-prime correction matrix of rank at most 14. A Hankel matrix supported on a small number of antidiagonals can have large rank. More decisively, the actual family here gives an exact counterexample.

Take `K=30`, `N=3`, `h=27`, and the outer prime `p=17` (`K/3<p≤K`). Let `Q_s(t)` be the polynomial quotient in division of

`t D₃(t)^6 t^s` by `D₃₀(t)`, for `0≤s≤52`.

The numerator and denominator are monic integer polynomials. Hence `Q_s∈Z[t]`, and when nonzero its degree is `s−11`. The weight-three polynomial moments are

`μ^(3)(t^m)=(−1)^m B_(2m+2)(2m+3)/2`.

For `0≤m<15`, these moments are 17-integral: the possible Bernoulli pole at `m=7` is canceled by `2m+3=17`. The first nonintegral moment is `m=15`, and

`17 μ^(3)(t^15) ≡ 8 (mod 17)`.

Define the actual correction matrix modulo 17 by

`L_{ij}=17 μ^(3)(Q_(i+j)) mod 17`, `0≤i,j≤26`.

All entries with `i+j<26` vanish, while all entries with `i+j=26` equal 8, because `Q_26` is monic of degree 15 and its lower-degree moments are integral. Reversing the columns therefore gives a triangular matrix with diagonal 8. Thus

`det L = (−1)^(27·26/2) 8^27 ≡ 15 (mod 17)`,

so **`rank L=27`, not at most 14**. This uses the permitted case `a=b=1` if a concrete mixed-weight pair is desired.

This is not an isolated small-index issue. For `K=30n`, `N=3n`, the quotient degree is `s−12n+1`. At a sufficiently large outer prime, the first nonintegral moment is `m=p−2`; the first nonzero correction antidiagonal is

`i+j=p+12n−3`,

with value `−1/2 mod p`. A suitable square submatrix has rank at least

`min(p+12n−2, 42n+2−p)`,

when that antidiagonal lies in range. This is of order `n`, not bounded independently of `K`.

The claimed `exp(O(K))` determinant loss therefore has no support from the given rank argument. Replacing a constant rank bound by an `O(K)` bound may cost `exp(O(K²))` over outer primes, which can consume the very small asserted decay margin. A new determinant-valuation argument is necessary. This counterexample refutes the stated intermediate assertion; it does not logically refute the final irrationality claim.

## 7. Theorem 4.6: determinant bounds, heights, and normalization

### 7.1 The derivative determinant and a typographical/algebraic correction

The Vandermonde cancellation yields

`|det M_K| = ∏_{a=N+1}^K a⁴ [ (a+N)! / (a (a−N−1)!) ]^5`.

After subtracting `10αλ K² log K`, the limiting constant is

`C_M=(5/2)[(1+α)²log(1+α)−(1−α)²log(1−α)−(2α)²log(2α)]−15αλ`.

The manuscript prints `−15α`; this must be **`−15αλ`**. Its numerical subtraction of `1.35` already corresponds to `αλ=0.09`.

At `α=0.1, λ=0.9`, rigorous intervals give

- `C_M∈(−0.6873879,−0.6873878)`;
- `C_*∈(3.2445775,3.2445776)`;
- `C_*+C_M∈(2.5571896,2.5571897)`.

The manuscript's `C_*=3.244587…` and total `2.557199…` are numerically inaccurate, but the corrected total still exceeds `2.32380+0.23310`. Thus the determinant lower bound survives **if** the independently needed `U≤2.32380` is supplied for this parameter sequence. With that input one gets the stronger lower rate `0.2333896…`.

### 7.2 The Jensen upper bound can be repaired without the missing arithmetic input

Restrict the Andréief integral to `(0,L)^h`, use the first positive exponential term of the weight, and apply Jensen under the arcsine probability measure. Its logarithmic energy and averages are finite. The omitted density, factorial and entropy terms are `O(K log K)` and disappear after division by `K²`; the scaled product sums can be controlled by integral comparison with the same order of error. This gives the stated structural lower bound

`liminf K^(−2) log F_K(ξ) ≥ λ² log(L/4) − λ∫V₅ dρ̃_L + C_*`.

At `L=1/4`, the closed-form average of `J_a` printed in the manuscript is correct. Its numerical evaluations are not all correct. In particular,

`∫J₁ dρ̃≈−1.1213857494`,

`−6∫J_0.1 dρ̃≈1.5439485172`,

`∫V₅ dρ̃≈2.4225627679`.

The certified results are

`liminf K^(−2)log F_K(ξ) ≥ −1.181525853…`,

and hence

`limsup K^(−2)log|det B_K| ≤ 3.738715486… < 3.73980`.

Thus the displayed upper endpoint `3.73980` remains valid after correcting the calculations, conditional only on the preceding integral architecture, not on the external `U` or integer normalization. The proof should state enough error control for the limiting Jensen step rather than presenting its numerical value as self-certifying.

### 7.3 Upper heights and primitive decay: valid conditional consequences

The factorization

`Q_K(X)=Q_K(ξ)∏_j[1+(X−ξ)β_j]`

and `|ξ|<2` give

`H(P_K)≤H(Q_K)≤exp(−0.0004K²)(1+3 exp(11.411K))^(0.9K)`.

Thus the upper bound `exp(10.27K²)` follows from the stated integer decay and spectral estimates. The factor `3` is a harmless bound for the coefficient norm of a linear factor. For `Q_K=c_K P_K`, positive integral content gives

`log P_K(ξ)≤−(ε+δ_K)K²`, `δ_K=K^(−2)log c_K≥0`.

Also

`|lead(P_K)|=P_K(ξ)|det B_K|≥1`,

so the determinant upper bound controls the primitive decay exponent from above. Therefore `0.0004≤ε_P≤3.73980` is a correct conditional consequence.

Content removal can **improve** the decay rate. The conservative input `0.0004` is not an upper bound on the actual primitive decay and should not be treated as such in optimization claims.

### 7.4 The lower height estimate uses the arithmetic inequality backwards

The final line of the proof reads, in substance,

`lim K^(−2)log|lead Q_K| = A_M + 2.557199 ≥ −2.32425 + 2.55690`.

But the only preceding hypothesis is **`A_M≤−2.32425`**. This does not provide the required lower bound. The inference is invalid independently of the small numerical errors. A value of `A_M` substantially more negative would be compatible with that upper bound and would give a much smaller leading coefficient rate.

To prove `log H(Q_K)≥0.23K²` by this route requires, for example, a lower estimate on the actual normalization rate satisfying `A_M+C_*+C_M>0.23`. A certified equality or two-sided evaluation of `A_M` could repair it; none is provided. The same gap affects the claimed primitive lower estimate

`log H(P_K)≥(0.23265−δ_K−o(1))K²`.

These specific lower bounds are unproved for the actual family, not disproved merely by this invalid inference.

## 8. Theorem 4.7: root count, nearest root, and factor separation

Let `s_j=K^(−1)log|β_j|`. The spectral bound gives `s_j≤11.411`, and the asserted determinant lower bound gives

`(1/h)∑s_j≥0.23310/0.9−o(1)>0.2589`.

If `S_+={j:s_j≥0.10}`, then

`0.2589h ≤ 11.411|S_+|+0.10(h−|S_+|)`.

Therefore `|S_+|/h≥0.1589/11.311>0.0140`, and `0.014h=0.0126K>0.012K`. Negative or unbounded-below values of the other `s_j` cause no problem: only their upper bound `0.10` is used. This part of the proof is correct conditional on the determinant lower input.

The nearest-root lower bound follows from the norm. The upper bound follows from the integer leading coefficient and polynomial value. It is far from optimal even using the section's own information: the determinant lower bound implies some `s_j≥0.259−o(1)`, so the nearest gap is at most `exp(−cK)` for every fixed `c<0.259`, much stronger than `exp(−K/2250)`. With the corrected determinant constant and the stated `U`, one can take any `c<0.2593218…`.

The trace identity follows from `r_j−ξ=−β_j^(−1)` and similarity of `B_K^(−1)` to `M_K^(−1)G_K`. The sum of opposite-side distances gives `r_+−r_-≥2 exp(−11.411K)`. The macroscopic cluster need not have a positive proportion on **both** sides; that is not established by this averaging argument.

The factor-separation proof quotes Mahler's inequality with the wrong height. The classical formula uses **Mahler measure** `M(f)`:

`sep(f) > sqrt(3|disc(f)|) d^(−(d+2)/2) M(f)^(−(d−1))`.

Replacing `M(f)` directly by naive height `H(f)` omits a factor; `M(f)≤sqrt(d+1)H(f)` is the appropriate elementary comparison. Nevertheless the manuscript's final loose asymptotic bound survives. An especially clean repair avoids a separate factor-height loss:

`M(f)≤M(P_K)≤sqrt(h+1)H(P_K)`,

because the complementary integer factor has Mahler measure at least one. This yields the stronger bound

`sep(f)≥exp(−10.27(d−1)K²−O(K log K))`,

which implies the printed estimate. A primary source explicitly giving Mahler's formula is Knapp–Yip, Theorem 1.1, <https://arxiv.org/html/2410.01126v1>.

## 9. Proposition 4.8: distinguish local exclusion from the unsupported global claim

For a rational root **already known** to lie in `|X−ξ|≤exp(−τK)`, the irrationality estimate gives

`b^(−25687)<|a/b−ξ|≤exp(−τK)`,

hence `b>exp(τK/25687)`. The finitely many denominators below the irrationality threshold are excluded from shrinking disks for large `K`. This local statement is correct conditional on Theorem 4.4's arithmetic conclusion.

The proof then takes `τ=11.411`, asserting that this closeness condition holds for all roots. Theorem 4.4 gives exactly the opposite inequality:

`|r_j−ξ|≥exp(−11.411K)`.

It is a zero-free disk, not an upper bound on root distances. Thus the global assertion that **no** rational root has denominator at most `exp(K/2251)` is not proved.

There is also a numerical problem even if the incorrect closeness premise were granted:

`11.411·2251=25686.161<25687`,

so `11.411/25687<1/2251`. The quoted local estimate would not imply the displayed denominator threshold.

Root-gap and small-value hypotheses do not exclude fixed rational roots far from `ξ`: multiplying a hypothetical small-value family by a fixed integer linear factor with such a root preserves the relevant exponential estimates, with harmless margins and a degree increase of one. This is a counterexample to the **general inference**, not an explicit rational root of the manuscript's particular determinants. The actual global exclusion remains unresolved without another arithmetic or factorization argument.

Part (2) is valid: from `|F(ξ)|=|c_F|∏|ξ−r_j|`, lower bounds on all gaps give the lower degree estimate, and an assumed cluster upper bound on all gaps gives the upper degree estimate. The integer condition `|c_F|≥1` justifies the second lower inequality.

## 10. Remark 4.9: what the section actually proves about the variational quantity

Conditionally on the earlier determinant lower bound and spectral upper bound, one has

`0.2590 ≤ liminf K^(−1)log||B_K|| ≤ limsup K^(−1)log||B_K|| ≤ 11.411`.

This follows immediately from `|det B_K|≤||B_K||^h`. Neither Theorem 4.4 nor Theorem 4.6 by itself inserts the new number `ρ_var` between the limsup and `11.411`. To do so requires an asymptotic comparison between weighted polynomial norms, their logarithmic potentials, and the relevant extremal problem. Such a lemma is neither proved nor precisely cited at this point.

The supremum over all positive Borel measures on `C` of mass at most `λ` also needs an admissibility definition. Without a logarithmic moment condition or an equivalent normalization, expressions may contain infinities or `∞−∞`. Restricting initially to compactly supported measures with finite relevant potentials would make the formula more meaningful, but extension and approximation still require proof.

There is a plausible route to the upper bound on the variational expression. A potential version of Bernstein–Walsh would give

`U^ν(−u²)≤sup_[a,b] U^ν + λ log R(u)`.

Since `V₅≤F₅(a,b)` on the interval,

`sup_{t≥0}(2U^ν(t)−V₅(t))≥2sup_[a,b]U^ν−F₅(a,b)`.

The expression would then be bounded by `Φ(u)+2λlog R(u)+F₅`, the same one used in Theorem 4.4. This outlines an explicit missing lemma and its connection to the spectral proof; it is not a substitute for establishing it for the stated measure class, nor does it prove the separate finite-`K` asymptotic comparison.

The assertion `−M_eq≥4.274` has no supplied definition/certified computation in this section from which that number can be checked. Even granting `ρ_var≥4.8823`, the conclusion that the **actual** spectral rate cannot give an irrationality exponent below 10985 does not follow from an inequality `ρ_actual≤ρ_var`: a lower bound on an upper bound is not a lower bound on the quantity bounded. Equality with the actual limit is precisely what Conjecture 4.11 proposes. At most, a lower bound on `ρ_var` constrains estimates that deliberately use this variational number itself, after its validity is proved.

The stated `ε=0.0004` is a conservative certified lower decay rate, not the actual best decay rate. Content normalization and stronger archimedean/arithmetic analysis can change the optimization. Therefore no universal barrier for the determinant method is established here.

## 11. Remark 4.10: the Lee–Yang and first-order claims do not follow

Lee–Yang's circle theorem is a theorem for particular partition functions with specified hypotheses. Arbitrary real-rooted integer polynomials do not become instances merely by calling them partition functions and adapting the axis. The source theorem is Lee–Yang, *Physical Review* 87 (1952), 410: <https://journals.aps.org/pr/abstract/10.1103/PhysRev.87.410>.

The manuscript supplies no proof that

`f(X)=lim_K [log|P_K(X)|/(hK)]`

exists, no neighborhood regularity of that limit, and no one-sided derivative analysis. A first-order transition conventionally requires the corresponding derivative discontinuity of a well-defined free energy. Real-root collapse alone proves none of these.

Here is an explicit primitive integer-polynomial counterexample to the proposed inference. Let `t=3+2sqrt(2)` and write

`p_j+q_j sqrt(2)=t^j`, so `p_j²−2q_j²=1`.

Define, for `n≥1`,

`R_n(X)=∏_{j=n}^{2n−1}(q_jX−p_j)(p_jX−2q_j)`.

Each factor is primitive, because `gcd(p_j,q_j)=1` and `p_j` is odd, so `R_n` is primitive by Gauss's lemma. Its `2n` roots are real, distinct, occur on both sides of `ξ=sqrt(2)`, and approach `ξ` at exponential rates comparable to `t^(−2j)`. At `ξ`, each pair has value

`(q_jξ−p_j)(p_jξ−2q_j)=−sqrt(2)t^(−2j)`.

Consequently

`lim_n [log|R_n(ξ)|/(2n²)] = −(3/2)log t`.

For every fixed `X≠ξ`, the same normalized limit is instead

`lim_n [log|R_n(X)|/(2n²)] = +(3/2)log t`.

Thus even with primitive integer coefficients, real simple roots on both sides, exponential root collapse, exponential zero-free scales, and quadratic small values, the normalized logarithm can have an isolated downward discontinuity rather than a first-order free-energy transition. Taking the even subsequence makes `R_n(ξ)>0` if positivity is desired. Alternating the starting index scales gives examples where the analogous limit fails to exist.

This does not determine the actual limiting behavior of the manuscript's particular family. It shows that the claimed implication is invalid. The remark should presently be described as a physical analogy or a conjectural program, not an established first-order transition. The “exact two-sided spectral gap” is also an overstatement: the displayed formula is a lower bound, not an exact value or two-sided asymptotic equivalence.

## 12. Conjecture 4.11 and the dependency consequences

The limit-existence/equality statement is explicitly labeled a conjecture and should remain so. A correct formulation must specify the admissible potentials and the meaning of the supremum in `ρ_var`. Its truth would require an asymptotic spectral/extremal-polynomial argument not provided by the finite interval estimate.

The section's dependencies can be separated as follows:

| Input or repair | Consequences it can support | Consequences it does not automatically support |
|---|---|---|
| Integral/derivative identities plus corrected spectral proof | Eventual norm bound `11.407`, exponential zero-free disk | Integer polynomial decay, irrationality |
| New `K=30n` integer normalization and certified decay | Theorem 4.4's irrationality exponent, upper heights, local rational-root exclusion | Effective onset unless error bounds are effective; global rational-root exclusion |
| New `K=30n` archimedean `U≤2.32380` | Positive determinant lower rate, macroscopic cluster, norm lower rate | Lower height of the normalized polynomial without a lower arithmetic normalization bound |
| Corrected Jensen estimate | Determinant upper rate, upper primitive-decay rate once primitive integrality is available | Integer decay or content growth |
| A replacement mixed-weight valuation theorem | Potential repair of Theorem 4.5 | Cannot be replaced by the false rank-14 assertion |
| A lower bound or certified value for `A_M` | Possible repair of lower coefficient-height estimates | Not supplied by the existing upper bound |
| Variational asymptotic theorem and numerical certificate | Possible repair of the `ρ_var` sandwich | Equality remains conjectural unless separately proved |
| Free-energy limit and derivative analysis | Possible phase-transition theorem | Not implied just by root collapse |

## 13. Reproducible checks and limits of this audit

The exact interval checker is `tmp/pdfs/new_upload_review/audit_section4_numeric.py`. Running it exited successfully. Its output, stored in `audit_section4_numeric.txt`, is:

```text
third(.1) : 196367/10000 < value < 12273/625
third(.25) : 26037/5000 < value < 2083/400
Psi prime(.973) : 773/20000 < value < 1933/50000
Psi prime(.974) : -61/20000 < value < -19/6250
Phi(.973) : 360897/500000 < value < 144359/200000
1.8 log R(.974) : 5035101/1000000 < value < 2517551/500000
F5 : 5649503/1000000 < value < 176547/31250
spectral split upper expression : 7129/625 < value < 11406401/1000000
Cstar : 1297831/400000 < value < 2027861/625000
correct Cm : -6873879/10000000 < value < -3436939/5000000
scaled derivative determinant rate : 3196487/1250000 < value < 25571897/10000000
arcsine average V : 24225627/10000000 < value < 6056407/2500000
Jensen lower F rate : -11815259/10000000 < value < -5907629/5000000
upper B determinant rate : 18693577/5000000 < value < 9346789/2500000
All comparisons proved with exact Fraction arithmetic and analytic series remainder bounds.
```

The rank counterexample was independently checked with exact rational Bernoulli moments and modular polynomial division. The reproducer is `tmp/pdfs/new_upload_review/audit_section4_rank.py`, with raw output in `audit_section4_rank.txt`. It exited successfully and reported:

```text
K=30, N=3, h=27, p=17
Nonzero p*mu3(t^m) modulo p: [(15, 8), (23, 16), (31, 7), (39, 15)]
Rank over F_17: 27
Determinant modulo 17: 15
PASS: actual correction rank 27 exceeds claimed bound 14.
```

The triangular proof given above is a compact exact certificate and does not depend on trusting floating-point rank detection.

This audit does not certify every theorem in Sections 2–3, the full Fauzan manuscript, any unknown `K=30n` arithmetic certificate, or the open asymptotic conjecture. Claims described as conditional remain conditional. The strongest immediate manuscript repairs are: retain the generic transfer results, correct the numerical spectral/determinant calculations, state the new arithmetic hypotheses explicitly, replace the mixed-weight rank argument, remove the unsupported global rational-root exclusion and height lower bound pending new proofs, and recast the variational/phase assertions at their actually established level.
