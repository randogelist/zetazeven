# Section 6.11–6.18 and discussion: independent audit

Scope: the supplied 52-page PDF dated 21 October 2026. Two passes: reconstruct each displayed claim and then test signs, normalization, quantifiers, and local arithmetic. No Lean formalization. Exact scripts are separate from on-paper arguments. F means false displayed statement or calculation; G means proof gap or undefined object; R means explicit repair available; C means checked argument, sometimes conditional on corrected inputs. A false statement cannot be retained verbatim, but this is not a claim that the research direction is irreparable.

## Theorem 6.11 (pp.40–42)

**(1), local count and fixed-weight archimedean scaling: C at the indicated elementary level; global denominator rate: G.** Odd integers in an interval meet a nonzero square class with count 2K/p+O(1); the displayed Euler multiplication formula is correct. For fixed k, multiplying an exponentially decaying weight by a fixed power changes log determinants by at most the expected O(kK log K), provided a valid integral representation and bounds have first been established. The necessary beta integral representation is not valid as previously printed (see 6.4). A signed weight also does not automatically justify the positive-measure variational principle used here.

The claimed exact/strict growth of the denominator exponent is stronger than the calculation supplied. At k=1 the displayed difference is exactly zero, so its final strict inequality already needs k>1. Earlier gamma is a signed sum of half-weights. The actual clearing exponent involves max(0,-gamma), so subtracting the same constant from each half-weight does not, without an active-regime argument, imply the displayed change of the minimal clearing exponent. The O(k/M) term does not by itself establish strict positivity for every k and M. Fixed k then K→∞ also does not justify an assertion uniform as k→∞ without tracking constants. **Repair:** give the actual multiplier definition, prove its active regimes, specify the order of limits and uniform error constants; state a lower bound rather than an exact asymptotic if that is all the local estimate supplies.

**(2), polynomial quotient algebra: C.** Substitution t=4w−1 gives t+(2j+1)^2=4(w+j(j+1)); monic Euclidean division proves the displayed quotient expansion. This is useful and independent of the analytic representation.

**(2), claimed beta moments and valuation: F under the manuscript's definition.** Equation (6.3) defines the beta(4) constant moment as 1/4, whereas 6.11 uses mu(1)=±1 and v_2(mu(1))=0. The actual valuation of 1/4 is −2. Already the e=0 case contradicts the earlier definition; the general shifted-moment parity assertion is therefore not established. **Repair:** specify one functional consistently, recompute its shifted moments, then restate the obstruction. The quotient identity alone survives. A degree-zero quotient obstructs the specific proposed divisibility mechanism; it does not rule out every possible global content cancellation.

## Theorem 6.12 (pp.42–43)

**Definition and lattice: G/F dependency.** The earlier beta functional is defined on odd-square poles. This theorem silently uses the standard integer-square D_K and a different beta weight, with unresolved references to 'Theorem ??'. The positive derivative weights from the odd-square construction cannot be imported to this different lattice without a definition and calculation. Consequently the advertised unconditional beta conclusions are not established as written.

**(1), abstract sign-flip algebra: C conditionally.** If M=V diag(gamma_j)V^T with gamma_j>0 at poles −a_j^2, multiplying the numerator by t−r^2 replaces M by −V diag((a_j^2+r^2)gamma_j)V^T, which is negative definite. A symmetric pencil with definite derivative is real-rooted regardless of whether its value at the target is definite. This is a valid reusable lemma for any correctly defined lattice.

**(2), continuity repair: C conditionally, 'explicit' not supplied.** For a correctly identified weight w with exactly one simple sign change at u_0, (u^2−u_0^2)w(u)>0 except at u_0, so its finite Gram matrix A_0 is positive definite. Writing A(r)=H−r^2G, the explicit sufficient condition is

$$|r^2-u_0^2|\,\|G\|<\lambda_{\min}(A_0).$$

Rational density proves existence, not the claimed numerical construction or a height bound. A terminating search can be stated using certified interval bounds for the finitely many entries and Sylvester's criterion. With M(r) negative definite, all roots are above the target. This part is worth retaining as an abstract theorem, after the functional is repaired.

**(3), valuations: G.** Multiplication of already proved local diagonal blocks by units preserves their leading valuation. The cited underlying integer-lattice theorem is not identified, and its hypotheses/normalization must first be supplied. In addition, q-integrality of polynomial moments does not follow merely from E_{2e} being integral when rational normalizing factorials/coefficients are left unspecified. The final 'unconditionally' must retain all stated congruence and unit hypotheses. A strengthening after repair is simultaneous real closeness and a prescribed q-adic unit condition, using rational density in a fixed congruence class; no global denominator bound follows from this.

## Theorem 6.13 (pp.43–44)

**(1), central-factorial differential identity: C.** For f_p(z)=cosh(z)^(−p),

$$f_p''=p^2f_p-p(p+1)f_{p+2}.$$

Induction therefore proves exactly

$$\prod_{r=1}^{k-1}((2r-1)^2-D^2)\frac1{2\cosh z}
=\frac{(2k-2)!}{2\cosh^{2k-1}z},$$

and applying −D proves the positive closed form in (6.5). The first k−1 Laplace modes vanish and the rate e^{−(2k−1)z} is correct.

**(1), series in (6.5): F, explicit sign repair.** The displayed product reverses all k−1 factors without compensating its sign. Replace (−1)^l by (−1)^(l+k−1), or retain (−1)^l and replace every factor by (2r−1)^2−(2l+1)^2. At k=2 the printed series has negative leading term −24e^(−3z), whereas the closed form has positive leading term +24e^(−3z).

**Weight identification and (2): G, then C as abstract matrix implications.** The asserted relation of this differential identity to the previously defined beta functionals is not proved with consistent constants or pole lattices. There is also a definite substitution-sign omission: the evaluated weight of the displayed pencil contains (−1)^(k−m) c-tilde_(k,m) u^(2k−2m) w_beta(2m), not the unsigned sum in the proof. Coefficients c-tilde include powers of pi, so this coupled pencil is not automatically a rational/integer polynomial pencil. Once G(target) and M are both proved positive definite for the same pencil, real roots below the target and positive shifted coefficients follow immediately. Newton inequalities are non-strict in general; strictness requires M not proportional to G. On a valid positive negative-pole representation this follows from M_01<0 while G_01>0, for h≥2. Add that argument explicitly; do not rely on an unsupported assertion that the normalized matrix is nonscalar.

## Theorem 6.14 (pp.45–46)

**(1): F/G, multiple incompatible scale definitions.** The page is visibly clipped on the right and the proof contains unfinished text beginning 'Wait:'. It defines w-tilde(v)=−4w(2v), then changes the normalization in the proof. For any genuinely represented functional mu(R)=integral R(u^2)w(u)du, the first definition forces the exact identities

$$\widetilde\mu(R)=-2\mu(R(t/4)),\qquad
\widetilde\mu(t^e)=-2\,4^{-e}\mu(t^e),\qquad
\widetilde\mu((t+j^2)^{-1})=-8\mu((t+(2j)^2)^{-1}).$$

These are the change-of-variables corrections; the displayed theorem formulas and the several later rescalings cannot all hold simultaneously. Further, evaluating the old functional at even-square poles is outside its stated odd-square domain. A complete repair needs a newly defined functional on the needed poles and a new moment calculation, not a cosmetic factor adjustment.

The claim 'v_p=0' for every odd prime must in any case be weakened to v_p≥0: integer Euler/binomial numerators may contain odd primes (e.g. E_4=5). Dyadic denominators imply odd-prime integrality, not unit valuation.

**(2)(i), weight sign: F, explicit correction conditional on repaired functional.** The functional contains mu-tilde(−tR), hence the combined weight is b w_5−(a/4)v^2 w-tilde_beta4, not the printed plus sign. The symmetric sufficient cone |a|C_4/4<b would still imply positivity for either sign, but the identity must be corrected.

**(2)(ii), comparison argument: C conditionally.** Given a consistent negative w-tilde_beta2 and finite ratio bound C_2, a>−b/C_2 yields positivity and two-sided comparison. The small-v limit of the zeta weight in (3.1) is 1/pi for every odd weight, not the printed pi^2/6. The derivative, signature and rate11.411 then depend on the corrected residue calculation, the parity of N, and the Section4 spectral estimate. They do not follow from the current inconsistent formulas.

## Theorem 6.15 (pp.46–47)

**(1), beta formula, transcendence and linear independence: C.** The Euler-number formula beta(2k+1)=q_k pi^(2k+1), q_k nonzero rational, proves these assertions from transcendence of pi. The collection of all odd beta values has transcendence degree one, not algebraic independence.

**(1), effective power-type measures: valid with a precise replacement citation.** A fixed-degree polynomial lower bound for pi applied to the integer polynomial corresponding to b q_k X^(2k+1)−a gives a power-type rational-approximation bound for beta(2k+1). The vague attribution to Mahler does not identify a theorem with the required strength. An explicit valid source is Waldschmidt, *Transcendence measures for exponentials and logarithms* (1978), Corollary3.2, pp.451–452 of the article: for fixed degree its transcendence measure is linear in log H. Small finitely many denominators can be absorbed into a larger computable C_k, since the value is computable and irrational. For beta(1)=pi/4, the 7.10321 assertion also needs a specific source and the rational-scaling argument.

**(2), moments, strict total positivity, rank-one derivative, exact rational root and root side: C.** Expanding the geometric series and integrating proves the moments; the positive measure and Andreief identity give strict total positivity. The determinant lemma gives exact degree one and

$$|\beta(2k+1)-r_K|=(v_-^TG^{-1}v_-)^{-1}.$$

For k=0 define eta(1)=log2 directly: (1−2^{1−s})zeta(s) at s=1 must be interpreted by its removable limit, not literal multiplication by zeta(1).

**Claimed h^(−2k) prefactor: F for k≥1; explicit asymptotic repair.** At fixed k,N, the correct two-sided order is

$$|\beta(2k+1)-r_K|\asymp_{k,N}(3+2\sqrt2)^{-2h}.$$

The conformal map proves only the exponential rate; it does not introduce the printed algebraic factor. A rigorous comparison proof: after t=u^2 the measure has density proportional to t^(N−1/2)(−log t)^(2k)/(1+t). It lies between positive constant multiples of the two Jacobi weights t^(N−1/2)(1−t)^(2k) and t^(N−3/4)(1−t)^(2k), because 1−t≤−log t and t^(1/(8k))(−log t)/(1−t) is bounded (k≥1). Both exponents at zero exceed −1. Exterior Jacobi asymptotics imply their Christoffel functions at −1 are comparable to (3+2sqrt2)^(−2h), and the extremal formula transfers both bounds. For k=0 the same conclusion follows directly by comparable Jacobi weights. Reference: DLMF18.15(i), exterior Jacobi asymptotics, citing Szego Theorem8.21.7/Elliott1971. Do not infer small primitive integer errors from the unnormalized rational root distance alone.

## Theorem 6.16 (pp.47–48)

**(1): G inherited from6.14.** With the asserted formal pole coefficients taken as a new definition, the collapse to Z and derivative M is algebraically correct; the stated sign (−1)^(k+1−r) in the weight is the correct substitution sign. The integral interpretation remains unproved until the beta functional is repaired.

**(2): C conditionally, signature correction.** For valid weights with positive finite limits of W/w at0 and infinity and W>0, compactness gives two-sided comparison. The actual small-v constant of the zeta weight is 1/pi, not the displayed Bernoulli-index expression; bk>0 supplies the positive endpoint limit of the ratio. The signature of M depends on the parity of N+1, not universally (floor(h/2),ceil(h/2)). The Loewner/root-gap argument survives with that correction.

**(3), harmonic valuation bound: F.** The fixed condition p>max(coefficients,2k+3) does not exclude p^2 or higher powers among harmonic denominators. Example k=2,r=2,p=11,j=31: H_62^(beta,4) contains the unique denominator121^4 and has valuation−8, not≥−4. This is checked by exact rational arithmetic in late_exact_checks.py. **Repair:** the local bound holds when p>2sqrt(K), since the odd harmonic denominators are <4K. Small primes need a separate bound. Even the corrected pointwise bound does not establish preservation of the stronger determinant/distribution cancellation, which requires its own local matrix analysis. Thus 'zero quadratic odd-prime overhead' is not established by the supplied argument.

## Theorem 6.17 (pp.48–49)

**Moment formula and (1): C.** The x→x^4 substitution gives the zeta component exactly; the alternating geometric series gives the beta component with H_(2n). The displayed rational symmetric pencil has derivative CC^T, which is positive definite for independent rows. Generalized symmetric eigenvalues give degree h and real roots. The subquadratic derivative-determinant bound follows under the stated integer polynomial-height assumption. These finite algebraic statements do not need any positivity of the evaluated signed form.

**(2): G/F quantifier, inherited tail gap.** An infinite difference-of-squares decomposition does not establish arbitrarily large positive and negative polynomial subspaces. Theorem5.2's deletion of the tail is invalid here too. If K is fixed as written, simultaneous h-dimensional positive and negative spaces require K+1≥2h; K=h=2 already violates this. State 'for every h there exists K' if intended, and then supply a genuine inertia/tail argument. This is not resolved by density.

**(3)(i), odd top-weight block: C at the algebraic level.** For n<2q and the stated large q, lower beta weights cannot match the leading odd weight's q-adic order. The original zeta block is retained, with kappa_1=2 avoiding its exceptional cancellation. This can be strengthened to arbitrary c in Z_q; an actual integer relation among constants is not used to establish nonvanishing of the formal pencil.

**(3)(ii), even top-weight valuation calculation: F; theorem conditional conclusion remains unsupported.** The proof confuses the index2n in H_(2n) with the odd denominator2nu+1. For upper rows the sums contain both q and3q, and some lower rows already contain q. A compact exact certificate is k=r=1,a_1=1,b_1=0,q=41,K=40,h=20. For the displayed basis and any integer c, the diagonal of 41^2G(c) modulo41 is ten entries37, then1, then nine zeros; all off-diagonal entries are zero. Its rank is11. Hence v_41(det G(c))≥−31 (or determinant zero), instead of the claimed−40. The vanishing diagonal factor is 5−4/3^2=41/9. Reproducer: late_exact_checks.py. **Logical boundary:** this refutes the algebraic valuation calculation for the formal pencil; it does not exhibit an integer value of beta(2), so it is not a literal counterexample satisfying the theorem's additional hypothetical integer-relation antecedent. Repair requires a differently designed basis/local block, or an explicit weaker valuation/nonvanishing lemma.

## Theorem 6.18 (pp.49–50)

**(1), degree threshold and vanishing quotient: C.** The inequality 2MN+2r−2+k+1−r_min≤K−1 proves the claimed absence of polynomial quotient. Require some a_m nonzero to define r_min, and handle the pure-zeta case separately.

**(1), dyadic integrality and spectral consequences: G.** Odd harmonic denominators are 2-adic units, but partial-fraction residues and the undefined correction terms also require analysis; this observation alone does not prove that the full beta pole contribution has only a fixed dyadic loss. 'No16^e quotient loss' is the precise structural conclusion currently supported. Hyperbolicity/positivity depend on repairing6.14–6.16 and explicitly imposing the positivity-cone hypotheses of6.16(2), which are not repeated here; leading-minor interlacing must handle degree drops/roots at infinity as in3.4.

**(2), degree42n−1 and monomial lower bound−4e: C for the displayed algebra.** At K=30n,N=3n,h=27n,2M=6,k=r_min=2 the quotient-free threshold is6n and the largest quotient degree is42n−1. For the displayed dyadic moment formula v_2≥−4e follows from integral Euler and binomial numerators. This is only the polynomial-quotient contribution. The assertion that the old odd-prime multiplier clears the full coupled determinant inherits the unresolved distribution claim of6.16(3).

**(3): G inherited from4.5, not a new proof.** The pure-zeta reduction and bounded Bernoulli2-adic denominators are correct. The effective measure25687 still requires the missing parameter-specific decay/input in4.4–4.5 and effective thresholds. Repeating it here does not remove that dependency.

## Section7 and manuscript-level revisions (pp.51–52)

The discussion correctly presents the weight-seven obstruction as a limitation and the later constructions as research directions; failure to prove zeta7 irrational is not an audit defect. Revise the proposed routes to remove reliance on false6.3(2), invalid5.6(3), and unrepaired beta identities. Distinguish raw derivative determinants from denominator-cleared primitive coefficients. The statement that two-variable derivative determinants have zero quadratic growth requires the integer polynomial-height hypothesis and does not make the entire height barrier vanish. Bounds called universal potential-theoretic invariants need their own existence/scaling hypotheses and a validated normalization.

The supplied PDF contains numerous unresolved cross-references, clipped right-hand formulas (notably pp.33,39,41,45), undefined beta variants and an unfinished derivation onp.45. These obstruct reproducibility and must be corrected after mathematical normalization is settled. They are not merely copyediting when they hide which functional or theorem is intended.

Primary references consulted for this section: Waldschmidt1978, https://webusers.imj-prg.fr/~michel.waldschmidt/articles/pdf/JAustralMS25-1978-445-465.pdf ; NIST DLMF18.15, https://dlmf.nist.gov/18.15 .
