# Section 3 chronological audit

Source: *Spectral Theory and Diophantine Bounds for Zeta Hankel Determinants*, uploaded file `Zetahyperbolic (3)(2).pdf`, 52 pages. This report audits printed pages 7–14, including Remark 3.10. Page numbers below are both printed and PDF page numbers. Ambiguous displayed formulas were checked against rendered pages, especially Proposition 3.2, Corollaries 3.5–3.6, Theorem 3.7, and Theorem 3.9.

This is an on-paper mathematical audit, supplemented by exact rational calculations for stated counterexamples. It is not a Lean verification. The work had two passes: reconstruct the arguments from the definitions, then test their assumptions and conclusions independently. Theorem 4.7 is cited below only to identify its stated scope; its proof and constants are outside this report.

## Executive assessment

The basic odd-weight integral representation, positive Gram matrix, full-pencil hyperbolicity, exact degree, and universal inertia are sound. The errors are concentrated in the claimed consequences of those facts and in the normalization of one extension. In particular:

* Proposition 3.2's weight differs by a factor of π/2 from the odd-weight weight, so its claimed agreement with the original pencil is false. One coefficient correction repairs it.
* Principal pencils need not have their nominal matrix size as degree. There is a systematic initial zero pattern in the derivative matrix. In the paper's main weight-five family, the first **6n−1** principal determinant polynomials are constant. The interlacing theorem needs to accommodate zero eigenvalues and roots at infinity.
* Corollary 3.5's continued fraction is false even in dimension one. It uses the wrong resolvent, omits a positive normalization, and reverses the endpoint convention. Its full-length strict Lanczos assertion additionally needs a cyclic-vector proof. Its exponential root bound is stated far beyond Theorem 4.7's scope and has an exact counterexample.
* Corollary 3.6 has an odd-power sign error, a reversed finite-power inequality, and an impossible claim of strictly positive Hankel determinants at all orders for a finite atomic measure. Its even-power limit is valid.
* Theorem 3.7's Turán and Newton inequalities survive. Its claimed universal nonvanishing of shifted coefficients is unsupported, and its argument about zero blocks is false. A short real-rootedness argument proves the desired strict shifted Newton inequalities without that claim.
* Theorem 3.8 is sound once the deformation is explicitly defined. The Hurwitz extension in Theorem 3.9 is sound after completing the functional definition. The Dirichlet extension is a valid real-pencil construction, but supplies no demonstrated rational/integer coefficient structure for later arithmetic applications.
* Remark 3.10 does not prove the stated non-classicality. Several of its proposed obstructions are false as general statements; its fixed-principal-chain argument also does not identify the varying-K family.

## Status ledger

“Repairable” means a stated correction or replacement proof is supplied below. “Unresolved” means this audit does not establish the claimed conclusion or a counterexample in the actual parameter family; this is not an impossibility claim.

| Claim | Pages | Status |
|---|---:|---|
| (3.1), monomial integral, and (3.2) | 7 | Checked on paper for all stated odd weights and all rational functions in the functional's domain |
| Theorem 3.1: positivity, degree h, real roots, no root at ξ, zero-free bound | 7–8 | Checked on paper; root simplicity is not asserted or proved |
| Proposition 3.2: hyperbolicity for real s>1 | 8 | Checked on paper |
| Proposition 3.2: agreement at odd integers | 8 | False as printed; explicit factor correction repairs it |
| Theorem 3.3(1): strict total positivity and determinacy | 8–9 | Conclusion checked; near-zero estimate in proof needs repair; condition 2mN≤K is unnecessary |
| Theorem 3.3(2): leading sign in weight five | 9 | Checked on paper |
| Theorem 3.3(3): universal signature | 9 | Checked on paper; unified counting formula supplied |
| Theorem 3.4(1): eigenvalue interlacing | 9–10 | Checked on paper |
| Theorem 3.4(1): r finite roots and minimum over r roots | 9–10 | False presupposition in general; repair using rank, zero eigenvalues, and infinity |
| Theorem 3.4(2), equation (3.5) | 9–10 | Checked on paper |
| Corollary 3.5(1), equation (3.6) | 10 | False as stated, with dimension-one counterexample; corrected resolvent formula supplied |
| Corollary 3.5: full Lanczos length and all bᵢ>0 | 10 | Unproved in this family; quoted general justification is false without cyclicity |
| Corollary 3.5(2): rational ratio at zero | 10–11 | Correct if denominator is nonzero; the explanation omits rational pole contributions |
| Corollary 3.5(2): universal exponential edge bound | 10–11 | False as stated; exact permitted-parameter counterexample supplied |
| Corollary 3.6: logarithmic derivative identity | 11 | Odd-power sign error; explicit correction supplied |
| Corollary 3.6: even-power moment representation and limit | 11 | Checked on paper |
| Corollary 3.6: all-order strict Hankel positivity | 11 | False; finite rank is an exact obstruction |
| Corollary 3.6: displayed finite-power factor bounds | 11 | Reversed; proof itself contains the correct bounds |
| Theorem 3.7(1) | 11–12 | Checked on paper |
| Theorem 3.7(2) | 11–12 | Checked on paper, including the stated equality criterion |
| Theorem 3.7(3): strict shifted Newton inequalities | 11–12 | Correct with a replacement proof |
| Theorem 3.7(3): all intermediate eₘ are nonzero | 11–12 | Unresolved in this actual family; supplied reasoning is false and the claim is unnecessary |
| Theorem 3.8(1) | 12–13 | Checked on paper |
| Theorem 3.8(2), equation (3.8) | 12–13 | Checked after explicitly defining the deformed Gram matrix |
| Theorem 3.9(1) | 13 | Checked after specifying monomial values as well as pole values |
| Theorem 3.9(2): positive kernels and hyperbolicity | 13–14 | Checked as a real-pencil statement after resolving the undefined-center/parity wording |
| Theorem 3.9(2): implicit arithmetic applicability | 13–14 | Not established; no rationality theorem for the coefficients is supplied |
| Remark 3.10 | 14 | Conclusion unresolved; several proposed proof steps are false |

## Notation and the foundational integral

Write s=2k+1≥3, h=K−N, ξ=ζ(s),

\[
D_N(t)=\prod_{\nu=1}^N(t+\nu^2),\qquad
D_{\rm tail}(t)=D_K(t)/D_N(t),\qquad
R(t)=D_N(t)^{2m}/D_K(t).
\]

The Section 2 functional is defined on polynomials and simple negative-square poles. Its relevant values are

\[
\mu_X(t^e)=\frac{(-1)^eB_{2e+2}(2e+2k+1)!}{(2k)!(2e+2)!},
\quad
\mu_X((t+j^2)^{-1})=j^{2k}(X-H_j^{(s)})+\frac1{2j}-\frac1{2k}.
\]

Let G(X) have entries μ_X(R(t)t^{i+j}), 0≤i,j<h, and let M=[X]G(X). The factorization from Theorem 2.5 is

\[
M=V\Gamma V^T,\quad V_{ia}=(-a^2)^i,\quad
\gamma_a=\frac{a^{2k}D_N(-a^2)^{2m-1}}{D_{\rm tail}'(-a^2)},
\quad N<a\le K.
\]

### Equations (3.1)–(3.2), page 7

The weight

\[
w_s(y)=\frac{2(2\pi)^{2k}}{(2k)!}y^{2k+1}
\sum_{\ell\ge1}\ell^{2k}e^{-2\pi\ell y}
\]

is strictly positive. Termwise Gamma integration gives the displayed monomial formula and Euler's even-zeta formula gives exactly μ_X(t^e). Tonelli applies to the positive series.

For completeness, the pole identity has a useful form valid for every real a>0:

\[
\boxed{\displaystyle
\int_0^\infty\frac{w_s(y)}{y^2+a^2}\,dy
=a^{2k}\zeta(2k+1,a)-\frac1{2a}-\frac1{2k}.}
\]

To obtain it, write w_s=2y^{2k+1}(d/dy)^{2k}(e^{2πy}−1)^{-1}/(2k)!, divide y^{2k+1}/(y²+a²) into its polynomial part plus (−1)^k a^{2k}y/(y²+a²), and integrate by parts 2k times. The polynomial part disappears after differentiation. Hermite's integral formula yields the boxed expression. The boundary terms vanish: near zero, the products of derivatives in each boundary term are O(y), and at infinity the Bose factor and its derivatives decay exponentially. For integer a=j, the relation ζ(s,j)=ζ(s)−H_j^(s)+j^−s recovers the manuscript's pole value exactly.

Consequently (3.2) is valid by linearity for the stated domain. All such rational functions are integrable against the weight. In fact w_s(y)→1/π as y↓0, while at infinity it is polynomial times an exponential. The condition 2mN≤K is not required for this integral identity or the positivity of G(ξ).

## Theorem 3.1, pages 7–8

The proof is sound. For every nonzero complex coefficient vector v and its polynomial q,

\[
v^*G(\xi)v=\int_0^\infty R(y^2)|q(y^2)|^2w_s(y)\,dy>0.
\]

The integrand is positive except at finitely many polynomial zeros. Thus G(ξ) is positive definite. Since V is invertible and every γ_a is nonzero, M is invertible. Multiplying the residue denominators gives precisely

\[
\det M=(-1)^{h(h-1)/2}\prod_{a=N+1}^K a^{2k}D_N(-a^2)^{2m-1}\ne0.
\]

This establishes exact degree h. With B=G(ξ)^−1/2 M G(ξ)^−1/2,

\[
\Delta(X)=\Delta(\xi)\det(I+(X-\xi)B).
\]

B is real symmetric and nonsingular, so its eigenvalues β_j are real and nonzero, and the roots, counted with multiplicity, are r_j=ξ−β_j^−1. The primitive normalization divides by a positive scalar and changes no roots.

The phrase “all roots are real and distinct from ξ” is correct. It does **not** mean the roots are pairwise distinct. No simplicity conclusion follows from this proof.

For the Euclidean operator norm the zero-free estimate can be sharpened to an equality for the nearest root:

\[
\min_j|r_j-\xi|=\|B\|_2^{-1}.
\]

## Proposition 3.2, page 8

The printed continuous weight is

\[
w_s^{\rm printed}(y)=\frac{(2\pi)^s}{2\Gamma(s)}y^s
\sum_{\ell\ge1}\ell^{s-1}e^{-2\pi\ell y}.
\]

At s=2k+1 it equals (π/2)w_{2k+1}(y), not w_{2k+1}(y). This is also visible at the origin: its limit is 1/2 rather than 1/π. Thus the assertion that this pencil coincides with (2.8) at odd integers is false.

Replace its coefficient by

\[
\boxed{\frac{2(2\pi)^{s-1}}{\Gamma(s)}}.
\]

The claimed continuous extension then agrees exactly at odd integers. Its hyperbolicity argument is otherwise valid for every real s>1. Indeed the integral matrix is positive definite and its proposed derivative is symmetric and nonsingular. Even the incorrectly normalized pencil is hyperbolic; only the agreement fails. At odd integers its roots are related to the original roots by

\[
r_j^{\rm printed}=\xi+\frac\pi2(r_j^{\rm original}-\xi).
\]

The signature and total-positivity arguments below extend to the corrected continuous family as well.

## Theorem 3.3, pages 8–9

### Part (1): strict total positivity and determinacy

The conclusion is correct. The measure

\[
d\mu(t)=R(t)\frac{w_s(\sqrt t)}{2\sqrt t}\,dt
\]

has a strictly positive density on (0,∞), finite moments of every order, and infinite support. Andréief's determinant identity expresses every Hankel minor with strictly increasing row and column exponents as an integral of two generalized Vandermonde determinants. Both have the same strict sign on 0<t₁<⋯<t_r. Their product is strictly positive on a set of positive measure. Hence all such minors are strictly positive.

The proof's global estimate w_s(y)≤C y^s e^−2πy is false near zero: its right side tends to zero while w_s(y)→1/π. This does not invalidate determinacy. Split the integral at y=1. Put d=max(2mN−K,0). For suitable positive constants independent of r,

\[
\mu_r\le C_0+C_1\frac{\Gamma(2r+s+2d+1)}{(2\pi)^{2r+s+2d+1}}.
\]

Stirling's estimate gives μ_r^−1/(2r)≥c/r for all sufficiently large r. Thus the Stieltjes Carleman sum diverges. This argument proves determinacy without the restriction 2mN≤K.

### Part (2): leading sign

For the main family s=5, K=30n, N=3n, 2m=6, the sign of the leading coefficient is

\[
(-1)^{h(h-1)/2+5Nh}=(-1)^{n(n-1)/2}.
\]

Here h=27n; direct reduction of the exponent modulo 2 confirms the manuscript's expression. Positive-content normalization preserves this sign.

### Part (3): universal signature

Each D_N(−a²) has sign (−1)^N. The tail derivative has a−N−1 negative factors. Thus

\[
\operatorname{sgn}\gamma_a=(-1)^{(2m-1)N+a-N-1}=(-1)^{a-1}.
\]

Sylvester's inertia theorem transfers these signs to M and B. A uniform count is

\[
n_+=\left\lfloor\frac{K+1}2\right\rfloor-\left\lfloor\frac{N+1}2\right\rfloor,
\qquad
n_-=\left\lfloor\frac K2\right\rfloor-\left\lfloor\frac N2\right\rfloor.
\]

There are n_+ roots below ξ and n_- above ξ, with multiplicities. These counts include all parity cases and verify the special weight-five counts in the text. For h≥2 both signs occur. The signature is independent of s and m.

## Theorem 3.4, pages 9–10

### Part (1): correct matrix interlacing, missing degree qualification

The Cholesky argument is correct. If G(ξ)=LLᵀ, then

\[
\widehat B_r=L_r^{-1}M_rL_r^{-T}
\]

is orthogonally similar to G_r^−1/2 M_r G_r^−1/2, and the matrices \(\widehat B_r\) are nested leading principal blocks. Cauchy interlacing therefore applies.

However M_r can be singular or zero. The full derivative M is invertible, but this does not imply its leading principal blocks are invertible. The exact statement is

\[
\Delta_r(X)=\Delta_r(\xi)\prod_{j=1}^r(1+(X-\xi)\beta_j^{(r)}),
\quad
\deg\Delta_r=\operatorname{rank}M_r.
\]

Only nonzero β_j correspond to finite roots. The map β↦ξ−β^−1 preserves order on each open half-line but is undefined at zero. Consequently the branchwise interlacing conclusion requires omitting zero modes, or adding roots at infinity. The displayed minimum over 1≤j≤r is not always defined as a minimum of r finite roots.

A clean corrected distance statement is

\[
\delta_r:=\begin{cases}
\min\{|r-\xi|:\Delta_r(r)=0\},&\Delta_r\text{ nonconstant},\\
+\infty,&\Delta_r\text{ constant},
\end{cases}
\quad
\delta_r=\|\widehat B_r\|_2^{-1},
\]

with 1/0=∞. The operator norms of nested symmetric principal blocks are nondecreasing, so δ_r is nonincreasing.

An exact small counterexample to the implicit degree-r assumption is s=3, N=1, K=5, m=1. Here

\[
M_{00}=-\frac1{105}+\frac9{70}-\frac{20}{63}+\frac{25}{126}=0.
\]

Thus Δ₁(X)=G₀₀(ξ)>0 is a constant and has no finite root.

### Stronger structural finding: a forced zero triangle

This is not an isolated cancellation. Define

\[
T=h-1-k-(2m-1)N=K-2mN-k-1.
\]

At the tail nodes v_a=−a², let

\[
f_{ij}(t)=(-1)^k t^{i+j+k}D_N(t)^{2m-1}.
\]

Then M_{ij}=Σ_a f_{ij}(v_a)/D_tail'(v_a). The Lagrange leading-coefficient identity says that this sum is zero for a polynomial of degree below h−1 and equals its leading coefficient when its degree is h−1. Therefore

\[
\boxed{M_{ij}=0\quad(i+j<T),\qquad M_{ij}=(-1)^k\quad(i+j=T).}
\]

When T≥0, lower-triangular Cholesky conjugation preserves the zero triangle and gives

\[
\widehat B_{ij}=0\quad(i+j<T),\qquad
\widehat B_{ij}=\frac{(-1)^k}{L_{ii}L_{jj}}\quad(i+j=T).
\]

Moreover, for 1≤r≤T+1,

\[
\boxed{\operatorname{rank}M_r=\max(0,2r-T-1).}
\]

If 2r≤T+1 the block is zero. Otherwise its first T−r+1 rows and columns are zero, and the remaining block has a nonzero first antidiagonal and zeros before it, so is invertible. This proves the rank formula exactly.

For the manuscript's main family k=2, m=3, N=3n, K=30n,

\[
T=12n-3,\qquad \Delta_r(X)\text{ is constant for every }r\le6n-1.
\]

The first nonconstant principal determinant, at r=6n, has degree 2. Any discussion of the entire principal-minor hierarchy as degree 0,1,2,… needs to be rewritten around this fact.

### Part (2): Dodgson condensation

The symmetric Desnanot–Jacobi identity gives the stated polynomial identity. At a root of Δ_{r−1}, its first product term vanishes and the remaining term is −Σ_{r−1}²≤0. This is correct, even when the condition is vacuous because Δ_{r−1} is constant. No nonsingularity assumption is needed to invoke the determinant identity.

## Corollary 3.5, pages 10–11

### Part (1): the displayed fraction is false

The error can be certified in the smallest allowed dimension. Take s=3, N=1, K=2, m=1, so h=1. Then

\[
\frac{D_1(t)^2}{D_2(t)}=\frac{t+1}{t+4}=1-\frac3{t+4},
\quad
G(X)=\frac{29}{2}-12X.
\]

Set g=G(ζ(3))>0, as follows already from the valid integral identity. The single Lanczos diagonal is a₁=β=−12/g. At X=ξ, the manuscript's (3.6) says

\[
\frac1g=\frac1{a_1}=-\frac g{12},
\]

which is impossible because the two sides have opposite signs. Thus this is a genuine false equality, not merely an unproved theorem.

### Exact correction

Put t=X−ξ and κ=Δ_{h−1}(ξ)/Δ_h(ξ)=L_{hh}^{−2}, using 1-based matrix indices. Cramer's rule and the Cholesky factorization give

\[
\boxed{\frac{\Delta_{h-1}(X)}{\Delta_h(X)}
=\kappa\,e_h^T(I+t\widehat B_h)^{-1}e_h.}
\]

The missing κ is positive but usually not 1. The resolvent is I+tB, whereas the printed J-fraction uses B+tI. Thus, with a Lanczos basis convention Qe₁=e_h and a full h-step reduction, the right formula is

\[
\frac{\kappa}{\displaystyle 1+t a_1-
\frac{t^2b_1^2}{\displaystyle 1+t a_2-
\frac{t^2b_2^2}{\displaystyle\ddots-
\frac{t^2b_{h-1}^2}{1+t a_h}}}}.
\]

If the manuscript retains Qe_h=e_h instead, the expansion begins at a_h and proceeds backwards. A polynomial identity or rational-function interpretation handles intermediate denominators that vanish away from zeros of Δ_h.

### Cyclicity and spectral visibility

The text additionally asserts that Lanczos supplies h−1 strictly positive off-diagonal entries because the symmetric matrix has distinct eigenvalues. First, simplicity has not been proved. Second, simplicity alone is insufficient: diag(1,2) has simple spectrum, but Lanczos started at e₂ terminates immediately.

The necessary condition is that the starting vector be cyclic: it must have nonzero projection onto every eigenspace and there must be no repeated eigenvalues if a single starting vector is to generate all h dimensions. Without that condition the algorithm terminates at a length d≤h, giving positive bᵢ only before termination. The correct continued fraction represents the spectral measure seen by e_h, which can omit eigenvalues of the full matrix. Such omitted eigenvalues cancel between numerator and denominator of the ratio.

This audit has not found an actual-parameter counterexample to cyclicity of e_h, nor established cyclicity for the whole family. Therefore the full-length assertion should be classified as unproved in this construction, not impossible. Any claim that the fraction's spectral edge tracks the closest root of the full determinant needs this visibility issue resolved.

The spectral measure is a positive measure on the real β-axis, generally with support on both signs. “Finite Jacobi fraction” avoids suggesting support on [0,∞), as the term “Stieltjes” can do.

### Part (2): rationality and the overbroad root bound

The ratio Δ_{h−1}(0)/Δ_h(0) is rational **if Δ_h(0)≠0** because both polynomials have rational coefficients. The proof's assertion that only Bernoulli monomial moments occur is inaccurate: pole values at X=0 also occur and are rational. Rationality does not require the erroneous fraction.

The exponential estimate |r_min−ξ|≤e^−K/2250 is not a general consequence of the stated parameters. Theorem 4.7 concerns the specific weight-five family, with sufficiently large K divisible by 30, N=K/10, and m=3. Corollary 3.5 is stated for arbitrary allowed K,N,m,s.

There is an exact counterexample within that broad scope. Take s=3, N=1, K=2, m=7, so again h=1. Exact polynomial division and the functional values give

\[
G(X)=\frac{5783933697}{143}-6377292X,
\quad
r=\frac{1927977899}{303984252}>6.
\]

Since ζ(3)<3/2, its only root is more than 9/2 from ξ. This exceeds 1, whereas e^−2/2250<1. All hypotheses explicitly stated in Corollary 3.5 are met. The occasional restriction 2mN≤K in Theorem 3.3(1) is not a standing assumption in Corollary 3.5.

The displayed root bound must be restricted to the precise separately established scope of Theorem 4.7, and that theorem must itself survive its own audit. β_max also needs to mean an eigenvalue of maximum **absolute value**, not merely the largest algebraic eigenvalue.

## Corollary 3.6, page 11

There are three independent corrections.

### Odd-power sign

For any real nonzero evaluation of P, use log|P| or equivalently its formal logarithmic derivatives. Direct differentiation gives

\[
\frac{(-1)^{m-1}}{(m-1)!}(\log|P|)^{(m)}(q_0)
=\sum_j(q_0-r_j)^{-m}.
\]

The printed right side Σ(r_j−q₀)^−m is wrong for odd m. To retain that right side the prefactor must be −1/(m−1)!, independent of m. Every even-power assertion is unaffected.

### Finite-rank Hankel positivity

For u_j=(r_j−q₀)^−2>0,

\[
S_{2r}(q_0)=\sum_{j=1}^h u_j^r.
\]

Thus these numbers form the moments of a positive finite atomic measure. They are rational, since the logarithmic derivatives of a rational-coefficient polynomial at a rational point are rational when the denominator is nonzero.

If d is the number of distinct values among u₁,…,u_h, its Hankel matrices have rank d. Leading Hankel determinants are strictly positive up to size d and are zero above size d. In particular, every determinant of size h+1 is zero. Already at h=1,

\[
\det\begin{pmatrix}1&u\\u&u^2\end{pmatrix}=0.
\]

The claim of all-order strict Hankel positivity is therefore false. Positive semidefiniteness and this exact finite-rank description are the correct replacements.

### Correct finite-power estimate and valid limit

Let d_min=min_j|r_j−q₀|. Since max_j u_j=d_min^−2,

\[
d_{\min}^{-2r}\le S_{2r}(q_0)\le h\,d_{\min}^{-2r}.
\]

Taking negative powers gives

\[
\boxed{h^{-1/(2r)}\le
\frac{S_{2r}(q_0)^{-1/(2r)}}{d_{\min}}
\le1.}
\]

The theorem statement reverses this interval; its proof prints the correct version. For h≥2 the stated lower bound ≥1 is strictly false, because the sum contains more than its largest positive summand. The limit as r→∞ is d_min, as claimed.

## Theorem 3.7, pages 11–12

### Part (1): checked

Let Q=P^(m−1), of degree at least two. Away from its roots,

\[
\frac{(Q')^2-QQ''}{Q^2}=\sum_j\frac1{(X-r_j(Q))^2}>0.
\]

Continuity gives nonnegativity on the whole real axis. At a simple root of Q the expression equals Q'²>0; at a multiple root it vanishes. This proves the stated claim and its possible equality locations.

At ξ,

\[
\frac{P''(\xi)}{P(\xi)}=\left(\sum_j\beta_j\right)^2-\sum_j\beta_j^2
<\left(1-\frac1h\right)\left(\sum_j\beta_j\right)^2.
\]

Strictness is justified because h≥2 and Theorem 3.3 gives both positive and negative β_j, so equality in Cauchy–Schwarz is impossible.

### Part (2): checked, including signs and equality

Normalized Newton inequalities hold for the coefficient sequence of an arbitrary real-rooted polynomial, not just a polynomial with positive coefficients. One direct route is the strengthened Laguerre inequality

\[
(Q')^2\ge\frac{d}{d-1}QQ'',\qquad d=\deg Q,
\]

applied to Q=P^(m−1) at zero. This gives exactly \(\widetilde a_m^2\ge\widetilde a_{m-1}\widetilde a_{m+1}\).

If the neighboring product is negative, strictness is immediate. If it is positive, equality forces all roots of Q to coincide. Because P is real-rooted and its roots are not all equal, this is impossible: a derivative of degree at least two with all roots equal forces, by Rolle/interlacing and the multiplicity relations, the original real-rooted polynomial to have all roots equal. If the neighboring product is zero, equality is equivalent to the middle coefficient being zero. This yields exactly the criterion in part (2).

### Part (3): strict conclusion survives; the nonvanishing argument does not

The shifted polynomial Φ(Y)=P(ξ+Y)/P(ξ) is real-rooted, has Φ(0)=1, and its roots are nonzero and not all equal. The strict Newton inequalities claimed at the end are true, but do not require every intermediate coefficient to be nonzero.

A useful elementary fact is that a real-rooted polynomial with nonzero constant term cannot have two adjacent coefficients equal to zero. If P^(j)(0)=P^(j+1)(0)=0, apply part (1) to Q=P^(j−1). Its Turán expression is zero at zero, so Q(0) must also be zero. Repeating descends to P(0)=0, a contradiction. Applying part (2)'s equality criterion to Φ now rules out every equality case. Therefore

\[
\boxed{\widetilde e_m^2>\widetilde e_{m-1}\widetilde e_{m+1}
\quad(1\le m\le h-1).}
\]

This proves the desired strictness even when an individual e_m is zero.

The manuscript instead claims that a Hankel spectrum is generically distinct and therefore all e_m are nonzero. This implication is false. For example, the real symmetric Hankel matrix

\[
H=\begin{pmatrix}
0&1&0&0\\1&0&0&0\\0&0&0&2\\0&0&2&0
\end{pmatrix}
\]

has the distinct eigenvalues −2,−1,1,2, yet

\[
\det(I+YH)=1-5Y^2+4Y^4,
\]

so e₁=e₃=0. This also disproves the asserted reasoning that two zero neighbors of a coefficient force a block of consecutive zeros or a structure g(Y^q) with q≥3. At m=2 the neighbors vanish while the middle coefficient is −5. Moreover, \(G^{-1/2}MG^{-1/2}\) need not itself be Hankel even though G and M are.

The example is a counterexample to the proposed general structural justification, not a certified counterexample to e_m≠0 for a specific allowed manuscript parameter tuple. Universal nonvanishing in that exact family remains unresolved in this audit. It should be removed unless separately proved; it contributes nothing to the valid strict Newton theorem. Genericity cannot prove a claim for every integer parameter tuple in any event.

## Theorem 3.8, pages 12–13

### Part (1): checked

The measure has all moments and a positive density, so the monic orthogonal polynomials and their positive squared norms exist. The kernel formula in the statement is the standard basis-independent reproducing-kernel identity.

Let A=G^−1/2V, an invertible matrix. Then

\[
B=A\Gamma A^T,\qquad A^{-1}BA=\Gamma A^TA=\Gamma V^TG^{-1}V.
\]

The latter matrix has entries γ_a K_h(−a²,−b²). This is an exact similarity, so it preserves eigenvalues with multiplicities. The pole-kernel matrix is not generally symmetric, but is similar to a real symmetric matrix. All its eigenvalues are real and nonzero.

### Part (2): checked after an explicit deformation definition

The intended definition should be written directly:

\[
G_{ij}(\xi;\tau)=\int_0^\infty
y^{2(i+j)}R(y^2)w_s(y;\tau)\,dy,
\quad
w_s(y;\tau)=\frac{2(2\pi)^{2k}}{(2k)!}y^{2k+1}
\sum_{\ell\ge1}\ell^{2k}e^{-2\pi\ell\tau y}.
\]

It is positive definite for τ>0. Differentiating under the integral is justified locally uniformly for τ in any compact subinterval of (0,∞): the differentiated weight remains bounded near zero and decays exponentially at infinity. Jacobi's determinant identity and the reproducing-kernel formula give exactly (3.8).

If a full deformed pencil is wanted, one may define G(X;τ)=G(ξ;τ)+(X−ξ)M. The paper's phrase about a μ_X-evaluated contribution having no τ-dependence should not replace this definition; the original rational functional at τ=1 does not automatically supply the deformed integrals at τ≠1.

A useful strengthening follows immediately: ∂_τw_s(y;τ)<0 for every y>0, so G'(ξ;τ) is negative definite and

\[
\frac{\partial}{\partial\tau}\log\det G(\xi;\tau)<0.
\]

## Theorem 3.9, pages 13–14

### Part (1): Hurwitz extension

The boxed general pole integral above gives, for a=j+θ,

\[
\int_0^\infty\frac{w_s(y)}{y^2+(j+\theta)^2}\,dy
=(j+\theta)^{2k}\left(\zeta(s,\theta)-
\sum_{\nu=0}^{j-1}(\nu+\theta)^{-s}\right)
-\frac1{2(j+\theta)}-\frac1{2k}.
\]

Thus r_{j,θ}=−1/[2(j+θ)]−1/(2k), which is rational for rational θ. The displayed identity is correct.

The functional must also be defined on monomials by the same Bernoulli values as (2.2). Defining it only on simple poles is insufficient because the entries D_{N,θ}^{2m}t^{i+j}/D_{K,θ} can have polynomial parts. With this explicit completion, the functional is rational-coefficient, its value at X=ζ(s,θ) is a positive integral, and its derivative has the stated nonsingular Vandermonde diagonal factorization. Exact degree h, real-rootedness, and no root at ζ(s,θ) follow.

The same inertia counts hold after aligning the tail-node indexing; the signs alternate. The zero-free spectral formula also applies. Real θ>0 suffices for the analytic/hyperbolic conclusion; rational θ is needed for coefficients in Q[X].

### Part (2): Dirichlet extension

The listed character-polynomial factorizations are correct:

\[
\begin{aligned}
F_{\chi_{-3}}(z)&=z(1-z),&
F_{\chi_{-4}}(z)&=z(1-z^2),\\
F_{\chi_5}(z)&=z(1-z)^2(1+z),&
F_{\chi_8}(z)&=z(1-z^2)(1-z^4),\\
F_{\chi_{-8}}(z)&=z(1+z^2)(1-z^4).
\end{aligned}
\]

They are positive for 0<z<1, so g_χ=F_χ/(1−z^q)>0 and Ω_{s,χ}(y)=y^{s−1}g_χ(y)>0. The integrals converge at zero and infinity, with all polynomial moments finite. The construction therefore yields a positive Gram matrix at the chosen center and an invertible symmetric derivative matrix. In its proof, the undefined coefficient c_{r,χ} should simply be j_r^{s−1}>0. Hyperbolicity and exact degree follow.

The statement says “any integer s≥2” but only defines ξ_χ when χ(−1)=(−1)^{s−1}. Either restrict s to that parity or define ξ_χ=L(s,χ) for every s under discussion. The real-pencil argument works with any real center, so no parity condition is needed for the pure hyperbolicity assertion. Likewise χ(a₀)=+1 is not needed for that assertion once the artificial positive derivative j_r^{s−1} has been chosen.

The arithmetic scope needs an explicit boundary. The monomial constants are

\[
\int_0^\infty y^{2e+s-1}g_\chi(y)\,dy
=\Gamma(2e+s)\left(\frac q{2\pi}\right)^{2e+s}L(2e+s,\chi).
\]

The text proves neither their rationality nor a rational affine expression in the single target L(s,χ). Under the selected parity, these include higher noncritical L-values. The result is a valid real-pencil construction, but it does not, by itself, produce rational determinant polynomials, primitive integer normalizations, or the arithmetic input used in Section 4. That would require an additional rationalization theorem. The theorem's literal real-rootedness claim is not false for failing to establish an arithmetic property it does not explicitly state.

A modest analytic extension is available: positivity also holds, for example, for the primitive characters of discriminants −7 and 12, since

\[
F_{\chi_{-7}}(z)=z(1-z)(1+2z+z^2+2z^3+z^4),
\quad
F_{\chi_{12}}(z)=z(1-z^4)(1-z^6).
\]

More generally, any periodic real coefficient sequence with its finite generating polynomial positive on (0,1) supplies such a positive analytic kernel. This is an extension of the real-pencil statement only.

## Remark 3.10, page 14

The claimed non-classicality of the varying-K primitive family is not established by the two proposed obstructions.

1. **The proposed root-birth criterion is false.** Orthogonal-polynomial interlacing does not say that all new roots are born only at outer edges or that distance to a fixed interior point cannot decrease. Legendre polynomials already give a counterexample: P₂ has roots ±1/√3, while P₃ has a root at zero. Thus approach to an interior point does not contradict Favard theory.

2. **The reciprocal characteristic polynomial needs normalization.** The exact relation is

   \[
   Y^r\Delta_r(\xi-Y^{-1})=\Delta_r(\xi)\det(YI-\widehat B_r).
   \]

   The scalar Δ_r(ξ)>0 does not affect zeros but matters when claiming equality to a monic characteristic polynomial.

3. **The stated “if and only if” is false.** A symmetric matrix need not be tridiagonal in the given basis for its leading characteristic polynomials to agree with an orthogonal-polynomial segment. The nontridiagonal symmetric matrix

   \[
   A=\begin{pmatrix}0&1&1\\1&0&0\\1&0&0\end{pmatrix}
   \]

   has successive leading characteristic polynomials 1, Y, Y²−1, Y³−2Y. These obey the positive Favard recurrence q_{r+1}=Yq_r−q_{r−1} and extend to a positive orthogonal-polynomial family, despite A₁₃≠0. The determinant sequence does not uniquely determine the original matrix in its given basis.

4. **Disjoint support does not imply the claimed entrywise nonvanishing.** The forced zero triangle above gives actual counterexamples. With s=3, N=1, m=1, K=7, one has T=3, so \(\widehat B_{02}=0\) despite |0−2|=2, while \(\widehat B_{03}\ne0\). Thus the parenthetical claim that every off-tridiagonal entry is nonzero is false in the paper's own family. For T≥2 the nonzero entry \(\widehat B_{0T}\) does prove nontridiagonality, including the main weight-five family, but nontridiagonality does not repair the false “if and only if.”

5. **Two distinct families are being conflated.** The theorem about principal minors fixes K and varies r. The claim of non-classicality concerns P_K as K varies. Changing K changes the denominator and all the moments. In general Δ_{K,r} is not a scalar multiple of P_{N+r}; a property of the former chain cannot be transferred to the latter without proof.

A narrower true statement is available for the main family: the normalized reciprocal characteristic polynomials of the fixed-K principal chain begin q₁(Y)=Y and q₂(Y)=Y², because the initial derivative blocks vanish. They cannot be the first terms of a positive Favard recurrence, which would require a strictly positive coefficient b₁ in q₂=(Y−a₁)q₁−b₁. This establishes a precise obstruction for that **fixed-K principal chain**, but not the manuscript's broad non-classicality statement for the varying-K family.

## Downstream propagation and recommended repair order

1. Preserve the valid foundation: the odd-weight integral identity, full positive Gram matrix, exact degree, symmetric spectral factorization, and inertia. They require no irrationality assumption and no simple-spectrum assumption.
2. Correct Proposition 3.2 before using it as an extension agreeing with the original family.
3. Replace nominal principal-minor degree by rank and explicitly accommodate zero eigenvalues. The main-family constant-minor phenomenon is large enough to require revising any principal-chain narrative, not merely adding a footnote.
4. Replace Corollary 3.5's formula by the normalized I+tB resolvent identity. Prove cyclicity if full spectral visibility is needed; otherwise state the shorter fraction for the visible spectral measure. Restrict quantitative root-collapse claims to the independently justified parameter regime.
5. Correct Corollary 3.6 to finite-rank positive semidefinite moment matrices and the correctly oriented bounds. Its useful limit remains available.
6. Retain the strict Newton theorem using the adjacent-zero argument; remove the unsupported coefficient-nonvanishing claim and genericity language.
7. Define the deformation in Theorem 3.8 and complete the Hurwitz functional. Keep the Dirichlet real-pencil result separate from rational/integer arithmetic claims until those are proved.
8. Remove or substantially reprove Remark 3.10. Its present proof does not establish non-classicality.

The positive Gram integral in Section 3 is a one-variable form involving |q(y²)|². It should not be conflated with a later two-variable kernel form involving P(x)P(y): pointwise positivity of a two-variable kernel alone does not imply positive semidefiniteness of that bilinear form. This report certifies (3.2), including for use in later sections, but does not certify such a transfer without its own argument.

## Exact arithmetic reproducibility for the m=7 counterexample

For k=1, N=1, K=2 and m=7, divide (t+1)^13 by t+4. The remainder is (−3)^13. Apply

\[
\mu_X(t^e)=(-1)^e B_{2e+2}(2e+3)/2,
\qquad \mu_X((t+4)^{-1})=4X-19/4.
\]

This gives the displayed affine polynomial exactly. A standard-library rational calculation is:

```python
from fractions import Fraction
from math import comb

B = [Fraction(1)]
for n in range(1, 52):
    B.append(-sum(Fraction(comb(n + 1, j)) * B[j]
                  for j in range(n)) / Fraction(n + 1))
d = 13
c = [Fraction(comb(d, i)) for i in range(d + 1)]
q = [Fraction(0)] * d
for i in range(d, 0, -1):
    q[i - 1] = c[i]
    c[i - 1] -= 4 * c[i]
remainder = c[0]
constant = sum(q[e] * (-1)**e * B[2*e + 2] * Fraction(2*e + 3, 2)
               for e in range(d)) - Fraction(19, 4) * remainder
slope = 4 * remainder
root = -constant / slope
assert constant == Fraction(5783933697, 143)
assert slope == -6377292
assert root == Fraction(1927977899, 303984252)
assert root > 6
```

This is a reproducibility appendix for one exact counterexample, not a numerical approximation to ζ(3).
