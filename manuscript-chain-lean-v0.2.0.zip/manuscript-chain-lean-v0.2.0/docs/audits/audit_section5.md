# Section 5 audit of the supplied 52-page manuscript

Source: /workspace/scratch/579a0a3d0f04/upload/Zetahyperbolic (3)(2).pdf.
Physical PDF pages and printed pages agree. Section 5 occupies pp.22–29. Formulas on pp.24, 27, and 28 were also checked against rendered pages. This assesses the manuscript's structural claims on their own terms. No Lean compilation was performed.

Method: first reconstruct the proofs from their stated definitions; then attack the exact quantifiers, omitted terms, endpoint values, local valuations, and coefficient formulas. Numerical checks below use exact rational arithmetic.

## Status register

| Claim | Status | Finding |
|---|---|---|
| 5.1, (5.1)–(5.2), pp.22–23 | Correct | Both moment formulas follow from the product substitution. |
| 5.2(1), pp.23–24 | Correct | The coefficient Gram matrix is positive definite; congruence gives exact degree and real roots. |
| 5.2(2), (5.4), pp.23–24 | Correct; omitted convergence justification supplied below | The signed expansion is absolutely convergent for real \(L^2\) functions. |
| 5.2(3), literal fixed-\(K\) statement | False | At \(K=h=2\), a three-dimensional form cannot have both positive and negative index at least two. |
| 5.2(3), intended growing-\(K\) statement | Not established by its proof | The proof deletes the full infinite tail. |
| 5.3, pp.24–25 | Correct | The \(x^{4k}\) restriction supplies the correct alternating-tail phase and rational off-diagonal moments. |
| 5.4, (5.5), p.25 | Correct conclusion; replace proof | The pole definition proves the result immediately. The printed reflection sign and special-case division identity are wrong. |
| 5.5, p.25 | Correct domain qualification | An extension is needed before discussing higher-order poles. |
| 5.6(1): integral, pp.26–27 | Correct | Eleven affine-piece integrals sum to \(453803/288000\). |
| 5.6(1): continuity/endpoints | False as written; finite-point repair | Right continuity fails at \(1/3\) and \(1/2\). The integral is unaffected. |
| 5.6(2), pp.26–27 | Correct conclusion after explicit repair | Replace \(25\) by \(16\) in \(Q\). The stated tail bound survives; a stronger bound is available. |
| 5.6(3), pp.26–27 | False local refinement | The two smallest surviving tail poles need not be \(a,p-a\). Exact local valuation \(3\) occurs where the upgrade requires \(9\). |
| 5.7: degree statement for (5.7), p.28 | Correct | The polynomial part and residue at infinity vanish. |
| 5.7: identifying (5.8) with the partial fractions of (5.7) | False | The function has no pole at zero, but the displayed \(A_{n,0}=n!\ne0\). |
| 5.7(1), interpreting (5.8) as an independent definition | Correct, with scaling clarification | The Hermite-block proof works. Its zeta-relation hypothesis is unused. |
| 5.7(2), interpreting (5.8) as an independent definition | Requires explicit correction | There is an extra loss at \(p=5\); another intermediate valuation claim fails when \(n+k\ge p^2\), but factorial valuations repair that issue. |

For 5.7(2), arbitrary integer test parameters do not satisfy the unproved zeta relation. They refute the relation-independent valuation mechanism, not literally the conditional theorem under its full hypothesis. A corrected unconditional algebraic statement is proved below.

## 5.1: reconstruction and adversarial check (pp.22–23)

Write
\[
B(P,Q)=\frac1{720}\int_0^1\int_0^1P(x)Q(y)
\frac{[-\log(xy)]^5}{1-xy}\,dx\,dy.
\]
With \(u=xy\), integration over \(x\in(u,1)\) contributes \(-\log u\) for equal exponents. Thus
\[
B(x^r,x^r)=\frac1{720}\int_0^1\frac{u^r(-\log u)^6}{1-u}\,du
=\sum_{n=r+1}^{\infty}n^{-7}.
\]
For \(r>s\), the inner integral is \((1-u^{r-s})/(r-s)\). Its quotient by \(1-u\) is a finite geometric sum, giving
\[
B(x^r,x^s)=\frac{H_r^{(6)}-H_s^{(6)}}{6(r-s)}.
\]
Tonelli justifies the nonnegative series; the other calculation is finite. The formulas and positivity of the measure are correct.

Positivity of the measure is distinct from positivity of \(B(P,P)\), whose integrand contains \(P(x)P(y)\). For example,
\[
B(1,1)=\zeta(7)>0,\qquad B(1-6x,1-6x)=37\zeta(7)-38<0.
\]
The last inequality follows, for example, from the elementary estimate \(\zeta(7)<97/96\). This is consistent with the intended indefinite dual-pencil architecture.

## 5.2(1): reconstruction and verdict (pp.23–24)

The independent coefficient rows give \(CC^T\succ0\). If \(CC^T=LL^T\), then
\[
G_A(X)=L\left[L^{-1}G_A(\zeta(7))L^{-T}+(X-\zeta(7))I\right]L^T.
\]
The constant middle matrix is real symmetric. Hence the leading coefficient is \(\det(CC^T)>0\), the degree is exactly \(h\), and the roots are \(\zeta(7)-\gamma_j\), counted with multiplicity. No definiteness of \(G_A(\zeta(7))\) is required. The hypothesis can harmlessly be weakened from \(K\ge h\) to \(K+1\ge h\).

## 5.2(2): reconstruction and convergence (pp.23–24)

Define
\[
I_{m,\nu}(f)=\int_0^1 f(x)x^m(-\log x)^\nu\,dx.
\]
Expanding the kernel gives
\[
B(f,f)=\frac1{720}\sum_{m\ge0}\sum_{\nu=0}^5
\binom5\nu I_{m,\nu}(f)I_{m,5-\nu}(f).
\]
Pairing \(\nu\) with \(5-\nu\) gives exactly the paper's \(1/1440\) prefactor and (5.4).

Here is a full convergence justification and a quantitative strengthening. Cauchy–Schwarz gives
\[
|I_{m,\nu}(f)|\le \|f\|_2
\sqrt{\frac{(2\nu)!}{(2m+1)^{2\nu+1}}},
\]
so
\[
|I_{m,\nu}(f)I_{m,5-\nu}(f)|
\le \|f\|_2^2\frac{\sqrt{(2\nu)!(10-2\nu)!}}{(2m+1)^6}.
\]
Furthermore,
\[
C_5:=\frac1{720}\sum_{\nu=0}^5\binom5\nu
\sqrt{(2\nu)!(10-2\nu)!}<13.
\]
Pair symmetric terms and use \(\sqrt{10!}<1905\), \(\sqrt{80640}<284\), and \(\sqrt{17280}<132\). This proves absolute convergence of the paired series and continuity of the quadratic form on real \(L^2(0,1)\). Applying the estimate to \(|f|\) justifies interchange of the kernel expansion and integration.

If “Krein decomposition” is intended to assert separate finiteness of the positive and negative square sums, that also holds. For \(\nu\ge1\), the displayed estimate makes \(\sum_m I_{m,\nu}^2\) summable. For \(\nu=0\), apply the Schur test to \(1/(1-xy)\), with weight \((1-x)^{-1/2}\). Its weighted row integral is at most \(\pi(1-x)^{-1/2}\), giving \(\sum_m I_{m,0}^2\le\pi\|f\|_2^2\). Thus both signed square sums in (5.4) are finite.

## 5.2(3): two independent failures (pp.23–24)

### Quantifiers

The theorem starts with fixed \(K\ge h\), and part (3) claims both \(h\)-dimensional definite subspaces in \(\mathbf Q[x]_{\le K}\). Literally this is false: at \(K=h=2\), the ambient dimension is three, while positive and negative indices cannot both be at least two.

The intended theorem presumably allows a new \(K=K(h,M)\), as suggested by “taking \(K\) sufficiently large” in the proof. This needs an explicit correction. It is separate from the tail problem.

### The missing tail

The finite exponential-logarithmic family is linearly independent. Its Gram system does produce the stated \(f_i\). But their orthogonality conditions only remove negative coordinates for \(m\le M\). The displayed equality on p.24 beginning “reduces by the exact Krein decomposition (5.4) to” must include the additional term
\[
R_M(i,j)=\frac1{1440}\sum_{m>M}\sum_{\nu=0}^2\binom5\nu
\left[
\langle f_i,\psi^+_{m,\nu}\rangle\langle f_j,\psi^+_{m,\nu}\rangle
-\langle f_i,\psi^-_{m,\nu}\rangle\langle f_j,\psi^-_{m,\nu}\rangle
\right].
\]
No sign or sufficiently small norm for \(R_M\) is proved. Membership in the finite span \(W\) does not remove later moments. Thus neither the positive matrix nor its negative analogue has been established. Polynomial density preserves a previously proved strict margin; it cannot supply the missing margin.

Other correctable defects: the statement requests every \(M\ge h\), whereas the proof sets \(M=h-1\); the \(m=0\) exponential-polynomials are not in unweighted \(L^2(0,\infty)\), though their pointwise independence is valid; and the displayed expression for \(u_i^{(0,0)}\) does not match its definition. The finite positive truncation does contain the required identity contribution from all \(m=0,\ldots,h-1,\nu=0\), so that last normalization error is not the central problem.

### A valid explicit finite-tail repair

Let \(H_M\) be the full signed truncation through \(m=M\). The preceding estimate gives, for every \(M\ge0\),
\[
|B(f,f)-H_M(f,f)|
\le13\|f\|_2^2\sum_{m=M+1}^{\infty}(2m+1)^{-6}
\le\frac{13}{10(2M+1)^5}\|f\|_2^2.
\]
The last step is the decreasing-function integral comparison over \([M,\infty)\).

For a rational polynomial basis, its truncated matrix \(H_M\) and \(L^2\) Gram matrix \(L\) are rational. Consequently
\[
H_M-\frac{13}{10(2M+1)^5}L\succ0
\]
is a finite exact sufficient positivity certificate, and
\[
H_M+\frac{13}{10(2M+1)^5}L\prec0
\]
is a negativity certificate. This repairs checking a given proposed basis. It does not prove that the paper's specific construction succeeds for every dimension; that existence claim needs a separate argument.

## 5.3: beta(4) (pp.24–25)

The proof is correct. On the diagonal, \(u^{4k}/(1+u^2)\) is the alternating tail starting at \(2k\), with positive phase. The product substitution supplies another logarithm, giving exactly \(\beta(4)-H_{2k}^{(\beta,4)}\).

Off the diagonal, \(1+u^2\) divides \(1-u^{4(k_1-k_2)}\), and its finite alternating quotient gives the factor \(1/[12(k_1-k_2)]\). Hence the derivative is \(CC^T\), and the valid proof of 5.2(1) gives real-rootedness. This proposition does not depend on 5.2(3).

## 5.4–5.5: simple-pole cancellation (p.25)

The conclusion is immediate from Lemma 2.2's actual pole definition:
\[
\tau_X((x-j)^{-1}-(x+j)^{-1})
=(H_j^{(s)}-X)-(H_{j-1}^{(s)}-X)=j^{-s}.
\]
It holds for every \(j\ge1\), with no special argument at \(j=1\).

The printed proof has two errors:

1. Reflection gives \(\tau_X((x+j)^{-1})=\tau_X((x-(j-1))^{-1})\), with a **plus** sign. Two minus signs cancel. The following line then proceeds as though the corrected sign had been used.
2. The special-case division identity for \(x^{2k+1}/(1-x^2)\) wrongly uses the even difference \(E_1\). Its residual pole expression should be \(-\tfrac12[(x-1)^{-1}+(x+1)^{-1}]\). Thus the printed calculation does not force \(\tau(E_1)=1\).

The one-line calculation from the pole definition completely repairs 5.4. It avoids broader reflection assertions. The introductory sentence asserting the difference identity for every rational \(h\) regular at zero is broader than the earlier specified domain theorem and is unnecessary here.

Remark 5.5 correctly restricts the result to simple poles in the specified domain; a higher-order extension must be defined before making corresponding statements.

## 5.6(1): exact scalar integral, incorrect endpoint claims (pp.26–27)

All eleven affine expressions hold on the interiors of their table intervals; all eleven listed integrals check exactly. Their sum is \(453803/288000\).

Direct substitution at the floor jumps gives instead
\[
T(1/3)=23/6,\qquad T(1/3+)=113/24,
\]
\[
T(1/2)=67/20,\qquad T(1/2+)=4.
\]
At \(y=1\), the definition gives \(-1\), while the final affine piece extends to \(17/20\). Thus the continuity assertions on the half-closed intervals are false, and the table uses one-sided endpoint extensions rather than the actual values. Replace these continuity intervals by open intervals and label the jump entries as limits, or redefine the function at the finitely many exceptional points. The integral is unchanged.

The scalar integration alone does not verify that the function correctly encodes all arithmetic prime valuations; that interpretation additionally needs the local valuation arguments.

## 5.6(2): explicit correction and stronger conclusion (pp.26–27)

Put \(e=l(x,z)-2x\), \(e_\alpha=l(\alpha x,z)-2\alpha x\). Both have mean zero, and
\[
\int_0^{1/2}e_\alpha^2\,dz=d(g)(1-2d(g))\le1/8.
\]
This is the **squared** \(L^2\) norm, not the norm. Because \(b=4l(\alpha x,z)\), the \(-b^2\) term in \(\Gamma\), after changing sign in \(R=-\Gamma-N\), contributes \(+16\int e_\alpha^2\), not \(25\int e_\alpha^2\). The correct identity is
\[
R=xF+Q_{\rm corr},
\]
\[
Q_{\rm corr}=
\frac{\tau(\tau-\sigma)-(\tau-\sigma)_++\eta(1-\eta)}2
+16d(g)(1-2d(g))-4\int_0^{1/2}e e_\alpha\,dz.
\]
An exact test at \(x=3\) gives \(R-3F=199/100\); the printed expression gives \(2483/800\); the corrected expression gives \(199/100\).

The remaining periodic-primitive calculation is valid. Moreover
\[
Q_{\rm corr}\le1/8+2+1/2=21/8:
\]
the \(\tau\) expression is nonpositive, \(\eta(1-\eta)\le1/4\), and Cauchy–Schwarz bounds the covariance by \(1/8\).

The stated \(P,C\), derivatives, means, \(P(20)=74/3\), \(C(20)=0\), and \(|C|<22\) all check. Two integrations by parts give the stronger bound
\[
\int_{20}^{\infty}\frac{R(x)}{x^3}\,dx
\le-\frac{37}{800}
-\frac{74/3-11729/720}{400}
+\frac{44}{8000}+\frac{21}{6400}
=-\frac{8411}{144000}.
\]
This is smaller than the claimed \(-33104/576000=-2069/36000\). Thus the theorem's advertised bound remains valid after correcting the false expansion.

## 5.6(3): exact failure of the local gain (pp.26–27)

The replacement factors are monic of the same degree and congruent modulo \(p\) to the old factors; the basis-change observation is valid. The error is claiming the two smallest **tail** poles are always \(a,p-a\), regardless of \(N\).

Take \(n=1,K=40,N=3,p=11,a=1\). The prime lies in the stated inner range for any \(M>40/11\). The tail poles in the square class \(\pm1\bmod11\) are
\[
10,12,21,23,32,34.
\]
The prescribed top index \(i=s_a-2=4\) cancels \(34,32,23,21\), leaving **10 and 12**. The pole 1 is absent because it is at most \(N\). The surviving pole 12 is above \(p\); its harmonic number retains an \(11^{-7}\) term.

This yields a precise failure of the claimed local valuation. Up to a prefix which is a unit at the two surviving poles, put
\[
E(t)=\prod_{k\in\{34,32,23,21\}}(t+k^2).
\]
The proposed full prefix can be \(t^3E(t)\); it does not affect valuations in this class. At \(k=10,12\), the residue of \(D_N^7E^2/D_{\rm tail}\) has valuation
\[
7+2\cdot4-5=10.
\]
These count respectively one 11-factor in \(D_N(-k^2)\), four in \(E(-k^2)\), and five in \(D_{\rm tail}'(-k^2)\). At \(k=12\),
\[
v_{11}\left(-12^6H_{12}^{(7)}+1/24-1/6\right)=-7,
\]
whereas the moment at 10 is 11-integral. Therefore the local constant sum has valuation exactly \(10-7=3\): its other summand has valuation at least 10, so no cancellation can raise it.

Here \(l_N(1)=1,l_K(1)=7\). The original half-weight is \(4+4-(7+6)/2=3/2\), correctly giving diagonal lower bound 3. The proposed half-weight \(4+4-7/2=9/2\) requires diagonal valuation at least 9, which is false by six powers of 11. The other top index has the analogous discrepancy.

The uniform gain \(6(p-1)\), limiting increase \(+6\) in \(\Gamma\), and universal integral reduction \(1/3\) are thus invalid as claimed. A limited improvement may be available for classes with both \(a,p-a>N\), but the manuscript does not calculate a valid class-dependent gain. For \(p\le N\), neither alleged surviving pole belongs to the tail at all.

## 5.7: the rational function and the functional must be separated (pp.28–29)

### Valid degree statement; false coefficient identification

The degree is \(-7n-2\); multiplication by a polynomial of degree at most \(6n-1\) gives degree at most \(-n-3\le-4\). The polynomial part and residue at infinity vanish.

But the numerator of (5.7) contains \(t^5\), and its denominator only \(t^2\); \(R_n\) has a zero of order three at zero. The printed \(A_{n,0}=n!\ne0\) is impossible as a pole coefficient.

For \(k\ge1\), the actual coefficients are
\[
A^{\rm true}_{n,k}=(-1)^n\binom{6n}{k}^2
\left(\frac{(k+n-1)!}{(k-1)!}\right)^5,
\]
\[
\frac{B^{\rm true}_{n,k}}{A^{\rm true}_{n,k}}
=2H_k-2H_{6n-k}-5(H_{k+n-1}-H_{k-1}).
\]
Both coefficients at \(k=0\) vanish. The discrepancies include sign, shift, and normalization, not a single global scalar. For \(n=1,k=1\), the true double-pole coefficient is \(-36\), whereas the printed formula gives \(-1152\).

Consequently the derivation of (5.8) from (5.7) is false. The correct rational-function construction must be redone. Nevertheless, (5.8) may independently define a rational functional using the printed coefficients; its algebraic valuation properties can still be assessed.

### Part (1) for the independently defined functional

This proof works. At \(q=9m+1,n=2m\), the \(3m\) nodes \(k=q,\ldots,6n\) are distinct modulo \(q\), so their Hermite basis is unimodular. At each node, \(A/n!\) is a unit and \(U_k\equiv-bq^{-6}\pmod{q^{-5}\mathbf Z_q}\). The block is
\[
\begin{pmatrix}(AV+BU)/n!&AU/n!\\AU/n!&0\end{pmatrix}.
\]
Its diagonal has valuation at least \(-7\), and its off-diagonal has valuation exactly \(-6\). The low-node contributions are integral: denominators from \(H_{6n-k}\) or \(H_{n+k}\) are offset by binomial valuations in \(A\). The scaled determinant is a unit, yielding \(v_q(J_{2m})=-36m=-18n\).

To avoid treating \(q^{1/2}\) as an element of \(\mathbf Q_q\), use left block scaling \(\operatorname{diag}(q^7,q^6)\) and right block scaling \(\operatorname{diag}(1,q^{-1})\). This gives the same integer entry exponents \(7,6,6,5\) and determinant factor \(q^{12}\) per block.

The zeta relation is unused. The valid algebraic result holds for arbitrary integers \(a,b,c\), with \(q>11\), \(q\equiv1\bmod9\), and \(q\nmid b\). What is not justified is transferring it to the displayed rational function or a claimed simultaneous-zeta representation.

### Part (2): valid rank mechanism, two coefficient defects

Each local pole contribution has image in the span of its evaluation and derivative vectors, hence rank at most two. The sum over \(L_\rho\) poles has rank at most \(2L_\rho\). The Taylor-basis minor argument and the determinant expansion over residue classes are valid in principle.

The first defect is the printed formula, checked visually:
\[
V_k=a/k^6+b/(5k^7).
\]
It is not \(a/k^6+5b/k^7\). At \(p=5\), \(v_5(V_5)=-8\) when \(5\nmid b\), contradicting the printed bound \(-7\). The stated prime range allows \(p=5\) for \(n=1,2,3,4\).

The second defect is that \(p^2>6n\) does not imply \(p^2>n+k\). In the latter exceptional case \(H_{n+k}\) can have valuation \(-2\), so the printed inequality \(v_p((B/A)U)\ge-7\) fails. However, the same event gives at least five extra powers of \(p\) in \(A/n!\), which repairs the combined term.

Precisely, put \(e=\mathbf1_{n+k\ge p^2}\). Legendre's formula gives
\[
v_p(A/n!)\ge\omega_p(\rho)+5e,\qquad
v_p(B/A)\ge-1-e.
\]
With \(v_p(U_k)\ge-6\), the combined \(BU/n!\) contribution has valuation at least \(\omega_p(\rho)-7+4e\). The \(AV/n!\) term has valuation at least \(\omega_p(\rho)-7-v_p(5)\). After extracting Taylor row/column powers, the derivative term has the same adequate bound. Thus a valid replacement for (5.9), for arbitrary integer parameters, is
\[
v_p(J_n)\ge
\min_{\substack{0\le m_\rho\le2L_\rho\\\sum m_\rho=3n}}
\sum_\rho m_\rho\bigl(m_\rho-1+\omega_p(\rho)-7-v_p(5)\bigr).
\]
Equivalently subtract \(3n\,v_p(5)\) from the printed right-hand side. For \(p\ne5\), the printed bound is restored by the corrected proof. Restricting the theorem to \(p\ne5\) and treating 5 separately is another valid option.

For an exact test of the relation-independent coefficient argument, take \(n=1,a=0,b=1,c=0\) in (5.8). Then
\[
J_1=
-\frac{21036421776477502103541322265419483469081705335403}
{23509249228800000000000000000000}.
\]
Hence \(v_5(J_1)=-20\) and \(5^{20}J_1\equiv4\bmod5\). The printed optimization has \(\omega=(0,0,2,2,7)\), \(L=(2,2,1,1,1)\), and minimum \(-19\). This refutes the universal valuation mechanism asserted in the proof. It does **not** satisfy the assumed zeta relation, and must not be presented as a literal counterexample to that conditional hypothesis. The corrected inequality above avoids that logical issue by being proved for all integer parameters.

## Dependency propagation and retained structural results

1. The moments, positive derivative, and real-rootedness in 5.1, 5.2(1), and 5.3 survive independently of the cone and valuation errors.
2. The signed decomposition survives and gives an explicit finite-tail certificate. Infinitely many plus and minus coordinates alone do not prove infinite positive and negative indices.
3. The fixed-degree version of 5.2(3) must be withdrawn. The growing-degree existence version needs another proof. Later invocations of its construction, including 6.7 and analogous assertions, inherit that gap unless separately justified.
4. The explicit cone in 6.3(2), pp.32–33, does not repair the gap. Its finite-annihilation/concentration argument fails; an independent exact \(h=4\) calculation for the unchanged space and constraints gives a rational vector with \(B(P,P)<-10^{-53}\). The constraint matrix has rank 12 and nullity 4, and all twelve constraints vanish exactly. This refutes that specified universal cone.
5. Simple-pole cancellation (5.5) is retained after replacing its proof with the direct pole-definition calculation.
6. The exact outer integral and the stronger corrected inner tail bound remain available as scalar facts. The uniform pole-ordering improvement does not. Arithmetic exponents using its \(1/3\) gain must be recomputed from a valid class-dependent estimate.
7. The printed functional in 5.7 has a valid independent \(q\)-adic nonvanishing theorem and an explicitly repairable local minor bound. Its claimed rational-function origin is false. Later multi-pole analogues require their own coefficient checks.

These distinctions preserve the section's valid structural content while identifying which results need small corrections, new proofs, or withdrawal.
