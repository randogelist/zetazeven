# Chronological audit: introduction and all of Section 2

Source: `upload/Zetahyperbolic (3)(2).pdf`, 52 pages, dated 21 October 2026. This audit covers the abstract and introduction on pp. 1–3, and Section 2 on pp. 3–7. Page numbers below are the printed page numbers, which agree with PDF page indices. It does not certify the later theorems merely because the introduction announces them.

Two passes were completed. The first reconstructed the algebra, domains, changes of basis, and constants. The second tested boundary cases, exceptional Bernoulli indices, pole shifts, sign parities, and the introduction's claimed transfer principle. Rendered pages 4–6 and enlarged crops of pp. 1 and 4 were checked to resolve signs and denominators. The calculations below are mathematical checks, not Lean certification. An independent standard-library Python script supplies exact rational regression checks; finite checks supplement, rather than replace, the general proofs given here.

## Coverage and principal verdicts

| Item | Pages | Classification | Verdict |
|---|---:|---|---|
| Abstract and introductory previews | 1–3 | Mixed: wording repair; later claims remain dependencies | Do not treat previews as established until the corresponding later arguments pass. “Symmetrically” must not mean equal root distances from ζ(s). |
| Introductory linear-form implication | 1–2 | **False as stated; explicit counterexample** | Exponential upper bounds for linear forms and their coefficients alone do not imply a finite irrationality measure. A Liouville number meets these hypotheses by Dirichlet approximation. |
| Setup and equation (2.1) | 3 | **Correct, checked on paper** | Parameters, products, harmonic numbers, and Bernoulli convention are consistent. |
| Definition 2.1; equations (2.2), (2.3) | 3–4 | **Correct, checked on paper** | A unique Q-linear, affine-in-X functional is defined by the partial-fraction basis. |
| Lemma 2.2; equations (2.4), (2.5) | 4 | **Correct, checked on paper** | Both the monomial and simple-pole pullback calculations are correct, including the constant −1/(2k). |
| Lemma 2.3(1); equation (2.6) | 5 | **Repairable proof; statement is correct** | The polynomial part of the printed proof contains false intermediate identities. A short formal generating-function proof repairs it without changing the lemma. |
| Lemma 2.3(2); equation (2.7) | 5 | **Repairable proof/explanation; stated formula is correct** | There is a derivative-sign error for negative poles and a false domain explanation. The statement can be strengthened to include r=1. |
| Hankel and primitive definitions; (2.8), (2.9) | 5 | **Correct with a forward nonvanishing dependency** | All entries belong to the functional's domain. Nonzero determinant, required in (2.9), follows algebraically from Theorem 2.5; move or explicitly anticipate that observation. |
| Theorem 2.4 | 6 | **Correct, checked on paper** | Rational basis changes preserve the primitive determinant up to sign. For the same basis on both sides, preservation is exact. |
| Commentary following Theorem 2.4 | 6 | **Repairable scope qualification** | The theorem concerns bases of one fixed Q-polynomial space; it does not authorize arbitrary rational-function or X-dependent basis substitutions. |
| Theorem 2.5(1), (2); equations (2.10), (2.11), derivative factorization | 6–7 | **Correct, checked on paper** | The Vandermonde orientation, residues, cancellation, and nonzero weights check. A useful strengthening is sgn γ_a = (−1)^(a−1). |

There are exactly five numbered Definition/Lemma/Theorem items in Section 2: Definition 2.1, Lemmas 2.2 and 2.3, and Theorems 2.4 and 2.5. All are covered. Every numbered equation (2.1)–(2.11) is covered. None of the five result statements has been disproved. The substantive counterexample in this scope is to the introduction's unnumbered linear-form implication, while Lemma 2.3 has genuine but repairable proof defects.

## 1. Abstract and introduction, in manuscript order

### 1.1 Historical claims and primary-reference dependencies, p. 1

The classical Apéry/Beukers/Ball–Rivoal/Zudilin history is background rather than a proof supplied by this manuscript. It should remain attributed to the cited sources. I did not reconstruct those classical proofs in this audit.

The particularly recent references were checked against their primary repository pages on 23 October 2026. They are not nonexistent or automatically refuted by older statements about the status of ζ(5):

- Brown–Zudilin, arXiv:2210.03391v3, dated 29 January 2026, explicitly states an effective infinite sequence with `0 < |ζ(5) − p/q| < q^(-0.86)`. The introduction's approximation-exponent attribution is supported. This exponent concerns approximation error relative to denominator; it is not itself an irrationality measure or an irrationality proof.
- Lai, arXiv:2610.06838, submitted 5 October and revised 15 October 2026, explicitly announces Q-linear independence of `1, ζ(3), ζ(4)` and attributes the determinant method to Fauzan. This verifies the attribution and existence of the source, not every step of its proof.
- Lai–Lupu–Sprang, arXiv:2505.23088, exists and concerns p-adic irrationality. Its primary abstract gives a p-adic analogue of the familiar odd-zeta result. The manuscript's more detailed methodological description requires reading the cited paper, not merely its metadata.
- Fauzan's Zenodo record 22826419 exists and announces a determinant proof of irrationality of ζ(5). The record describes degree `37n`, decay `exp(−139 n²/5)`, and a measure exponent `260`; it also describes the posted material as an initial presentation and says a full manuscript is in preparation. These metadata support the attribution but **do not independently certify the exact prime-sum estimates or numerical constants imported later by the present manuscript**. Different parameters here need an explicit bridge to the exact version/theorem being cited.

Primary URLs consulted:

1. https://arxiv.org/abs/2210.03391
2. https://arxiv.org/abs/2610.06838
3. https://arxiv.org/abs/2505.23088
4. https://zenodo.org/records/22826419

Classification: **source-supported attribution, with external proof dependencies**. Do not call the recent claims false merely because they were open before these cited preprints. Conversely, source existence is not a substitute for checking an imported estimate.

### 1.2 The claimed immediate linear-form irrationality measure, pp. 1–2

The manuscript claims that constructing integer linear forms

`L_n(X) = a_n X − b_n`,

with

`0 < |L_n(ξ)| ≤ exp(−γ n)` and `log |a_n| ≤ τ n`

immediately gives an effective finite irrationality measure by the triangle inequality.

**This implication is false as stated.** The omitted nonvanishing issue occurs already in degree one.

Here is a counterexample using the classical Liouville number

`ξ = Σ_{j≥1} 10^(−j!)`.

For each positive integer n, put `Q = ceil(exp(n))`. Dirichlet's elementary pigeonhole argument gives integers `1 ≤ a_n ≤ Q` and `b_n` with

`0 < |a_n ξ − b_n| ≤ 1/Q ≤ exp(−n)`.

The strict inequality on the left follows from irrationality of ξ. For n≥1, `Q ≤ exp(2n)`, hence `log a_n ≤ 2n`. Thus the printed hypotheses hold with `γ=1`, `τ=2`.

Yet the truncation at index J is a rational with denominator `q_J = 10^(J!)`, and its positive tail satisfies

`0 < ξ − p_J/q_J < 2 · 10^(−(J+1)!) = 2 q_J^(−(J+1))`.

The fraction is in fact reduced (the numerator ends in 1); even without that observation its displayed denominator already supplies the contradiction. For every finite μ, sufficiently large J gives error below `q_J^(−μ)`. There is therefore no finite irrationality measure of the stated kind.

**Where the triangle-inequality argument fails.** If `L_n(a/b) ≠ 0`, then `|L_n(a/b)| ≥ 1/b`, which is useful. But the smallness assumption at ξ does not ensure `L_n(a/b) ≠ 0`. Many successive forms can have the same rational zero. The bounds supplied in the introduction do not control those plateaux.

**Explicit repairs.** Either of the following standard additional hypotheses is sufficient for the intended comparison:

1. Require `a_n b_(n+1) − a_(n+1) b_n ≠ 0` eventually, together with the displayed bounds at every sufficiently large index. Then a rational cannot be a zero of both neighboring forms. Choose n with both errors below `1/(2b)` and apply the integer lower bound to one of them. With effective hypotheses, every exponent `μ > 1 + τ/γ` is effective after absorbing constants.
2. Supply a matching exponential lower bound for `|L_n(ξ)|` as well as the upper bound. If the chosen form vanishes at `a/b`, the lower bound for its value at ξ, divided by its coefficient bound, controls the approximation. The exact resulting exponent depends on the stated lower and upper rates.

Suggested replacement: “For suitably regular sequences of linear forms, with a nonvanishing condition at nearby rationals or appropriate two-sided size bounds, the usual integer lower bound yields an irrationality measure. For growing-degree determinant polynomials one must establish an analogous nonvanishing and perturbation estimate.”

**Downstream effect.** This does not by itself disprove the later zero-free-disk transfer theorem. A zero-free disk is precisely a possible remedy for rational vanishing. It does invalidate the introduction's assertion that the difficulty is absent merely because degree is one.

### 1.3 Growing-degree barrier, p. 2

The observation that `b^h Q_K(a/b)` is an integer, but may be zero, is correct for `Q_K ∈ Z[X]` of degree at most h. A quantitative root-free neighborhood gives nonvanishing there and controls the product

`Q_K(x)/Q_K(ξ) = ∏_j (1 + (x−ξ)/(ξ−r_j))`.

This part of the motivation is sound. Root reality is not needed for that product estimate: a complex zero-free disk also suffices. Hyperbolicity can still be valuable for obtaining or interpreting a root bound, but it should not be conflated with the precise hypothesis of the transfer argument.

### 1.4 Abstract wording “interlace symmetrically across ζ(2k+1),” p. 1

If “symmetrically” means reflection symmetry, or equal distances on the two sides, it is false. It is at best ambiguous if it only means a two-sided interlacing/counting pattern.

An exact example within the printed definitions is `s=3, K=3, N=1, m=1, h=2`. Direct calculation gives

```
G(X) = [[12X − 173/12,       −120X + 577/4],
        [−120X + 577/4,     1128X − 16271/12]],

det G(X) = −864X² + 2087X − 90739/72.
```

The two roots are

`(2087 ± sqrt(97))/1728`.

Their midpoint is `2087/1728`, not ζ(3). This inequivalence needs no high-precision computation: the integral test gives

`ζ(3) < H_5^(3) + 1/50 = 260423/216000 < 260875/216000 = 2087/1728`.

Replace “symmetrically” by the exact, proved count/interlacing formulation. The parity dependence of the general pole signature, derived below, also needs to be respected.

### 1.5 Outline and advertised results, pp. 2–3

The Section 2 preview is supported by the checked algebra below, with the precise basis-space restriction noted under Theorem 2.4. The following later announcements are **not established by the introduction or by Section 2** and must receive their verdict from their own audits: universal hyperbolicity; positive moment realization; total positivity; bilateral root counts; interlacing/pinching; the claimed finite continued fraction and spectral-edge convergence; Newton inequalities and equality cases; Christoffel–Darboux identification; Hurwitz/Dirichlet extensions; the asserted non-classical-family exclusion; quantitative transfer and all numerical exponents; multi-weight irrationality; root-collapse/height claims; and the two-variable/Krein/prime-sum/multiple-pole results.

Two editorial corrections are already definite: the introduction ends with “Section ??” instead of the actual discussion section; and its outline does not adequately describe the substantial Section 6. Renumbered or expanded manuscript content needs a full cross-reference pass.

## 2. Setup and Definition 2.1, pp. 3–4

### 2.1 Equation (2.1), harmonic numbers, and Bernoulli convention

The setup `K>N≥1`, `h=K−N`, `α=N/K`, `λ=h/K=1−α` is consistent. The products

`D_m(t)=∏_{j=1}^m(t+j²)`, `D_0=1`

are monic of degree m with distinct negative-square roots. The harmonic-number and Bernoulli recurrences give the stated values, with the important convention `B_1=−1/2`. There is no sign error here. Reusing m later for the exponent parameter is legal but using a different letter for the index in this preliminary definition would improve readability.

### 2.2 Definition 2.1 and equation (2.2)

Make the domain explicitly

`V = {R ∈ Q(t): all finite poles are simple and belong to {−j²:j≥1}}`.

Every element has a unique finite decomposition

`R(t)=Q(t)+Σ_j c_j/(t+j²)`, with `Q ∈ Q[t]`, `c_j ∈ Q`.

Consequently the given values determine a unique Q-linear map `V → Q[X]`, indeed with image in `Q+QX`. There is no compatibility obstruction from choosing the values independently on monomials and poles. This is a vector space, not an algebra closed under arbitrary multiplication; later uses must continue checking simple-pole membership.

The two forms of (2.2) agree because

`∏_{r=3}^{2k+1}(2e+r) = (2e+2k+1)!/(2e+2)!`.

For k=1 this is one factor, `2e+3`, not an empty product. Some useful low-degree values are `μ_X^(3)(1)=1/4`, `μ_X^(5)(1)=5/12`, and `μ_X^(7)(1)=7/12`. These check the factorial offsets.

### 2.3 Equation (2.3)

The pole value

`μ_X^s((t+j²)^(-1)) = j^(2k)(X−H_j^s)+1/(2j)−1/(2k)`

is well-defined for j≥1, k≥1. All three specializations printed for s=3,5,7 are correct. At this point this is a definition; positivity at X=ζ(s) is a separate analytic claim, not a consequence of its being a rational functional.

A useful immediate coefficient formula is

`[X] μ_X^s(R) = Σ_j j^(2k)c_j`

for the unique partial-fraction decomposition above. This formula already contains the derivative-matrix mechanism of Theorem 2.5.

## 3. Lemma 2.2, p. 4

### 3.1 Definition of τ and equation (2.4)

The analogous domain in `Q(x)` has polynomial part plus finitely many simple integer poles, including the poles at 0 and −1. With `d(r)=r` for r≥0 and `d(r)=−r−1` for r<0, the assignment

`τ_X^s((x−r)^(-1)) = H_(d(r))^s − X`

is well-defined for every integer r. In particular,

`τ_X^s(1/x) = τ_X^s(1/(x+1)) = −X`.

This fact matters for the incorrect domain explanation in Lemma 2.3.

The polynomial prescription (2.4) is also consistent. Its first two nonzero values are

`τ(x^(2k−1))=1/(2k)` and `τ(x^(2k))=−1/2`.

The second is the exceptional even degree overlooked by the printed reflection proof.

### 3.2 Pullback identity (2.5)

For a monomial R(t)=t^e, substitution gives `x^(2k+1)R(−x²)=(-1)^e x^(2e+2k+1)`. Applying (2.4) gives exactly (2.2).

For R(t)=1/(t+j²), the printed rational identity is correct:

`x^(2k+1)/(j²−x²) = −Σ_(r=1)^k j^(2r−2)x^(2k+1−2r) − (j^(2k)/2)(1/(x−j)+1/(x+j))`.

It can be verified by multiplication by `j²−x²`. The r=1 polynomial term maps to `−1/(2k)`; every remaining polynomial term has degree below `2k−1` and maps to zero. The pole pair maps to

`−(j^(2k)/2)(H_j^s+H_(j−1)^s−2X) = j^(2k)(X−H_j^s)+1/(2j)`.

Adding the polynomial contribution recovers (2.3), including both rational correction terms. The enlarged rendering confirms the manuscript really prints the minus sign before `1/(2k)` in this proof.

The domain check also passes: each original negative-square pole produces distinct simple poles at ±j, and j≥1 prevents a collision at x=0. Thus the linear-extension argument covers every R in Definition 2.1.

**Verdict: correct, with a complete valid proof.** No p-adic integral interpretation follows merely from this algebraic identity; any such interpretation is an additional downstream theorem.

## 4. Lemma 2.3, p. 5

### 4.1 Reflection identity (2.6): true statement, incorrect polynomial proof

The simple-pole proof is correct because `d(−1−r)=d(r)` and

`1/(−1−x−r) = −1/(x−(−1−r))`.

The polynomial proof contains two distinct false assertions:

1. It claims `τ((1+x)^d)=τ(x^d)` throughout the range d≥2k−1. At d=2k,

   `τ(x^(2k))=−1/2`, whereas `τ((1+x)^(2k))=−1/2+2k·(1/(2k))=+1/2`.

   The exceptional Bernoulli index 1 does not disappear in the way claimed.
2. It says Bernoulli numbers with even index greater than 1 vanish. The vanishing indices are odd indices greater than 1. In addition, the degree d=2k contributes despite being even.

These errors invalidate that argument, **not the reflection identity itself**.

A complete replacement is obtained from the formal exponential generating function

`T(z)=Σ_(d≥0) τ(x^d) z^d/d! = z^(2k)/((2k)!(e^z−1))`.

This is a formal power series (its lowest exponent is 2k−1). Then

`Σ_(d≥0) τ((-1−x)^d) z^d/d! = e^(−z)T(−z) = −T(z)`.

Coefficient comparison proves the polynomial identity for every d, including d=2k. Together with the correct pole calculation, this proves (2.6) for the entire stated domain.

**Downstream impact:** reflection-based deductions need not be discarded, but they should cite this repaired proof rather than repeat the false parity reasoning.

### 4.2 Difference identity (2.7): true on the stated domain and stronger than stated

For r≥1,

`τ((x−(r−1))^(-1)−(x−r)^(-1)) = H_(r−1)^s−H_r^s = −r^(−s)`.

For r≤−1,

`τ((x−(r−1))^(-1)−(x−r)^(-1)) = H_(−r)^s−H_(−r−1)^s = (−r)^(−s) = −r^(−s)`.

The derivative is uniformly

`h^(2k)(0) = (2k)! (−r)^(−(2k+1)) = −(2k)! r^(−(2k+1))`.

In the negative-r paragraph the manuscript instead first writes `(2k)!(-1)^(2k)r^(−(2k+1))`; that expression has the wrong sign. For k=1,r=−1 it is −2, while the actual second derivative of 1/(x+1) at 0 is +2. Replace that step with the uniform derivative formula above.

The explanation for excluding r=0 and r=1 is also false: τ was expressly defined at poles at 0. The actual distinction is:

- r=0 must be excluded from an ordinary derivative-at-zero statement because h is singular at 0. The τ-values themselves remain defined; their difference is 0.
- r=1 is permitted. Its shifted function is 1/x, which belongs to the domain of τ. The left side is `−X−(1−X)=−1`, exactly the derivative expression.

The lemma can therefore be strengthened by replacing `r ∈ Z \ {0,1}` with `r ∈ Z \ {0}`.

There is a further useful rigorous extension. For every g in the τ-domain that is regular at 0,

`τ(g(x+1)−g(x)) = g^(2k)(0)/(2k)!`.

The polynomial part follows from `(e^z−1)T(z)=z^(2k)/(2k)!`; the pole part follows from the calculation just given. For the entire τ-domain, including a simple pole at 0, the same formula holds if the right side is read as the coefficient of x^(2k) in the Laurent expansion of g at 0. The 1/x basis element has coefficient zero and τ-difference zero.

**Downstream impact:** any p-adic or shift argument should state regularity at the evaluation point, or explicitly use the Laurent coefficient. Treating τ as undefined at pole 0 is inconsistent with Lemma 2.2 and can cause spurious exclusions later.

## 5. Equations (2.8) and (2.9), p. 5

For m≥1,

`D_N(t)^(2m)t^(i+j)/D_K(t) = D_N(t)^(2m−1)t^(i+j)/D_tail(t)`.

All remaining poles lie at −a² with N<a≤K, and are simple. Thus every matrix entry lies in the domain of Definition 2.1, for all i,j<h. No additional inequality such as `2mN≤K` is needed merely to define the functional; polynomial quotients are explicitly allowed.

Each entry is affine in X and the matrix is symmetric/Hankel, so its determinant belongs to Q[X] and has degree at most h. The content definition is the usual unique positive rational content for a nonzero rational polynomial. Dividing by it produces a primitive integer polynomial without changing the leading sign.

Equation (2.9) is introduced before nonvanishing of Δ has been proved. This is a presentation dependency, not a counterexample: Theorem 2.5 immediately gives an invertible derivative matrix and hence a nonzero leading coefficient. Move (2.9) after that observation, or state explicitly here that nonvanishing will follow from Theorem 2.5. No analytic positivity is needed for this particular issue.

## 6. Theorem 2.4 and its scope, p. 6

Let M_A and M_B be the coefficient matrices of the two Q-bases in the monomial basis. The displayed relation

`G_(A,B)(X)=M_A G_K(X) M_B^T`

has the correct orientation. Its determinant is `c Δ_K(X)` with nonzero rational `c=det(M_A)det(M_B)`. The content identity

`cont_Q(c Δ)=|c| cont_Q(Δ)`

then gives `P_(A,B)=sgn(c) P_K`. This is a complete proof under the stated nonvanishing hypothesis.

**Strengthening.** If the same basis is used on both sides, `c=(det M_A)^2>0`, so the primitive polynomial is exactly unchanged, without a sign ambiguity. More generally the argument works for any bilinear form on any fixed finite-dimensional Q-vector space whose values lie in Q[X]; the special form of W is unnecessary for the invariance theorem itself.

**Scope correction in the following prose.** Pochhammer or Jacobi families are covered only when their members form a Q-basis of the stated space (in particular, rational parameters/coefficient conditions and nonzero degrees must be respected). “Cauchy-type rational bases over the common denominator” require an explicit identification with the same fixed polynomial numerator space and the same bilinear form. Arbitrary rational-function substitutions need not lie in Q[t]_<h and may create higher-order poles outside the domain. Arbitrary X-dependent changes are excluded as well: even in dimension one, multiplying a basis vector by X multiplies the determinant by X and changes its primitive polynomial.

This is a genuine basis-invariance statement, not a proof that changing the subspace, denominator, weight, pole multiplicities, or moment functional can never improve an arithmetic construction.

## 7. Theorem 2.5, pp. 6–7

### 7.1 Interpolation and equation (2.10)

The nodes `v_a=−a²`, N<a≤K, are distinct. The matrix `V_(i,a)=v_a^i` is h×h and invertible. The Lagrange polynomials in (2.10) satisfy `L_a(v_b)=δ_(a,b)`; the denominator is exactly

`D_tail'(v_a)=∏_(N<b≤K,b≠a)(b²−a²)`.

If C is their coefficient matrix, `CV=I`, hence C=V^(-1). Therefore the transformed Gram matrix is correctly

`G_tilde=V^(-1)G(V^T)^(-1)`.

There is no transpose error here.

### 7.2 Off-diagonal assertion

Using `D_K=D_N D_tail`, the argument of μ in the transformed (a,b) entry is

`R_(a,b)(t)=D_N(t)^(2m−1)D_tail(t) / [D_tail'(v_a)D_tail'(v_b)(t+a²)(t+b²)]`.

For a≠b both denominator factors cancel. The result is a polynomial with rational coefficients, so its μ-value is independent of X. This proves Theorem 2.5(1).

### 7.3 Diagonal assertion and equation (2.11)

For a=b a single simple pole remains at v_a. Its residue is

`c_a=D_N(v_a)^(2m−1)/D_tail'(v_a)`.

Write `R_(a,a)=P_a+c_a/(t+a²)`. Applying (2.3) gives

`G_tilde_(a,a)=γ_a(X−H_a^s)+r_a`,

where

`γ_a=a^(2k)c_a`,

`r_a=μ(P_a)+c_a(1/(2a)−1/(2k)) ∈ Q`.

This both proves (2.11) and makes the previously unspecified rational constant explicit. Nonvanishing holds because a>N, so no factor in `D_N(−a²)` vanishes, and every node difference in the denominator is nonzero.

Taking the X coefficient and reversing the congruence gives exactly

`M_K=V diag(γ_a) V^T`.

All assertions of Theorem 2.5 pass.

### 7.4 Strengthenings and downstream parity constraints

The sign is especially simple. The numerator `D_N(−a²)^(2m−1)` has sign (−1)^N. Among the factors of `D_tail'(−a²)`, exactly a−N−1 are negative. Hence

`sgn γ_a = (−1)^(a−1)`.

Thus positive weights occur at odd a and negative weights at even a, independently of k and m. By real congruence, the inertia of M is the count of odd and even integers in `{N+1,…,K}`:

- h even: `(h/2,h/2)`;
- h odd and N even: `((h+1)/2,(h−1)/2)`;
- h odd and N odd: `((h−1)/2,(h+1)/2)`.

A claimed general signature `(floor(h/2),ceil(h/2))` therefore needs the appropriate parity condition. The specialized weight-five choice N=3n,h=27n does have that signature: for n odd the interval starts at an even integer, and for n even h is even. This distinction should not be lost when generalizing the statement to arbitrary N,K.

An exact one-dimensional check makes the issue transparent: for s=3,m=1,

`N=1,K=2: G(X)=29/2−12X`,

`N=2,K=3: G(X)=360X−5191/12`.

Their derivative signs are opposite.

The determinant identity also gives

`det M = (−1)^(h(h−1)/2) ∏_(a=N+1)^K a^(2k)D_N(−a²)^(2m−1) ≠ 0`.

Consequently Δ has **exact degree h** already by algebra, before any positivity argument, and (2.9) is legitimate. Its leading sign is `(−1)^(hN+h(h−1)/2)`, unchanged by positive rational-content normalization. The factorization itself does not prove that G(ζ(s)) is positive definite or that the roots are real; those remain the next section's analytic responsibilities.

## 8. Exact reproducibility and limits of these checks

Files in this review directory:

- `check_section2.py`: Python standard library only; exact rational polynomial arithmetic, no floating-point assertions.
- `check_section2_results.txt`: captured successful output.
- `section2-page-04.png`, `section2-page-05.png`, `section2-page-06.png`: rendered source pages.
- `section2-page04-pullback.png` and `intro-linearform.png`: enlarged source crops resolving the key signs and the exact introductory hypotheses.

Run:

`python3 tmp/pdfs/new_upload_review/check_section2.py`

The script passed 160 polynomial reflection checks, 260 difference checks, 85 pullback checks, and 54 matrix parameter sets (`1≤N≤3`, `1≤h≤3`, `1≤m≤2`, `1≤k≤3`). It verifies the derivative factorization, nonzero leading coefficient, degree, sign parity, and the exact 2×2 example. It also prints the reflection-proof and derivative-sign counterexamples.

These finite checks are deliberately not presented as proofs for all parameters. The universal arguments are the partial-fraction uniqueness, formal generating-function identities, and Vandermonde/residue calculations supplied above. The introduction's Liouville counterexample is proved mathematically and does not depend on a finite numerical search.
