import ITEMS_01_DEFINITIONS
import Mathlib.Algebra.Polynomial.BigOperators
import Mathlib.Algebra.Polynomial.Degree.SmallDegree
import Mathlib.LinearAlgebra.Complex.Module
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.Symmetric
import Mathlib.Tactic.Ring

/-!
# ITEMS 02 — Section 2: selected algebraic pencil foundation

CONSTRUCTIONS: the centered real symmetric pencil.
PROOFS: symmetry, exact polynomial identification, determinant evaluation, and
positive-Gram input implies nonvanishing of the actual manuscript determinant.
HYPOTHESIS WHEN USED: positive definiteness of the actual Gram matrix; its
analytic integral realization is not asserted by the algebraic definitions.
This file does not claim to formalize every numbered statement in Section 2.
-/

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChain.Spectral

/-- A real symmetric affine pencil, with its base value specified at its center. -/
structure SymmetricAffinePencil (n : ℕ) where
  center : ℝ
  base : Matrix (Fin n) (Fin n) ℝ
  direction : Matrix (Fin n) (Fin n) ℝ
  base_symmetric : base.IsSymm
  direction_symmetric : direction.IsSymm

namespace SymmetricAffinePencil

variable {n : ℕ} (p : SymmetricAffinePencil n)

/-- The actual matrix evaluated at a real parameter. -/
def matrixAt (x : ℝ) : Matrix (Fin n) (Fin n) ℝ :=
  p.base + (x - p.center) • p.direction

/-- The actual affine matrix with polynomial entries. -/
def polynomialMatrix : Matrix (Fin n) (Fin n) ℝ[X] :=
  fun i j => C (p.base i j) + (X - C p.center) * C (p.direction i j)

/-- The determinant polynomial, rather than an unspecified polynomial proxy. -/
def detPolynomial : ℝ[X] := Matrix.det p.polynomialMatrix

/-- The determinant of the actual evaluated matrix. -/
def detValue (x : ℝ) : ℝ := Matrix.det (p.matrixAt x)

/-- The analytic positive-Gram assertion that has to be supplied for an actual
manuscript pencil. This definition does not construct a proof of that assertion. -/
def BasePositive : Prop := p.base.PosDef

@[simp] theorem matrixAt_center : p.matrixAt p.center = p.base := by
  simp [matrixAt]

/-- Polynomial evaluation commutes with this determinant. -/
theorem eval_detPolynomial (x : ℝ) : p.detPolynomial.eval x = p.detValue x := by
  unfold detPolynomial detValue
  change (Polynomial.evalRingHom x) (Matrix.det p.polynomialMatrix) = _
  rw [(Polynomial.evalRingHom x).map_det]
  congr 1
  ext i j
  simp [polynomialMatrix, matrixAt]

@[simp] theorem eval_detPolynomial_center :
    p.detPolynomial.eval p.center = Matrix.det p.base := by
  rw [p.eval_detPolynomial]
  simp [detValue]

/-- Positive definiteness alone proves nonvanishing of the base determinant;
no root-factorization certificate is needed for this implication. -/
theorem base_det_ne_zero_of_positive (h : p.BasePositive) : Matrix.det p.base ≠ 0 := by
  exact ((Matrix.isUnit_iff_isUnit_det p.base).mp
    (show p.base.PosDef from h).isUnit).ne_zero

theorem center_nonvanishing_of_positive (h : p.BasePositive) :
    p.detPolynomial.eval p.center ≠ 0 := by
  rw [p.eval_detPolynomial_center]
  exact p.base_det_ne_zero_of_positive h

end SymmetricAffinePencil


end ManuscriptChain.Spectral

namespace ManuscriptChain.Real

theorem numerator_symmetric (p : Parameters) (i j : ℕ) :
    numerator p i j = numerator p j i := by
  simp only [numerator, Nat.add_comm]

theorem entryA_symmetric (p : Parameters) (i j : ℕ) :
    entryA p i j = entryA p j i := by
  simp only [entryA, quotient, residue, numerator_symmetric p i j]

theorem entryM_symmetric (p : Parameters) (i j : ℕ) :
    entryM p i j = entryM p j i := by
  simp only [entryM, residue, numerator_symmetric p i j]

@[simp] theorem evalQ_pencil (p : Parameters) (i j : Fin p.h) (x : ℝ) :
    evalQ (pencil p i j) x =
      (entryA p i.val j.val : ℝ) + (entryM p i.val j.val : ℝ) * x := by
  simp [evalQ, realPolynomial, pencil]

theorem gram_symmetric (p : Parameters) (x : ℝ) : (gram p x).IsSymm := by
  ext i j
  simp only [Matrix.transpose_apply, gram, evalQ_pencil,
    entryA_symmetric p j.val i.val, entryM_symmetric p j.val i.val]

theorem derivativeMatrix_symmetric (p : Parameters) : (derivativeMatrix p).IsSymm := by
  ext i j
  simp only [Matrix.transpose_apply, derivativeMatrix, entryM_symmetric p j.val i.val]

/-- The actual manuscript pencil centered at its zeta value. -/
def manuscriptPencil (p : Parameters) : Spectral.SymmetricAffinePencil p.h where
  center := zeta p.weight
  base := gram p (zeta p.weight)
  direction := derivativeMatrix p
  base_symmetric := gram_symmetric p _
  direction_symmetric := derivativeMatrix_symmetric p

@[simp] theorem manuscriptPencil_center (p : Parameters) :
    (manuscriptPencil p).center = zeta p.weight := rfl

theorem manuscriptPencil_matrixAt (p : Parameters) (x : ℝ) :
    (manuscriptPencil p).matrixAt x = gram p x := by
  ext i j
  simp only [Spectral.SymmetricAffinePencil.matrixAt, manuscriptPencil,
    Matrix.add_apply, Matrix.smul_apply, smul_eq_mul, gram, evalQ_pencil,
    derivativeMatrix]
  ring

theorem manuscriptPencil_polynomialMatrix (p : Parameters) :
    (manuscriptPencil p).polynomialMatrix =
      (pencil p).map (Polynomial.mapRingHom (Rat.castHom ℝ)) := by
  apply Matrix.ext
  intro i j
  simp [Spectral.SymmetricAffinePencil.polynomialMatrix, manuscriptPencil,
    gram, evalQ, realPolynomial, derivativeMatrix, pencil, Polynomial.mapRingHom]
  ring

/-- Exact equality of determinant polynomials, not just equality of their roots. -/
theorem manuscriptPencil_detPolynomial (p : Parameters) :
    (manuscriptPencil p).detPolynomial = realPolynomial (delta p) := by
  unfold Spectral.SymmetricAffinePencil.detPolynomial
  rw [manuscriptPencil_polynomialMatrix]
  exact ((Polynomial.mapRingHom (Rat.castHom ℝ)).map_det (pencil p)).symm

theorem delta_eval_eq_det_gram (p : Parameters) (x : ℝ) :
    evalQ (delta p) x = Matrix.det (gram p x) := by
  rw [evalQ, ← manuscriptPencil_detPolynomial,
    Spectral.SymmetricAffinePencil.eval_detPolynomial]
  simp only [Spectral.SymmetricAffinePencil.detValue, manuscriptPencil_matrixAt]

/-- A genuine positive-Gram input gives nonvanishing for the actual rational
determinant evaluated at the actual real zeta series. -/
theorem delta_nonzero_of_positive (p : Parameters)
    (h : (gram p (zeta p.weight)).PosDef) :
    evalQ (delta p) (zeta p.weight) ≠ 0 := by
  have hc := (manuscriptPencil p).center_nonvanishing_of_positive h
  simpa only [manuscriptPencil_detPolynomial, manuscriptPencil_center, evalQ] using hc


end ManuscriptChain.Real
