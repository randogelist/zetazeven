#!/usr/bin/env python3
"""Validate audit metadata and provenance; this is not a mathematical proof."""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-sources", action="store_true",
                        help="also verify the bundled PDF, text, and Markdown snapshots")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    raw = (root / "catalog.json").read_bytes()
    catalog = json.loads(raw)
    errors: list[str] = []

    def check(condition: bool, message: str) -> None:
        if not condition:
            errors.append(message)

    claims = catalog["claims"]
    subclaims = [sub for claim in claims for sub in claim["subclaims"]]
    holes = catalog["hole_catalog"]
    expected = [f"{section}.{index}" for section, count in
                [(2, 5), (3, 10), (4, 11), (5, 7), (6, 18)]
                for index in range(1, count + 1)]
    claim_ids = [claim["id"] for claim in claims]
    subclaim_ids = [sub["id"] for sub in subclaims]
    hole_ids = [hole["id"] for hole in holes]
    known = set(claim_ids + subclaim_ids)
    allowed_statuses = {"verified-on-paper", "repair", "open-bridge",
                        "refuted-as-written", "conjecture"}
    check(claim_ids == expected, "Numbered coverage differs from Sections 2.1–6.18.")
    check(len(claim_ids) == len(set(claim_ids)) == 51, "Numbered IDs are not 51 unique IDs.")
    check(len(subclaim_ids) == len(set(subclaim_ids)) == 198,
          "Subclaim IDs are not 198 unique IDs.")
    check(len(hole_ids) == len(set(hole_ids)) == 30, "Hole tags are not 30 unique IDs.")
    check(catalog["schema_version"] == "1.0.0", "Unexpected catalog schema version.")

    for claim in claims:
        for sub in claim["subclaims"]:
            check(sub["id"].startswith(claim["id"] + "."),
                  f"Subclaim {sub['id']} has the wrong numbered parent.")
    for item in claims + subclaims:
        ident = item["id"]
        check(item["status"] in allowed_statuses, f"Unknown status for {ident}.")
        check(bool(item["source_pages"]) and all(
            isinstance(page, int) and 1 <= page <= 52 for page in item["source_pages"]),
            f"Invalid source pages for {ident}.")
        check(set(item["dependencies"]) <= known, f"Unknown dependency for {ident}.")
        check(set(item["holes"]) <= set(hole_ids), f"Unknown hole tag for {ident}.")
    for sub in subclaims:
        if sub["status"] == "refuted-as-written":
            check(not sub["holes"], f"Refuted subclaim {sub['id']} has a hole tag.")
            check(sub["admissible_as_whole_printed_hypothesis"] is False,
                  f"Refuted subclaim {sub['id']} is not explicitly excluded.")
            check(sub["debt_classification"] == "refuted-no-admissible-proof-obligation",
                  f"Refuted subclaim {sub['id']} has the wrong debt class.")
        if sub["status"] == "open-bridge" and sub["holes"]:
            check(sub["debt_classification"] == "mathematical-hole",
                  f"Active bridge {sub['id']} is not a mathematical hole.")
    refuted = {sub["id"] for sub in subclaims if sub["status"] == "refuted-as-written"}
    check(len(refuted) == 46, "Expected exactly 46 refuted subclaims.")
    check(set(catalog["forbidden_as_hypotheses"]) == refuted,
          "The forbidden-hypothesis list differs from the refuted subclaims.")
    for hole in holes:
        check(hole["debt_classification"] == "mathematical-hole" and
              hole["eligible_as_explicit_hypothesis"] is True and
              hole["not_a_refuted_printed_assertion"] is True,
              f"Invalid mathematical-hole classification for {hole['id']}.")
        check(set(hole.get("required_for", [])) | set(hole.get("used_by", [])) <= known,
              f"Unknown hole consumer for {hole['id']}.")
    roles = {
        "mathematical-dependency-on-the-stated-subclaim-with-its-hypotheses",
        "mixed-item-context-select-retained-subclaims-before-formalization",
        "numbered-item-summary-reference",
        "refutation-or-replacement-context-not-a-premise",
    }
    for edge in catalog["dependency_edges"]:
        check(edge["from_id"] in known and edge["to_id"] in known,
              f"Unknown endpoint in dependency edge {edge}.")
        check(edge["role"] in roles, f"Unknown dependency role: {edge['role']}.")
    for endpoint in catalog["endpoints"]:
        check(set(endpoint["required_claims"]) <= known,
              f"Unknown claim in endpoint {endpoint['id']}.")
        check(set(endpoint["required_holes"]) <= set(hole_ids),
              f"Unknown hole in endpoint {endpoint['id']}.")
    check(dict(Counter(item["status"] for item in claims)) ==
          catalog["status_summary"]["numbered_items"], "Numbered status summary is stale.")
    check(dict(Counter(item["status"] for item in subclaims)) ==
          catalog["status_summary"]["subclaims"], "Subclaim status summary is stale.")

    manuscript = catalog["source"]["manuscript"]
    check(manuscript["sha256"] ==
          "935767c0cda7468f376cd8eadc374077caf6c8a060351d3bea26ac3f838a9d0c",
          "Unexpected manuscript identity.")
    check(manuscript["page_count"] == 52 and manuscript["manuscript_date"] == "2026-10-21",
          "Unexpected manuscript date or page count.")
    inventory = (root / "ManuscriptChain" / "Inventory.lean").read_text()
    for name, expected_hash in [
        ("catalogSha256", hashlib.sha256(raw).hexdigest()),
        ("sourceSha256", manuscript["sha256"]),
    ]:
        match = re.search(rf'def {name} : String := "([0-9a-f]{{64}})"', inventory)
        check(match is not None and match.group(1) == expected_hash,
              f"Inventory.lean has a stale {name}.")

    if args.check_sources:
        snapshots = [("source/manuscript.pdf", manuscript),
                     ("source/paper.txt", manuscript["text_extraction"]),
                     ("docs/AUDIT.md", catalog["audits"]["consolidated_markdown"])]
        snapshots.extend((f"docs/audits/audit_{key}.md", catalog["audits"][key])
                         for key in ["section2", "section3", "section4", "section5",
                                     "section6a", "section6b"])
        for relative, provenance in snapshots:
            path = root / relative
            if not path.is_file():
                errors.append(f"Missing source snapshot: {relative}.")
                continue
            data = path.read_bytes()
            check(len(data) == provenance["byte_length"], f"Size mismatch: {relative}.")
            check(hashlib.sha256(data).hexdigest() == provenance["sha256"],
                  f"Hash mismatch: {relative}.")
    if errors:
        print("Catalog validation failed:", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    print("PASS: 51 numbered items, 198 subclaims, 30 mathematical holes, 46 excluded refutations.")
    print("PASS: references, classifications, summaries, and embedded catalog/source hashes.")
    if args.check_sources:
        print("PASS: bundled source and audit snapshot hashes.")
    print("These checks validate metadata and provenance, not mathematical truth.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
