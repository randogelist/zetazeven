import ITEMS_04_TRANSFER
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Algebra.Polynomial.Roots

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChain.Real

def mainParameters (n : ℕ) : Parameters := ⟨2, 3, 3 * n, 30 * n⟩

def section4Scale (n : ℕ) : ℚ :=
  let p := mainParameters n
  (Nat.factorial p.K : ℚ) ^ (2 * p.h) * 4 ^ (p.h - 1) /
    ((Nat.factorial p.N : ℚ) ^ (12 * p.h) *
      ∏ i ∈ Finset.Icc 1 (p.h - 1), (Nat.factorial (2 * i) : ℚ) ^ 2)

def mainDelta (n : ℕ) : ℚ[X] := delta (mainParameters n)
def mainF (n : ℕ) : ℚ[X] := C (section4Scale n) * mainDelta n

def epsilon : ℚ := 1 / 2500
def rhoPrinted : ℚ := 11411 / 1000
def rhoRepaired : ℚ := 11407 / 1000

end ManuscriptChain.Real

namespace ManuscriptChain.MainChain

open Polynomial
open RealTransfer

def zeta5 : ℝ := Real.zeta 5

def mainK (n : ℕ) : ℝ := ((Real.mainParameters n).K : ℝ)

@[simp] theorem mainK_eq (n : ℕ) : mainK n = (30 * n : ℕ) := rfl

structure MainNormalization where
  Q : ℕ → Polynomial ℤ
  multiplier : ℕ → ℚ
  onset : ℕ
  onset_ge_one : 1 ≤ onset
  multiplier_pos : ∀ n, onset ≤ n → 0 < multiplier n
  polynomial_identity : ∀ n, onset ≤ n →
    (Q n).map (algebraMap ℤ ℚ) = C (multiplier n) * Real.mainF n

theorem MainNormalization.eval_transport (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) (x : ℝ) :
    evalReal (A.Q n) x = (A.multiplier n : ℝ) * Real.evalQ (Real.mainF n) x := by
  have hcomp : (Rat.castHom ℝ).comp (Int.castRingHom ℚ) = Int.castRingHom ℝ := by
    ext z
    simp
  calc
    evalReal (A.Q n) x = Real.evalQ ((A.Q n).map (algebraMap ℤ ℚ)) x := by
      simp [evalReal, Real.evalQ, Real.realPolynomial, Polynomial.map_map, hcomp]
    _ = Real.evalQ (C (A.multiplier n) * Real.mainF n) x :=
      congrArg (fun p : Polynomial ℚ => Real.evalQ p x) (A.polynomial_identity n hn)
    _ = (A.multiplier n : ℝ) * Real.evalQ (Real.mainF n) x := by
      simp [Real.evalQ, Real.realPolynomial]

structure BaseValuePositive (onset : ℕ) : Prop where
  positive : ∀ n, onset ≤ n → 0 < Real.evalQ (Real.mainF n) zeta5

def multiplierRate : ℝ := -232425 / 100000 + 1 / 100000

def archimedeanRate : ℝ := 232380 / 100000 + 1 / 100000

def decayBudget (n : ℕ) : ℝ := _root_.Real.exp (-(1 / 2500 : ℝ) * (mainK n) ^ 2)

structure MultiplierUpper (A : MainNormalization) : Prop where
  upper : ∀ n, A.onset ≤ n →
    (A.multiplier n : ℝ) ≤ _root_.Real.exp (multiplierRate * (mainK n) ^ 2)

structure ArchimedeanUpper (onset : ℕ) : Prop where
  upper : ∀ n, onset ≤ n →
    Real.evalQ (Real.mainF n) zeta5 ≤
      _root_.Real.exp (archimedeanRate * (mainK n) ^ 2)

theorem combined_rate_le : multiplierRate + archimedeanRate ≤ -(1 / 2500 : ℝ) := by
  norm_num [multiplierRate, archimedeanRate]

theorem normalized_value_pos (A : MainNormalization)
    (positive : BaseValuePositive A.onset) (n : ℕ) (hn : A.onset ≤ n) :
    0 < evalReal (A.Q n) zeta5 := by
  rw [A.eval_transport n hn]
  exact mul_pos (by exact_mod_cast A.multiplier_pos n hn) (positive.positive n hn)

theorem main_decay (A : MainNormalization)
    (positive : BaseValuePositive A.onset)
    (multiplier : MultiplierUpper A)
    (archimedean : ArchimedeanUpper A.onset) :
    Decay A.Q zeta5 decayBudget A.onset := by
  constructor
  · intro n hn
    exact ne_of_gt (normalized_value_pos A positive n hn)
  · intro n hn
    have hpos := normalized_value_pos A positive n hn
    rw [abs_of_pos hpos, A.eval_transport n hn]
    calc
      (A.multiplier n : ℝ) * Real.evalQ (Real.mainF n) zeta5
          ≤ _root_.Real.exp (multiplierRate * (mainK n) ^ 2) *
            _root_.Real.exp (archimedeanRate * (mainK n) ^ 2) :=
        mul_le_mul (multiplier.upper n hn) (archimedean.upper n hn)
          (le_of_lt (positive.positive n hn)) (le_of_lt (_root_.Real.exp_pos _))
      _ = _root_.Real.exp ((multiplierRate + archimedeanRate) * (mainK n) ^ 2) := by
        rw [← _root_.Real.exp_add]
        congr 1
        ring
      _ ≤ decayBudget n := by
        apply _root_.Real.exp_le_exp.mpr
        exact mul_le_mul_of_nonneg_right combined_rate_le (sq_nonneg (mainK n))

end ManuscriptChain.MainChain

namespace ManuscriptChain.MainChain

open RealTransfer

@[simp] theorem main_dimension (n : ℕ) : (Real.mainParameters n).h = 27 * n := by
  dsimp [Real.mainParameters, Real.Parameters.h]
  omega

theorem section4Scale_pos (n : ℕ) : 0 < Real.section4Scale n := by
  have hfactorial : ∀ j : ℕ, (0 : ℚ) < (Nat.factorial j : ℚ) := by
    intro j
    exact_mod_cast Nat.factorial_pos j
  dsimp only [Real.section4Scale]
  apply div_pos
  · exact mul_pos (pow_pos (hfactorial _) _) (pow_pos (by norm_num) _)
  · exact mul_pos (pow_pos (hfactorial _) _)
      (Finset.prod_pos (fun i _ => pow_pos (hfactorial _) _))

theorem section4Scale_real_pos (n : ℕ) : (0 : ℝ) < (Real.section4Scale n : ℝ) := by
  exact_mod_cast section4Scale_pos n

def normalizationScale (A : MainNormalization) (n : ℕ) : ℝ :=
  (A.multiplier n : ℝ) * (Real.section4Scale n : ℝ)

theorem normalizationScale_pos (A : MainNormalization) (n : ℕ)
    (hn : A.onset ≤ n) : 0 < normalizationScale A n := by
  exact mul_pos (by exact_mod_cast A.multiplier_pos n hn) (section4Scale_real_pos n)

theorem MainNormalization.eval_spectral_transport (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) (x : ℝ) :
    evalReal (A.Q n) x = normalizationScale A n *
      (Real.manuscriptPencil (Real.mainParameters n)).detPolynomial.eval x := by
  rw [A.eval_transport n hn, Real.manuscriptPencil_detPolynomial]
  simp [Real.mainF, Real.mainDelta, Real.evalQ, Real.realPolynomial,
    normalizationScale, mul_assoc]

theorem MainNormalization.spectral_polynomial_identity (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) :
    (A.Q n).map (algebraMap ℤ ℝ) = C (normalizationScale A n) *
      (Real.manuscriptPencil (Real.mainParameters n)).detPolynomial := by
  apply Polynomial.funext
  intro x
  simpa [evalReal] using A.eval_spectral_transport n hn x

theorem MainNormalization.inverse_spectral_polynomial_identity (A : MainNormalization)
    (n : ℕ) (hn : A.onset ≤ n) :
    (Real.manuscriptPencil (Real.mainParameters n)).detPolynomial =
      C ((normalizationScale A n)⁻¹) * (A.Q n).map (algebraMap ℤ ℝ) := by
  rw [A.spectral_polynomial_identity n hn, ← mul_assoc, ← map_mul,
    inv_mul_cancel₀ (ne_of_gt (normalizationScale_pos A n hn)), map_one, one_mul]

def printedSpectralBound (n : ℕ) : ℝ :=
  _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)

theorem printedSpectralBound_pos (n : ℕ) : 0 < printedSpectralBound n :=
  _root_.Real.exp_pos _

def mainSpectralRadius (n : ℕ) : ℝ :=
  Spectral.comparisonRadius (Real.mainParameters n).h (printedSpectralBound n)

theorem mainSpectralRadius_pos (n : ℕ) : 0 < mainSpectralRadius n :=
  Spectral.comparisonRadius_pos _ _ (printedSpectralBound_pos n)

structure MainSpectralData (onset : ℕ) where
  factorization : ∀ n, onset ≤ n →
    Spectral.RootFactorization (Real.manuscriptPencil (Real.mainParameters n))
  beta_bound : ∀ n (hn : onset ≤ n) i,
    |(factorization n hn).beta i| ≤
      _root_.Real.exp ((Real.rhoPrinted : ℝ) * mainK n)

theorem MainNormalization.natDegree_eq (A : MainNormalization)
    (spectral : MainSpectralData A.onset) (n : ℕ) (hn : A.onset ≤ n) :
    (A.Q n).natDegree = 27 * n := by
  have hinj : Function.Injective (algebraMap ℤ ℝ) := by
    intro a b hab
    exact_mod_cast hab
  calc
    (A.Q n).natDegree = ((A.Q n).map (algebraMap ℤ ℝ)).natDegree :=
      (Polynomial.natDegree_map_eq_of_injective hinj (A.Q n)).symm
    _ = (C (normalizationScale A n) *
        (Real.manuscriptPencil (Real.mainParameters n)).detPolynomial).natDegree := by
      rw [A.spectral_polynomial_identity n hn]
    _ = (Real.manuscriptPencil (Real.mainParameters n)).detPolynomial.natDegree :=
      Polynomial.natDegree_C_mul (ne_of_gt (normalizationScale_pos A n hn))
    _ = (Real.mainParameters n).h := (spectral.factorization n hn).natDegree_eq
    _ = 27 * n := main_dimension n

theorem MainNormalization.degree_rate (A : MainNormalization)
    (spectral : MainSpectralData A.onset) (n : ℕ) (hn : A.onset ≤ n) :
    ((A.Q n).natDegree : ℝ) = (9 / 10 : ℝ) * mainK n := by
  rw [A.natDegree_eq spectral n hn, mainK_eq]
  push_cast
  ring

theorem main_localComparison (A : MainNormalization)
    (spectral : MainSpectralData A.onset) :
    LocalComparison A.Q zeta5 mainSpectralRadius A.onset := by
  apply Spectral.localComparison_of_spectral A.Q zeta5
    (fun n => (Real.mainParameters n).h)
    (fun n => Real.manuscriptPencil (Real.mainParameters n))
    printedSpectralBound (fun n => (normalizationScale A n)⁻¹) A.onset
    spectral.factorization
  · intro n _hn
    rfl
  · intro n _hn
    exact printedSpectralBound_pos n
  · intro n hn i
    exact spectral.beta_bound n hn i
  · intro n hn
    exact inv_ne_zero (ne_of_gt (normalizationScale_pos A n hn))
  · intro n hn
    exact A.inverse_spectral_polynomial_identity n hn

end ManuscriptChain.MainChain
