import ITEMS_02_PENCIL

noncomputable section
open scoped BigOperators
open Polynomial

namespace ManuscriptChain.Spectral

def spectralFactor (center beta : ℝ) : ℝ[X] :=
  1 + (X - C center) * C beta

structure RootFactorization {n : ℕ} (p : SymmetricAffinePencil n) where
  beta : Fin n → ℝ
  beta_ne_zero : ∀ i, beta i ≠ 0
  base_det_ne_zero : Matrix.det p.base ≠ 0
  factorization : p.detPolynomial =
    C (Matrix.det p.base) * ∏ i, spectralFactor p.center (beta i)

theorem linear_factor_eq_zero_iff {K : Type*} [Field K]
    (center beta x : K) (hb : beta ≠ 0) :
    1 + (x - center) * beta = 0 ↔ x = center - beta⁻¹ := by
  constructor
  · intro h
    have hmul : (x - center) * beta = -1 := by
      calc
        (x - center) * beta = (1 + (x - center) * beta) - 1 := by ring
        _ = -1 := by rw [h]; ring
    have hdiff : x - center = -(beta⁻¹) := by
      calc
        x - center = ((x - center) * beta) * beta⁻¹ := by
          rw [mul_assoc, mul_inv_cancel₀ hb, mul_one]
        _ = -(beta⁻¹) := by rw [hmul]; ring
    calc
      x = (x - center) + center := by ring
      _ = -(beta⁻¹) + center := by rw [hdiff]
      _ = center - beta⁻¹ := by ring
  · intro h
    rw [h]
    calc
      1 + (center - beta⁻¹ - center) * beta = 1 - beta⁻¹ * beta := by ring
      _ = 0 := by rw [inv_mul_cancel₀ hb]; ring

@[simp] theorem eval_spectralFactor (center beta x : ℝ) :
    (spectralFactor center beta).eval x = 1 + (x - center) * beta := by
  simp [spectralFactor]

theorem spectralFactor_ne_zero (center beta : ℝ) : spectralFactor center beta ≠ 0 := by
  intro h
  have he := congrArg (Polynomial.eval center) h
  simp at he

theorem natDegree_spectralFactor (center beta : ℝ) (hb : beta ≠ 0) :
    (spectralFactor center beta).natDegree = 1 := by
  have heq : spectralFactor center beta = C beta * X + C (1 - center * beta) := by
    simp only [spectralFactor, map_sub, map_one, map_mul]
    ring
  rw [heq]
  exact Polynomial.natDegree_linear hb

namespace RootFactorization

variable {n : ℕ} {p : SymmetricAffinePencil n} (c : RootFactorization p)

include c

def root (i : Fin n) : ℝ := p.center - (c.beta i)⁻¹

theorem eval_eq (x : ℝ) :
    p.detPolynomial.eval x = Matrix.det p.base *
      ∏ i, (1 + (x - p.center) * c.beta i) := by
  rw [c.factorization]
  simp [Polynomial.eval_prod]

theorem center_nonvanishing : p.detPolynomial.eval p.center ≠ 0 := by
  simpa using c.base_det_ne_zero

theorem determinant_center_nonvanishing : p.detValue p.center ≠ 0 := by
  simpa [SymmetricAffinePencil.detValue] using c.base_det_ne_zero

theorem polynomial_ne_zero : p.detPolynomial ≠ 0 := by
  intro h
  apply c.center_nonvanishing
  rw [h]
  simp

theorem natDegree_eq : p.detPolynomial.natDegree = n := by
  rw [c.factorization, Polynomial.natDegree_C_mul c.base_det_ne_zero]
  have hprod := Polynomial.natDegree_prod (s := Finset.univ)
    (fun i : Fin n => spectralFactor p.center (c.beta i))
    (fun i _ => spectralFactor_ne_zero p.center (c.beta i))
  simpa [natDegree_spectralFactor, c.beta_ne_zero] using hprod

theorem eval_eq_zero_iff (x : ℝ) :
    p.detPolynomial.eval x = 0 ↔ ∃ i, x = c.root i := by
  rw [c.eval_eq, mul_eq_zero]
  simp only [c.base_det_ne_zero, false_or, Finset.prod_eq_zero_iff, Finset.mem_univ,
    true_and]
  constructor
  · rintro ⟨i, hi⟩
    exact ⟨i, (linear_factor_eq_zero_iff p.center (c.beta i) x (c.beta_ne_zero i)).mp hi⟩
  · rintro ⟨i, hi⟩
    exact ⟨i, (linear_factor_eq_zero_iff p.center (c.beta i) x (c.beta_ne_zero i)).mpr hi⟩

theorem eval_root (i : Fin n) : p.detPolynomial.eval (c.root i) = 0 :=
  (c.eval_eq_zero_iff _).mpr ⟨i, rfl⟩

theorem root_ne_center (i : Fin n) : c.root i ≠ p.center := by
  intro h
  exact c.center_nonvanishing (h ▸ c.eval_root i)

theorem complex_root_location (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial = 0) :
    ∃ i, z = (c.root i : ℂ) := by
  have heval : Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial =
      ((Matrix.det p.base : ℝ) : ℂ) * ∏ i, (1 + (z - (p.center : ℂ)) * (c.beta i : ℂ)) := by
    rw [c.factorization]
    simp [spectralFactor, Polynomial.eval₂_finsetProd]
  rw [heval] at hz
  have hd : ((Matrix.det p.base : ℝ) : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr c.base_det_ne_zero
  have hp := (mul_eq_zero.mp hz).resolve_left hd
  obtain ⟨i, _, hi⟩ := Finset.prod_eq_zero_iff.mp hp
  refine ⟨i, ?_⟩
  have hb : (c.beta i : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (c.beta_ne_zero i)
  have hx := (linear_factor_eq_zero_iff (p.center : ℂ) (c.beta i : ℂ) z hb).mp hi
  simpa [root] using hx

theorem complex_root_im_zero (z : ℂ)
    (hz : Polynomial.eval₂ (algebraMap ℝ ℂ) z p.detPolynomial = 0) : z.im = 0 := by
  obtain ⟨i, rfl⟩ := c.complex_root_location z hz
  simp

theorem root_distance (i : Fin n) : |c.root i - p.center| = 1 / |c.beta i| := by
  have heq : c.root i - p.center = -((c.beta i)⁻¹) := by
    simp only [root]
    ring
  rw [heq, abs_neg, abs_inv, one_div]

theorem root_distance_lower_bound (bound : ℝ)
    (hbound : ∀ i, |c.beta i| ≤ bound) (i : Fin n) :
    1 / bound ≤ |c.root i - p.center| := by
  rw [c.root_distance]
  exact one_div_le_one_div_of_le (abs_pos.mpr (c.beta_ne_zero i)) (hbound i)

theorem eval_ne_zero_of_distance_lt (bound x : ℝ)
    (hbound : ∀ i, |c.beta i| ≤ bound)
    (hx : |x - p.center| < 1 / bound) : p.detPolynomial.eval x ≠ 0 := by
  intro hz
  obtain ⟨i, rfl⟩ := (c.eval_eq_zero_iff x).mp hz
  exact (not_lt_of_ge (c.root_distance_lower_bound bound hbound i)) hx

end RootFactorization

end ManuscriptChain.Spectral

namespace ManuscriptChain.Real

theorem delta_real_natDegree (p : Parameters)
    (c : Spectral.RootFactorization (manuscriptPencil p)) :
    (realPolynomial (delta p)).natDegree = p.h := by
  rw [← manuscriptPencil_detPolynomial]
  exact c.natDegree_eq

end ManuscriptChain.Real
