import ITEMS_01_DEFINITIONS

import ITEMS_02_PENCIL

import ITEMS_03_SPECTRAL

import ITEMS_04_TRANSFER

import ITEMS_05_MAIN_INPUTS

import ITEMS_06_EXTENSIONS

namespace ManuscriptChain

open MainChain RealTransfer

theorem MAIN_CHAIN_MEASURE
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset)
    {b₀ : ℕ}
    (index : IndexBudget normalization.Q mainSpectralRadius decayBudget
      normalization.onset 25687 b₀) :
    ∀ a : ℤ, ∀ b : ℕ, 0 < b → b₀ ≤ b →
      1 / (b : ℝ) ^ 25687 < |Real.zeta 5 - (a : ℝ) / (b : ℝ)| := by

  have comparison := main_localComparison normalization spectral

  have decay := main_decay normalization positive multiplier archimedean

  exact conditional_measure comparison decay index

theorem MAIN_CHAIN
    (normalization : MainNormalization)
    (positive : BaseValuePositive normalization.onset)
    (multiplier : MultiplierUpper normalization)
    (archimedean : ArchimedeanUpper normalization.onset)
    (spectral : MainSpectralData normalization.onset)
    {b₀ : ℕ}
    (index : IndexBudget normalization.Q mainSpectralRadius decayBudget
      normalization.onset 25687 b₀) :
    Irrational (Real.zeta 5) := by
  have measure : RationalMeasure (Real.zeta 5) 25687 b₀ :=
    MAIN_CHAIN_MEASURE normalization positive multiplier archimedean spectral index
  exact measure.irrational

theorem MAIN_EXTENSION_POSITIVITY {h K M : ℕ}
    (coefficients : Fin h → Fin (K + 1) → ℚ)
    (tail : Extensions.WeightSevenTailBound coefficients M)
    (certificate : Extensions.FinitePositiveCertificate coefficients M) :
    Extensions.PositiveQForm (Extensions.weightSevenGram coefficients) :=
  Extensions.weight_seven_positive_from_finite_certificate coefficients tail certificate

end ManuscriptChain

#check ManuscriptChain.MAIN_CHAIN_MEASURE
#check ManuscriptChain.MAIN_CHAIN
#check ManuscriptChain.MAIN_EXTENSION_POSITIVITY

#print axioms ManuscriptChain.MAIN_CHAIN_MEASURE
#print axioms ManuscriptChain.MAIN_CHAIN
#print axioms ManuscriptChain.MAIN_EXTENSION_POSITIVITY
