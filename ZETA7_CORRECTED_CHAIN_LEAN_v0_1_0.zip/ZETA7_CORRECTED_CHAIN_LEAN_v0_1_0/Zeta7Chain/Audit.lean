import Zeta7Chain.Endpoint

/-! The standard foundational axioms are permitted. Every listed theorem is
checked again by the runner, which rejects unproved-proof and native-evaluation
dependencies. Open arithmetic inputs appear in theorem types. -/

#check Zeta7Chain.zeta7_eq_tsum
#check Zeta7Chain.native_zeta7_euler_interval
#check Zeta7Chain.strong_zeta7_bounds
#check Zeta7Chain.zeta7_denominator_exclusion
#check Zeta7Chain.Obstruction.cubic_root_17295_17152_obstructed
#check Zeta7Chain.ZETA7_IRRATIONAL_OF_EXHAUSTION
#check Zeta7Chain.ZETA7_IRRATIONAL_OF_HALVING
#check Zeta7Chain.ZETA7_IRRATIONAL_OF_LIFT_AND_EXHAUSTION

#print axioms Zeta7Chain.zeta7_eq_tsum
#print axioms Zeta7Chain.coefficientGram_posDef
#print axioms Zeta7Chain.determinant_basis_change_zero_iff
#print axioms Zeta7Chain.realMomentShift_charpoly_splits
#print axioms Zeta7Chain.momentShift_four_witness
#print axioms Zeta7Chain.strong_normSq
#print axioms Zeta7Chain.strong_rationalNumerator
#print axioms Zeta7Chain.strong_coprime
#print axioms Zeta7Chain.strong_isotropic
#print axioms Zeta7Chain.strong_affine_identity
#print axioms Zeta7Chain.strong_primitiveForm
#print axioms Zeta7Chain.primitive_coprime
#print axioms Zeta7Chain.primitiveDen_scale
#print axioms Zeta7Chain.primitiveNum_scale
#print axioms Zeta7Chain.readoutQ_pos
#print axioms Zeta7Chain.readout_coprime
#print axioms Zeta7Chain.native_zeta7_euler_interval
#print axioms Zeta7Chain.euler112_window_lower
#print axioms Zeta7Chain.euler112_window_upper
#print axioms Zeta7Chain.zeta7_in_certified_window
#print axioms Zeta7Chain.strong_zeta7_bounds
#print axioms Zeta7Chain.strong_zeta7_billionfold
#print axioms Zeta7Chain.zeta7_denominator_exclusion
#print axioms Zeta7Chain.obstructed_root_in_interval
#print axioms Zeta7Chain.Obstruction.unit_mod_eight_anisotropic
#print axioms Zeta7Chain.Obstruction.cubicObstruction_diagonal_certificate
#print axioms Zeta7Chain.Obstruction.cubic_root_17295_17152_obstructed
#print axioms Zeta7Chain.irrational_of_arbitrarily_small_positive_forms
#print axioms Zeta7Chain.irrational_of_halving_successor
#print axioms Zeta7Chain.ZETA7_IRRATIONAL_OF_EXHAUSTION
#print axioms Zeta7Chain.ZETA7_IRRATIONAL_OF_HALVING
#print axioms Zeta7Chain.ZETA7_IRRATIONAL_OF_LIFT_AND_EXHAUSTION
