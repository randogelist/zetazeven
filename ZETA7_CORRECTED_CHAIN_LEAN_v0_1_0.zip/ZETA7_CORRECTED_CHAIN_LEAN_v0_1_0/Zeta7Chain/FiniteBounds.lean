import Zeta7Chain.EulerBound
import Zeta7Chain.EulerArithmetic
import Zeta7Chain.FiniteWindow
import Zeta7Chain.Readout

namespace Zeta7Chain

/-- A rational interval for Mathlib's actual zeta value, proved analytically. -/
theorem zeta7_in_certified_window : InCertifiedWindow zeta7 := by
  have h := native_zeta7_euler_interval 112
  have hl : (windowLower : ℝ) ≤ (64 / 63 : ℝ) * (eulerApprox 112 : ℝ) := by
    have hc := (Rat.cast_le (K := ℝ)).mpr euler112_window_lower
    simpa only [Rat.cast_mul, Rat.cast_div, Rat.cast_ofNat] using hc
  have hu : (64 / 63 : ℝ) * ((eulerApprox 112 : ℝ) + 1 / (2 : ℝ)^112) ≤
      (windowUpper : ℝ) := by
    have hc := (Rat.cast_le (K := ℝ)).mpr euler112_window_upper
    simpa only [Rat.cast_mul, Rat.cast_div, Rat.cast_add, Rat.cast_pow,
      Rat.cast_one, Rat.cast_ofNat] using hc
  exact ⟨hl.trans h.1, h.2.trans hu⟩

/-- The finite strong witness has strictly positive error below 5e-17. -/
theorem strong_zeta7_bounds :
    0 < (strongQ : ℝ) * zeta7 - strongP ∧
      (strongQ : ℝ) * zeta7 - strongP < 1 / 20000000000000000 :=
  strong_bounds_of_window zeta7_in_certified_window

theorem strong_zeta7_billionfold :
    (strongQ : ℝ) * zeta7 - strongP <
      (1616068 * zeta7 - 1629561) / 1000000000 :=
  strong_billionfold_of_window zeta7_in_certified_window

/-- Any positive denominator in a rational representation must exceed 2e16. -/
theorem zeta7_denominator_exclusion (a b : ℤ) (hb : 0 < b)
    (heq : zeta7 = (a : ℝ) / b) : 20000000000000000 < b :=
  denominator_exclusion_of_window zeta7_in_certified_window a b hb heq

theorem strong_zeta7_admissible : Admissible zeta7 strongCoeffs := by
  refine ⟨strongCoeffs_ne_zero, ?_⟩
  rw [strong_error]
  exact strong_zeta7_bounds.1

theorem obstructed_root_in_interval :
    (121 / 120 : ℝ) < 17295 / 17152 ∧ (17295 / 17152 : ℝ) < zeta7 := by
  constructor
  · norm_num
  · have h : (17295 / 17152 : ℝ) < (windowLower : ℝ) := by
      norm_num [windowLower]
    exact h.trans_le zeta7_in_certified_window.1

end Zeta7Chain
