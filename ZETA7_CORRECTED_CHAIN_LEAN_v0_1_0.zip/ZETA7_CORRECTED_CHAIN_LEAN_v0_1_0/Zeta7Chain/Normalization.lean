import Zeta7Chain.Witness
import Mathlib.Data.Int.GCD
import Mathlib.Tactic

/-!
# Primitive integer normalisation

Dividing both coefficients of an integer linear form by their nonnegative gcd
removes its entire integer content.  The resulting form is coprime, and its
leading coefficient stays positive when the original leading coefficient is
positive.  The final certificates identify the actual primitive forms of the
two explicit matrix witnesses.
-/

namespace Zeta7Chain

/-- The leading coefficient after removing integer content. -/
def primitiveDen (a b : ℤ) : ℤ := a / (Int.gcd a b : ℤ)

/-- The constant numerator after removing integer content. -/
def primitiveNum (a b : ℤ) : ℤ := b / (Int.gcd a b : ℤ)

/-- The primitive real-valued integer linear form. -/
noncomputable def primitiveForm (a b : ℤ) (X : ℝ) : ℝ :=
  (primitiveDen a b : ℝ) * X - primitiveNum a b

theorem linear_content_pos {a b : ℤ} (ha : a ≠ 0) :
    (0 : ℤ) < (Int.gcd a b : ℤ) := by
  exact_mod_cast Int.gcd_pos_of_ne_zero_left b ha

theorem primitiveDen_decomposition (a b : ℤ) :
    a = (Int.gcd a b : ℤ) * primitiveDen a b := by
  simpa [primitiveDen, mul_comm] using
    (Int.ediv_mul_cancel (Int.gcd_dvd_left a b)).symm

theorem primitiveNum_decomposition (a b : ℤ) :
    b = (Int.gcd a b : ℤ) * primitiveNum a b := by
  simpa [primitiveNum, mul_comm] using
    (Int.ediv_mul_cancel (Int.gcd_dvd_right a b)).symm

theorem primitive_coprime {a b : ℤ} (ha : a ≠ 0) :
    Int.gcd (primitiveDen a b) (primitiveNum a b) = 1 := by
  exact Int.gcd_ediv_gcd_ediv_gcd_of_ne_zero_left ha

theorem primitiveDen_pos {a b : ℤ} (ha : 0 < a) : 0 < primitiveDen a b := by
  have hg := linear_content_pos (b := b) ha.ne'
  have hp : 0 < (Int.gcd a b : ℤ) * primitiveDen a b := by
    rw [← primitiveDen_decomposition a b]
    exact ha
  exact (mul_pos_iff_of_pos_left hg).mp hp

/-- This identity records the precise content cost, for every real input. -/
theorem primitiveForm_decomposition (a b : ℤ) (X : ℝ) :
    (a : ℝ) * X - b = (Int.gcd a b : ℝ) * primitiveForm a b X := by
  have ha : (a : ℝ) = (Int.gcd a b : ℝ) * (primitiveDen a b : ℝ) := by
    exact_mod_cast primitiveDen_decomposition a b
  have hb : (b : ℝ) = (Int.gcd a b : ℝ) * (primitiveNum a b : ℝ) := by
    exact_mod_cast primitiveNum_decomposition a b
  rw [ha, hb, primitiveForm]
  ring

theorem primitiveForm_pos_iff {a b : ℤ} (ha : a ≠ 0) (X : ℝ) :
    0 < primitiveForm a b X ↔ 0 < (a : ℝ) * X - b := by
  have hg : (0 : ℝ) < (Int.gcd a b : ℝ) := by
    exact_mod_cast linear_content_pos (b := b) ha
  rw [primitiveForm_decomposition]
  exact (mul_pos_iff_of_pos_left hg).symm

/-- A positive common integer scaling disappears in primitive normalisation. -/
theorem primitiveDen_scale {k a b : ℤ} (hk : 0 < k) :
    primitiveDen (k * a) (k * b) = primitiveDen a b := by
  unfold primitiveDen
  rw [Int.gcd_mul_left, Nat.cast_mul, Int.natAbs_of_nonneg hk.le]
  exact Int.mul_ediv_mul_of_pos a (Int.gcd a b) hk

theorem primitiveNum_scale {k a b : ℤ} (hk : 0 < k) :
    primitiveNum (k * a) (k * b) = primitiveNum a b := by
  unfold primitiveNum
  rw [Int.gcd_mul_left, Nat.cast_mul, Int.natAbs_of_nonneg hk.le]
  exact Int.mul_ediv_mul_of_pos b (Int.gcd a b) hk

theorem primitiveDen_of_coprime {a b : ℤ} (h : Int.gcd a b = 1) :
    primitiveDen a b = a := by
  simp [primitiveDen, h]

theorem primitiveNum_of_coprime {a b : ℤ} (h : Int.gcd a b = 1) :
    primitiveNum a b = b := by
  simp [primitiveNum, h]

/-- The exact primitive denominator of the large cubic certificate. -/
theorem strong_primitiveDen :
    primitiveDen (witnessD * normSq strongCoeffs)
      (rationalNumerator strongCoeffs) = strongQ := by
  have hk : 0 < witnessD * strongScale := by
    exact mul_pos (by norm_num [witnessD]) strongScale_pos
  have hc : Int.gcd strongQ strongP = 1 := by
    rw [Int.gcd_comm]
    exact strong_coprime
  rw [strong_normSq, strong_rationalNumerator]
  have ha : witnessD * (strongQ * strongScale) =
      (witnessD * strongScale) * strongQ := by ring
  have hb : witnessD * strongP * strongScale =
      (witnessD * strongScale) * strongP := by ring
  rw [ha, hb, primitiveDen_scale hk, primitiveDen_of_coprime hc]

/-- The exact primitive numerator of the large cubic certificate. -/
theorem strong_primitiveNum :
    primitiveNum (witnessD * normSq strongCoeffs)
      (rationalNumerator strongCoeffs) = strongP := by
  have hk : 0 < witnessD * strongScale := by
    exact mul_pos (by norm_num [witnessD]) strongScale_pos
  have hc : Int.gcd strongQ strongP = 1 := by
    rw [Int.gcd_comm]
    exact strong_coprime
  rw [strong_normSq, strong_rationalNumerator]
  have ha : witnessD * (strongQ * strongScale) =
      (witnessD * strongScale) * strongQ := by ring
  have hb : witnessD * strongP * strongScale =
      (witnessD * strongScale) * strongP := by ring
  rw [ha, hb, primitiveNum_scale hk, primitiveNum_of_coprime hc]

theorem strong_primitiveForm (X : ℝ) :
    primitiveForm (witnessD * normSq strongCoeffs)
      (rationalNumerator strongCoeffs) X = (strongQ : ℝ) * X - strongP := by
  rw [primitiveForm, strong_primitiveDen, strong_primitiveNum]

theorem seed_primitiveDen :
    primitiveDen (witnessD * normSq seedCoeffs)
      (rationalNumerator seedCoeffs) = 120 := by
  norm_num [primitiveDen, witnessD, seed_normSq, seed_rationalNumerator]

theorem seed_primitiveNum :
    primitiveNum (witnessD * normSq seedCoeffs)
      (rationalNumerator seedCoeffs) = 121 := by
  norm_num [primitiveNum, witnessD, seed_normSq, seed_rationalNumerator]

theorem seed_primitiveForm (X : ℝ) :
    primitiveForm (witnessD * normSq seedCoeffs)
      (rationalNumerator seedCoeffs) X = 120 * X - 121 := by
  rw [primitiveForm, seed_primitiveDen, seed_primitiveNum]
  norm_num

end Zeta7Chain
