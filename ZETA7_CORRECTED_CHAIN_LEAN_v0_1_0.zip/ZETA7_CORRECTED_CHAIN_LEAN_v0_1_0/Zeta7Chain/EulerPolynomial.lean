import Zeta7Chain.EulerSupport

noncomputable section
open Filter
open ChebyshevMastertier
namespace Zeta7Chain

/-- Integer numerator of the N-term Euler transform of 1/(1+x). -/
def eulerNumerator : ℕ → Polynomial ℤ
  | 0 => 0
  | n + 1 => 2 * eulerNumerator n + (1 - Polynomial.X) ^ n

theorem euler_polynomial_lock (n : ℕ) :
    (1 + Polynomial.X) * eulerNumerator n =
      (2 : Polynomial ℤ) ^ n - (1 - Polynomial.X) ^ n := by
  induction n with
  | zero => simp [eulerNumerator]
  | succ n ih =>
      simp only [eulerNumerator, pow_succ]
      calc
        (1 + Polynomial.X) *
            (2 * eulerNumerator n + (1 - Polynomial.X) ^ n) =
          2 * ((1 + Polynomial.X) * eulerNumerator n) +
            (1 + Polynomial.X) * (1 - Polynomial.X) ^ n := by ring
        _ = 2 * (2 ^ n - (1 - Polynomial.X) ^ n) +
            (1 + Polynomial.X) * (1 - Polynomial.X) ^ n := by rw [ih]
        _ = 2 ^ n * 2 - (1 - Polynomial.X) ^ n * (1 - Polynomial.X) := by ring

theorem euler_natDegree_le (n : ℕ) : (eulerNumerator n).natDegree ≤ n := by
  induction n with
  | zero => simp [eulerNumerator]
  | succ n ih =>
      unfold eulerNumerator
      apply Polynomial.natDegree_add_le_of_degree_le
      · have h := Polynomial.natDegree_mul_le_of_le
          (by norm_num : (2 : Polynomial ℤ).natDegree ≤ 0) ih
        omega
      · have hbase : (1 - Polynomial.X : Polynomial ℤ).natDegree ≤ 1 := by
          apply (Polynomial.natDegree_sub_le _ _).trans
          norm_num
        have h := Polynomial.natDegree_pow_le_of_le n hbase
        omega

def eulerApprox (n : ℕ) : ℚ :=
  finiteMoment (eulerNumerator n) (n + 1) / (2 : ℚ) ^ n

def eulerScalar (n : ℕ) (x : ℝ) : ℝ :=
  intPolyReal (eulerNumerator n) x / (2 : ℝ) ^ n

theorem euler_scalar_lock (n : ℕ) (x : ℝ) :
    (1 + x) * intPolyReal (eulerNumerator n) x =
      (2 : ℝ) ^ n - (1 - x) ^ n := by
  have h := congrArg (fun p : Polynomial ℤ => intPolyReal p x)
    (euler_polynomial_lock n)
  simpa [intPolyReal, Polynomial.eval₂_pow] using h

theorem euler_scalar_error (n : ℕ) (x : ℝ) (hx : 0 ≤ x) :
    1 / (1 + x) - eulerScalar n x =
      (1 - x) ^ n / ((2 : ℝ) ^ n * (1 + x)) := by
  have hden : (1 + x : ℝ) ≠ 0 := by linarith
  have hpow : (2 : ℝ) ^ n ≠ 0 := by positivity
  have h := euler_scalar_lock n x
  unfold eulerScalar
  field_simp
  nlinarith

theorem euler_scalar_interval (n : ℕ) (x : ℝ)
    (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ 1 / (1 + x) - eulerScalar n x ∧
      1 / (1 + x) - eulerScalar n x ≤ 1 / (2 : ℝ) ^ n := by
  rw [euler_scalar_error n x hx0]
  have hp0 : 0 ≤ (1 - x) ^ n := pow_nonneg (by linarith) _
  have hp1 : (1 - x) ^ n ≤ (1 : ℝ) :=
    pow_le_one₀ (by linarith) (by linarith)
  have htwo : (0 : ℝ) < 2 ^ n := by positivity
  have hx : (0 : ℝ) < 1 + x := by linarith
  constructor
  · positivity
  · apply (div_le_div_iff₀ (mul_pos htwo hx) htwo).2
    nlinarith

theorem euler_grid_tendsto (n : ℕ) :
    Tendsto (fun m : ℕ => (sevenfoldGrid m).eval (eulerScalar n))
      atTop (nhds (eulerApprox n : ℝ)) := by
  have hd : (eulerNumerator n).natDegree < n + 1 :=
    Nat.lt_succ_of_le (euler_natDegree_le n)
  have h := (sevenfoldGrid_poly_tendsto (eulerNumerator n) (n + 1) hd).div_const
    ((2 : ℝ) ^ n)
  have hfun : (fun m : ℕ => (sevenfoldGrid m).eval (eulerScalar n)) =
      (fun m : ℕ => (sevenfoldGrid m).eval (intPolyReal (eulerNumerator n)) /
        (2 : ℝ) ^ n) := by
    funext m
    unfold eulerScalar
    simp only [div_eq_mul_inv]
    conv_lhs => arg 2; ext x; rw [mul_comm]
    rw [sevenfoldGrid_scale]
    ring
  rw [hfun]
  simpa only [eulerApprox, Rat.cast_div, Rat.cast_pow, Rat.cast_ofNat] using h

theorem eta_natDegree_le (n : ℕ) : (etaNumerator n).natDegree ≤ 2 * n := by
  induction n with
  | zero => simp [etaNumerator]
  | succ n ih =>
      unfold etaNumerator
      apply Polynomial.natDegree_add_le_of_degree_le
      · have h := Polynomial.natDegree_sub_le (1 : Polynomial ℤ) Polynomial.X
        simp only [Polynomial.natDegree_one, Polynomial.natDegree_X, Nat.zero_max] at h
        omega
      · have h := Polynomial.natDegree_mul_le_of_le ih
          (by norm_num [etaKernel] : etaKernel.natDegree ≤ 2)
        omega

theorem eta_scalar_poly (n : ℕ) (x : ℝ) (hx : 0 ≤ x) :
    etaScalarEntry n x = intPolyReal (etaNumerator n) x := by
  have h := congrArg (fun p : Polynomial ℤ => intPolyReal p x)
    (eta_polynomial_lock n)
  have hden : (1 + x : ℝ) ≠ 0 := by linarith
  have hlock : (1 + x) * intPolyReal (etaNumerator n) x = 1 - x ^ (2 * n) := by
    simpa [intPolyReal, Xplus, etaKernel, pow_mul, Polynomial.eval₂_pow] using h
  unfold etaScalarEntry
  field_simp
  nlinarith

/-- Means agree on functions agreeing throughout their supporting interval. -/
theorem interval_mean_congr (μ : PositiveIntervalMean) (f g : ℝ → ℝ)
    (h : ∀ x, 0 ≤ x → x ≤ 1 → f x = g x) : μ.eval f = μ.eval g := by
  apply le_antisymm
  · exact μ.mono f g (fun x hx hy => le_of_eq (h x hx hy))
  · exact μ.mono g f (fun x hx hy => le_of_eq (h x hx hy).symm)

end Zeta7Chain
