import Zeta7Chain.Witness
import Mathlib.Data.Int.Basic
import Mathlib.Tactic.IntervalCases
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Algebra.Ring.Rat
import Mathlib.Tactic.Push

namespace Zeta7Chain.Obstruction

/-- The three possible square residues, retaining the parity information. -/
theorem square_mod_eight_cases (x : ℤ) :
    (x ^ 2 % 8 = 0 ∧ x % 2 = 0) ∨
    (x ^ 2 % 8 = 1 ∧ x % 2 = 1) ∨
    (x ^ 2 % 8 = 4 ∧ x % 2 = 0) := by
  have hnonneg : 0 ≤ x % 8 := Int.emod_nonneg _ (by norm_num)
  have hlt : x % 8 < 8 := Int.emod_lt_of_pos _ (by norm_num)
  have hs : x ^ 2 % 8 = (x % 8) ^ 2 % 8 := by
    simp only [pow_two, Int.mul_emod, Int.emod_emod]
  interval_cases h : x % 8 <;> norm_num [h] at hs <;> omega

/-- Modulo eight already forces the first two coordinates to be even. -/
theorem unit_mod_eight_head_even (a b c d x y z w : ℤ)
    (ha : a % 8 = 1) (hb : b % 8 = 1)
    (hc : c % 8 = 1) (hd : d % 8 = 1)
    (hzero : a * x ^ 2 + b * y ^ 2 + 2 * c * z ^ 2 + 2 * d * w ^ 2 = 0) :
    x % 2 = 0 ∧ y % 2 = 0 := by
  have hax : (a * x ^ 2) % 8 = x ^ 2 % 8 := by
    rw [Int.mul_emod, ha]
    simp
  have hby : (b * y ^ 2) % 8 = y ^ 2 % 8 := by
    rw [Int.mul_emod, hb]
    simp
  have hcz : (2 * c * z ^ 2) % 8 = (2 * (z ^ 2 % 8)) % 8 := by
    rw [Int.mul_emod (2 * c), Int.mul_emod 2 c, hc]
    norm_num
  have hdw : (2 * d * w ^ 2) % 8 = (2 * (w ^ 2 % 8)) % 8 := by
    rw [Int.mul_emod (2 * d), Int.mul_emod 2 d, hd]
    norm_num
  have hr : ((a * x ^ 2) % 8 + (b * y ^ 2) % 8 +
      (2 * c * z ^ 2) % 8 + (2 * d * w ^ 2) % 8) % 8 = 0 := by omega
  rw [hax, hby, hcz, hdw] at hr
  rcases square_mod_eight_cases x with ⟨hx, hpx⟩ | ⟨hx, hpx⟩ | ⟨hx, hpx⟩ <;>
    rcases square_mod_eight_cases y with ⟨hy, hpy⟩ | ⟨hy, hpy⟩ | ⟨hy, hpy⟩ <;>
    rcases square_mod_eight_cases z with ⟨hz, hpz⟩ | ⟨hz, hpz⟩ | ⟨hz, hpz⟩ <;>
    rcases square_mod_eight_cases w with ⟨hw, hpw⟩ | ⟨hw, hpw⟩ | ⟨hw, hpw⟩ <;>
    omega

/-- Applying the modulo-eight argument again after dividing by two forces
all four coordinates to be even. This is the effective modulo-sixteen step. -/
theorem unit_mod_eight_zero_forces_even (a b c d x y z w : ℤ)
    (ha : a % 8 = 1) (hb : b % 8 = 1)
    (hc : c % 8 = 1) (hd : d % 8 = 1)
    (hzero : a * x ^ 2 + b * y ^ 2 + 2 * c * z ^ 2 + 2 * d * w ^ 2 = 0) :
    2 ∣ x ∧ 2 ∣ y ∧ 2 ∣ z ∧ 2 ∣ w := by
  obtain ⟨hx, hy⟩ := unit_mod_eight_head_even a b c d x y z w ha hb hc hd hzero
  obtain ⟨x', rfl⟩ := Int.dvd_of_emod_eq_zero hx
  obtain ⟨y', rfl⟩ := Int.dvd_of_emod_eq_zero hy
  have hswap : c * z ^ 2 + d * w ^ 2 + 2 * a * x' ^ 2 + 2 * b * y' ^ 2 = 0 := by
    nlinarith [hzero]
  obtain ⟨hz, hw⟩ := unit_mod_eight_head_even c d a b z w x' y' hc hd ha hb hswap
  exact ⟨dvd_mul_right 2 x', dvd_mul_right 2 y',
    Int.dvd_of_emod_eq_zero hz, Int.dvd_of_emod_eq_zero hw⟩

private theorem two_pow_succ_dvd_double {n : ℕ} {x : ℤ}
    (h : (2 : ℤ) ^ n ∣ x) : (2 : ℤ) ^ (n + 1) ∣ 2 * x := by
  obtain ⟨k, rfl⟩ := h
  refine ⟨k, ?_⟩
  rw [pow_succ]
  ring

/-- Infinite descent, recorded as divisibility by every power of two. -/
theorem unit_mod_eight_zero_pow_dvd (a b c d : ℤ)
    (ha : a % 8 = 1) (hb : b % 8 = 1)
    (hc : c % 8 = 1) (hd : d % 8 = 1)
    (n : ℕ) (x y z w : ℤ)
    (hzero : a * x ^ 2 + b * y ^ 2 + 2 * c * z ^ 2 + 2 * d * w ^ 2 = 0) :
    (2 : ℤ) ^ n ∣ x ∧ (2 : ℤ) ^ n ∣ y ∧ (2 : ℤ) ^ n ∣ z ∧ (2 : ℤ) ^ n ∣ w := by
  induction n generalizing x y z w with
  | zero => simp
  | succ n ih =>
    obtain ⟨hx, hy, hz, hw⟩ :=
      unit_mod_eight_zero_forces_even a b c d x y z w ha hb hc hd hzero
    obtain ⟨x', rfl⟩ := hx
    obtain ⟨y', rfl⟩ := hy
    obtain ⟨z', rfl⟩ := hz
    obtain ⟨w', rfl⟩ := hw
    have hsmall : a * x' ^ 2 + b * y' ^ 2 + 2 * c * z' ^ 2 + 2 * d * w' ^ 2 = 0 := by
      nlinarith [hzero]
    obtain ⟨hx', hy', hz', hw'⟩ := ih x' y' z' w' hsmall
    exact ⟨two_pow_succ_dvd_double hx', two_pow_succ_dvd_double hy',
      two_pow_succ_dvd_double hz', two_pow_succ_dvd_double hw'⟩

theorem int_zero_of_all_two_pow_dvd (x : ℤ)
    (h : ∀ n : ℕ, (2 : ℤ) ^ n ∣ x) : x = 0 := by
  apply Int.eq_zero_of_dvd_of_natAbs_lt_natAbs (h x.natAbs)
  simpa using (Nat.lt_two_pow_self : x.natAbs < 2 ^ x.natAbs)

/-- An elementary anisotropy theorem for units congruent to one modulo eight. -/
theorem unit_mod_eight_anisotropic (a b c d x y z w : ℤ)
    (ha : a % 8 = 1) (hb : b % 8 = 1)
    (hc : c % 8 = 1) (hd : d % 8 = 1)
    (hzero : a * x ^ 2 + b * y ^ 2 + 2 * c * z ^ 2 + 2 * d * w ^ 2 = 0) :
    x = 0 ∧ y = 0 ∧ z = 0 ∧ w = 0 := by
  have hp := unit_mod_eight_zero_pow_dvd a b c d ha hb hc hd
  exact ⟨int_zero_of_all_two_pow_dvd x (fun n => (hp n x y z w hzero).1),
    int_zero_of_all_two_pow_dvd y (fun n => (hp n x y z w hzero).2.1),
    int_zero_of_all_two_pow_dvd z (fun n => (hp n x y z w hzero).2.2.1),
    int_zero_of_all_two_pow_dvd w (fun n => (hp n x y z w hzero).2.2.2)⟩

/-- Clearing a common denominator transfers the integral descent to rational
coordinates. The congruences are imposed on the integer coefficients. -/
theorem unit_mod_eight_rational_anisotropic (a b c d : ℤ) (x y z w : ℚ)
    (ha : a % 8 = 1) (hb : b % 8 = 1)
    (hc : c % 8 = 1) (hd : d % 8 = 1)
    (hzero : (a : ℚ) * x ^ 2 + (b : ℚ) * y ^ 2 +
      2 * (c : ℚ) * z ^ 2 + 2 * (d : ℚ) * w ^ 2 = 0) :
    x = 0 ∧ y = 0 ∧ z = 0 ∧ w = 0 := by
  let m : ℚ := x.den * y.den * z.den * w.den
  let X : ℤ := x.num * y.den * z.den * w.den
  let Y : ℤ := x.den * y.num * z.den * w.den
  let Z : ℤ := x.den * y.den * z.num * w.den
  let W : ℤ := x.den * y.den * z.den * w.num
  have hm : m ≠ 0 := by
    dsimp [m]
    exact mul_ne_zero (mul_ne_zero (mul_ne_zero
      (Nat.cast_ne_zero.mpr x.den_ne_zero) (Nat.cast_ne_zero.mpr y.den_ne_zero))
      (Nat.cast_ne_zero.mpr z.den_ne_zero)) (Nat.cast_ne_zero.mpr w.den_ne_zero)
  have hx : (X : ℚ) = m * x := by
    dsimp [X, m]
    push_cast
    rw [← Rat.mul_den_eq_num x]
    ring
  have hy : (Y : ℚ) = m * y := by
    dsimp [Y, m]
    push_cast
    rw [← Rat.mul_den_eq_num y]
    ring
  have hz : (Z : ℚ) = m * z := by
    dsimp [Z, m]
    push_cast
    rw [← Rat.mul_den_eq_num z]
    ring
  have hw : (W : ℚ) = m * w := by
    dsimp [W, m]
    push_cast
    rw [← Rat.mul_den_eq_num w]
    ring
  have hscaled : (a : ℚ) * (X : ℚ) ^ 2 + (b : ℚ) * (Y : ℚ) ^ 2 +
      2 * (c : ℚ) * (Z : ℚ) ^ 2 + 2 * (d : ℚ) * (W : ℚ) ^ 2 = 0 := by
    rw [hx, hy, hz, hw]
    calc
      _ = m ^ 2 * ((a : ℚ) * x ^ 2 + (b : ℚ) * y ^ 2 +
        2 * (c : ℚ) * z ^ 2 + 2 * (d : ℚ) * w ^ 2) := by ring
      _ = 0 := by rw [hzero]; ring
  have hint : a * X ^ 2 + b * Y ^ 2 + 2 * c * Z ^ 2 + 2 * d * W ^ 2 = 0 := by
    exact_mod_cast hscaled
  obtain ⟨hX, hY, hZ, hW⟩ := unit_mod_eight_anisotropic a b c d X Y Z W ha hb hc hd hint
  have hx0 : m * x = 0 := by rw [← hx, hX]; norm_num
  have hy0 : m * y = 0 := by rw [← hy, hY]; norm_num
  have hz0 : m * z = 0 := by rw [← hz, hZ]; norm_num
  have hw0 : m * w = 0 := by rw [← hw, hW]; norm_num
  exact ⟨(mul_eq_zero.mp hx0).resolve_left hm, (mul_eq_zero.mp hy0).resolve_left hm,
    (mul_eq_zero.mp hz0).resolve_left hm, (mul_eq_zero.mp hw0).resolve_left hm⟩

/-- The degree-three pencil evaluated at the rational test value `17295/17152`.
This is the scalar quadratic polynomial, with its integer matrix numerator
expanded explicitly. -/
def cubicObstructionValue (x y z w : ℚ) : ℚ :=
  (17295 / 17152 : ℚ) * (x ^ 2 + y ^ 2 + z ^ 2 + w ^ 2) -
    (-71663616 * x * y - 36391680 * x * z - 24293888 * x * w +
      214990848 * y ^ 2 - 1119744 * y * z - 609024 * y * w +
      216670464 * z ^ 2 - 98304 * z * w + 216768768 * w ^ 2) / 214990848

/-- Exact rational LDL certificate. A common positive denominator converts
the four diagonal units to integers congruent to one modulo eight. -/
theorem cubicObstruction_diagonal_certificate (x y z w : ℚ) :
    80682092819996504323850830828800 * cubicObstructionValue x y z w =
    81354757189939338985599353963625 *
      (x + (8576 / 51885 : ℚ) * y + (871 / 10377 : ℚ) * z +
        (6358166 / 113472495 : ℚ) * w) ^ 2 +
    (-1549974247590460192516822421655) *
      (y + (30395890 / 51289111 : ℚ) * z +
        (46257525811 / 112169285757 : ℚ) * w) ^ 2 +
    2 * 6778990719596594863840588425 *
      (z + (523450631732 / 484951002777 : ℚ) * w) ^ 2 +
    2 * (-1090475650417534960615590775) * w ^ 2 := by
  unfold cubicObstructionValue
  ring

/-- The actual degree-three rational pencil has no nonzero rational isotropic
vector at `17295/17152`. This is an arithmetic obstruction, not a real one. -/
theorem cubicObstruction_anisotropic (x y z w : ℚ)
    (hzero : cubicObstructionValue x y z w = 0) :
    x = 0 ∧ y = 0 ∧ z = 0 ∧ w = 0 := by
  have hd := cubicObstruction_diagonal_certificate x y z w
  rw [hzero, mul_zero] at hd
  have hh := unit_mod_eight_rational_anisotropic
    81354757189939338985599353963625 (-1549974247590460192516822421655)
    6778990719596594863840588425 (-1090475650417534960615590775)
    (x + (8576 / 51885 : ℚ) * y + (871 / 10377 : ℚ) * z +
      (6358166 / 113472495 : ℚ) * w)
    (y + (30395890 / 51289111 : ℚ) * z +
      (46257525811 / 112169285757 : ℚ) * w)
    (z + (523450631732 / 484951002777 : ℚ) * w) w
    (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    (by norm_num at hd ⊢; exact hd.symm)
  obtain ⟨hx, hy, hz, hw⟩ := hh
  have hz0 : z = 0 := by rw [hw] at hz; simpa using hz
  have hy0 : y = 0 := by rw [hw, hz0] at hy; simpa using hy
  have hx0 : x = 0 := by rw [hw, hz0, hy0] at hx; simpa using hx
  exact ⟨hx0, hy0, hz0, hw⟩

/-- The displayed polynomial is exactly the existing five-coordinate witness
pencil on its cubic coordinate subspace. -/
theorem cubicObstruction_value_of_coefficients (c : Fin 5 → ℤ) (hc : c 4 = 0) :
    cubicObstructionValue (c 0) (c 1) (c 2) (c 3) =
    (17295 / 17152 : ℚ) * (normSq c : ℚ) -
      (rationalNumerator c : ℚ) / (witnessD : ℚ) := by
  have hv2 : (![c 0, c 1, c 2, c 3, 0] : Fin 5 → ℤ) 2 = c 2 := rfl
  have hv3 : (![c 0, c 1, c 2, c 3, 0] : Fin 5 → ℤ) 3 = c 3 := rfl
  have hcvec : c = ![c 0, c 1, c 2, c 3, 0] := by
    funext i
    fin_cases i <;> simp [hc]
  rw [hcvec]
  norm_num [cubicObstructionValue, normSq, rationalNumerator, witnessA, witnessD,
    Fin.sum_univ_succ]
  simp only [hv2, hv3]
  ring

/-- No nonzero integer cubic coefficient vector has this rational root.
This endpoint uses precisely the numerator and squared norm of `Witness.lean`. -/
theorem cubic_root_17295_17152_obstructed (c : Fin 5 → ℤ) (hc : c 4 = 0)
    (hroot : witnessD * 17295 * normSq c = 17152 * rationalNumerator c) :
    c = 0 := by
  have hcast : (witnessD : ℚ) * 17295 * (normSq c : ℚ) =
      17152 * (rationalNumerator c : ℚ) := by exact_mod_cast hroot
  have hzero : cubicObstructionValue (c 0) (c 1) (c 2) (c 3) = 0 := by
    rw [cubicObstruction_value_of_coefficients c hc]
    norm_num [witnessD] at hcast ⊢
    linarith
  obtain ⟨h0, h1, h2, h3⟩ := cubicObstruction_anisotropic (c 0) (c 1) (c 2) (c 3) hzero
  funext i
  fin_cases i
  · exact_mod_cast h0
  · exact_mod_cast h1
  · exact_mod_cast h2
  · exact_mod_cast h3
  · exact hc

end Zeta7Chain.Obstruction
