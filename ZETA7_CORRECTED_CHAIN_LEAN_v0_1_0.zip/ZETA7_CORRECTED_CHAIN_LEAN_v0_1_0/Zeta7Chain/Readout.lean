import Zeta7Chain.Normalization
import Zeta7Chain.Closure
import Zeta7Chain.NativeZeta

namespace Zeta7Chain

abbrev Coefficients := Fin 5 → ℤ

def readoutQ (c : Coefficients) : ℤ :=
  primitiveDen (witnessD * normSq c) (rationalNumerator c)

def readoutP (c : Coefficients) : ℤ :=
  primitiveNum (witnessD * normSq c) (rationalNumerator c)

noncomputable def witnessError (ξ : ℝ) (c : Coefficients) : ℝ :=
  (readoutQ c : ℝ) * ξ - readoutP c

theorem normSq_pos {c : Coefficients} (hc : c ≠ 0) : 0 < normSq c := by
  have hex : ∃ i, c i ≠ 0 := by
    by_contra hn
    apply hc
    ext i
    simpa using (not_exists.mp hn i)
  obtain ⟨i, hi⟩ := hex
  exact Finset.sum_pos' (fun j _ => sq_nonneg (c j))
    ⟨i, Finset.mem_univ i, sq_pos_of_ne_zero hi⟩

theorem readoutQ_pos {c : Coefficients} (hc : c ≠ 0) : 0 < readoutQ c := by
  exact primitiveDen_pos (mul_pos (by norm_num [witnessD]) (normSq_pos hc))

theorem readout_coprime {c : Coefficients} (hc : c ≠ 0) :
    Int.gcd (readoutQ c) (readoutP c) = 1 := by
  exact primitive_coprime
    (mul_pos (by norm_num [witnessD]) (normSq_pos hc)).ne'

theorem witnessError_eq_primitiveForm (ξ : ℝ) (c : Coefficients) :
    witnessError ξ c =
      primitiveForm (witnessD * normSq c) (rationalNumerator c) ξ := rfl

theorem strong_error (ξ : ℝ) :
    witnessError ξ strongCoeffs = (strongQ : ℝ) * ξ - strongP :=
  strong_primitiveForm ξ

theorem seed_error (ξ : ℝ) :
    witnessError ξ seedCoeffs = 120 * ξ - 121 :=
  seed_primitiveForm ξ

theorem strongCoeffs_ne_zero : strongCoeffs ≠ 0 := by
  intro h
  have hh := congrFun h (0 : Fin 5)
  norm_num [strongCoeffs] at hh

/-- A nonzero coefficient vector with positive primitive integer error. -/
def Admissible (ξ : ℝ) (c : Coefficients) : Prop := c ≠ 0 ∧ 0 < witnessError ξ c

/-- This universal statement is the open arithmetic input. -/
def WitnessExhaustion (ξ : ℝ) : Prop :=
  ∀ n : ℕ, ∃ c : Coefficients,
    Admissible ξ c ∧ witnessError ξ c < (1 / 2 : ℝ) ^ n

/-- The corrected endpoint does not assert its exhaustion premise. -/
theorem irrational_of_witness_exhaustion {ξ : ℝ} (h : WitnessExhaustion ξ) :
    Irrational ξ := by
  apply irrational_of_dyadic_positive_forms
  intro n
  obtain ⟨c, hc, he⟩ := h n
  exact ⟨readoutP c, readoutQ c, hc.2, he⟩

theorem ZETA7_IRRATIONAL_OF_EXHAUSTION (h : WitnessExhaustion zeta7) :
    Irrational zeta7 := irrational_of_witness_exhaustion h

/-- The all-state successor law remains an explicit premise. -/
def HalvingLaw (ξ : ℝ) (next : Coefficients → Coefficients) : Prop :=
  ∀ c, Admissible ξ c →
    Admissible ξ (next c) ∧ witnessError ξ (next c) ≤ witnessError ξ c / 2

theorem irrational_of_admitted_halving {ξ : ℝ}
    (next : Coefficients → Coefficients) (seed : Coefficients)
    (hseed : Admissible ξ seed) (hnext : HalvingLaw ξ next) : Irrational ξ := by
  apply irrational_of_halving_successor readoutP readoutQ next seed (Admissible ξ)
    hseed
  · intro c hc
    exact (hnext c hc).1
  · intro c hc
    exact hc.2
  · intro c hc
    exact (hnext c hc).2

/-- Formal interface for the on-paper Meyer lift; no proof is postulated. -/
def UniversalQuarticLift : Prop :=
  ∀ p q : ℤ, 0 < q → Int.gcd q p = 1 →
    (121 / 120 : ℝ) < (p : ℝ) / q → (p : ℝ) / q < 101 / 100 →
    ∃ c : Coefficients, c ≠ 0 ∧ readoutP c = p ∧ readoutQ c = q

def ApproximationExhaustion (ξ : ℝ) : Prop :=
  ∀ n : ℕ, ∃ p q : ℤ,
    0 < q ∧ Int.gcd q p = 1 ∧
    (121 / 120 : ℝ) < (p : ℝ) / q ∧ (p : ℝ) / q < 101 / 100 ∧
    0 < (q : ℝ) * ξ - p ∧ (q : ℝ) * ξ - p < (1 / 2 : ℝ) ^ n

theorem witness_exhaustion_of_lift_and_approximants {ξ : ℝ}
    (hlift : UniversalQuarticLift) (happrox : ApproximationExhaustion ξ) :
    WitnessExhaustion ξ := by
  intro n
  obtain ⟨p, q, hq, hg, hl, hu, hp, he⟩ := happrox n
  obtain ⟨c, hc, hcp, hcq⟩ := hlift p q hq hg hl hu
  have herror : witnessError ξ c = (q : ℝ) * ξ - p := by
    simp only [witnessError, hcp, hcq]
  exact ⟨c, ⟨hc, herror.symm ▸ hp⟩, herror.symm ▸ he⟩

end Zeta7Chain
