import Mathlib.Tactic
import Mathlib.NumberTheory.LSeries.RiemannZeta
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Data.Matrix.Basic
import Mathlib.Data.Matrix.Mul
import Mathlib.Algebra.Polynomial.Degree.Lemmas

/-!
Support results reused from CHEBYSHEV_MASTERTIER_LEAN_v0_1_43.
The source order is preserved and module scopes are closed explicitly.
Only imports are consolidated; every proof is replayed in this module.
-/


/- Source module: ScalarPower.lean -/

-- The scalar ratio depends on the noncomputable Real division instance.
noncomputable section

-- Filter.Tendsto and Filter.atTop are not in the root namespace.
open Filter

/-!
CHEBYSHEV-MASTERTIER / exact scalar matrix-power model.

This file is independent of the analytic zeta(7) identification.
It proves the 2x2 real matrix closed form, its exact finite error,
and a quantitative two-index Cauchy inequality on [0,1].

It is intended to be checked by native Lean 4.33 and Mathlib.
-/

namespace ChebyshevMastertier

/-- A fixed triangular matrix encoding geometric interpolation. -/
def scalarTriangular (t q : ℝ) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![1, t * (1 - q); 0, q]

/-- A closed form for every nonnegative integer power. -/
def scalarClosed (t q : ℝ) (m : ℕ) : Matrix (Fin 2) (Fin 2) ℝ :=
  !![1, t * (1 - q ^ m); 0, q ^ m]

/-- All-depth matrix-power theorem (without a limit hypothesis). -/
theorem scalar_triangular_power (t q : ℝ) (m : ℕ) :
    scalarTriangular t q ^ m = scalarClosed t q m := by
  induction m with
  | zero =>
      apply Matrix.ext
      intro i j
      fin_cases i <;> fin_cases j <;> simp [scalarClosed]
  | succ m ih =>
      rw [pow_succ, ih]
      apply Matrix.ext
      intro i j
      fin_cases i <;> fin_cases j <;>
        simp [scalarClosed, scalarTriangular, Matrix.mul_apply,
          Fin.sum_univ_two, pow_succ] <;> ring

/-- The top-right entry of the matrix power is exactly a geometric partial sum. -/
theorem scalar_triangular_entry (t q : ℝ) (m : ℕ) :
    (scalarTriangular t q ^ m) 0 1 = t * (1 - q ^ m) := by
  rw [scalar_triangular_power]
  simp [scalarClosed]

/-- The Chebyshev polynomial of degree two in the variable `2*x-1`. -/
def scalarCheb (x : ℝ) : ℝ := 8 * x ^ 2 - 8 * x + 1

/-- The exact eigenvalue of our arithmetic normalized 2x2 matrix. -/
def scalarRatio (x : ℝ) : ℝ := scalarCheb x ^ 2 / 289

/-- Arithmetic seed factorization, evaluated at every real x≥0. -/
theorem scalar_seed_connection (x : ℝ) (hx0 : 0 ≤ x) :
    (288 - 272*x + 192*x^2 - 64*x^3) / (289 : ℝ) =
      (1 / (1+x)) * (1 - scalarRatio x) := by
  have hden : (1 + x : ℝ) ≠ 0 := by linarith
  dsimp [scalarRatio, scalarCheb]
  field_simp [hden]
  ring

/-- Interval certificate used for the matrix spectral gap. -/
theorem scalar_cheb_interval (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    -1 ≤ scalarCheb x ∧ scalarCheb x ≤ 1 := by
  have hnonneg : 0 ≤ x * (1 - x) :=
    mul_nonneg hx0 (by linarith)
  have hupper : x * (1 - x) ≤ (1 / 4 : ℝ) := by
    nlinarith [sq_nonneg (x - (1 / 2 : ℝ))]
  dsimp [scalarCheb]
  constructor <;> nlinarith

/-- The normalized eigenvalue is inside [0,1/289] on the entire interval. -/
theorem scalar_ratio_interval (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ scalarRatio x ∧ scalarRatio x ≤ 1 / 289 := by
  obtain ⟨hlo, hhi⟩ := scalar_cheb_interval x hx0 hx1
  have hprod : 0 ≤ (1 - scalarCheb x) * (1 + scalarCheb x) :=
    mul_nonneg (by linarith) (by linarith)
  have hsq : scalarCheb x ^ 2 ≤ 1 := by nlinarith [hprod]
  constructor
  · exact div_nonneg (sq_nonneg _) (by norm_num)
  · dsimp [scalarRatio]
    apply (div_le_div_iff₀ (by norm_num : (0 : ℝ) < 289)
      (by norm_num : (0 : ℝ) < 289)).2
    nlinarith

/-- Exact difference between the limiting top-right value and its m-th power. -/
theorem scalar_geometric_error (x : ℝ) (m : ℕ) :
    1 / (1 + x) -
      (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ m) 0 1 =
        scalarRatio x ^ m / (1 + x) := by
  rw [scalar_triangular_entry]
  ring

/-- Explicit uniform finite-stage error; no zeta-value appears in this theorem. -/
theorem scalar_geometric_error_interval
    (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) (m : ℕ) :
    0 ≤ 1 / (1 + x) -
        (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ m) 0 1 ∧
    1 / (1 + x) -
        (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ m) 0 1
      ≤ 1 / (289 : ℝ) ^ m := by
  rw [scalar_geometric_error]
  have hden : 0 < 1 + x := by linarith
  obtain ⟨hq0, hqle⟩ := scalar_ratio_interval x hx0 hx1
  have hqpow0 : 0 ≤ scalarRatio x ^ m := pow_nonneg hq0 _
  have hqpowl : scalarRatio x ^ m ≤ (1 / (289 : ℝ)) ^ m := by
    gcongr
  constructor
  · exact div_nonneg hqpow0 (le_of_lt hden)
  · calc
      scalarRatio x ^ m / (1 + x) ≤ scalarRatio x ^ m := by
        apply (div_le_iff₀ hden).2
        nlinarith
      _ ≤ (1 / (289 : ℝ)) ^ m := hqpowl
      _ = 1 / (289 : ℝ) ^ m := by simp

/-- Two-index quantitative Cauchy certificate, for arbitrary powers. -/
theorem scalar_pairwise_cauchy_bound
    (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) (m n : ℕ) :
    |(scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ m) 0 1 -
      (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ n) 0 1|
      ≤ 1 / (289 : ℝ) ^ m + 1 / (289 : ℝ) ^ n := by
  let u : ℝ := (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ m) 0 1
  let v : ℝ := (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ n) 0 1
  change |u - v| ≤ 1 / (289 : ℝ) ^ m + 1 / (289 : ℝ) ^ n
  have hm := scalar_geometric_error_interval x hx0 hx1 m
  have hn := scalar_geometric_error_interval x hx0 hx1 n
  change 0 ≤ 1 / (1 + x) - u ∧
    1 / (1 + x) - u ≤ 1 / (289 : ℝ) ^ m at hm
  change 0 ≤ 1 / (1 + x) - v ∧
    1 / (1 + x) - v ≤ 1 / (289 : ℝ) ^ n at hn
  have halg : u - v = -(1 / (1 + x) - u) + (1 / (1 + x) - v) := by ring
  rw [halg]
  calc
    |-(1 / (1 + x) - u) + (1 / (1 + x) - v)|
      ≤ |-(1 / (1 + x) - u)| + |1 / (1 + x) - v| := abs_add_le _ _
    _ = (1 / (1 + x) - u) + (1 / (1 + x) - v) := by
      rw [abs_neg, abs_of_nonneg hm.1, abs_of_nonneg hn.1]
    _ ≤ 1 / (289 : ℝ) ^ m + 1 / (289 : ℝ) ^ n :=
      add_le_add hm.2 hn.2

/-- The exact double-exponential finite-stage scalar error. -/
theorem scalar_dyadic_error_interval
    (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) (n : ℕ) :
    0 ≤ 1 / (1 + x) -
      (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ (2 ^ n)) 0 1 ∧
    1 / (1 + x) -
      (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ (2 ^ n)) 0 1
      ≤ 1 / (289 : ℝ) ^ (2 ^ n) :=
  scalar_geometric_error_interval x hx0 hx1 (2 ^ n)

/-- Genuine pointwise convergence of all integer matrix powers to the rank-one observable. -/
theorem scalar_geometric_tendsto
    (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    Tendsto (fun m : ℕ =>
        (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ m) 0 1)
      atTop (nhds (1 / (1 + x))) := by
  obtain ⟨hq0, hqle⟩ := scalar_ratio_interval x hx0 hx1
  have hq1 : scalarRatio x < 1 := by linarith
  have hpow : Tendsto (fun m : ℕ => scalarRatio x ^ m) atTop (nhds (0 : ℝ)) :=
    tendsto_pow_atTop_nhds_zero_of_lt_one hq0 hq1
  have hterm :
      (fun m : ℕ => (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ m) 0 1) =
      (fun m : ℕ => (1 / (1 + x)) * (1 - scalarRatio x ^ m)) := by
    funext m
    exact scalar_triangular_entry _ _ m
  have hs : Tendsto (fun m : ℕ => (1 : ℝ) - scalarRatio x ^ m)
      atTop (nhds (1 : ℝ)) := by
    simpa using (tendsto_const_nhds.sub hpow)
  have hprod : Tendsto
      (fun m : ℕ => (1 / (1 + x)) * (1 - scalarRatio x ^ m))
      atTop (nhds (1 / (1 + x))) := by
    simpa using (tendsto_const_nhds.mul hs)
  rw [hterm]
  exact hprod

/-- Unconditional Cauchy theorem for the scalar matrix readout. -/
theorem scalar_geometric_cauchy
    (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    CauchySeq (fun m : ℕ =>
      (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ m) 0 1) :=
  (scalar_geometric_tendsto x hx0 hx1).cauchySeq

/-- Dyadic repeated squaring converges to the same scalar limit. -/
theorem scalar_dyadic_tendsto
    (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    Tendsto (fun n : ℕ =>
        (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ (2 ^ n)) 0 1)
      atTop (nhds (1 / (1 + x))) := by
  have hexp : Tendsto (fun n : ℕ => (2 : ℕ) ^ n) atTop atTop :=
    tendsto_pow_atTop_atTop_of_one_lt (by norm_num : (1 : ℕ) < 2)
  exact (scalar_geometric_tendsto x hx0 hx1).comp hexp

/-- A genuine CauchySeq proof for the dyadic squaring algorithm. -/
theorem scalar_dyadic_cauchy
    (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    CauchySeq (fun n : ℕ =>
      (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ (2 ^ n)) 0 1) :=
  (scalar_dyadic_tendsto x hx0 hx1).cauchySeq

#print axioms scalar_triangular_power
#print axioms scalar_triangular_entry
#print axioms scalar_seed_connection
#print axioms scalar_cheb_interval
#print axioms scalar_ratio_interval
#print axioms scalar_geometric_error
#print axioms scalar_geometric_error_interval
#print axioms scalar_pairwise_cauchy_bound
#print axioms scalar_dyadic_error_interval
#print axioms scalar_geometric_tendsto
#print axioms scalar_geometric_cauchy
#print axioms scalar_dyadic_tendsto
#print axioms scalar_dyadic_cauchy

end ChebyshevMastertier
end


/- Source module: UniversalSemigroup.lean -/

/-!
# CHEBYSHEV-MASTERTIER: Universal 2x2 matrix semigroup

A general identity over **every commutative ring**. The construction is
polynomial in the two parameters and therefore does not use division,
limits, the zeta function, RH, or any extra mathematical premise.

M_t(q) = [[1, t (1-q)], [0,q]]
M_t(q) M_t(r) = M_t(qr).
-/

noncomputable section
namespace ChebyshevMastertier

variable {R : Type*} [CommRing R]

/-- Uniform, denominator-free triangular semigroup matrix. -/
def universalMatrix (t q : R) : Matrix (Fin 2) (Fin 2) R :=
  !![1, t * (1 - q); 0, q]

/-- An exact multiplication identity over *every* commutative ring. -/
theorem universal_matrix_mul (t q r : R) :
    universalMatrix t q * universalMatrix t r =
      universalMatrix t (q * r) := by
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    simp [universalMatrix, Matrix.mul_apply, Fin.sum_univ_two] <;> ring

/-- The two matrices commute, without spectral assumptions. -/
theorem universal_matrix_commute (t q r : R) :
    universalMatrix t q * universalMatrix t r =
      universalMatrix t r * universalMatrix t q := by
  rw [universal_matrix_mul, universal_matrix_mul, mul_comm q r]

/-- The element q=1 is the identity matrix. -/
theorem universal_matrix_one (t : R) :
    universalMatrix t 1 = 1 := by
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    simp [universalMatrix, Matrix.one_apply]

/-- Universal exponentiation requires no matrix diagonalization. -/
theorem universal_matrix_pow (t q : R) (n : ℕ) :
    universalMatrix t q ^ n = universalMatrix t (q ^ n) := by
  induction n with
  | zero =>
      simp only [pow_zero]
      exact (universal_matrix_one t).symm
  | succ n ih =>
      calc
        universalMatrix t q ^ (n + 1) =
            universalMatrix t q ^ n * universalMatrix t q := by rw [pow_succ]
        _ = universalMatrix t (q ^ n) * universalMatrix t q := by rw [ih]
        _ = universalMatrix t (q ^ n * q) := universal_matrix_mul t _ _
        _ = universalMatrix t (q ^ (n + 1)) := by rw [pow_succ]

/-- Two independent integer exponents compose multiplicatively. -/
theorem universal_two_parameter (t q r : R) (n m : ℕ) :
    universalMatrix t q ^ n * universalMatrix t r ^ m =
      universalMatrix t (q ^ n * r ^ m) := by
  rw [universal_matrix_pow, universal_matrix_pow, universal_matrix_mul]

/-- Exact scalar entry, no limits or analytic estimates. -/
theorem universal_upper_right (t q : R) :
    universalMatrix t q 0 1 = t * (1 - q) := by
  simp [universalMatrix]

theorem universal_two_parameter_entry (t q r : R) (n m : ℕ) :
    (universalMatrix t q ^ n * universalMatrix t r ^ m) 0 1 =
      t * (1 - q ^ n * r ^ m) := by
  rw [universal_two_parameter]
  exact universal_upper_right t _

/-- Compatibility with the already kernel-checked scalar matrix. -/
theorem universal_eq_scalar (t q : ℝ) :
    universalMatrix t q = scalarTriangular t q := rfl

/-- The concrete eta/Chebyshev matrices commute at every real x. -/
theorem eta_cheb_real_commute (x : ℝ) :
    universalMatrix (1 / (1 + x)) (x ^ 2) *
        universalMatrix (1 / (1 + x)) (scalarRatio x) =
      universalMatrix (1 / (1 + x)) (scalarRatio x) *
        universalMatrix (1 / (1 + x)) (x ^ 2) :=
  universal_matrix_commute _ _ _

/-- For x≠-1 the eta matrix really has upper-right entry 1-x. -/
theorem eta_upper_right_eq_one_sub (x : ℝ) (hx : 1 + x ≠ 0) :
    universalMatrix (1 / (1 + x)) (x ^ 2) 0 1 = 1 - x := by
  rw [universal_upper_right]
  field_simp [hx]
  ring

#print axioms universal_matrix_mul
#print axioms universal_matrix_commute
#print axioms universal_matrix_one
#print axioms universal_matrix_pow
#print axioms universal_two_parameter
#print axioms universal_two_parameter_entry
#print axioms eta_cheb_real_commute
#print axioms eta_upper_right_eq_one_sub

end ChebyshevMastertier
end


/- Source module: MeanTransfer.lean -/

noncomputable section
open Filter

/-!
CHEBYSHEV-MASTERTIER / positive-mean transfer.

The previous module proves the explicit pointwise matrix-power estimate.
This file transports that same estimate through ANY positive, normalized,
real-valued linear readout on functions of the unit interval.

No Riemann-zeta identity is assumed or claimed here. The concrete
sevenfold Mellin moment readout is still to be instantiated.
-/

namespace ChebyshevMastertier

/-- An algebraic probability mean on functions restricted to [0,1].
No continuity or analytic evaluation is assumed in this definition. -/
structure PositiveIntervalMean where
  eval : (ℝ → ℝ) → ℝ
  map_sub : ∀ (f g : ℝ → ℝ),
    eval (fun x => f x - g x) = eval f - eval g
  map_const : ∀ (c : ℝ), eval (fun _ => c) = c
  mono : ∀ (f g : ℝ → ℝ),
    (∀ x : ℝ, 0 ≤ x → x ≤ 1 → f x ≤ g x) → eval f ≤ eval g

/-- The exact scalar (top right) entry at exponent 2^n. -/
def dyadicEntry (n : ℕ) (x : ℝ) : ℝ :=
  (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ (2 ^ n)) 0 1

/-- The target observable of a probability mean. -/
def meanTarget (μ : PositiveIntervalMean) : ℝ :=
  (64 / 63 : ℝ) * μ.eval (fun x => 1 / (1 + x))

/-- The matrix approximation obtained by applying the very same mean. -/
def meanStage (μ : PositiveIntervalMean) (n : ℕ) : ℝ :=
  (64 / 63 : ℝ) * μ.eval (dyadicEntry n)

/-- Exact all-depth transfer of the uniform Chebyshev estimate.
The upper bound 64/(63*289^(2^n)) uses normalization μ(1)=1. -/
theorem mean_stage_error (μ : PositiveIntervalMean) (n : ℕ) :
    0 ≤ meanTarget μ - meanStage μ n ∧
    meanTarget μ - meanStage μ n ≤
      (64 / 63 : ℝ) * (1 / (289 : ℝ)) ^ (2 ^ n) := by
  let e : ℝ → ℝ := fun x => 1 / (1 + x) - dyadicEntry n x
  have hpos : 0 ≤ μ.eval e := by
    have h := μ.mono (fun _ => (0 : ℝ)) e (by
      intro x hx0 hx1
      exact (scalar_dyadic_error_interval x hx0 hx1 n).1)
    rw [μ.map_const] at h
    exact h
  have hupper : μ.eval e ≤ (1 / (289 : ℝ)) ^ (2 ^ n) := by
    have h := μ.mono e (fun _ => (1 / (289 : ℝ)) ^ (2 ^ n)) (by
      intro x hx0 hx1
      change 1 / (1 + x) -
        (scalarTriangular (1 / (1 + x)) (scalarRatio x) ^ (2 ^ n)) 0 1
        ≤ (1 / (289 : ℝ)) ^ (2 ^ n)
      simpa only [div_pow, one_pow] using
        (scalar_dyadic_error_interval x hx0 hx1 n).2)
    rw [μ.map_const] at h
    exact h
  have hident : meanTarget μ - meanStage μ n =
      (64 / 63 : ℝ) * μ.eval e := by
    dsimp [meanTarget, meanStage, e]
    rw [μ.map_sub]
    ring
  rw [hident]
  constructor
  · exact mul_nonneg (by norm_num) hpos
  · exact mul_le_mul_of_nonneg_left hupper (by norm_num)

/-- The readout error tends to zero double exponentially, for any such mean. -/
theorem mean_stage_tendsto (μ : PositiveIntervalMean) :
    Tendsto (fun n : ℕ => meanStage μ n) atTop (nhds (meanTarget μ)) := by
  have hq0 : (0 : ℝ) ≤ 1 / 289 := by norm_num
  have hq1 : (1 / 289 : ℝ) < 1 := by norm_num
  have hpow : Tendsto (fun m : ℕ => (1 / (289 : ℝ)) ^ m)
      atTop (nhds (0 : ℝ)) :=
    tendsto_pow_atTop_nhds_zero_of_lt_one hq0 hq1
  have hexp : Tendsto (fun n : ℕ => (2 : ℕ) ^ n) atTop atTop :=
    tendsto_pow_atTop_atTop_of_one_lt (by norm_num : (1 : ℕ) < 2)
  have hbound : Tendsto
      (fun n : ℕ => (64 / 63 : ℝ) * (1 / (289 : ℝ)) ^ (2 ^ n))
      atTop (nhds (0 : ℝ)) := by
    simpa using (tendsto_const_nhds.mul (hpow.comp hexp))
  have herr : Tendsto (fun n : ℕ => meanTarget μ - meanStage μ n)
      atTop (nhds (0 : ℝ)) :=
    squeeze_zero
      (fun n => (mean_stage_error μ n).1)
      (fun n => (mean_stage_error μ n).2)
      hbound
  have hconst :
      Tendsto (fun _ : ℕ => meanTarget μ) atTop (nhds (meanTarget μ)) :=
    tendsto_const_nhds
  have h : Tendsto
      (fun n : ℕ => meanTarget μ - (meanTarget μ - meanStage μ n))
      atTop (nhds (meanTarget μ)) := by
    simpa only [sub_zero] using (hconst.sub herr)
  have heq :
      (fun n : ℕ => meanTarget μ - (meanTarget μ - meanStage μ n)) =
      (fun n : ℕ => meanStage μ n) := by
    funext n
    ring
  rw [heq] at h
  exact h

/-- All-depth Cauchy property of the transferred scalar readout. -/
theorem mean_stage_cauchy (μ : PositiveIntervalMean) :
    CauchySeq (fun n : ℕ => meanStage μ n) :=
  (mean_stage_tendsto μ).cauchySeq

/-- Nonvacuity: evaluation at any point of [0,1] is such a mean. -/
def pointMass (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) : PositiveIntervalMean where
  eval := fun f => f x
  map_sub := by intro f g; rfl
  map_const := by intro c; rfl
  mono := by
    intro f g h
    exact h x hx0 hx1

/-- This abstract transfer specializes precisely to the proven pointwise matrix limit. -/
theorem pointMass_stage (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1) (n : ℕ) :
    meanStage (pointMass x hx0 hx1) n =
      (64 / 63 : ℝ) * dyadicEntry n x := rfl

#print axioms mean_stage_error
#print axioms mean_stage_tendsto
#print axioms mean_stage_cauchy
#print axioms pointMass_stage

end ChebyshevMastertier
end


/- Source module: HybridError.lean -/

/-!
# CHEBYSHEV-MASTERTIER: two-parameter hybrid error

Eta and Chebyshev are independent commuting contractions, with exponents
2^n and 2^m. This file proves the exact residual and its uniform bound
and transports it through the kernel-checked abstract positive mean.

The sharper moment-weighted bound for the specific zeta(7) mean is a
separate analytic identification: no zeta value is used in these proofs.
-/

noncomputable section
namespace ChebyshevMastertier

/-- The two independently exponentiated eigenvalues. -/
def hybridRatio (x : ℝ) (n m : ℕ) : ℝ :=
  (x ^ 2) ^ (2 ^ n) * (scalarRatio x) ^ (2 ^ m)

/-- The upper-right entry of the product of two genuine matrix powers. -/
def hybridEntry (x : ℝ) (n m : ℕ) : ℝ :=
  (universalMatrix (1 / (1 + x)) (x ^ 2) ^ (2 ^ n) *
   universalMatrix (1 / (1 + x)) (scalarRatio x) ^ (2 ^ m)) 0 1

/-- Exact two-parameter matrix-power entry. -/
theorem hybrid_entry_closed (x : ℝ) (n m : ℕ) :
    hybridEntry x n m = (1 / (1 + x)) * (1 - hybridRatio x n m) := by
  exact universal_two_parameter_entry
    (1 / (1 + x)) (x ^ 2) (scalarRatio x) (2 ^ n) (2 ^ m)

/-- The full residual is explicitly a PRODUCT of the eta and Chebyshev errors. -/
theorem hybrid_error_exact (x : ℝ) (n m : ℕ) :
    1 / (1 + x) - hybridEntry x n m =
      (1 / (1 + x)) * hybridRatio x n m := by
  rw [hybrid_entry_closed]
  ring

/-- Pointwise quantitative positivity and the independent two-scale bound. -/
theorem hybrid_error_interval (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x ≤ 1)
    (n m : ℕ) :
    0 ≤ 1 / (1 + x) - hybridEntry x n m ∧
    1 / (1 + x) - hybridEntry x n m ≤
      (1 / (289 : ℝ)) ^ (2 ^ m) * (x ^ 2) ^ (2 ^ n) := by
  rw [hybrid_error_exact]
  obtain ⟨hq0, hqle⟩ := scalar_ratio_interval x hx0 hx1
  have hpow0 : 0 ≤ (x ^ 2) ^ (2 ^ n) := by positivity
  have hqp0 : 0 ≤ scalarRatio x ^ (2 ^ m) := pow_nonneg hq0 _
  have hqp_bound : scalarRatio x ^ (2 ^ m) ≤
      (1 / (289 : ℝ)) ^ (2 ^ m) := by
    gcongr
  have hratio0 : 0 ≤ hybridRatio x n m := by
    exact mul_nonneg hpow0 hqp0
  have hratio_bound : hybridRatio x n m ≤
      (1 / (289 : ℝ)) ^ (2 ^ m) * (x ^ 2) ^ (2 ^ n) := by
    dsimp [hybridRatio]
    calc
      (x ^ 2) ^ (2 ^ n) * scalarRatio x ^ (2 ^ m) ≤
        (x ^ 2) ^ (2 ^ n) * (1 / (289 : ℝ)) ^ (2 ^ m) :=
          mul_le_mul_of_nonneg_left hqp_bound hpow0
      _ = (1 / (289 : ℝ)) ^ (2 ^ m) * (x ^ 2) ^ (2 ^ n) := by ring
  have hden : 0 < 1 + x := by linarith
  have hrec0 : 0 ≤ (1 / (1 + x) : ℝ) := by positivity
  have hrec1 : (1 / (1 + x) : ℝ) ≤ 1 := by
    apply (div_le_iff₀ hden).2
    linarith
  constructor
  · exact mul_nonneg hrec0 hratio0
  · calc
      (1 / (1 + x)) * hybridRatio x n m ≤ hybridRatio x n m := by
        simpa using mul_le_mul_of_nonneg_right hrec1 hratio0
      _ ≤ (1 / (289 : ℝ)) ^ (2 ^ m) * (x ^ 2) ^ (2 ^ n) := hratio_bound

/-- A positive mean of the exact residual. -/
def hybridMean (μ : PositiveIntervalMean) (n m : ℕ) : ℝ :=
  (64 / 63 : ℝ) * μ.eval (fun x => hybridEntry x n m)

def hybridResidual (n m : ℕ) : ℝ → ℝ :=
  fun x => (1 / (1 + x)) * hybridRatio x n m

/-- An exact bridge between the scalar error and its product form. -/
theorem hybrid_residual_eq_error (n m : ℕ) (x : ℝ) :
    hybridResidual n m x = 1 / (1 + x) - hybridEntry x n m := by
  exact (hybrid_error_exact x n m).symm

/-- The error is an exact positive-mean observable, not merely a bound. -/
theorem hybrid_mean_error_exact (μ : PositiveIntervalMean) (n m : ℕ) :
    meanTarget μ - hybridMean μ n m =
      (64 / 63 : ℝ) * μ.eval (hybridResidual n m) := by
  calc
    meanTarget μ - hybridMean μ n m =
        (64 / 63 : ℝ) *
        (μ.eval (fun x => 1 / (1 + x)) -
          μ.eval (fun x => hybridEntry x n m)) := by
            dsimp [meanTarget, hybridMean]
            ring
    _ = (64 / 63 : ℝ) *
        μ.eval (fun x => 1 / (1 + x) - hybridEntry x n m) := by
          rw [μ.map_sub]
    _ = (64 / 63 : ℝ) * μ.eval (hybridResidual n m) := by
          congr 1
          apply congrArg μ.eval
          funext x
          exact hybrid_error_exact x n m

/-- Universal double-exponential bound for every positive normalized mean.
The moment-weighted refinement is proved separately below when linearity and
an actual seventh moment are supplied. -/
theorem hybrid_mean_error_bound (μ : PositiveIntervalMean) (n m : ℕ) :
    0 ≤ meanTarget μ - hybridMean μ n m ∧
    meanTarget μ - hybridMean μ n m ≤
      (64 / 63 : ℝ) * (1 / (289 : ℝ)) ^ (2 ^ m) := by
  rw [hybrid_mean_error_exact]
  have hpos : 0 ≤ μ.eval (hybridResidual n m) := by
    have h := μ.mono (fun _ => (0 : ℝ)) (hybridResidual n m) (by
      intro x hx0 hx1
      rw [hybrid_residual_eq_error]
      exact (hybrid_error_interval x hx0 hx1 n m).1)
    rw [μ.map_const] at h
    exact h
  have hupper : μ.eval (hybridResidual n m) ≤
      (1 / (289 : ℝ)) ^ (2 ^ m) := by
    have h := μ.mono (hybridResidual n m)
        (fun _ => (1 / (289 : ℝ)) ^ (2 ^ m)) (by
      intro x hx0 hx1
      have hp := (hybrid_error_interval x hx0 hx1 n m).2
      have hsq : x ^ 2 ≤ (1 : ℝ) := by
        nlinarith [mul_nonneg hx0 (sub_nonneg.mpr hx1)]
      have hpow : (x ^ 2) ^ (2 ^ n) ≤ 1 := by
        have hh : (x ^ 2) ^ (2 ^ n) ≤ (1 : ℝ) ^ (2 ^ n) := by
          gcongr <;> exact hsq
        simpa using hh
      have hq0 : 0 ≤ (1 / (289 : ℝ)) ^ (2 ^ m) := by positivity
      change hybridResidual n m x ≤ (1 / (289 : ℝ)) ^ (2 ^ m)
      rw [hybrid_residual_eq_error]
      calc
        1 / (1 + x) - hybridEntry x n m ≤
          (1 / (289 : ℝ)) ^ (2 ^ m) * (x ^ 2) ^ (2 ^ n) := hp
        _ ≤ (1 / (289 : ℝ)) ^ (2 ^ m) * 1 :=
            mul_le_mul_of_nonneg_left hpow hq0
        _ = (1 / (289 : ℝ)) ^ (2 ^ m) := by ring)
    rw [μ.map_const] at h
    exact h
  constructor
  · exact mul_nonneg (by norm_num) hpos
  · exact mul_le_mul_of_nonneg_left hupper (by norm_num)

/-- The additional assumption needed for a moment-weighted error bound is
explicit, not silently embedded in the definition of a positive mean. -/
theorem hybrid_mean_moment_bound
    (μ : PositiveIntervalMean) (n m : ℕ)
    (hscale : ∀ (c : ℝ) (f : ℝ → ℝ),
      μ.eval (fun x => c * f x) = c * μ.eval f) :
    meanTarget μ - hybridMean μ n m ≤
      (64 / 63 : ℝ) * (1 / (289 : ℝ)) ^ (2 ^ m) *
        μ.eval (fun x => (x ^ 2) ^ (2 ^ n)) := by
  rw [hybrid_mean_error_exact]
  have h := μ.mono (hybridResidual n m)
      (fun x => (1 / (289 : ℝ)) ^ (2 ^ m) * (x ^ 2) ^ (2 ^ n)) (by
    intro x hx0 hx1
    rw [hybrid_residual_eq_error]
    exact (hybrid_error_interval x hx0 hx1 n m).2)
  rw [hscale] at h
  have hc : 0 ≤ (64 / 63 : ℝ) := by norm_num
  have := mul_le_mul_of_nonneg_left h hc
  calc
    (64 / 63 : ℝ) * μ.eval (hybridResidual n m) ≤
        (64 / 63 : ℝ) *
         ((1 / (289 : ℝ)) ^ (2 ^ m) *
         μ.eval (fun x => (x ^ 2) ^ (2 ^ n))) := this
    _ = (64 / 63 : ℝ) * (1 / (289 : ℝ)) ^ (2 ^ m) *
         μ.eval (fun x => (x ^ 2) ^ (2 ^ n)) := by ring

/-- The desired seventh-moment estimate is now immediate, *conditionally on
identifying the actual moments*. This is a stated theorem hypothesis. -/
theorem hybrid_mean_seventh_moment_bound
    (μ : PositiveIntervalMean) (n m : ℕ)
    (hscale : ∀ (c : ℝ) (f : ℝ → ℝ),
      μ.eval (fun x => c * f x) = c * μ.eval f)
    (hmoment : μ.eval (fun x => (x ^ 2) ^ (2 ^ n)) =
      1 / (((2 ^ (n + 1) + 1 : ℕ) : ℝ) ^ 7)) :
    meanTarget μ - hybridMean μ n m ≤
      (64 / 63 : ℝ) * (1 / (289 : ℝ)) ^ (2 ^ m) /
        (((2 ^ (n + 1) + 1 : ℕ) : ℝ) ^ 7) := by
  have h := hybrid_mean_moment_bound μ n m hscale
  rw [hmoment] at h
  simpa only [div_eq_mul_inv, one_mul, mul_assoc] using h

#print axioms hybrid_entry_closed
#print axioms hybrid_error_exact
#print axioms hybrid_error_interval
#print axioms hybrid_mean_error_exact
#print axioms hybrid_mean_error_bound
#print axioms hybrid_mean_moment_bound
#print axioms hybrid_mean_seventh_moment_bound

end ChebyshevMastertier
end


/- Source module: GridMean.lean -/

/-!
CHEBYSHEV-MASTERTIER / Positive finite grid means and sevenfold composition.

This constructs concrete finite probability means on the real unit interval.
Every stage is a finite arithmetic average, not an abstract existential mean.
The continuum limit and its identification with zeta(7) are future theorems.
-/

noncomputable section
namespace ChebyshevMastertier

/-- A rational point in (0,1] on a normalized grid. -/
def gridNode (m : ℕ) (k : Fin (m + 1)) : ℝ :=
  ((k.val + 1 : ℕ) : ℝ) / ((m + 1 : ℕ) : ℝ)

theorem gridNode_mem (m : ℕ) (k : Fin (m + 1)) :
    0 ≤ gridNode m k ∧ gridNode m k ≤ 1 := by
  constructor
  · unfold gridNode
    positivity
  · unfold gridNode
    apply (div_le_one (by positivity : (0 : ℝ) < ((m + 1 : ℕ) : ℝ))).2
    exact_mod_cast Nat.succ_le_of_lt k.isLt

/-- Uniform average over the m+1 rational grid points. -/
def gridMean (m : ℕ) : PositiveIntervalMean where
  eval := fun f =>
    (∑ k : Fin (m + 1), f (gridNode m k)) / ((m + 1 : ℕ) : ℝ)
  map_sub := by
    intro f g
    change (∑ k : Fin (m + 1),
      (f (gridNode m k) - g (gridNode m k))) / ((m + 1 : ℕ) : ℝ) =
      (∑ k : Fin (m + 1), f (gridNode m k)) / ((m + 1 : ℕ) : ℝ) -
      (∑ k : Fin (m + 1), g (gridNode m k)) / ((m + 1 : ℕ) : ℝ)
    rw [Finset.sum_sub_distrib, sub_div]
  map_const := by
    intro c
    change (∑ _k : Fin (m + 1), c) / ((m + 1 : ℕ) : ℝ) = c
    have hne : ((m + 1 : ℕ) : ℝ) ≠ 0 := by positivity
    simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    apply (div_eq_iff hne).2
    ring
  mono := by
    intro f g hfg
    change (∑ k : Fin (m + 1), f (gridNode m k)) /
      ((m + 1 : ℕ) : ℝ) ≤
      (∑ k : Fin (m + 1), g (gridNode m k)) /
      ((m + 1 : ℕ) : ℝ)
    apply div_le_div_of_nonneg_right ?_ (by positivity)
    apply Finset.sum_le_sum
    intro k _
    exact hfg (gridNode m k) (gridNode_mem m k).1 (gridNode_mem m k).2

/-- Pushforward of two probability means by multiplication on [0,1]. -/
def productMean (μ ν : PositiveIntervalMean) : PositiveIntervalMean where
  eval := fun f => μ.eval (fun x => ν.eval (fun y => f (x * y)))
  map_sub := by
    intro f g
    change μ.eval (fun x => ν.eval (fun y => f (x*y) - g (x*y))) =
      μ.eval (fun x => ν.eval (fun y => f (x*y))) -
      μ.eval (fun x => ν.eval (fun y => g (x*y)))
    have hpoint :
        (fun x => ν.eval (fun y => f (x*y) - g (x*y))) =
        (fun x => ν.eval (fun y => f (x*y)) -
          ν.eval (fun y => g (x*y))) := by
      funext x
      exact ν.map_sub (fun y => f (x*y)) (fun y => g (x*y))
    rw [hpoint]
    exact μ.map_sub _ _
  map_const := by
    intro c
    change μ.eval (fun _x => ν.eval (fun _y => c)) = c
    have h : (fun _x : ℝ => ν.eval (fun _y : ℝ => c)) =
        (fun _x : ℝ => c) := by
      funext x
      exact ν.map_const c
    rw [h]
    exact μ.map_const c
  mono := by
    intro f g hfg
    apply μ.mono
    intro x hx0 hx1
    apply ν.mono
    intro y hy0 hy1
    have hxy : x * y ≤ 1 := by
      nlinarith [mul_nonneg hx0 (sub_nonneg.mpr hy1)]
    exact hfg (x * y) (mul_nonneg hx0 hy0) hxy

/-- Exact algebraic product of n interval probability means. -/
def productPower : ℕ → PositiveIntervalMean → PositiveIntervalMean
  | 0, _ => pointMass 1 (by norm_num) (by norm_num)
  | n + 1, μ => productMean μ (productPower n μ)

/-- A sevenfold, finite, normalized mean constructed from rational grid nodes. -/
def sevenfoldGrid (m : ℕ) : PositiveIntervalMean :=
  productPower 7 (gridMean m)

/-- Apply the previously proved matrix error bound to a concrete 7-fold mean. -/
theorem grid_sevenfold_error (m n : ℕ) :
    0 ≤ meanTarget (sevenfoldGrid m) - meanStage (sevenfoldGrid m) n ∧
    meanTarget (sevenfoldGrid m) - meanStage (sevenfoldGrid m) n ≤
      (64 / 63 : ℝ) * (1 / (289 : ℝ)) ^ (2 ^ n) :=
  mean_stage_error (sevenfoldGrid m) n

/-- For each finite grid, dyadic matrix readouts converge without research axioms. -/
theorem grid_sevenfold_cauchy (m : ℕ) :
    CauchySeq (fun n => meanStage (sevenfoldGrid m) n) :=
  mean_stage_cauchy (sevenfoldGrid m)

#print axioms gridNode_mem
#print axioms grid_sevenfold_error
#print axioms grid_sevenfold_cauchy

end ChebyshevMastertier
end


/- Source module: GridMomentLock.lean -/

/-!
CHEBYSHEV-MASTERTIER / All-depth finite sevenfold moment identification.

There are no unknown zeta values in this module. We prove that the
sevenfold positive grid mean reads X^k as the seventh power of an
explicit one-dimensional grid moment, itself a rational number.

This exact finite factorization is the algebraic input for the later
limit of grid moments to 1/(k+1)^7. The continuum limit is NOT assumed.
-/

noncomputable section
namespace ChebyshevMastertier

/-- First grid moment: an actual finite probability mean. -/
def gridMoment (m k : ℕ) : ℝ :=
  (gridMean m).eval (fun x => x ^ k)

/-- This finite mean is linear under multiplication by a real scalar. -/
theorem gridMean_scale (m : ℕ) (c : ℝ) (f : ℝ → ℝ) :
    (gridMean m).eval (fun x => c * f x) =
      c * (gridMean m).eval f := by
  change (∑ j : Fin (m + 1), c * f (gridNode m j)) /
      ((m + 1 : ℕ) : ℝ) =
    c * ((∑ j : Fin (m + 1), f (gridNode m j)) /
      ((m + 1 : ℕ) : ℝ))
  rw [← Finset.mul_sum]
  ring

/-- No normalization is hidden: every single-grid zeroth moment is 1. -/
theorem gridMoment_zero (m : ℕ) : gridMoment m 0 = 1 := by
  simpa [gridMoment] using (gridMean m).map_const (1 : ℝ)

/-- A concrete nonnegative, bounded first-grid moment for every k. -/
theorem gridMoment_interval (m k : ℕ) :
    0 ≤ gridMoment m k ∧ gridMoment m k ≤ 1 := by
  have h0 : (0 : ℝ) ≤ (gridMean m).eval (fun x => x ^ k) := by
    calc
      (0 : ℝ) = (gridMean m).eval (fun _ => (0 : ℝ)) :=
        ((gridMean m).map_const 0).symm
      _ ≤ (gridMean m).eval (fun x => x ^ k) := by
        apply (gridMean m).mono
        intro x hx0 hx1
        exact pow_nonneg hx0 _
  have h1 : (gridMean m).eval (fun x => x ^ k) ≤ 1 := by
    calc
      (gridMean m).eval (fun x => x ^ k) ≤
          (gridMean m).eval (fun _ => (1 : ℝ)) := by
        apply (gridMean m).mono
        intro x hx0 hx1
        have hpow : x ^ k ≤ (1 : ℝ) ^ k := by
          gcongr <;> assumption
        simpa using hpow
      _ = 1 := (gridMean m).map_const 1
  exact ⟨h0, h1⟩

/-- Every finite product-grid monomial factors exactly into its 1D moments.
We prove the stronger version with an arbitrary scalar coefficient c. -/
theorem productPower_grid_monomial_scaled
    (m k n : ℕ) (c : ℝ) :
    (productPower n (gridMean m)).eval (fun x => c * x ^ k) =
      c * gridMoment m k ^ n := by
  induction n generalizing c with
  | zero =>
      change c * (1 : ℝ) ^ k = c * gridMoment m k ^ 0
      simp
  | succ n ih =>
      change (gridMean m).eval
          (fun x => (productPower n (gridMean m)).eval
            (fun y => c * (x * y) ^ k)) =
        c * gridMoment m k ^ (n + 1)
      have hinner (x : ℝ) :
          (productPower n (gridMean m)).eval (fun y => c * (x * y) ^ k) =
            (c * x ^ k) * gridMoment m k ^ n := by
        have heq :
            (fun y : ℝ => c * (x * y) ^ k) =
            (fun y : ℝ => (c * x ^ k) * y ^ k) := by
          funext y
          rw [mul_pow]
          ring
        rw [heq]
        exact ih (c * x ^ k)
      have hfun :
          (fun x : ℝ => (productPower n (gridMean m)).eval
            (fun y => c * (x * y) ^ k)) =
          (fun x : ℝ => (c * gridMoment m k ^ n) * x ^ k) := by
        funext x
        rw [hinner]
        ring
      rw [hfun, gridMean_scale]
      change (c * gridMoment m k ^ n) * gridMoment m k =
        c * gridMoment m k ^ (n + 1)
      rw [pow_succ]
      ring

/-- The full sevenfold grid moment is literally a seventh power. -/
theorem sevenfoldGrid_monomial (m k : ℕ) :
    (sevenfoldGrid m).eval (fun x => x ^ k) =
      gridMoment m k ^ 7 := by
  simpa only [sevenfoldGrid, one_mul] using
    (productPower_grid_monomial_scaled m k 7 (1 : ℝ))

/-- Every sevenfold monomial moment is in [0,1]. -/
theorem sevenfoldGrid_monomial_interval (m k : ℕ) :
    0 ≤ (sevenfoldGrid m).eval (fun x => x ^ k) ∧
    (sevenfoldGrid m).eval (fun x => x ^ k) ≤ 1 := by
  rw [sevenfoldGrid_monomial]
  obtain ⟨h0, h1⟩ := gridMoment_interval m k
  constructor
  · positivity
  · have h : gridMoment m k ^ 7 ≤ (1 : ℝ) ^ 7 := by
      gcongr <;> assumption
    simpa using h

/-- Fully rational one-dimensional grid moment. -/
def rationalGridMoment (m k : ℕ) : ℚ :=
  (∑ j : Fin (m + 1),
    ((((j.val + 1 : ℕ) : ℚ) / ((m + 1 : ℕ) : ℚ)) ^ k)) /
    ((m + 1 : ℕ) : ℚ)

/-- No real approximation: the rational finite sum casts to the true grid moment. -/
theorem rationalGridMoment_cast (m k : ℕ) :
    (rationalGridMoment m k : ℝ) = gridMoment m k := by
  change
    ( (((∑ j : Fin (m + 1),
       ((((j.val + 1 : ℕ) : ℚ) / ((m + 1 : ℕ) : ℚ)) ^ k)) /
       ((m + 1 : ℕ) : ℚ)) : ℚ) : ℝ) =
    (∑ j : Fin (m + 1),
        ((((j.val + 1 : ℕ) : ℝ) / ((m + 1 : ℕ) : ℝ)) ^ k)) /
        ((m + 1 : ℕ) : ℝ)
  -- Move the rational-to-real cast through the finite sum, division, and power.
  -- Unlike `norm_cast`, these rewrites do not leave a residual cast of a sum.
  simp only [Rat.cast_div, Rat.cast_sum, Rat.cast_pow, Rat.cast_natCast]

/-- The exact sevenfold arithmetic moment, with no integral. -/
def rationalSevenfoldMoment (m k : ℕ) : ℚ :=
  rationalGridMoment m k ^ 7

theorem sevenfoldGrid_monomial_rational (m k : ℕ) :
    (sevenfoldGrid m).eval (fun x => x ^ k) =
      (rationalSevenfoldMoment m k : ℝ) := by
  calc
    (sevenfoldGrid m).eval (fun x => x ^ k) =
        gridMoment m k ^ 7 := sevenfoldGrid_monomial m k
    _ = (rationalGridMoment m k : ℝ) ^ 7 := by
          rw [rationalGridMoment_cast]
    _ = (rationalSevenfoldMoment m k : ℝ) := by
          simp [rationalSevenfoldMoment]

#print axioms gridMean_scale
#print axioms gridMoment_zero
#print axioms gridMoment_interval
#print axioms productPower_grid_monomial_scaled
#print axioms sevenfoldGrid_monomial
#print axioms sevenfoldGrid_monomial_interval
#print axioms rationalGridMoment_cast
#print axioms sevenfoldGrid_monomial_rational

end ChebyshevMastertier
end


/- Source module: PowerSumSqueeze.lean -/

/-!
CHEBYSHEV–MASTERTIER / Elementary power sums.

We prove the universal arithmetic estimate for the right rectangular mean
of X^k, without integrals, external approximation assumptions, or ζ-values.
The real-valued auxiliary objects here are finite sums of natural powers.
-/

noncomputable section
namespace ChebyshevMastertier

private theorem power_step_squeeze (x : ℝ) (hx : 0 ≤ x) (k : ℕ) :
    (k + 1 : ℕ) * x ^ k ≤ (x + 1) ^ (k + 1) - x ^ (k + 1) ∧
    (x + 1) ^ (k + 1) - x ^ (k + 1) ≤
      (k + 1 : ℕ) * (x + 1) ^ k := by
  induction k with
  | zero => constructor <;> norm_num <;> ring
  | succ k ih =>
      have ha : 0 ≤ x + 1 := by linarith
      have hp : x ^ (k + 1) ≤ (x + 1) ^ (k + 1) := by
        gcongr <;> linarith
      have hident : (x + 1) ^ (k + 2) - x ^ (k + 2) =
          (x + 1) * ((x + 1) ^ (k + 1) - x ^ (k + 1)) +
            x ^ (k + 1) := by
        have he : k + 2 = (k + 1) + 1 := by omega
        rw [he, pow_succ, pow_succ]
        ring
      have hmullo := mul_le_mul_of_nonneg_left ih.1 ha
      have hmulhi := mul_le_mul_of_nonneg_left ih.2 ha
      have hstep : ((k + 1 : ℕ) : ℝ) * x ^ (k + 1) ≤
          (x + 1) * (((k + 1 : ℕ) : ℝ) * x ^ k) := by
        calc
          ((k + 1 : ℕ) : ℝ) * x ^ (k + 1) =
              x * (((k + 1 : ℕ) : ℝ) * x ^ k) := by rw [pow_succ]; ring
          _ ≤ (x + 1) * (((k + 1 : ℕ) : ℝ) * x ^ k) := by
            apply mul_le_mul_of_nonneg_right (by linarith : x ≤ x + 1)
            exact mul_nonneg (by positivity) (pow_nonneg hx k)
      constructor
      · calc
          ((k + 2 : ℕ) : ℝ) * x ^ (k + 1) =
              (((k + 1 : ℕ) : ℝ) * x ^ (k + 1)) + x ^ (k + 1) := by
                push_cast; ring
          _ ≤ (x + 1) * (((k + 1 : ℕ) : ℝ) * x ^ k) + x ^ (k + 1) :=
                add_le_add hstep (le_refl _)
          _ ≤ (x + 1) * ((x + 1) ^ (k + 1) - x ^ (k + 1)) +
                x ^ (k + 1) := add_le_add hmullo (le_refl _)
          _ = (x + 1) ^ (k + 2) - x ^ (k + 2) := hident.symm
      · calc
          (x + 1) ^ (k + 2) - x ^ (k + 2) =
              (x + 1) * ((x + 1) ^ (k + 1) - x ^ (k + 1)) +
                x ^ (k + 1) := hident
          _ ≤ (x + 1) * (((k + 1 : ℕ) : ℝ) * (x + 1) ^ k) +
                (x + 1) ^ (k + 1) := add_le_add hmulhi hp
          _ = ((k + 2 : ℕ) : ℝ) * (x + 1) ^ (k + 1) := by
                push_cast
                rw [pow_succ]
                ring

def rightPowerSum (m k : ℕ) : ℝ :=
  ∑ j ∈ Finset.range m, ((j : ℝ) + 1) ^ k

def leftPowerSum (m k : ℕ) : ℝ :=
  ∑ j ∈ Finset.range m, (j : ℝ) ^ k

private theorem telescoping_power (m k : ℕ) :
    (∑ j ∈ Finset.range m,
      (((j : ℝ) + 1) ^ k - (j : ℝ) ^ k)) =
      (m : ℝ) ^ k - (0 : ℝ) ^ k := by
  induction m with
  | zero => simp
  | succ m ih =>
      rw [Finset.sum_range_succ, ih]
      push_cast
      ring

private theorem right_sub_left (m k : ℕ) :
    rightPowerSum m k - leftPowerSum m k =
      (m : ℝ) ^ k - (0 : ℝ) ^ k := by
  unfold rightPowerSum leftPowerSum
  rw [← Finset.sum_sub_distrib]
  exact telescoping_power m k

/-- Discrete finite-difference inequalities, with both endpoints kept explicit. -/
theorem arithmetic_power_sum_bounds (m k : ℕ) :
    ((k + 1 : ℕ) : ℝ) * leftPowerSum m k ≤ (m : ℝ) ^ (k + 1) ∧
    (m : ℝ) ^ (k + 1) ≤ ((k + 1 : ℕ) : ℝ) * rightPowerSum m k := by
  constructor
  · calc
      ((k + 1 : ℕ) : ℝ) * leftPowerSum m k =
          ∑ j ∈ Finset.range m,
            ((k + 1 : ℕ) : ℝ) * (j : ℝ) ^ k := by
              simp only [leftPowerSum, Finset.mul_sum]
      _ ≤ ∑ j ∈ Finset.range m,
            (((j : ℝ) + 1) ^ (k + 1) - (j : ℝ) ^ (k + 1)) := by
            apply Finset.sum_le_sum
            intro j hj
            exact (power_step_squeeze (j : ℝ) (by positivity) k).1
      _ = (m : ℝ) ^ (k + 1) := by
            rw [telescoping_power]
            simp
  · calc
      (m : ℝ) ^ (k + 1) =
          ∑ j ∈ Finset.range m,
            (((j : ℝ) + 1) ^ (k + 1) - (j : ℝ) ^ (k + 1)) := by
            rw [telescoping_power]
            simp
      _ ≤ ∑ j ∈ Finset.range m,
            ((k + 1 : ℕ) : ℝ) * ((j : ℝ) + 1) ^ k := by
            apply Finset.sum_le_sum
            intro j hj
            exact (power_step_squeeze (j : ℝ) (by positivity) k).2
      _ = ((k + 1 : ℕ) : ℝ) * rightPowerSum m k := by
            simp only [rightPowerSum, Finset.mul_sum]

/-- Core right-Riemann finite-sum error bound: uniform in m, all exponents k. -/
theorem normalized_power_sum_error (m k : ℕ) :
    0 ≤ rightPowerSum (m + 1) k / (((m + 1 : ℕ) : ℝ) ^ (k + 1)) -
      1 / (((k + 1 : ℕ) : ℝ)) ∧
    rightPowerSum (m + 1) k / (((m + 1 : ℕ) : ℝ) ^ (k + 1)) -
      1 / (((k + 1 : ℕ) : ℝ)) ≤
      1 / (((m + 1 : ℕ) : ℝ)) := by
  let M : ℝ := ((m + 1 : ℕ) : ℝ)
  let K : ℝ := ((k + 1 : ℕ) : ℝ)
  let U : ℝ := rightPowerSum (m + 1) k
  let L : ℝ := leftPowerSum (m + 1) k
  have hM : 0 < M := by dsimp [M]; positivity
  have hK : 0 < K := by dsimp [K]; positivity
  have hMp : 0 < M ^ (k + 1) := pow_pos hM _
  have hleft : K * L ≤ M ^ (k + 1) := (arithmetic_power_sum_bounds (m+1) k).1
  have hright : M ^ (k + 1) ≤ K * U := (arithmetic_power_sum_bounds (m+1) k).2
  have hgap : U ≤ L + M ^ k := by
    have ht := right_sub_left (m + 1) k
    have hz : 0 ≤ (0 : ℝ) ^ k := pow_nonneg (le_refl _) _
    dsimp [U, L, M]
    linarith
  have hlow : 1 / K ≤ U / M ^ (k + 1) := by
    apply (div_le_div_iff₀ hK hMp).2
    simpa [one_mul, mul_comm] using hright
  have hL : L / M ^ (k + 1) ≤ 1 / K := by
    have hf : L ≤ M ^ (k + 1) / K :=
      (le_div_iff₀ hK).2 (by nlinarith [hleft])
    calc
      L / M ^ (k + 1) ≤ (M ^ (k + 1) / K) / M ^ (k + 1) :=
        div_le_div_of_nonneg_right hf hMp.le
      _ = 1 / K := by
        field_simp [hK.ne', hMp.ne']
  have hU : U / M ^ (k + 1) ≤ 1 / K + 1 / M := by
    calc
      U / M ^ (k + 1) ≤ (L + M ^ k) / M ^ (k + 1) :=
        div_le_div_of_nonneg_right hgap hMp.le
      _ = L / M ^ (k + 1) + 1 / M := by
        rw [add_div, pow_succ]
        field_simp [hM.ne']
      _ ≤ 1 / K + 1 / M := add_le_add hL (le_refl _)
  constructor <;> dsimp [M, K, U, L] at * <;> linarith

#print axioms arithmetic_power_sum_bounds
#print axioms normalized_power_sum_error

end ChebyshevMastertier
end


/- Source module: GridMomentLimit.lean -/

/-!
CHEBYSHEV–MASTERTIER / Genuine moment convergence from finite power sums.

The finite-grid moments converge to the seventh Hausdorff moments.
The *separate* DyadicGridReadout module then binds this limiting finite
polynomial readout to the already-audited rational matrix-stage functional.
No zeta(7) identification is assumed or claimed here.
-/

noncomputable section
open Filter
namespace ChebyshevMastertier

/-- Exact arithmetic normalization of the finite one-dimensional grid sum. -/
theorem gridMoment_eq_normalized_power_sum (m k : ℕ) :
    gridMoment m k =
      rightPowerSum (m + 1) k / (((m + 1 : ℕ) : ℝ) ^ (k + 1)) := by
  let M : ℝ := ((m + 1 : ℕ) : ℝ)
  have hfin :
      (∑ j : Fin (m + 1), ((((j.val + 1 : ℕ) : ℝ) / M) ^ k)) =
      (∑ j ∈ Finset.range (m + 1), ((((j + 1 : ℕ) : ℝ) / M) ^ k)) := by
    exact Fin.sum_univ_eq_sum_range
      (fun j : ℕ => ((((j + 1 : ℕ) : ℝ) / M) ^ k)) (m + 1)
  change (∑ j : Fin (m + 1), ((((j.val + 1 : ℕ) : ℝ) / M) ^ k)) / M =
    rightPowerSum (m + 1) k / M ^ (k + 1)
  rw [hfin]
  have hsum :
      (∑ j ∈ Finset.range (m + 1), ((((j + 1 : ℕ) : ℝ) / M) ^ k)) =
      rightPowerSum (m + 1) k / M ^ k := by
    calc
      _ = ∑ j ∈ Finset.range (m + 1), (((j : ℝ) + 1) ^ k / M ^ k) := by
        apply Finset.sum_congr rfl
        intro j hj
        simp only [div_pow, Nat.cast_add, Nat.cast_one]
      _ = (∑ j ∈ Finset.range (m + 1), ((j : ℝ) + 1) ^ k) / M ^ k := by
        simp only [div_eq_mul_inv, Finset.sum_mul]
      _ = rightPowerSum (m + 1) k / M ^ k := rfl
  rw [hsum, pow_succ]
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

/-- Universal explicit finite-grid error, using only power-sum arithmetic. -/
theorem gridMoment_rate (m k : ℕ) :
    0 ≤ gridMoment m k - 1 / (((k + 1 : ℕ) : ℝ)) ∧
    gridMoment m k - 1 / (((k + 1 : ℕ) : ℝ)) ≤
      1 / (((m + 1 : ℕ) : ℝ)) := by
  rw [gridMoment_eq_normalized_power_sum]
  exact normalized_power_sum_error m k

/-- Convergence of each actual finite probability grid moment. -/
theorem gridMoment_tendsto (k : ℕ) :
    Tendsto (fun m : ℕ => gridMoment m k) atTop
      (nhds (1 / (((k + 1 : ℕ) : ℝ)))) := by
  let a : ℝ := 1 / (((k + 1 : ℕ) : ℝ))
  have hbound : Tendsto
      (fun m : ℕ => (1 : ℝ) / (m + 1)) atTop (nhds 0) :=
    tendsto_one_div_add_atTop_nhds_zero_nat
  have herr : Tendsto
      (fun m : ℕ => gridMoment m k - a)
      atTop (nhds (0 : ℝ)) := by
    apply squeeze_zero
      (fun m => (gridMoment_rate m k).1)
      (fun m => (gridMoment_rate m k).2)
    simpa only [a, Nat.cast_add, Nat.cast_one] using hbound
  have hc : Tendsto (fun _ : ℕ => a) atTop (nhds a) :=
    tendsto_const_nhds
  have h := hc.add herr
  have heq : (fun m : ℕ => a + (gridMoment m k - a)) =
      (fun m : ℕ => gridMoment m k) := by
    funext m
    ring
  simpa only [heq, add_zero, a] using h

/-- The same grid limit after the exact rational-to-real embedding. -/
theorem rationalGridMoment_tendsto (k : ℕ) :
    Tendsto (fun m : ℕ => (rationalGridMoment m k : ℝ)) atTop
      (nhds (1 / (((k + 1 : ℕ) : ℝ)))) := by
  simpa only [rationalGridMoment_cast] using gridMoment_tendsto k

/-- Exact seventh Hausdorff moment of the sevenfold grid in the limit. -/
theorem sevenfoldGrid_monomial_tendsto (k : ℕ) :
    Tendsto (fun m : ℕ =>
      (sevenfoldGrid m).eval (fun x => x ^ k)) atTop
      (nhds (1 / (((k + 1 : ℕ) : ℝ) ^ 7))) := by
  have h := (gridMoment_tendsto k).pow 7
  have ht : (1 / (((k + 1 : ℕ) : ℝ))) ^ 7 =
      1 / (((k + 1 : ℕ) : ℝ) ^ 7) := by simp [div_pow]
  simpa only [sevenfoldGrid_monomial, ht] using h

/-- Finite polynomial evaluations inherit the moment limit term by term. -/
theorem finite_rational_grid_moment_tendsto (s : Finset ℕ) (a : ℕ → ℚ) :
    Tendsto (fun m : ℕ =>
      ∑ k ∈ s, (a k : ℝ) * (rationalGridMoment m k : ℝ) ^ 7) atTop
      (nhds (∑ k ∈ s, (a k : ℝ) / (((k + 1 : ℕ) : ℝ) ^ 7))) := by
  apply tendsto_finsetSum s
  intro k hk
  have h := (rationalGridMoment_tendsto k).pow 7
  have hc : Tendsto (fun _ : ℕ => (a k : ℝ)) atTop (nhds (a k : ℝ)) :=
    tendsto_const_nhds
  have hmul := hc.mul h
  have hpow : (1 / (((k + 1 : ℕ) : ℝ))) ^ 7 =
      1 / (((k + 1 : ℕ) : ℝ) ^ 7) := by
    simp only [one_div, inv_pow]
  have hlim : (a k : ℝ) * (1 / (((k + 1 : ℕ) : ℝ))) ^ 7 =
      (a k : ℝ) / (((k + 1 : ℕ) : ℝ) ^ 7) := by
    rw [hpow]
    ring
  rw [hlim] at hmul
  exact hmul

#print axioms gridMoment_eq_normalized_power_sum
#print axioms gridMoment_rate
#print axioms gridMoment_tendsto
#print axioms rationalGridMoment_tendsto
#print axioms sevenfoldGrid_monomial_tendsto
#print axioms finite_rational_grid_moment_tendsto

end ChebyshevMastertier
end


/- Source module: EtaChebGridComparison.lean -/

/-!
CHEBYSHEV-MASTERTIER / two-grid comparison without continuum integration.

The native eta matrix endpoint was checked independently.  This module
builds a positive comparison between the eta and Chebyshev upper-right
entries on each concrete sevenfold rational grid.  Its seventh moment
converges by the previously checked elementary power-sum squeeze.
-/

noncomputable section
namespace ChebyshevMastertier

open Filter

/-- Upper-right entry of the eta semigroup at an arbitrary integer depth. -/
def etaScalarEntry (N : ℕ) (x : ℝ) : ℝ :=
  (1 / (1 + x)) * (1 - x ^ (2 * N))

/-- Pointwise eta error is a single positive monomial times a resolvent. -/
theorem eta_scalar_residual (N : ℕ) (x : ℝ) :
    1 / (1 + x) - etaScalarEntry N x =
      (1 / (1 + x)) * x ^ (2 * N) := by
  dsimp [etaScalarEntry]
  ring

/-- Uniform elementary domination of the eta residual on the unit interval. -/
theorem eta_scalar_residual_interval (N : ℕ) (x : ℝ)
    (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    0 ≤ 1 / (1 + x) - etaScalarEntry N x ∧
      1 / (1 + x) - etaScalarEntry N x ≤ x ^ (2 * N) := by
  rw [eta_scalar_residual]
  have hden : (0 : ℝ) < 1 + x := by linarith
  have hrec0 : (0 : ℝ) ≤ 1 / (1 + x) := by positivity
  have hrec1 : 1 / (1 + x) ≤ (1 : ℝ) := by
    apply (div_le_iff₀ hden).2
    linarith
  have hp : 0 ≤ x ^ (2 * N) := pow_nonneg hx0 _
  constructor
  · exact mul_nonneg hrec0 hp
  · calc
      (1 / (1 + x)) * x ^ (2 * N) ≤
          (1 : ℝ) * x ^ (2 * N) :=
            mul_le_mul_of_nonneg_right hrec1 hp
      _ = x ^ (2 * N) := one_mul _

/-- Eta counterpart of the previously checked Chebyshev mean stage. -/
def etaMeanStage (μ : PositiveIntervalMean) (N : ℕ) : ℝ :=
  (64 / 63 : ℝ) * μ.eval (etaScalarEntry N)

/-- Exact eta scalar remainder for any positive interval mean. -/
theorem eta_mean_error_exact (μ : PositiveIntervalMean) (N : ℕ) :
    meanTarget μ - etaMeanStage μ N =
      (64 / 63 : ℝ) *
        μ.eval (fun x => (1 / (1 + x)) * x ^ (2 * N)) := by
  calc
    meanTarget μ - etaMeanStage μ N =
        (64 / 63 : ℝ) *
          (μ.eval (fun x => 1 / (1 + x)) - μ.eval (etaScalarEntry N)) := by
            dsimp [meanTarget, etaMeanStage]
            ring
    _ = (64 / 63 : ℝ) *
        μ.eval (fun x => 1 / (1 + x) - etaScalarEntry N x) := by
          rw [μ.map_sub]
    _ = (64 / 63 : ℝ) *
        μ.eval (fun x => (1 / (1 + x)) * x ^ (2 * N)) := by
          have hfun :
              (fun x : ℝ => 1 / (1 + x) - etaScalarEntry N x) =
              (fun x : ℝ => (1 / (1 + x)) * x ^ (2 * N)) := by
            funext x
            exact eta_scalar_residual N x
          rw [hfun]

/-- Eta mean error is controlled by one moment, without using integration. -/
theorem eta_mean_error_interval (μ : PositiveIntervalMean) (N : ℕ) :
    0 ≤ meanTarget μ - etaMeanStage μ N ∧
      meanTarget μ - etaMeanStage μ N ≤
        (64 / 63 : ℝ) * μ.eval (fun x => x ^ (2 * N)) := by
  rw [eta_mean_error_exact]
  let e : ℝ → ℝ := fun x => (1 / (1 + x)) * x ^ (2 * N)
  have hp : 0 ≤ μ.eval e := by
    have h := μ.mono (fun _ => (0 : ℝ)) e (by
      intro x hx0 hx1
      change (0 : ℝ) ≤ (1 / (1 + x)) * x ^ (2 * N)
      have hres := (eta_scalar_residual_interval N x hx0 hx1).1
      rw [eta_scalar_residual] at hres
      exact hres)
    rw [μ.map_const] at h
    exact h
  have hu : μ.eval e ≤ μ.eval (fun x => x ^ (2 * N)) := by
    apply μ.mono
    intro x hx0 hx1
    change (1 / (1 + x)) * x ^ (2 * N) ≤ x ^ (2 * N)
    have hres := (eta_scalar_residual_interval N x hx0 hx1).2
    rw [eta_scalar_residual] at hres
    exact hres
  change 0 ≤ (64 / 63 : ℝ) * μ.eval e ∧
    (64 / 63 : ℝ) * μ.eval e ≤
      (64 / 63 : ℝ) * μ.eval (fun x => x ^ (2 * N))
  constructor
  · exact mul_nonneg (by norm_num) hp
  · exact mul_le_mul_of_nonneg_left hu (by norm_num)

/-- Concrete sevenfold grid: the eta error is bounded by its seventh moment. -/
theorem eta_grid_error (m N : ℕ) :
    0 ≤ meanTarget (sevenfoldGrid m) - etaMeanStage (sevenfoldGrid m) N ∧
      meanTarget (sevenfoldGrid m) - etaMeanStage (sevenfoldGrid m) N ≤
        (64 / 63 : ℝ) * gridMoment m (2 * N) ^ 7 := by
  simpa only [sevenfoldGrid_monomial] using
    (eta_mean_error_interval (sevenfoldGrid m) N)

/-- Finite eta and Chebyshev grid observables are close at every pair of depths. -/
theorem cheb_eta_grid_comparison (m n N : ℕ) :
    |meanStage (sevenfoldGrid m) n -
      etaMeanStage (sevenfoldGrid m) N| ≤
      (64 / 63 : ℝ) * (1 / (289 : ℝ)) ^ (2 ^ n) +
      (64 / 63 : ℝ) * gridMoment m (2 * N) ^ 7 := by
  have hc := grid_sevenfold_error m n
  have he := eta_grid_error m N
  have hc0 : (0 : ℝ) ≤
      (64 / 63 : ℝ) * (1 / (289 : ℝ)) ^ (2 ^ n) := by positivity
  have he0 : (0 : ℝ) ≤
      (64 / 63 : ℝ) * gridMoment m (2 * N) ^ 7 := by
    exact mul_nonneg (by norm_num) (pow_nonneg (gridMoment_interval m (2 * N)).1 _)
  apply abs_le.mpr
  constructor
  · linarith [hc.2, he.1, hc0, he0]
  · linarith [hc.1, he.2, hc0, he0]

/-- The moment contribution in the comparison has an explicit rational limit. -/
theorem eta_grid_comparison_moment_tendsto (N : ℕ) :
    Tendsto (fun m : ℕ => (64 / 63 : ℝ) * gridMoment m (2 * N) ^ 7)
      atTop (nhds ((64 / 63 : ℝ) /
        (((2 * N + 1 : ℕ) : ℝ) ^ 7))) := by
  have hpow := (gridMoment_tendsto (2 * N)).pow 7
  have hmul : Tendsto
      (fun m : ℕ => (64 / 63 : ℝ) * gridMoment m (2 * N) ^ 7)
      atTop (nhds ((64 / 63 : ℝ) *
        (1 / (((2 * N + 1 : ℕ) : ℝ))) ^ 7)) := by
    simpa using (tendsto_const_nhds.mul hpow)
  have hrecip7 :
      (1 / (((2 * N + 1 : ℕ) : ℝ))) ^ 7 =
      1 / ((((2 * N + 1 : ℕ) : ℝ)) ^ 7) := by
    rw [div_pow]
    simp only [one_pow]
  rw [hrecip7] at hmul
  simpa only [div_eq_mul_inv, one_mul] using hmul

#print axioms eta_scalar_residual
#print axioms eta_scalar_residual_interval
#print axioms eta_mean_error_exact
#print axioms eta_mean_error_interval
#print axioms eta_grid_error
#print axioms cheb_eta_grid_comparison
#print axioms eta_grid_comparison_moment_tendsto

end ChebyshevMastertier
end


/- Source module: Core.lean -/

/-!
CHEBYSHEV-MASTERTIER / exact 2x2 polynomial arithmetic.
This file proves algebraic statements about the concrete integer recurrence.
The identification of its limiting rational readout with zeta(7) is a
separate analytic obligation and is not asserted as a theorem here.
-/

-- Polynomial ℤ uses noncomputable algebra instances in Mathlib.
-- This affects execution of definitions, not the logical content of proofs.
noncomputable section

namespace ChebyshevMastertier

abbrev ZPoly := Polynomial ℤ

def chebC : ZPoly :=
  8 * Polynomial.X ^ 2 - 8 * Polynomial.X + 1

def seedV : ZPoly := chebC ^ 2

def seedW : ZPoly :=
  288 - 272 * Polynomial.X + 192 * Polynomial.X ^ 2 - 64 * Polynomial.X ^ 3

def Xplus : ZPoly := 1 + Polynomial.X

-- An exact identity in Z[X], with no numerical approximations.
theorem seed_factorization :
    Xplus * seedW = (289 : ZPoly) - seedV := by
  dsimp [Xplus, seedW, seedV, chebC]
  ring

structure Stage where
  a : ZPoly
  v : ZPoly
  w : ZPoly

-- The upper-triangular entries of the fixed arithmetic matrix.
def initial : Stage := ⟨289, seedV, seedW⟩

def step (s : Stage) : Stage :=
  ⟨s.a ^ 2, s.v ^ 2, s.w * (s.a + s.v)⟩

def stage : ℕ → Stage
  | 0 => initial
  | n + 1 => step (stage n)

def Locked (s : Stage) : Prop :=
  Xplus * s.w = s.a - s.v

theorem initial_locked : Locked initial := by
  change Xplus * seedW = (289 : ZPoly) - seedV
  exact seed_factorization

-- Difference of squares transports the arithmetic invariant forever.
theorem locked_step (s : Stage) (hs : Locked s) : Locked (step s) := by
  change Xplus * s.w = s.a - s.v at hs
  change Xplus * (s.w * (s.a + s.v)) = s.a ^ 2 - s.v ^ 2
  calc
    Xplus * (s.w * (s.a + s.v)) = (Xplus * s.w) * (s.a + s.v) := by ring
    _ = (s.a - s.v) * (s.a + s.v) := by rw [hs]
    _ = s.a ^ 2 - s.v ^ 2 := by ring

theorem every_stage_locked (n : ℕ) : Locked (stage n) := by
  induction n with
  | zero => exact initial_locked
  | succ n ih => exact locked_step (stage n) ih

theorem stage_a_power (n : ℕ) :
    (stage n).a = (289 : ZPoly) ^ (2 ^ n) := by
  induction n with
  | zero => simp [stage, initial]
  | succ n ih =>
      calc
        (stage (n + 1)).a = (stage n).a ^ 2 := rfl
        _ = ((289 : ZPoly) ^ (2 ^ n)) ^ 2 := by rw [ih]
        _ = (289 : ZPoly) ^ (2 ^ (n + 1)) := by
          have he : (2 : ℕ) ^ (n + 1) = 2 ^ n * 2 := by simp [pow_succ]
          rw [he, pow_mul]

theorem stage_v_power (n : ℕ) :
    (stage n).v = seedV ^ (2 ^ n) := by
  induction n with
  | zero => simp [stage, initial]
  | succ n ih =>
      calc
        (stage (n + 1)).v = (stage n).v ^ 2 := rfl
        _ = (seedV ^ (2 ^ n)) ^ 2 := by rw [ih]
        _ = seedV ^ (2 ^ (n + 1)) := by
          have he : (2 : ℕ) ^ (n + 1) = 2 ^ n * 2 := by simp [pow_succ]
          rw [he, pow_mul]

-- Uniform, all-depth polynomial divisibility: no RH and no analytic bridge.
theorem every_stage_divisibility (n : ℕ) :
    Xplus ∣ ((289 : ZPoly) ^ (2 ^ n) - seedV ^ (2 ^ n)) := by
  refine ⟨(stage n).w, ?_⟩
  have hlock : Xplus * (stage n).w = (stage n).a - (stage n).v :=
    every_stage_locked n
  calc
    (289 : ZPoly) ^ (2 ^ n) - seedV ^ (2 ^ n)
        = (stage n).a - (stage n).v := by
          rw [stage_a_power, stage_v_power]
    _ = Xplus * (stage n).w := hlock.symm

-- Actual 2x2 matrix: squaring is not merely a scalar analogy.
def stageMatrix (s : Stage) : Matrix (Fin 2) (Fin 2) ZPoly :=
  !![s.a, s.w; 0, s.v]

theorem stage_matrix_square (s : Stage) :
    stageMatrix (step s) = stageMatrix s * stageMatrix s := by
  -- Use precisely Matrix.ext; a generic `ext i j` can also descend into
  -- Polynomial.ext, introducing an unintended coefficient goal.
  apply Matrix.ext
  intro i j
  fin_cases i <;> fin_cases j <;>
    simp [stageMatrix, step, Matrix.mul_apply, Fin.sum_univ_two] <;> ring

theorem matrix_exponentiation (n : ℕ) :
    stageMatrix (stage n) = stageMatrix initial ^ (2 ^ n) := by
  induction n with
  | zero => simp [stage]
  | succ n ih =>
      calc
        stageMatrix (stage (n + 1)) = stageMatrix (step (stage n)) := rfl
        _ = stageMatrix (stage n) * stageMatrix (stage n) := stage_matrix_square _
        _ = (stageMatrix initial ^ (2 ^ n)) * (stageMatrix initial ^ (2 ^ n)) := by
          rw [ih]
        _ = stageMatrix initial ^ (2 ^ (n + 1)) := by
          have he : (2 : ℕ) ^ (n + 1) = 2 ^ n * 2 := by simp [pow_succ]
          rw [he, pow_mul, pow_two]

-- The limiting rank-one matrix is an idempotent, at every scalar value.
def scalarProjector (t : ℚ) : Matrix (Fin 2) (Fin 2) ℚ :=
  !![1, t; 0, 0]

theorem projector_idempotent (t : ℚ) :
    scalarProjector t * scalarProjector t = scalarProjector t := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [scalarProjector, Matrix.mul_apply, Fin.sum_univ_two]

-- The finite-stage arithmetic readout, using only coefficients in Z[X].
def finiteMoment (p : ZPoly) (d : ℕ) : ℚ :=
  ∑ k ∈ Finset.range d, (p.coeff k : ℚ) / (((k + 1 : ℕ) : ℚ) ^ 7)

def rationalStage (n : ℕ) : ℚ :=
  (64 : ℚ) * finiteMoment (stage n).w (4 * 2 ^ n) /
    (63 * (289 : ℚ) ^ (2 ^ n))

-- Independent seed-value equalities over Q, not decimal observations.
theorem arithmetic_certificate_0 :
    (64 : ℚ) *
      (288 - (272 : ℚ) / (2 : ℚ)^7 + 192 / (3 : ℚ)^7 - 64 / (4 : ℚ)^7) /
      (63 * 289)
      = (3139223 : ℚ) / 3123036 := by
  norm_num

theorem stage_one_polynomial :
    (stage 1).w =
      (83520 : ZPoly) - 83488 * Polynomial.X + 83072 * Polynomial.X ^ 2 -
      80256 * Polynomial.X ^ 3 + 69632 * Polynomial.X ^ 4 -
      47104 * Polynomial.X ^ 5 + 20480 * Polynomial.X ^ 6 -
      4096 * Polynomial.X ^ 7 := by
  dsimp [stage, step, initial, seedW, seedV, chebC]
  ring

theorem arithmetic_certificate_1 :
    (64 : ℚ) *
      (83520 - (83488 : ℚ) / (2 : ℚ)^7 + 83072 / (3 : ℚ)^7 -
       80256 / (4 : ℚ)^7 + 69632 / (5 : ℚ)^7 -
       47104 / (6 : ℚ)^7 + 20480 / (7 : ℚ)^7 - 4096 / (8 : ℚ)^7) /
      (63 * 83521)
      = (1990841190500918815273 : ℚ) / 1974376897931300625000 := by
  norm_num

#print axioms seed_factorization
#print axioms every_stage_locked
#print axioms stage_a_power
#print axioms every_stage_divisibility
#print axioms matrix_exponentiation
#print axioms projector_idempotent
#print axioms arithmetic_certificate_0
#print axioms arithmetic_certificate_1

end ChebyshevMastertier
end


/- Source module: HardyArithmetic.lean -/

/-!
CHEBYSHEV-MASTERTIER / Arithmetic sevenfold Hardy operator.

Purely rational exact arithmetic: the diagonal Hardy operator applied seven
successive times divides the k-th coefficient by (k+1)^7. The readout is
identical to the one in the previously audited Core.lean, not a new postulate.

No real analytic or zeta-function assumption enters this file.
-/

noncomputable section
namespace ChebyshevMastertier

/-- Diagonal arithmetic Hardy averaging on a rational coefficient sequence. -/
def hardyCoeff (a : ℕ → ℚ) : ℕ → ℚ :=
  fun k => a k / ((k + 1 : ℕ) : ℚ)

/-- Exact integer-indexed iterates of the Hardy average. -/
def hardyIter : ℕ → (ℕ → ℚ) → (ℕ → ℚ)
  | 0, a => a
  | d + 1, a => hardyCoeff (hardyIter d a)

/-- All-depth algebraic Hardy multiplier, with no limits. -/
theorem hardyIter_coeff (d k : ℕ) (a : ℕ → ℚ) :
    hardyIter d a k = a k / (((k + 1 : ℕ) : ℚ) ^ d) := by
  induction d with
  | zero => simp [hardyIter]
  | succ d ih =>
      change hardyIter d a k / ((k + 1 : ℕ) : ℚ) =
        a k / (((k + 1 : ℕ) : ℚ) ^ (d + 1))
      rw [ih, pow_succ]
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring

/-- Integer polynomial coefficients are embedded exactly into rationals. -/
def integerCoeffs (p : ZPoly) : ℕ → ℚ :=
  fun k => (p.coeff k : ℚ)

/-- Finite arithmetic Hardy moment; every summand is rational. -/
def hardyMoment (p : ZPoly) (bound depth : ℕ) : ℚ :=
  ∑ k ∈ Finset.range bound, hardyIter depth (integerCoeffs p) k

/-- The arithmetic moment explicitly as one finite coefficient sum. -/
theorem hardyMoment_formula (p : ZPoly) (bound depth : ℕ) :
    hardyMoment p bound depth =
      ∑ k ∈ Finset.range bound,
        (p.coeff k : ℚ) / (((k + 1 : ℕ) : ℚ) ^ depth) := by
  simp [hardyMoment, integerCoeffs, hardyIter_coeff]

/-- The sevenfold Hardy readout equals the original finiteMoment. -/
theorem hardyMoment_seven (p : ZPoly) (bound : ℕ) :
    hardyMoment p bound 7 = finiteMoment p bound := by
  simpa [finiteMoment] using hardyMoment_formula p bound 7

/-- Explicitly lift the sevenfold multiplier to each dyadic integer matrix stage. -/
def sevenfoldDyadic (n : ℕ) : ℚ :=
  (64 : ℚ) * hardyMoment (stage n).w (4 * 2 ^ n) 7 /
    (63 * (289 : ℚ) ^ (2 ^ n))

/-- No hidden normalization: this is the same rationalStage as Core.lean. -/
theorem sevenfoldDyadic_eq_rationalStage (n : ℕ) :
    sevenfoldDyadic n = rationalStage n := by
  simp only [sevenfoldDyadic, rationalStage, hardyMoment_seven]

/-- The Hardy transformation respects exact finite addition of coefficients. -/
theorem hardyCoeff_add (a b : ℕ → ℚ) (k : ℕ) :
    hardyCoeff (fun j => a j + b j) k =
      hardyCoeff a k + hardyCoeff b k := by
  simp [hardyCoeff, add_div]

#print axioms hardyIter_coeff
#print axioms hardyMoment_formula
#print axioms hardyMoment_seven
#print axioms sevenfoldDyadic_eq_rationalStage
#print axioms hardyCoeff_add

end ChebyshevMastertier
end


/- Source module: DyadicGridReadout.lean -/

/-!
CHEBYSHEV–MASTERTIER / Concrete integer-matrix readout transfer.

This module binds the finite polynomial grid to the *exact same*
rationalStage from Core.lean. It does not assume the analytic zeta bridge.
-/

noncomputable section
open Filter
namespace ChebyshevMastertier

/-- Cast the original sevenfold rational polynomial functional to reals. -/
theorem finiteMoment_cast (p : ZPoly) (d : ℕ) :
    (finiteMoment p d : ℝ) =
      ∑ k ∈ Finset.range d, (p.coeff k : ℝ) / (((k + 1 : ℕ) : ℝ) ^ 7) := by
  simp only [finiteMoment, Rat.cast_sum, Rat.cast_div,
    Rat.cast_intCast, Rat.cast_natCast, Rat.cast_pow]

/-- Actual dyadic stage scalar is the limit of rational grid evaluations. -/
theorem dyadic_integer_readout_grid_limit (n : ℕ) :
    Tendsto (fun m : ℕ =>
      (64 / (63 * (289 : ℝ) ^ (2 ^ n))) *
        (∑ k ∈ Finset.range (4 * 2 ^ n),
          ((((stage n).w.coeff k : ℤ) : ℚ) : ℝ) *
            (rationalGridMoment m k : ℝ) ^ 7)) atTop
      (nhds (rationalStage n : ℝ)) := by
  have hg := finite_rational_grid_moment_tendsto
    (Finset.range (4 * 2 ^ n))
    (fun k => (((stage n).w.coeff k : ℤ) : ℚ))
  have hc : Tendsto
      (fun _ : ℕ => (64 : ℝ) / (63 * (289 : ℝ) ^ (2 ^ n))) atTop
      (nhds ((64 : ℝ) / (63 * (289 : ℝ) ^ (2 ^ n)))) :=
    tendsto_const_nhds
  have hmul := hc.mul hg
  have htarget :
      ((64 : ℝ) / (63 * (289 : ℝ) ^ (2 ^ n))) *
        (∑ k ∈ Finset.range (4 * 2 ^ n),
          ((((stage n).w.coeff k : ℤ) : ℚ) : ℝ) /
            (((k + 1 : ℕ) : ℝ) ^ 7)) =
      (rationalStage n : ℝ) := by
    rw [rationalStage]
    -- The coefficient has two routes into ℝ:
    --   (Int → Rat → Real) and (Int → Real).
    -- Normalize them BEFORE asking `ring` to compare the readouts.
    simp only [Rat.cast_div, Rat.cast_mul, Rat.cast_natCast,
      Rat.cast_ofNat, Rat.cast_pow, finiteMoment_cast,
      Rat.cast_intCast]
    ring
  simpa only [htarget] using hmul

#print axioms finiteMoment_cast
#print axioms dyadic_integer_readout_grid_limit

end ChebyshevMastertier
end


/- Source module: PolynomialGridBridge.lean -/

/-!
# Integer polynomial → concrete sevenfold grid

Proves exact polynomial evaluation and moment transfer on the rational
sevenfold grids. The finite result has no zeta assumption.
-/
noncomputable section
open Filter
namespace ChebyshevMastertier

/-- Evaluate an integer-coefficient polynomial as a real polynomial. -/
def intPolyReal (p : ZPoly) (x : ℝ) : ℝ :=
  Polynomial.eval₂ (Int.castRingHom ℝ) x p

/-- Every positive interval mean is additive. -/
theorem positiveMean_add (μ : PositiveIntervalMean) (f g : ℝ → ℝ) :
    μ.eval (fun x => f x + g x) = μ.eval f + μ.eval g := by
  have h := μ.map_sub (fun x => f x + g x) g
  have hfun : (fun x : ℝ => f x + g x - g x) = f := by
    funext x
    ring
  rw [hfun] at h
  linarith

/-- Additivity under any finite sum of real-valued functions. -/
theorem positiveMean_finsetSum (μ : PositiveIntervalMean)
    (s : Finset ℕ) (f : ℕ → ℝ → ℝ) :
    μ.eval (fun x => ∑ k ∈ s, f k x) =
      ∑ k ∈ s, μ.eval (f k) := by
  classical
  induction s using Finset.induction_on with
  | empty =>
      simpa using μ.map_const (0 : ℝ)
  | @insert a s ha ih =>
      calc
        μ.eval (fun x => ∑ k ∈ insert a s, f k x) =
          μ.eval (fun x => f a x + ∑ k ∈ s, f k x) := by
            congr 1
            funext x
            simp only [Finset.sum_insert ha]
        _ = μ.eval (f a) + μ.eval (fun x => ∑ k ∈ s, f k x) :=
          positiveMean_add μ _ _
        _ = ∑ k ∈ insert a s, μ.eval (f k) := by
          rw [ih, Finset.sum_insert ha]

/-- Scaling can be transported through any finite product of grid means. -/
theorem gridProduct_scale (m n : ℕ) (c : ℝ) (f : ℝ → ℝ) :
    (productPower n (gridMean m)).eval (fun x => c * f x) =
      c * (productPower n (gridMean m)).eval f := by
  induction n generalizing c f with
  | zero =>
      rfl
  | succ n ih =>
      change (gridMean m).eval
          (fun x => (productPower n (gridMean m)).eval
            (fun y => c * f (x * y))) =
        c * (gridMean m).eval
          (fun x => (productPower n (gridMean m)).eval
            (fun y => f (x * y)))
      have hfun :
          (fun x : ℝ => (productPower n (gridMean m)).eval
            (fun y => c * f (x * y))) =
          (fun x : ℝ => c * (productPower n (gridMean m)).eval
            (fun y => f (x * y))) := by
        funext x
        exact ih c (fun y => f (x * y))
      rw [hfun]
      exact gridMean_scale m c _

/-- Sevenfold product mean is homogeneous for arbitrary functions. -/
theorem sevenfoldGrid_scale (m : ℕ) (c : ℝ) (f : ℝ → ℝ) :
    (sevenfoldGrid m).eval (fun x => c * f x) =
      c * (sevenfoldGrid m).eval f :=
  gridProduct_scale m 7 c f

/-- An arbitrary integer polynomial evaluates as a finite coefficient sum. -/
theorem intPolyReal_sum_range (p : ZPoly) (d : ℕ)
    (hd : p.natDegree < d) (x : ℝ) :
    intPolyReal p x =
      ∑ k ∈ Finset.range d, (p.coeff k : ℝ) * x ^ k := by
  exact Polynomial.eval₂_eq_sum_range' (Int.castRingHom ℝ) hd x

/-- Exact sevenfold grid evaluation for a polynomial of bounded degree. -/
theorem sevenfoldGrid_poly_eval (m d : ℕ) (p : ZPoly)
    (hd : p.natDegree < d) :
    (sevenfoldGrid m).eval (intPolyReal p) =
      ∑ k ∈ Finset.range d, (p.coeff k : ℝ) * gridMoment m k ^ 7 := by
  have heq : intPolyReal p =
      (fun x : ℝ => ∑ k ∈ Finset.range d, (p.coeff k : ℝ) * x ^ k) := by
    funext x
    exact intPolyReal_sum_range p d hd x
  rw [heq, positiveMean_finsetSum]
  apply Finset.sum_congr rfl
  intro k hk
  rw [sevenfoldGrid_scale, sevenfoldGrid_monomial]

/-- The grid evaluation converges to the exact finite rational seventh-moment readout. -/
theorem sevenfoldGrid_poly_tendsto (p : ZPoly) (d : ℕ)
    (hd : p.natDegree < d) :
    Tendsto (fun m : ℕ => (sevenfoldGrid m).eval (intPolyReal p))
      atTop (nhds (finiteMoment p d : ℝ)) := by
  have h := finite_rational_grid_moment_tendsto
      (Finset.range d) (fun k => ((p.coeff k : ℤ) : ℚ))
  have hfun :
      (fun m : ℕ => (sevenfoldGrid m).eval (intPolyReal p)) =
      (fun m : ℕ => ∑ k ∈ Finset.range d,
        ((((p.coeff k : ℤ) : ℚ) : ℝ)) *
          (rationalGridMoment m k : ℝ) ^ 7) := by
    funext m
    rw [sevenfoldGrid_poly_eval m d p hd]
    apply Finset.sum_congr rfl
    intro k hk
    simp only [Rat.cast_intCast, rationalGridMoment_cast]
  rw [hfun]
  have htarget :
      (∑ k ∈ Finset.range d,
        ((((p.coeff k : ℤ) : ℚ) : ℝ)) /
          (((k + 1 : ℕ) : ℝ) ^ 7)) =
      (finiteMoment p d : ℝ) := by
    simpa only [Rat.cast_intCast] using (finiteMoment_cast p d).symm
  rw [htarget] at h
  exact h

#print axioms positiveMean_add
#print axioms positiveMean_finsetSum
#print axioms gridProduct_scale
#print axioms sevenfoldGrid_scale
#print axioms intPolyReal_sum_range
#print axioms sevenfoldGrid_poly_eval
#print axioms sevenfoldGrid_poly_tendsto
end ChebyshevMastertier
end


/- Source module: EtaTsumGeneric.lean -/

/-!
# Generic eta/zeta even-odd decomposition
A theorem for ANY absolutely summable sequence with the precise odd-branch
scaling f(2n+1) = f(n)/128. No analytic zeta hypothesis is hidden here.
This is the main infinite-series structure needed for s = 7.
-/

noncomputable section
namespace ChebyshevMastertier

/-- Universal even/odd eta identity at seventh-power scaling. -/
theorem eta_tsum_of_odd_scaling (f : ℕ → ℂ)
    (hf : Summable f)
    (hodd : ∀ n : ℕ, f (2 * n + 1) = f n / 128) :
    (∑' n : ℕ, (f (2 * n) - f (2 * n + 1))) =
      (63 / 64 : ℂ) * (∑' n : ℕ, f n) := by
  have he : Summable (fun n : ℕ => f (2 * n)) :=
    hf.comp_injective (by
      intro i j hij
      omega)
  -- Spell out the odd-index embedding explicitly.  `omega` does not
  -- unfold the inferred function inside the comp_injective elaboration reliably.
  have hodd_injective : Function.Injective (fun n : ℕ => 2 * n + 1) := by
    intro i j hij
    change 2 * i + 1 = 2 * j + 1 at hij
    omega
  have ho : Summable (fun n : ℕ => f (2 * n + 1)) :=
    hf.comp_injective hodd_injective
  have hdecomp := tsum_even_add_odd he ho
  have hodd_sum :
      (∑' n : ℕ, f (2 * n + 1)) =
      (1 / 128 : ℂ) * (∑' n : ℕ, f n) := by
    calc
      (∑' n : ℕ, f (2 * n + 1)) =
          ∑' n : ℕ, (1 / 128 : ℂ) * f n := by
            congr 1
            funext n
            rw [hodd n]
            ring
      _ = (1 / 128 : ℂ) * (∑' n : ℕ, f n) := tsum_mul_left
  rw [he.tsum_sub ho]
  calc
    (∑' n : ℕ, f (2 * n)) - (∑' n : ℕ, f (2 * n + 1)) =
        ((∑' n : ℕ, f (2 * n)) + (∑' n : ℕ, f (2 * n + 1))) -
          2 * (∑' n : ℕ, f (2 * n + 1)) := by ring
    _ = (∑' n : ℕ, f n) - 2 * (∑' n : ℕ, f (2 * n + 1)) := by
          rw [hdecomp]
    _ = (63 / 64 : ℂ) * (∑' n : ℕ, f n) := by
          rw [hodd_sum]
          ring

#print axioms eta_tsum_of_odd_scaling

end ChebyshevMastertier
end


/- Source module: NativeZetaAnchor.lean -/

/-!
CHEBYSHEV-MASTERTIER / actual native Riemann zeta anchor.

Theorem one below uses Mathlib's existing zeta Dirichlet series result;
it is not an unrelated model function named zeta.
The second theorem records the shifted complex-power series, useful for
an eventual direct Dirichlet eta link.  No identification with the
Chebyshev rational limit is claimed here.
-/

noncomputable section
namespace ChebyshevMastertier

/-- Direct unconditional binding to Mathlib's actual Riemann zeta function. -/
theorem native_zeta7_dirichlet :
    riemannZeta (7 : ℂ) = ∑' n : ℕ, 1 / (n : ℂ) ^ 7 := by
  exact zeta_nat_eq_tsum_of_gt_one (by norm_num : 1 < (7 : ℕ))

/-- The shifted Dirichlet representation, with genuinely complex exponent. -/
theorem native_zeta7_shifted :
    riemannZeta (7 : ℂ) =
      ∑' n : ℕ, 1 / ((n : ℂ) + 1) ^ (7 : ℂ) := by
  apply zeta_eq_tsum_one_div_nat_add_one_cpow
  norm_num

#print axioms native_zeta7_dirichlet
#print axioms native_zeta7_shifted

end ChebyshevMastertier
end


/- Source module: NativeEtaSeven.lean -/

/-!
# Actual Mathlib zeta(7) from dyadic eta partial sums

No abstract zeta surrogate occurs in the final theorem: the endpoint is
`riemannZeta (7 : ℂ)` itself. This module uses only Mathlib's convergent
p-series and the previously proved generic even/odd lemma.

The eta-matrix coefficient readout is handled separately: this module proves
convergence of the explicit scalar eta sums, not yet their equality to
`finiteMoment (etaNumerator N) (2*N)`.
-/

noncomputable section
open Filter
namespace ChebyshevMastertier

/-- Seventh-power Dirichlet coefficient, with the index starting at zero. -/
def nativeTerm7 (n : ℕ) : ℂ :=
  1 / (((n + 1 : ℕ) : ℂ) ^ 7)

/-- The actual Dirichlet coefficients are absolutely summable. -/
theorem nativeTerm7_summable : Summable nativeTerm7 := by
  have hc : Summable (fun n : ℕ => (1 : ℂ) / (n : ℂ) ^ (7 : ℂ)) :=
    (Complex.summable_one_div_nat_cpow).2 (by norm_num)
  have hn : Summable (fun n : ℕ => (1 : ℂ) / (n : ℂ) ^ (7 : ℕ)) := by
    simpa only [Complex.cpow_ofNat] using hc
  have hsucc : Function.Injective (fun n : ℕ => n + 1) := by
    intro i j hij
    change i + 1 = j + 1 at hij
    omega
  exact hn.comp_injective hsucc

/-- Mathlib's real Riemann zeta function is not replaced by a new constant. -/
theorem native_zeta7_eq_term_tsum :
    riemannZeta (7 : ℂ) = ∑' n : ℕ, nativeTerm7 n := by
  calc
    riemannZeta (7 : ℂ) =
        ∑' n : ℕ, (1 : ℂ) / ((n : ℂ) + 1) ^ (7 : ℂ) :=
      native_zeta7_shifted
    _ = ∑' n : ℕ, nativeTerm7 n := by
      apply tsum_congr
      intro n
      simp [nativeTerm7, Complex.cpow_natCast, Nat.cast_add]

/-- Exact factor 128 on the odd-index branch. -/
theorem nativeTerm7_odd (n : ℕ) :
    nativeTerm7 (2 * n + 1) = nativeTerm7 n / 128 := by
  have hi : 2 * n + 1 + 1 = 2 * (n + 1) := by omega
  have hfactor :
      (((2 * n + 1 + 1 : ℕ) : ℂ) ^ 7) =
        (128 : ℂ) * (((n + 1 : ℕ) : ℂ) ^ 7) := by
    rw [hi]
    norm_num [Nat.cast_mul, mul_pow]
  unfold nativeTerm7
  rw [hfactor]
  simp only [div_eq_mul_inv, mul_inv_rev, one_mul] <;> ring

/-- Exact complex-valued eta partial sum, requiring only finite arithmetic. -/
def nativeEtaPartial (N : ℕ) : ℂ :=
  ∑ j ∈ Finset.range N,
    (nativeTerm7 (2 * j) - nativeTerm7 (2 * j + 1))

/-- The eta-Dirichlet scalar is exactly 63/64 times native zeta(7). -/
theorem native_eta7_eq_zeta7 :
    (∑' j : ℕ, (nativeTerm7 (2 * j) - nativeTerm7 (2 * j + 1))) =
      (63 / 64 : ℂ) * riemannZeta (7 : ℂ) := by
  calc
    (∑' j : ℕ, (nativeTerm7 (2 * j) - nativeTerm7 (2 * j + 1))) =
        (63 / 64 : ℂ) * (∑' n : ℕ, nativeTerm7 n) :=
      eta_tsum_of_odd_scaling nativeTerm7 nativeTerm7_summable nativeTerm7_odd
    _ = (63 / 64 : ℂ) * riemannZeta (7 : ℂ) := by
      rw [native_zeta7_eq_term_tsum]

/-- Ordinary rational eta partial sums converge to native complex zeta(7). -/
theorem native_eta7_partial_tendsto :
    Tendsto nativeEtaPartial atTop
      (nhds ((63 / 64 : ℂ) * riemannZeta (7 : ℂ))) := by
  have heinj : Function.Injective (fun j : ℕ => 2 * j) := by
    intro i j hij
    change 2 * i = 2 * j at hij
    omega
  have hoinj : Function.Injective (fun j : ℕ => 2 * j + 1) := by
    intro i j hij
    change 2 * i + 1 = 2 * j + 1 at hij
    omega
  have he : Summable (fun j : ℕ => nativeTerm7 (2 * j)) :=
    nativeTerm7_summable.comp_injective heinj
  have ho : Summable (fun j : ℕ => nativeTerm7 (2 * j + 1)) :=
    nativeTerm7_summable.comp_injective hoinj
  change Tendsto
    (fun N : ℕ => ∑ j ∈ Finset.range N,
      (nativeTerm7 (2 * j) - nativeTerm7 (2 * j + 1)))
    atTop (nhds ((63 / 64 : ℂ) * riemannZeta (7 : ℂ)))
  rw [← native_eta7_eq_zeta7]
  exact (he.sub ho).tendsto_sum_tsum_nat

/-- Dyadic rational eta limits: unconditional, actual Mathlib zeta(7). -/
theorem native_eta7_dyadic_tendsto :
    Tendsto (fun n : ℕ => (64 / 63 : ℂ) * nativeEtaPartial (2 ^ n))
      atTop (nhds (riemannZeta (7 : ℂ))) := by
  have hpow : Tendsto (fun n : ℕ => (2 : ℕ) ^ n) atTop atTop :=
    tendsto_pow_atTop_atTop_of_one_lt (by norm_num : 1 < (2 : ℕ))
  have hc : Tendsto (fun _ : ℕ => (64 / 63 : ℂ)) atTop
      (nhds (64 / 63 : ℂ)) := tendsto_const_nhds
  have h := hc.mul (native_eta7_partial_tendsto.comp hpow)
  have hscalar : (64 / 63 : ℂ) *
      ((63 / 64 : ℂ) * riemannZeta (7 : ℂ)) =
      riemannZeta (7 : ℂ) := by ring
  simpa only [Function.comp_def, hscalar] using h

#print axioms nativeTerm7_summable
#print axioms native_zeta7_eq_term_tsum
#print axioms nativeTerm7_odd
#print axioms native_eta7_eq_zeta7
#print axioms native_eta7_partial_tendsto
#print axioms native_eta7_dyadic_tendsto

end ChebyshevMastertier
end


/- Source module: EtaPolynomialLock.lean -/

/-!
# Exact eta matrix over the integer polynomial ring.

All matrix entries use the previously Lean-checked `stageMatrix` carrier,
so no polymorphic `!![...]` numeral is elaborated without its intended
`Polynomial ℤ` type. This module requires no convergence or zeta premise.
-/

noncomputable section
namespace ChebyshevMastertier

/-- The polynomial eigenvalue X² of the eta matrix. -/
def etaKernel : ZPoly := (Polynomial.X : ZPoly) ^ 2

/-- Exact integer numerator of the upper-right entry of etaMatrix^N. -/
def etaNumerator : ℕ → ZPoly
  | 0 => (0 : ZPoly)
  | N + 1 => ((1 : ZPoly) - (Polynomial.X : ZPoly)) +
      etaNumerator N * etaKernel

/-- Difference-of-powers identity at every eta truncation depth. -/
theorem eta_polynomial_lock (N : ℕ) :
    Xplus * etaNumerator N = (1 : ZPoly) - etaKernel ^ N := by
  induction N with
  | zero =>
      simp [etaNumerator]
  | succ N ih =>
      have hs : Xplus * ((1 : ZPoly) - Polynomial.X) =
          (1 : ZPoly) - etaKernel := by
        dsimp [Xplus, etaKernel]
        ring
      change Xplus * (((1 : ZPoly) - Polynomial.X) +
          etaNumerator N * etaKernel) = 1 - etaKernel ^ (N + 1)
      calc
        Xplus * (((1 : ZPoly) - Polynomial.X) + etaNumerator N * etaKernel) =
            Xplus * ((1 : ZPoly) - Polynomial.X) +
              (Xplus * etaNumerator N) * etaKernel := by ring
        _ = (1 - etaKernel) + (1 - etaKernel ^ N) * etaKernel := by
          rw [hs, ih]
        _ = 1 - etaKernel ^ (N + 1) := by
          rw [pow_succ]
          ring

/-- The fixed integer 2×2 eta matrix, defined using a typed Stage carrier. -/
def etaIntegerMatrix : Matrix (Fin 2) (Fin 2) ZPoly :=
  stageMatrix ⟨(1 : ZPoly), etaKernel,
    ((1 : ZPoly) - (Polynomial.X : ZPoly))⟩

/-- Explicit typed state for etaIntegerMatrix raised to N. -/
def etaPowerStage (N : ℕ) : Stage :=
  ⟨(1 : ZPoly), etaKernel ^ N, etaNumerator N⟩

/-- Exact, unconditionally valid eta matrix power theorem. -/
theorem eta_integer_matrix_power (N : ℕ) :
    etaIntegerMatrix ^ N = stageMatrix (etaPowerStage N) := by
  induction N with
  | zero =>
      apply Matrix.ext
      intro i j
      fin_cases i <;> fin_cases j <;>
        simp [etaPowerStage, etaNumerator, stageMatrix]
  | succ N ih =>
      calc
        etaIntegerMatrix ^ (N + 1) =
            etaIntegerMatrix ^ N * etaIntegerMatrix := pow_succ _ _
        _ = stageMatrix (etaPowerStage N) * etaIntegerMatrix := by
              rw [ih]
        _ = stageMatrix (etaPowerStage (N + 1)) := by
              apply Matrix.ext
              intro i j
              fin_cases i <;> fin_cases j <;>
                simp [etaIntegerMatrix, etaPowerStage, etaNumerator,
                  stageMatrix, Matrix.mul_apply, Fin.sum_univ_two,
                  pow_succ] <;> ring

/-- The upper-right matrix entry is exactly the arithmetic eta numerator. -/
theorem eta_integer_matrix_upper (N : ℕ) :
    (etaIntegerMatrix ^ N) 0 1 = etaNumerator N := by
  rw [eta_integer_matrix_power]
  simp [etaPowerStage, stageMatrix]

#print axioms eta_polynomial_lock
#print axioms eta_integer_matrix_power
#print axioms eta_integer_matrix_upper

end ChebyshevMastertier
end


/- Source module: EtaMomentExpansion.lean -/

/-!
# Eta numerator as an explicit integer alternating polynomial

This file turns the already certified eta polynomial lock into a closed,
finite integer polynomial. There is no infinite summation here.
-/

noncomputable section
namespace ChebyshevMastertier

/-- Append the last alternating monomial pair to the eta numerator. -/
theorem eta_numerator_succ_add (N : ℕ) :
    etaNumerator (N + 1) = etaNumerator N +
      ((1 : ZPoly) - Polynomial.X) * etaKernel ^ N := by
  have h := eta_polynomial_lock N
  change ((1 : ZPoly) + Polynomial.X) * etaNumerator N =
      1 - etaKernel ^ N at h
  change ((1 : ZPoly) - Polynomial.X) + etaNumerator N * etaKernel =
    etaNumerator N + ((1 : ZPoly) - Polynomial.X) * etaKernel ^ N
  dsimp [etaKernel] at h ⊢
  linear_combination - ((1 : ZPoly) - Polynomial.X) * h

/-- The integer matrix entry is the alternating polynomial through degree 2N-1. -/
theorem eta_numerator_explicit (N : ℕ) :
    etaNumerator N =
      ∑ j ∈ Finset.range N,
        ((Polynomial.X : ZPoly) ^ (2 * j) - Polynomial.X ^ (2 * j + 1)) := by
  induction N with
  | zero => simp [etaNumerator]
  | succ N ih =>
      rw [eta_numerator_succ_add, ih, Finset.sum_range_succ]
      dsimp [etaKernel]
      rw [pow_mul, pow_succ]
      ring

/-- Explicit alternating coefficient polynomial is literally the matrix entry. -/
theorem eta_integer_matrix_explicit (N : ℕ) :
    (etaIntegerMatrix ^ N) 0 1 =
      ∑ j ∈ Finset.range N,
        ((Polynomial.X : ZPoly) ^ (2 * j) - Polynomial.X ^ (2 * j + 1)) := by
  rw [eta_integer_matrix_upper, eta_numerator_explicit]

#print axioms eta_numerator_succ_add
#print axioms eta_numerator_explicit
#print axioms eta_integer_matrix_explicit

end ChebyshevMastertier
end


/- Source module: EtaMomentReadout.lean -/

/-!
# Exact rational evaluation of the eta integer-matrix entry

The fixed sevenfold arithmetic moment from Core evaluates the alternating
integer matrix polynomial to the corresponding alternating rational sum.
-/

noncomputable section
namespace ChebyshevMastertier

/-- Finite moment is additive in its integer-polynomial argument. -/
theorem finiteMoment_add (p q : ZPoly) (d : ℕ) :
    finiteMoment (p + q) d = finiteMoment p d + finiteMoment q d := by
  simp only [finiteMoment, Polynomial.coeff_add, Int.cast_add, add_div,
    Finset.sum_add_distrib]

/-- Finite moment is additive over a finite family of polynomials. -/
theorem finiteMoment_finset_sum (s : Finset ℕ) (p : ℕ → ZPoly) (d : ℕ) :
    finiteMoment (∑ j ∈ s, p j) d = ∑ j ∈ s, finiteMoment (p j) d := by
  induction s using Finset.induction_on with
  | empty => simp [finiteMoment]
  | @insert a s ha ih =>
      simp only [Finset.sum_insert ha]
      rw [finiteMoment_add, ih]

/-- Finite moment of the monomial X^e, when included in the degree cutoff. -/
theorem finiteMoment_X_pow (e d : ℕ) (he : e < d) :
    finiteMoment ((Polynomial.X : ZPoly) ^ e) d =
      1 / (((e + 1 : ℕ) : ℚ) ^ 7) := by
  classical
  unfold finiteMoment
  rw [Finset.sum_eq_single e]
  · simp [Polynomial.coeff_X_pow]
  · intro b hb hbe
    simp [Polynomial.coeff_X_pow, hbe, Ne.symm hbe]
  · intro hnot
    exact (hnot (Finset.mem_range.mpr he)).elim

/-- Finite moment is additive under subtraction as well. -/
theorem finiteMoment_sub (p q : ZPoly) (d : ℕ) :
    finiteMoment (p - q) d = finiteMoment p d - finiteMoment q d := by
  simp only [finiteMoment, Polynomial.coeff_sub, Int.cast_sub, sub_div,
    Finset.sum_sub_distrib]

/-- A literal, all-depth rational identity; no limit, zeta, or complex number. -/
theorem eta_integer_moment_eq_partial (N : ℕ) :
    finiteMoment (etaNumerator N) (2 * N) =
      ∑ j ∈ Finset.range N,
        ((1 : ℚ) / (((2 * j + 1 : ℕ) : ℚ) ^ 7) -
         (1 : ℚ) / (((2 * j + 2 : ℕ) : ℚ) ^ 7)) := by
  rw [eta_numerator_explicit, finiteMoment_finset_sum]
  apply Finset.sum_congr rfl
  intro j hj
  have hjlt : j < N := Finset.mem_range.mp hj
  have he : 2 * j < 2 * N := by omega
  have ho : 2 * j + 1 < 2 * N := by omega
  rw [finiteMoment_sub,
    finiteMoment_X_pow (2 * j) (2 * N) he,
    finiteMoment_X_pow (2 * j + 1) (2 * N) ho]

/-- Rational scalar readout of the actual Nth power of the eta matrix. -/
def etaMatrixReadout (N : ℕ) : ℚ :=
  (64 / 63 : ℚ) * finiteMoment ((etaIntegerMatrix ^ N) 0 1) (2 * N)

/-- Algebraically, the matrix readout equals exactly the alternating rational sum. -/
theorem etaMatrixReadout_eq_partial (N : ℕ) :
    etaMatrixReadout N = (64 / 63 : ℚ) *
      ∑ j ∈ Finset.range N,
        ((1 : ℚ) / (((2 * j + 1 : ℕ) : ℚ) ^ 7) -
         (1 : ℚ) / (((2 * j + 2 : ℕ) : ℚ) ^ 7)) := by
  simp only [etaMatrixReadout, eta_integer_matrix_upper, eta_integer_moment_eq_partial]

#print axioms finiteMoment_X_pow
#print axioms eta_integer_moment_eq_partial
#print axioms etaMatrixReadout_eq_partial

end ChebyshevMastertier
end


/- Source module: NativeEtaMatrixEndpoint.lean -/

/-!
# Unconditional native zeta(7) endpoint of one fixed integer polynomial 2x2 matrix

Unlike a mere formal eta value, the target is Mathlib's `riemannZeta (7 : ℂ)`.
At every finite stage the readout is rational, extracted from the exact
power of the same integer polynomial matrix. The limit is proved by
identifying it with the independently audited native eta partial sums.
-/

noncomputable section
open Filter
namespace ChebyshevMastertier

/-- A rational reciprocal seventh power is the native complex coefficient. -/
theorem rat_seventh_cast_nativeTerm (k : ℕ) :
    (((1 : ℚ) / (((k + 1 : ℕ) : ℚ) ^ 7)) : ℂ) = nativeTerm7 k := by
  simp [nativeTerm7, Rat.cast_div, Rat.cast_pow, Rat.cast_natCast]

/-- The exact integer polynomial matrix readout is equal to native eta partials. -/
theorem etaMatrixReadout_cast (N : ℕ) :
    (etaMatrixReadout N : ℂ) =
      (64 / 63 : ℂ) * nativeEtaPartial N := by
  -- The rational sum is deliberately named before the cast theorem.
  -- Expanding the local let *inside the goal* is essential: a proof about
  -- the complex-valued expanded sum is not definitionally the same as a
  -- proof about the cast of the rational finite sum without normalization.
  let S : ℚ := ∑ j ∈ Finset.range N,
    ((1 : ℚ) / (((2 * j + 1 : ℕ) : ℚ) ^ 7) -
     (1 : ℚ) / (((2 * j + 2 : ℕ) : ℚ) ^ 7))
  have hS : (S : ℂ) = nativeEtaPartial N := by
    -- The two denominators have the forms k+1 for k=2*j and k=2*j+1.
    -- Transport each term independently before applying the finite-sum rule.
    dsimp [S, nativeEtaPartial]
    simp only [Rat.cast_sum, Rat.cast_sub]
    apply Finset.sum_congr rfl
    intro j hj
    have hodd :
        (((1 : ℚ) / (((2 * j + 1 : ℕ) : ℚ) ^ 7)) : ℂ) =
          nativeTerm7 (2 * j) :=
      rat_seventh_cast_nativeTerm (2 * j)
    have hindex : (2 * j + 1 + 1 : ℕ) = 2 * j + 2 := by omega
    have heven :
        (((1 : ℚ) / (((2 * j + 2 : ℕ) : ℚ) ^ 7)) : ℂ) =
          nativeTerm7 (2 * j + 1) := by
      rw [← hindex]
      exact rat_seventh_cast_nativeTerm (2 * j + 1)
    -- The goal still contains the cast of a rational quotient, while hodd and
    -- heven use the quotient of the casts. Normalize both presentations.
    simpa only [Rat.cast_div, Rat.cast_pow, Rat.cast_natCast] using
      (congrArg₂ (fun a b : ℂ => a - b) hodd heven)
  have hR : etaMatrixReadout N = (64 / 63 : ℚ) * S :=
    etaMatrixReadout_eq_partial N
  calc
    (etaMatrixReadout N : ℂ) =
        (((64 / 63 : ℚ) * S : ℚ) : ℂ) :=
      congrArg (fun z : ℚ => (z : ℂ)) hR
    _ = (64 / 63 : ℂ) * (S : ℂ) := by
      simp only [Rat.cast_mul, Rat.cast_div, Rat.cast_ofNat]
    _ = (64 / 63 : ℂ) * nativeEtaPartial N :=
      congrArg (fun z : ℂ => (64 / 63 : ℂ) * z) hS

/-- Native Mathlib zeta(7) is exactly the dyadic limit of one fixed integer matrix. -/
theorem eta_matrix_zeta7_endpoint :
    Tendsto (fun n : ℕ => (etaMatrixReadout (2 ^ n) : ℂ))
      atTop (nhds (riemannZeta (7 : ℂ))) := by
  have hfun :
      (fun n : ℕ => (etaMatrixReadout (2 ^ n) : ℂ)) =
      (fun n : ℕ => (64 / 63 : ℂ) * nativeEtaPartial (2 ^ n)) := by
    funext n
    exact etaMatrixReadout_cast (2 ^ n)
  rw [hfun]
  exact native_eta7_dyadic_tendsto

#print axioms rat_seventh_cast_nativeTerm
#print axioms etaMatrixReadout_cast
#print axioms eta_matrix_zeta7_endpoint

end ChebyshevMastertier
end
