import Mathlib.NumberTheory.LSeries.RiemannZeta
import Mathlib.Analysis.PSeries
import Mathlib.Analysis.Complex.Basic
import Mathlib.Tactic

/-! The target is Mathlib's actual Riemann zeta function at seven. -/
noncomputable section
namespace Zeta7Chain

def zeta7 : ℝ := (riemannZeta (7 : ℂ)).re

def term7 (n : ℕ) : ℝ := 1 / (((n + 1 : ℕ) : ℝ) ^ 7)

theorem native_zeta7_dirichlet :
    riemannZeta (7 : ℂ) = ∑' n : ℕ, 1 / (n : ℂ) ^ 7 := by
  exact zeta_nat_eq_tsum_of_gt_one (by norm_num : 1 < (7 : ℕ))

theorem native_zeta7_shifted :
    riemannZeta (7 : ℂ) =
      ∑' n : ℕ, 1 / ((n : ℂ) + 1) ^ (7 : ℂ) := by
  apply zeta_eq_tsum_one_div_nat_add_one_cpow
  norm_num

theorem zeta7_eq_tsum : zeta7 = ∑' n : ℕ, term7 n := by
  have hcast : riemannZeta (7 : ℂ) = ((∑' n : ℕ, term7 n : ℝ) : ℂ) := by
    rw [native_zeta7_shifted, Complex.ofReal_tsum]
    apply tsum_congr
    intro n
    simp [term7, Nat.cast_add]
  have h := congrArg Complex.re hcast
  simpa [zeta7] using h

theorem term7_pos (n : ℕ) : 0 < term7 n := by
  unfold term7
  positivity

end Zeta7Chain
