import Zeta7Chain.Witness
import Zeta7Chain.NativeZeta
import Mathlib.Tactic

/-! Finite conclusions from a precisely specified rational window.
The actual zeta instance is supplied separately by the Euler bound. -/
namespace Zeta7Chain

def windowLower : ℚ :=
  1008349277381922826839797549849796 / 1000000000000000000000000000000000
def windowUpper : ℚ :=
  1008349277381922826839797549849797 / 1000000000000000000000000000000000

def InCertifiedWindow (ξ : ℝ) : Prop :=
  (windowLower : ℝ) ≤ ξ ∧ ξ ≤ (windowUpper : ℝ)

theorem window_ordered : windowLower < windowUpper := by
  norm_num [windowLower, windowUpper]

theorem strong_bounds_of_window {ξ : ℝ} (h : InCertifiedWindow ξ) :
    0 < (strongQ : ℝ) * ξ - strongP ∧
      (strongQ : ℝ) * ξ - strongP < 1 / 20000000000000000 := by
  have hq : (0 : ℝ) < strongQ := by norm_num [strongQ]
  have hlo : (0 : ℝ) < (strongQ : ℝ) * (windowLower : ℝ) - strongP := by
    norm_num [strongQ, strongP, windowLower]
  have hhi : (strongQ : ℝ) * (windowUpper : ℝ) - strongP <
      (1 : ℝ) / 20000000000000000 := by
    norm_num [strongQ, strongP, windowUpper]
  constructor
  · exact lt_of_lt_of_le hlo (sub_le_sub_right (mul_le_mul_of_nonneg_left h.1 hq.le) _)
  · exact lt_of_le_of_lt (sub_le_sub_right (mul_le_mul_of_nonneg_left h.2 hq.le) _) hhi

theorem strong_billionfold_of_window {ξ : ℝ} (h : InCertifiedWindow ξ) :
    (strongQ : ℝ) * ξ - strongP <
      (1616068 * ξ - 1629561) / 1000000000 := by
  have hq : (0 : ℝ) ≤ strongQ := by norm_num [strongQ]
  have hl : (strongQ : ℝ) * ξ - strongP ≤
      (strongQ : ℝ) * (windowUpper : ℝ) - strongP :=
    sub_le_sub_right (mul_le_mul_of_nonneg_left h.2 hq) _
  have hr : (1616068 : ℝ) * (windowLower : ℝ) - 1629561 ≤
      1616068 * ξ - 1629561 := by nlinarith [h.1]
  have hc : (strongQ : ℝ) * (windowUpper : ℝ) - strongP <
      (1616068 * (windowLower : ℝ) - 1629561) / 1000000000 := by
    norm_num [strongQ, strongP, windowLower, windowUpper]
  linarith

theorem seed_positive_of_window {ξ : ℝ} (h : InCertifiedWindow ξ) :
    0 < 120 * ξ - 121 := by
  have ht : (0 : ℝ) < 120 * (windowLower : ℝ) - 121 := by
    norm_num [windowLower]
  nlinarith [h.1]

theorem denominator_exclusion_of_window {ξ : ℝ} (h : InCertifiedWindow ξ)
    (a b : ℤ) (hb : 0 < b) (heq : ξ = (a : ℝ) / b) :
    20000000000000000 < b := by
  obtain ⟨hepos, hesmall⟩ := strong_bounds_of_window h
  have hbr : (0 : ℝ) < b := by exact_mod_cast hb
  have hprod : ((strongQ * a - strongP * b : ℤ) : ℝ) =
      ((strongQ : ℝ) * ξ - strongP) * b := by
    rw [heq]
    push_cast
    field_simp
  have hip : 0 < strongQ * a - strongP * b := by
    have hp : (0 : ℝ) < ((strongQ * a - strongP * b : ℤ) : ℝ) := by
      rw [hprod]
      exact mul_pos hepos hbr
    exact_mod_cast hp
  have hione : 1 ≤ strongQ * a - strongP * b := by omega
  have hreal : (1 : ℝ) ≤ ((strongQ * a - strongP * b : ℤ) : ℝ) := by
    exact_mod_cast hione
  rw [hprod] at hreal
  have hmul := mul_lt_mul_of_pos_right hesmall hbr
  have hresult : (20000000000000000 : ℝ) < b := by nlinarith
  exact_mod_cast hresult

end Zeta7Chain
