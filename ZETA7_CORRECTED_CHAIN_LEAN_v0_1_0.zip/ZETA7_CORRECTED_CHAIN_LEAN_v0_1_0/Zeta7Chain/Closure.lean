import Mathlib.NumberTheory.Real.Irrational
import Mathlib.Algebra.Order.Archimedean.Basic
import Mathlib.Tactic

/-!
# The generic irrationality endpoint

All hypotheses in this file concern **integer** linear forms.  In particular, a
small unnormalised rational expression cannot be supplied in place of a small
integer form.  These theorems do not assert that a suitable sequence exists for
any particular real number.
-/

namespace Zeta7Chain

/-- Positive integer linear forms can be made arbitrarily small. -/
def HasArbitrarilySmallPositiveForms (ξ : ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε →
    ∃ p q : ℤ, 0 < (q : ℝ) * ξ - p ∧ (q : ℝ) * ξ - p < ε

/-- A rational real number has a fixed positive lower bound for every positive
integer linear form.  Consequently arbitrarily small such forms certify
irrationality. -/
theorem irrational_of_arbitrarily_small_positive_forms {ξ : ℝ}
    (h : HasArbitrarilySmallPositiveForms ξ) : Irrational ξ := by
  by_contra hrat
  obtain ⟨r, rfl⟩ := exists_rat_of_not_irrational hrat
  have hd : (0 : ℝ) < r.den := by exact_mod_cast r.den_pos
  obtain ⟨p, q, hpos, hsmall⟩ := h (1 / (r.den : ℝ)) (by positivity)
  have hmul : ((q * r.num - p * (r.den : ℤ) : ℤ) : ℝ) =
      ((q : ℝ) * (r : ℝ) - p) * r.den := by
    push_cast
    rw [Rat.cast_def]
    field_simp
  have hintpos : 0 < q * r.num - p * (r.den : ℤ) := by
    have hreal : (0 : ℝ) < ((q * r.num - p * (r.den : ℤ) : ℤ) : ℝ) := by
      rw [hmul]
      exact mul_pos hpos hd
    exact_mod_cast hreal
  have hintone : 1 ≤ q * r.num - p * (r.den : ℤ) := by omega
  have hone : (1 : ℝ) ≤ ((q * r.num - p * (r.den : ℤ) : ℤ) : ℝ) := by
    exact_mod_cast hintone
  have hlt : ((q : ℝ) * (r : ℝ) - p) * r.den < 1 := by
    calc
      _ < (1 / (r.den : ℝ)) * r.den := mul_lt_mul_of_pos_right hsmall hd
      _ = 1 := by field_simp
  rw [hmul] at hone
  linarith

/-- A dyadic supply of positive integer forms is enough.  The pairs may depend
on `n`; no recurrence is assumed in this criterion. -/
theorem irrational_of_dyadic_positive_forms {ξ : ℝ}
    (h : ∀ n : ℕ, ∃ p q : ℤ,
      0 < (q : ℝ) * ξ - p ∧ (q : ℝ) * ξ - p < (1 / 2 : ℝ) ^ n) :
    Irrational ξ := by
  apply irrational_of_arbitrarily_small_positive_forms
  intro ε hε
  obtain ⟨n, hn⟩ := exists_pow_lt_of_lt_one hε (show (1 / 2 : ℝ) < 1 by norm_num)
  obtain ⟨p, q, hp, hq⟩ := h n
  exact ⟨p, q, hp, hq.trans hn⟩

/-- Halving bounds imply their explicit geometric bound. -/
theorem le_geometric_of_halving (e : ℕ → ℝ)
    (hhalf : ∀ n, e (n + 1) ≤ e n / 2) (n : ℕ) :
    e n ≤ e 0 * (1 / 2 : ℝ) ^ n := by
  induction n with
  | zero => simp
  | succ n ih =>
    calc
      e (n + 1) ≤ e n / 2 := hhalf n
      _ ≤ (e 0 * (1 / 2 : ℝ) ^ n) / 2 := div_le_div_of_nonneg_right ih (by norm_num)
      _ = e 0 * (1 / 2 : ℝ) ^ (n + 1) := by rw [pow_succ]; ring

/-- An actual infinite orbit of positive integer forms with a factor-two
decrease supplies the irrationality endpoint.  No initial numerical bound is
needed. -/
theorem irrational_of_halving_orbit {ξ : ℝ} (p q : ℕ → ℤ)
    (hpos : ∀ n, 0 < (q n : ℝ) * ξ - p n)
    (hhalf : ∀ n, (q (n + 1) : ℝ) * ξ - p (n + 1) ≤
      ((q n : ℝ) * ξ - p n) / 2) : Irrational ξ := by
  apply irrational_of_arbitrarily_small_positive_forms
  intro ε hε
  let e : ℕ → ℝ := fun n => (q n : ℝ) * ξ - p n
  have he0 : 0 < e 0 := hpos 0
  obtain ⟨n, hn⟩ := exists_pow_lt_of_lt_one (div_pos hε he0)
    (show (1 / 2 : ℝ) < 1 by norm_num)
  have hgeom := le_geometric_of_halving e hhalf n
  have hbound : e 0 * (1 / 2 : ℝ) ^ n < ε := by
    calc
      _ < e 0 * (ε / e 0) := mul_lt_mul_of_pos_left hn he0
      _ = ε := by field_simp
  exact ⟨p n, q n, hpos n, hgeom.trans_lt hbound⟩

/-- The orbit of a concrete successor. -/
def successorOrbit {S : Type*} (next : S → S) (seed : S) : ℕ → S
  | 0 => seed
  | n + 1 => next (successorOrbit next seed n)

/-- A proposed successor must preserve its invariant and contract the actual
integer form on every state covered by that invariant.  These are explicit
premises, rather than an assertion that such a successor has been constructed. -/
theorem irrational_of_halving_successor {S : Type*} {ξ : ℝ}
    (p q : S → ℤ) (next : S → S) (seed : S) (Good : S → Prop)
    (hseed : Good seed)
    (hpreserve : ∀ s, Good s → Good (next s))
    (hpos : ∀ s, Good s → 0 < (q s : ℝ) * ξ - p s)
    (hhalf : ∀ s, Good s →
      (q (next s) : ℝ) * ξ - p (next s) ≤ ((q s : ℝ) * ξ - p s) / 2) :
    Irrational ξ := by
  have hgood : ∀ n, Good (successorOrbit next seed n) := by
    intro n
    induction n with
    | zero => exact hseed
    | succ n ih => exact hpreserve _ ih
  apply irrational_of_halving_orbit
    (fun n => p (successorOrbit next seed n))
    (fun n => q (successorOrbit next seed n))
  · intro n
    exact hpos _ (hgood n)
  · intro n
    exact hhalf _ (hgood n)

end Zeta7Chain
