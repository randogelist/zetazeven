import Zeta7Chain.EulerPolynomial

noncomputable section
open Filter
open ChebyshevMastertier
namespace Zeta7Chain

theorem eta_top_coeff_zero (n : ℕ) : (etaNumerator n).coeff (2*n) = 0 := by
  rw [eta_numerator_explicit, Polynomial.finsetSum_coeff]
  apply Finset.sum_eq_zero
  intro j hj
  have hjn := Finset.mem_range.mp hj
  have h1 : 2 * j ≠ 2 * n := by omega
  have h2 : 2 * j + 1 ≠ 2 * n := by omega
  simp [Polynomial.coeff_sub, Polynomial.coeff_X_pow, Ne.symm h1, Ne.symm h2]

theorem eta_moment_extended (n : ℕ) :
    finiteMoment (etaNumerator n) (2*n+1) = finiteMoment (etaNumerator n) (2*n) := by
  simp only [finiteMoment, Finset.sum_range_succ, eta_top_coeff_zero,
    Int.cast_zero, zero_div, add_zero]

theorem eta_moment_native (n : ℕ) :
    (finiteMoment (etaNumerator n) (2*n) : ℝ) = (nativeEtaPartial n).re := by
  have h := etaMatrixReadout_cast n
  rw [etaMatrixReadout, eta_integer_matrix_upper] at h
  simp only [Rat.cast_mul, Rat.cast_div, Rat.cast_ofNat] at h
  have hc : ((finiteMoment (etaNumerator n) (2*n) : ℚ) : ℂ) = nativeEtaPartial n :=
    mul_left_cancel₀ (by norm_num : (64 / 63 : ℂ) ≠ 0) h
  have hr := congrArg Complex.re hc
  simpa using hr

theorem eta_grid_tendsto (n : ℕ) :
    Tendsto (fun m : ℕ => (sevenfoldGrid m).eval (etaScalarEntry n))
      atTop (nhds (nativeEtaPartial n).re) := by
  have hd : (etaNumerator n).natDegree < 2*n+1 :=
    Nat.lt_succ_of_le (eta_natDegree_le n)
  have h := sevenfoldGrid_poly_tendsto (etaNumerator n) (2*n+1) hd
  have hf : (fun m : ℕ => (sevenfoldGrid m).eval (etaScalarEntry n)) =
      (fun m : ℕ => (sevenfoldGrid m).eval (intPolyReal (etaNumerator n))) := by
    funext m
    exact interval_mean_congr (sevenfoldGrid m) _ _
      (fun x hx _ => eta_scalar_poly n x hx)
  rw [hf]
  simpa only [eta_moment_extended, eta_moment_native] using h

theorem euler_eta_grid_comparison (n N m : ℕ) :
    (sevenfoldGrid m).eval (etaScalarEntry N) ≤
      (sevenfoldGrid m).eval (eulerScalar n) + 1 / (2 : ℝ)^n ∧
    (sevenfoldGrid m).eval (eulerScalar n) ≤
      (sevenfoldGrid m).eval (etaScalarEntry N) + gridMoment m (2*N)^7 := by
  constructor
  · have h := (sevenfoldGrid m).mono (etaScalarEntry N)
        (fun x => eulerScalar n x + 1/(2 : ℝ)^n) (by
      intro x hx0 hx1
      have he := euler_scalar_interval n x hx0 hx1
      have ha := eta_scalar_residual_interval N x hx0 hx1
      linarith)
    simpa only [positiveMean_add, PositiveIntervalMean.map_const] using h
  · have h := (sevenfoldGrid m).mono (eulerScalar n)
        (fun x => etaScalarEntry N x + x^(2*N)) (by
      intro x hx0 hx1
      have he := euler_scalar_interval n x hx0 hx1
      have ha := eta_scalar_residual_interval N x hx0 hx1
      linarith)
    simpa only [positiveMean_add, sevenfoldGrid_monomial] using h

theorem euler_eta_comparison (n N : ℕ) :
    (nativeEtaPartial N).re ≤ (eulerApprox n : ℝ) + 1/(2 : ℝ)^n ∧
    (eulerApprox n : ℝ) ≤ (nativeEtaPartial N).re +
      (1 / (((2*N+1 : ℕ) : ℝ)))^7 := by
  constructor
  · exact le_of_tendsto_of_tendsto (eta_grid_tendsto N)
      ((euler_grid_tendsto n).add_const _) (Filter.Eventually.of_forall
        (fun m => (euler_eta_grid_comparison n N m).1))
  · exact le_of_tendsto_of_tendsto (euler_grid_tendsto n)
      ((eta_grid_tendsto N).add ((gridMoment_tendsto (2*N)).pow 7))
      (Filter.Eventually.of_forall (fun m => (euler_eta_grid_comparison n N m).2))

theorem eta_real_tendsto :
    Tendsto (fun N : ℕ => (nativeEtaPartial N).re) atTop
      (nhds ((63/64 : ℝ) * (riemannZeta (7 : ℂ)).re)) := by
  have h := Complex.continuous_re.continuousAt.tendsto.comp native_eta7_partial_tendsto
  simpa [Function.comp_def, Complex.mul_re] using h

theorem eta_remainder_bound_tendsto :
    Tendsto (fun N : ℕ => (1 / (((2*N+1 : ℕ) : ℝ)))^7) atTop (nhds 0) := by
  have hi : Tendsto (fun N : ℕ => 2*N) atTop atTop := by
    apply tendsto_atTop.2
    intro b
    filter_upwards [eventually_ge_atTop b] with a ha
    omega
  have h := ((tendsto_one_div_add_atTop_nhds_zero_nat (𝕜 := ℝ)).comp hi).pow 7
  simpa only [Function.comp_def, Nat.cast_add, Nat.cast_one, zero_pow (by decide : (7 : ℕ) ≠ 0)] using h

/-- Unconditional certified Euler interval for Mathlib's actual zeta(7). -/
theorem native_zeta7_euler_interval (n : ℕ) :
    (64/63 : ℝ) * (eulerApprox n : ℝ) ≤ (riemannZeta (7 : ℂ)).re ∧
    (riemannZeta (7 : ℂ)).re ≤
      (64/63 : ℝ) * ((eulerApprox n : ℝ) + 1/(2 : ℝ)^n) := by
  have hup : (63/64 : ℝ) * (riemannZeta (7 : ℂ)).re ≤
      (eulerApprox n : ℝ) + 1/(2 : ℝ)^n :=
    le_of_tendsto eta_real_tendsto (Filter.Eventually.of_forall
      (fun N => (euler_eta_comparison n N).1))
  have hlo : (eulerApprox n : ℝ) ≤ (63/64 : ℝ) * (riemannZeta (7 : ℂ)).re := by
    have h := ge_of_tendsto (eta_real_tendsto.add eta_remainder_bound_tendsto)
      (Filter.Eventually.of_forall (fun N => (euler_eta_comparison n N).2))
    simpa only [add_zero] using h
  constructor <;> linarith

end Zeta7Chain
