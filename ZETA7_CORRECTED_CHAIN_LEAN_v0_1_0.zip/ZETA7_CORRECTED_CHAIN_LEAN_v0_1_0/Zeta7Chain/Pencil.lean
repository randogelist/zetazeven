import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Matrix.Spectrum
import Mathlib.Algebra.Order.Star.Real
import Mathlib.LinearAlgebra.Matrix.Notation
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Tactic.Abel
import Mathlib.Tactic.Ext
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# The algebraic core of the zeta(7) moment pencil

This file proves finite-dimensional identities over a commutative ring and
defines the rational harmonic-moment matrix in every degree.  It does not
identify these rational entries with an improper integral, and it makes no
irrationality or infinite-descent claim.
-/

namespace Zeta7Chain

open Matrix
open scoped BigOperators

section Algebra

variable {α m n : Type*} [CommRing α]
variable [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]

/-- The coefficient Gram matrix of the rows of `C`. -/
def coefficientGram (C : Matrix m n α) : Matrix m m α := C * Cᵀ

/-- A monic symmetric pencil when `R` is symmetric. -/
def affinePencil (R : Matrix n n α) (X : α) : Matrix n n α := X • 1 - R

/-- Restrict a pencil to the row span of the coefficient matrix. -/
def compressedPencil (C : Matrix m n α) (R : Matrix n n α) (X : α) :
    Matrix m m α := C * affinePencil R X * Cᵀ

/-- The exact coefficient-Gram identity: the slope is independent of `R`. -/
theorem coefficientGram_identity (C : Matrix m n α) (R : Matrix n n α) (X : α) :
    compressedPencil C R X = X • coefficientGram C - C * R * Cᵀ := by
  simp only [compressedPencil, affinePencil, coefficientGram, Matrix.mul_sub,
    Matrix.sub_mul, Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_one]

/-- A derivative-free version of the constant-slope identity. -/
theorem compressedPencil_sub (C : Matrix m n α) (R : Matrix n n α) (X Y : α) :
    compressedPencil C R X - compressedPencil C R Y =
      (X - Y) • coefficientGram C := by
  rw [coefficientGram_identity, coefficientGram_identity, sub_smul]
  abel

theorem coefficientGram_isSymm (C : Matrix m n α) : (coefficientGram C).IsSymm := by
  unfold coefficientGram
  apply Matrix.IsSymm.ext
  intro i j
  simp only [Matrix.mul_apply, Matrix.transpose_apply]
  apply Finset.sum_congr rfl
  intro k _
  ring

theorem affinePencil_isSymm (R : Matrix n n α) (hR : R.IsSymm) (X : α) :
    (affinePencil R X).IsSymm := by
  exact (Matrix.isSymm_one.smul X).sub hR

theorem compressedPencil_isSymm (C : Matrix m n α) (R : Matrix n n α)
    (hR : R.IsSymm) (X : α) : (compressedPencil C R X).IsSymm := by
  change (C * affinePencil R X * Cᵀ)ᵀ = C * affinePencil R X * Cᵀ
  rw [Matrix.transpose_mul, Matrix.transpose_mul, Matrix.transpose_transpose,
    (affinePencil_isSymm R hR X).eq]
  simp only [Matrix.mul_assoc]

theorem compressedPencil_basis_change (U : Matrix m m α) (C : Matrix m n α)
    (R : Matrix n n α) (X : α) :
    compressedPencil (U * C) R X = U * compressedPencil C R X * Uᵀ := by
  simp only [compressedPencil, Matrix.transpose_mul]
  simp only [Matrix.mul_assoc]

/-- A row-basis change multiplies the determinant by the square of its determinant.
No invertibility hypothesis is needed for the identity itself. -/
theorem determinant_basis_change (U : Matrix m m α) (C : Matrix m n α)
    (R : Matrix n n α) (X : α) :
    (compressedPencil (U * C) R X).det =
      U.det ^ 2 * (compressedPencil C R X).det := by
  rw [compressedPencil_basis_change, Matrix.det_mul, Matrix.det_mul,
    Matrix.det_transpose]
  ring

/-- An invertible row-basis change preserves every determinant zero. -/
theorem determinant_basis_change_zero_iff [NoZeroDivisors α]
    (U : Matrix m m α) (C : Matrix m n α) (R : Matrix n n α) (X : α)
    (hU : U.det ≠ 0) :
    (compressedPencil (U * C) R X).det = 0 ↔ (compressedPencil C R X).det = 0 := by
  rw [determinant_basis_change, mul_eq_zero]
  simp [hU]

end Algebra

section RealSlope

variable {m n : Type*} [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]

/-- Every entry of the derivative is the corresponding coefficient-Gram entry. -/
theorem compressedPencil_entry_hasDerivAt (C : Matrix m n ℝ) (R : Matrix n n ℝ)
    (X : ℝ) (i j : m) :
    HasDerivAt (fun Y => compressedPencil C R Y i j) (coefficientGram C i j) X := by
  simp only [coefficientGram_identity, Matrix.sub_apply, Matrix.smul_apply, smul_eq_mul]
  exact (hasDerivAt_mul_const (coefficientGram C i j)).sub_const ((C * R * Cᵀ) i j)

theorem coefficientGram_posSemidef (C : Matrix m n ℝ) :
    (coefficientGram C).PosSemidef := by
  simpa only [coefficientGram, Matrix.conjTranspose_eq_transpose_of_trivial] using
    Matrix.posSemidef_self_mul_conjTranspose C

/-- Row independence is precisely the hypothesis needed here; it is not inferred
from positivity of a different moment matrix. -/
theorem coefficientGram_posDef (C : Matrix m n ℝ)
    (hC : Function.Injective C.vecMul) : (coefficientGram C).PosDef := by
  simpa only [coefficientGram, Matrix.conjTranspose_eq_transpose_of_trivial] using
    Matrix.PosDef.mul_conjTranspose_self C hC

/-- The real characteristic polynomial of a symmetric matrix splits over `ℝ`.
This is the monic-pencil real-rootedness statement supplied by the spectral theorem. -/
theorem symmetric_charpoly_splits (R : Matrix n n ℝ) (hR : R.IsSymm) :
    R.charpoly.Splits :=
  (Matrix.isHermitian_iff_isSymm.mpr hR).splits_charpoly

end RealSlope

section RationalMoments

/-- The finite generalized harmonic sum `sum_{k=1}^r k^(-s)`, over the rationals. -/
def harmonicRational (s r : ℕ) : ℚ := ∑ k ∈ Finset.range r, (1 : ℚ) / (k + 1) ^ s

/-- The rational matrix `R_K` in the zeta(7) pencil `X I - R_K`.
Its off-diagonal sign is the negative of the moment divided difference. -/
def momentShift (K : ℕ) : Matrix (Fin (K + 1)) (Fin (K + 1)) ℚ := fun i j =>
  if i = j then harmonicRational 7 i.val
  else -((harmonicRational 6 i.val - harmonicRational 6 j.val) /
    (6 * ((i.val : ℚ) - (j.val : ℚ))))

theorem momentShift_isSymm (K : ℕ) : (momentShift K).IsSymm := by
  apply Matrix.IsSymm.ext
  intro i j
  by_cases h : i = j
  · subst j
    rfl
  · simp only [momentShift, if_neg h, if_neg (Ne.symm h)]
    have hnum : harmonicRational 6 j.val - harmonicRational 6 i.val =
        -(harmonicRational 6 i.val - harmonicRational 6 j.val) := by ring
    have hden : 6 * ((j.val : ℚ) - (i.val : ℚ)) =
        -(6 * ((i.val : ℚ) - (j.val : ℚ))) := by ring
    rw [hnum, hden, neg_div_neg_eq]

theorem momentPencil_isSymm (K : ℕ) (X : ℚ) :
    (affinePencil (momentShift K) X).IsSymm :=
  affinePencil_isSymm _ (momentShift_isSymm K) _

/-- The same rational shift matrix, regarded as a real matrix. -/
noncomputable def realMomentShift (K : ℕ) :
    Matrix (Fin (K + 1)) (Fin (K + 1)) ℝ :=
  (momentShift K).map fun q => (q : ℝ)

theorem realMomentShift_isSymm (K : ℕ) : (realMomentShift K).IsSymm :=
  (momentShift_isSymm K).map _

theorem realMomentShift_charpoly_splits (K : ℕ) : (realMomentShift K).charpoly.Splits :=
  symmetric_charpoly_splits _ (realMomentShift_isSymm K)

theorem momentPencil_diagonal (K : ℕ) (X : ℚ) (i : Fin (K + 1)) :
    affinePencil (momentShift K) X i i = X - harmonicRational 7 i.val := by
  simp [affinePencil, momentShift]

theorem momentPencil_offDiagonal (K : ℕ) (X : ℚ) (i j : Fin (K + 1))
    (h : i ≠ j) :
    affinePencil (momentShift K) X i j =
      (harmonicRational 6 i.val - harmonicRational 6 j.val) /
        (6 * ((i.val : ℚ) - (j.val : ℚ))) := by
  simp [affinePencil, momentShift, h]

/-- The exact integer matrix whose division by `214990848` is `R_4`.
The common denominator is `6 * 12^7`. -/
def momentIntegerMatrix5 : Matrix (Fin 5) (Fin 5) ℚ :=
  !![0, -35831808, -18195840, -12146944, -9112395;
     -35831808, 214990848, -559872, -304512, -205924;
     -18195840, -559872, 216670464, -49152, -28950;
     -12146944, -304512, -49152, 216768768, -8748;
     -9112395, -205924, -28950, -8748, 216781890]

/-- An entrywise exact-rational certificate connecting the finite matrix to all
the harmonic-moment definitions, rather than treating its entries as assumptions. -/
theorem momentShift_four : momentShift 4 =
    (1 / 214990848 : ℚ) • momentIntegerMatrix5 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [momentShift, harmonicRational, momentIntegerMatrix5, Finset.sum_range_succ]

end RationalMoments

end Zeta7Chain
