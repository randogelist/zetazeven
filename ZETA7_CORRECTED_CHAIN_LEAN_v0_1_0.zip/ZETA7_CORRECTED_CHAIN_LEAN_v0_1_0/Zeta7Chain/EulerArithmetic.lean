import Zeta7Chain.EulerPolynomial
import Zeta7Chain.FiniteWindow
import Mathlib.Algebra.Polynomial.Eval.Degree
import Mathlib.Tactic

/-!
# Kernel-checked arithmetic for the 112-term Euler interval

The binomial coefficients below are certified by their multiplicative recurrence.
The Euler coefficients follow from the polynomial lock.  Python was used only to
prepare the integer literals: every identity and inequality is proved inside Lean.
No native evaluation, oracle, or floating-point comparison is used.
-/

noncomputable section
open ChebyshevMastertier
namespace Zeta7Chain
set_option maxRecDepth 10000
set_option maxHeartbeats 0

theorem one_sub_X_pow_coeff (n k : ℕ) :
    ((1 - Polynomial.X : Polynomial ℤ) ^ n).coeff k =
      (n.choose k : ℤ) * (-1 : ℤ) ^ k := by
  have hpoly : (1 - Polynomial.X : Polynomial ℤ) ^ n =
      ((1 + Polynomial.X : Polynomial ℤ) ^ n).comp
        (Polynomial.C (-1) * Polynomial.X) := by
    simp [Polynomial.pow_comp, Polynomial.add_comp, sub_eq_add_neg]
  rw [hpoly, Polynomial.comp_C_mul_X_coeff, Polynomial.coeff_one_add_X_pow]

theorem euler_coeff_zero (n : ℕ) :
    (eulerNumerator n).coeff 0 = (2 : ℤ) ^ n - 1 := by
  have h := congrArg (fun p : Polynomial ℤ => p.coeff 0) (euler_polynomial_lock n)
  have hp : (2 : Polynomial ℤ) ^ n = Polynomial.C ((2 : ℤ) ^ n) := by simp
  rw [add_mul, one_mul, Polynomial.coeff_add, Polynomial.coeff_X_mul_zero,
    add_zero, Polynomial.coeff_sub, hp, Polynomial.coeff_C_zero,
    one_sub_X_pow_coeff] at h
  simpa only [Nat.choose_zero_right, Nat.cast_one, pow_zero, mul_one] using h

theorem euler_coeff_succ (n k : ℕ) :
    (eulerNumerator n).coeff (k + 1) =
      -(n.choose (k + 1) : ℤ) * (-1 : ℤ) ^ (k + 1) -
        (eulerNumerator n).coeff k := by
  have h := congrArg (fun p : Polynomial ℤ => p.coeff (k + 1)) (euler_polynomial_lock n)
  have hp : (2 : Polynomial ℤ) ^ n = Polynomial.C ((2 : ℤ) ^ n) := by simp
  simp only [add_mul, one_mul, Polynomial.coeff_add, Polynomial.coeff_X_mul,
    Polynomial.coeff_sub, hp, Polynomial.coeff_C_succ, one_sub_X_pow_coeff] at h
  linarith


private theorem choose112_0 : Nat.choose 112 0 = 1 := by
  simp

private theorem choose112_1 : Nat.choose 112 1 = 112 := by
  have h := Nat.choose_succ_right_eq 112 0
  norm_num only [choose112_0] at h
  omega

private theorem choose112_2 : Nat.choose 112 2 = 6216 := by
  have h := Nat.choose_succ_right_eq 112 1
  norm_num only [choose112_1] at h
  omega

private theorem choose112_3 : Nat.choose 112 3 = 227920 := by
  have h := Nat.choose_succ_right_eq 112 2
  norm_num only [choose112_2] at h
  omega

private theorem choose112_4 : Nat.choose 112 4 = 6210820 := by
  have h := Nat.choose_succ_right_eq 112 3
  norm_num only [choose112_3] at h
  omega

private theorem choose112_5 : Nat.choose 112 5 = 134153712 := by
  have h := Nat.choose_succ_right_eq 112 4
  norm_num only [choose112_4] at h
  omega

private theorem choose112_6 : Nat.choose 112 6 = 2392407864 := by
  have h := Nat.choose_succ_right_eq 112 5
  norm_num only [choose112_5] at h
  omega

private theorem choose112_7 : Nat.choose 112 7 = 36227890512 := by
  have h := Nat.choose_succ_right_eq 112 6
  norm_num only [choose112_6] at h
  omega

private theorem choose112_8 : Nat.choose 112 8 = 475491062970 := by
  have h := Nat.choose_succ_right_eq 112 7
  norm_num only [choose112_7] at h
  omega

private theorem choose112_9 : Nat.choose 112 9 = 5494563394320 := by
  have h := Nat.choose_succ_right_eq 112 8
  norm_num only [choose112_8] at h
  omega

private theorem choose112_10 : Nat.choose 112 10 = 56594002961496 := by
  have h := Nat.choose_succ_right_eq 112 9
  norm_num only [choose112_9] at h
  omega

private theorem choose112_11 : Nat.choose 112 11 = 524780754733872 := by
  have h := Nat.choose_succ_right_eq 112 10
  norm_num only [choose112_10] at h
  omega

private theorem choose112_12 : Nat.choose 112 12 = 4416904685676756 := by
  have h := Nat.choose_succ_right_eq 112 11
  norm_num only [choose112_11] at h
  omega

private theorem choose112_13 : Nat.choose 112 13 = 33976189889821200 := by
  have h := Nat.choose_succ_right_eq 112 12
  norm_num only [choose112_12] at h
  omega

private theorem choose112_14 : Nat.choose 112 14 = 240260199935164200 := by
  have h := Nat.choose_succ_right_eq 112 13
  norm_num only [choose112_13] at h
  omega

private theorem choose112_15 : Nat.choose 112 15 = 1569699972909739440 := by
  have h := Nat.choose_succ_right_eq 112 14
  norm_num only [choose112_14] at h
  omega

private theorem choose112_16 : Nat.choose 112 16 = 9516306085765295355 := by
  have h := Nat.choose_succ_right_eq 112 15
  norm_num only [choose112_15] at h
  omega

private theorem choose112_17 : Nat.choose 112 17 = 53739140249027550240 := by
  have h := Nat.choose_succ_right_eq 112 16
  norm_num only [choose112_16] at h
  omega

private theorem choose112_18 : Nat.choose 112 18 = 283623240203200959600 := by
  have h := Nat.choose_succ_right_eq 112 17
  norm_num only [choose112_17] at h
  omega

private theorem choose112_19 : Nat.choose 112 19 = 1403188662057941589600 := by
  have h := Nat.choose_succ_right_eq 112 18
  norm_num only [choose112_18] at h
  omega

private theorem choose112_20 : Nat.choose 112 20 = 6524827278569428391640 := by
  have h := Nat.choose_succ_right_eq 112 19
  norm_num only [choose112_19] at h
  omega

private theorem choose112_21 : Nat.choose 112 21 = 28584957601351781525280 := by
  have h := Nat.choose_succ_right_eq 112 20
  norm_num only [choose112_20] at h
  omega

private theorem choose112_22 : Nat.choose 112 22 = 118237779169227823581840 := by
  have h := Nat.choose_succ_right_eq 112 21
  norm_num only [choose112_21] at h
  omega

private theorem choose112_23 : Nat.choose 112 23 = 462669570662195831407200 := by
  have h := Nat.choose_succ_right_eq 112 22
  norm_num only [choose112_22] at h
  omega

private theorem choose112_24 : Nat.choose 112 24 = 1715732991205642874801700 := by
  have h := Nat.choose_succ_right_eq 112 23
  norm_num only [choose112_23] at h
  omega

private theorem choose112_25 : Nat.choose 112 25 = 6039380129043862919301984 := by
  have h := Nat.choose_succ_right_eq 112 24
  norm_num only [choose112_24] at h
  omega

private theorem choose112_26 : Nat.choose 112 26 = 20208695047185233614587408 := by
  have h := Nat.choose_succ_right_eq 112 25
  norm_num only [choose112_25] at h
  omega

private theorem choose112_27 : Nat.choose 112 27 = 64368436076219632994611744 := by
  have h := Nat.choose_succ_right_eq 112 26
  norm_num only [choose112_26] at h
  omega

private theorem choose112_28 : Nat.choose 112 28 = 195404180945666743019357080 := by
  have h := Nat.choose_succ_right_eq 112 27
  norm_num only [choose112_27] at h
  omega

private theorem choose112_29 : Nat.choose 112 29 = 565998317221931255642275680 := by
  have h := Nat.choose_succ_right_eq 112 28
  norm_num only [choose112_28] at h
  omega

private theorem choose112_30 : Nat.choose 112 30 = 1565928677647343140610296048 := by
  have h := Nat.choose_succ_right_eq 112 29
  norm_num only [choose112_29] at h
  omega

private theorem choose112_31 : Nat.choose 112 31 = 4142133921518778630001428256 := by
  have h := Nat.choose_succ_right_eq 112 30
  norm_num only [choose112_30] at h
  omega

private theorem choose112_32 : Nat.choose 112 32 = 10484776488844408407191115273 := by
  have h := Nat.choose_succ_right_eq 112 31
  norm_num only [choose112_31] at h
  omega

private theorem choose112_33 : Nat.choose 112 33 = 25417639972956141593190582480 := by
  have h := Nat.choose_succ_right_eq 112 32
  norm_num only [choose112_32] at h
  omega

private theorem choose112_34 : Nat.choose 112 34 = 59058634054809858407707529880 := by
  have h := Nat.choose_succ_right_eq 112 33
  norm_num only [choose112_33] at h
  omega

private theorem choose112_35 : Nat.choose 112 35 = 131616384465004827308605352304 := by
  have h := Nat.choose_succ_right_eq 112 34
  norm_num only [choose112_34] at h
  omega

private theorem choose112_36 : Nat.choose 112 36 = 281512822327926991743405892428 := by
  have h := Nat.choose_succ_right_eq 112 35
  norm_num only [choose112_35] at h
  omega

private theorem choose112_37 : Nat.choose 112 37 = 578242553970877064121590481744 := by
  have h := Nat.choose_succ_right_eq 112 36
  norm_num only [choose112_36] at h
  omega

private theorem choose112_38 : Nat.choose 112 38 = 1141268198626731047608402266600 := by
  have h := Nat.choose_succ_right_eq 112 37
  norm_num only [choose112_37] at h
  omega

private theorem choose112_39 : Nat.choose 112 39 = 2165483248676361474949276095600 := by
  have h := Nat.choose_succ_right_eq 112 38
  norm_num only [choose112_38] at h
  omega

private theorem choose112_40 : Nat.choose 112 40 = 3952006928834359691782428874470 := by
  have h := Nat.choose_succ_right_eq 112 39
  norm_num only [choose112_39] at h
  omega

private theorem choose112_41 : Nat.choose 112 41 = 6940109728684729214837436072240 := by
  have h := Nat.choose_succ_right_eq 112 40
  norm_num only [choose112_40] at h
  omega

private theorem choose112_42 : Nat.choose 112 42 = 11732090255633708910796618122120 := by
  have h := Nat.choose_succ_right_eq 112 41
  norm_num only [choose112_41] at h
  omega

private theorem choose112_43 : Nat.choose 112 43 = 19098751578938595901296820198800 := by
  have h := Nat.choose_succ_right_eq 112 42
  norm_num only [choose112_42] at h
  omega

private theorem choose112_44 : Nat.choose 112 44 = 29950314976062798117942740766300 := by
  have h := Nat.choose_succ_right_eq 112 43
  norm_num only [choose112_43] at h
  omega

private theorem choose112_45 : Nat.choose 112 45 = 45258253741606006044891252713520 := by
  have h := Nat.choose_succ_right_eq 112 44
  norm_num only [choose112_44] at h
  omega

private theorem choose112_46 : Nat.choose 112 46 = 65919630449730487065385085474040 := by
  have h := Nat.choose_succ_right_eq 112 45
  norm_num only [choose112_45] at h
  omega

private theorem choose112_47 : Nat.choose 112 47 = 92567991695366215879051396623120 := by
  have h := Nat.choose_succ_right_eq 112 46
  norm_num only [choose112_46] at h
  omega

private theorem choose112_48 : Nat.choose 112 48 = 125352488754141750669548766260475 := by
  have h := Nat.choose_succ_right_eq 112 47
  norm_num only [choose112_47] at h
  omega

private theorem choose112_49 : Nat.choose 112 49 = 163725699597246368221451449809600 := by
  have h := Nat.choose_succ_right_eq 112 48
  norm_num only [choose112_48] at h
  omega

private theorem choose112_50 : Nat.choose 112 50 = 206294381492530423959028826760096 := by
  have h := Nat.choose_succ_right_eq 112 49
  norm_num only [choose112_49] at h
  omega

private theorem choose112_51 : Nat.choose 112 51 = 250789248088958554616858573708352 := by
  have h := Nat.choose_succ_right_eq 112 50
  norm_num only [choose112_50] at h
  omega

private theorem choose112_52 : Nat.choose 112 52 = 294195079488970612146699480696336 := by
  have h := Nat.choose_succ_right_eq 112 51
  norm_num only [choose112_51] at h
  omega

private theorem choose112_53 : Nat.choose 112 53 = 333051033383740315637772997014720 := by
  have h := Nat.choose_succ_right_eq 112 52
  norm_num only [choose112_52] at h
  omega

private theorem choose112_54 : Nat.choose 112 54 = 363889092030382937456085311553120 := by
  have h := Nat.choose_succ_right_eq 112 53
  norm_num only [choose112_53] at h
  omega

private theorem choose112_55 : Nat.choose 112 55 = 383737587959312915862780874001472 := by
  have h := Nat.choose_succ_right_eq 112 54
  norm_num only [choose112_54] at h
  omega

private theorem choose112_56 : Nat.choose 112 56 = 390590044887157789360330532465784 := by
  have h := Nat.choose_succ_right_eq 112 55
  norm_num only [choose112_55] at h
  omega

private theorem choose112_57 : Nat.choose 112 57 = 383737587959312915862780874001472 := by
  have h := Nat.choose_succ_right_eq 112 56
  norm_num only [choose112_56] at h
  omega

private theorem choose112_58 : Nat.choose 112 58 = 363889092030382937456085311553120 := by
  have h := Nat.choose_succ_right_eq 112 57
  norm_num only [choose112_57] at h
  omega

private theorem choose112_59 : Nat.choose 112 59 = 333051033383740315637772997014720 := by
  have h := Nat.choose_succ_right_eq 112 58
  norm_num only [choose112_58] at h
  omega

private theorem choose112_60 : Nat.choose 112 60 = 294195079488970612146699480696336 := by
  have h := Nat.choose_succ_right_eq 112 59
  norm_num only [choose112_59] at h
  omega

private theorem choose112_61 : Nat.choose 112 61 = 250789248088958554616858573708352 := by
  have h := Nat.choose_succ_right_eq 112 60
  norm_num only [choose112_60] at h
  omega

private theorem choose112_62 : Nat.choose 112 62 = 206294381492530423959028826760096 := by
  have h := Nat.choose_succ_right_eq 112 61
  norm_num only [choose112_61] at h
  omega

private theorem choose112_63 : Nat.choose 112 63 = 163725699597246368221451449809600 := by
  have h := Nat.choose_succ_right_eq 112 62
  norm_num only [choose112_62] at h
  omega

private theorem choose112_64 : Nat.choose 112 64 = 125352488754141750669548766260475 := by
  have h := Nat.choose_succ_right_eq 112 63
  norm_num only [choose112_63] at h
  omega

private theorem choose112_65 : Nat.choose 112 65 = 92567991695366215879051396623120 := by
  have h := Nat.choose_succ_right_eq 112 64
  norm_num only [choose112_64] at h
  omega

private theorem choose112_66 : Nat.choose 112 66 = 65919630449730487065385085474040 := by
  have h := Nat.choose_succ_right_eq 112 65
  norm_num only [choose112_65] at h
  omega

private theorem choose112_67 : Nat.choose 112 67 = 45258253741606006044891252713520 := by
  have h := Nat.choose_succ_right_eq 112 66
  norm_num only [choose112_66] at h
  omega

private theorem choose112_68 : Nat.choose 112 68 = 29950314976062798117942740766300 := by
  have h := Nat.choose_succ_right_eq 112 67
  norm_num only [choose112_67] at h
  omega

private theorem choose112_69 : Nat.choose 112 69 = 19098751578938595901296820198800 := by
  have h := Nat.choose_succ_right_eq 112 68
  norm_num only [choose112_68] at h
  omega

private theorem choose112_70 : Nat.choose 112 70 = 11732090255633708910796618122120 := by
  have h := Nat.choose_succ_right_eq 112 69
  norm_num only [choose112_69] at h
  omega

private theorem choose112_71 : Nat.choose 112 71 = 6940109728684729214837436072240 := by
  have h := Nat.choose_succ_right_eq 112 70
  norm_num only [choose112_70] at h
  omega

private theorem choose112_72 : Nat.choose 112 72 = 3952006928834359691782428874470 := by
  have h := Nat.choose_succ_right_eq 112 71
  norm_num only [choose112_71] at h
  omega

private theorem choose112_73 : Nat.choose 112 73 = 2165483248676361474949276095600 := by
  have h := Nat.choose_succ_right_eq 112 72
  norm_num only [choose112_72] at h
  omega

private theorem choose112_74 : Nat.choose 112 74 = 1141268198626731047608402266600 := by
  have h := Nat.choose_succ_right_eq 112 73
  norm_num only [choose112_73] at h
  omega

private theorem choose112_75 : Nat.choose 112 75 = 578242553970877064121590481744 := by
  have h := Nat.choose_succ_right_eq 112 74
  norm_num only [choose112_74] at h
  omega

private theorem choose112_76 : Nat.choose 112 76 = 281512822327926991743405892428 := by
  have h := Nat.choose_succ_right_eq 112 75
  norm_num only [choose112_75] at h
  omega

private theorem choose112_77 : Nat.choose 112 77 = 131616384465004827308605352304 := by
  have h := Nat.choose_succ_right_eq 112 76
  norm_num only [choose112_76] at h
  omega

private theorem choose112_78 : Nat.choose 112 78 = 59058634054809858407707529880 := by
  have h := Nat.choose_succ_right_eq 112 77
  norm_num only [choose112_77] at h
  omega

private theorem choose112_79 : Nat.choose 112 79 = 25417639972956141593190582480 := by
  have h := Nat.choose_succ_right_eq 112 78
  norm_num only [choose112_78] at h
  omega

private theorem choose112_80 : Nat.choose 112 80 = 10484776488844408407191115273 := by
  have h := Nat.choose_succ_right_eq 112 79
  norm_num only [choose112_79] at h
  omega

private theorem choose112_81 : Nat.choose 112 81 = 4142133921518778630001428256 := by
  have h := Nat.choose_succ_right_eq 112 80
  norm_num only [choose112_80] at h
  omega

private theorem choose112_82 : Nat.choose 112 82 = 1565928677647343140610296048 := by
  have h := Nat.choose_succ_right_eq 112 81
  norm_num only [choose112_81] at h
  omega

private theorem choose112_83 : Nat.choose 112 83 = 565998317221931255642275680 := by
  have h := Nat.choose_succ_right_eq 112 82
  norm_num only [choose112_82] at h
  omega

private theorem choose112_84 : Nat.choose 112 84 = 195404180945666743019357080 := by
  have h := Nat.choose_succ_right_eq 112 83
  norm_num only [choose112_83] at h
  omega

private theorem choose112_85 : Nat.choose 112 85 = 64368436076219632994611744 := by
  have h := Nat.choose_succ_right_eq 112 84
  norm_num only [choose112_84] at h
  omega

private theorem choose112_86 : Nat.choose 112 86 = 20208695047185233614587408 := by
  have h := Nat.choose_succ_right_eq 112 85
  norm_num only [choose112_85] at h
  omega

private theorem choose112_87 : Nat.choose 112 87 = 6039380129043862919301984 := by
  have h := Nat.choose_succ_right_eq 112 86
  norm_num only [choose112_86] at h
  omega

private theorem choose112_88 : Nat.choose 112 88 = 1715732991205642874801700 := by
  have h := Nat.choose_succ_right_eq 112 87
  norm_num only [choose112_87] at h
  omega

private theorem choose112_89 : Nat.choose 112 89 = 462669570662195831407200 := by
  have h := Nat.choose_succ_right_eq 112 88
  norm_num only [choose112_88] at h
  omega

private theorem choose112_90 : Nat.choose 112 90 = 118237779169227823581840 := by
  have h := Nat.choose_succ_right_eq 112 89
  norm_num only [choose112_89] at h
  omega

private theorem choose112_91 : Nat.choose 112 91 = 28584957601351781525280 := by
  have h := Nat.choose_succ_right_eq 112 90
  norm_num only [choose112_90] at h
  omega

private theorem choose112_92 : Nat.choose 112 92 = 6524827278569428391640 := by
  have h := Nat.choose_succ_right_eq 112 91
  norm_num only [choose112_91] at h
  omega

private theorem choose112_93 : Nat.choose 112 93 = 1403188662057941589600 := by
  have h := Nat.choose_succ_right_eq 112 92
  norm_num only [choose112_92] at h
  omega

private theorem choose112_94 : Nat.choose 112 94 = 283623240203200959600 := by
  have h := Nat.choose_succ_right_eq 112 93
  norm_num only [choose112_93] at h
  omega

private theorem choose112_95 : Nat.choose 112 95 = 53739140249027550240 := by
  have h := Nat.choose_succ_right_eq 112 94
  norm_num only [choose112_94] at h
  omega

private theorem choose112_96 : Nat.choose 112 96 = 9516306085765295355 := by
  have h := Nat.choose_succ_right_eq 112 95
  norm_num only [choose112_95] at h
  omega

private theorem choose112_97 : Nat.choose 112 97 = 1569699972909739440 := by
  have h := Nat.choose_succ_right_eq 112 96
  norm_num only [choose112_96] at h
  omega

private theorem choose112_98 : Nat.choose 112 98 = 240260199935164200 := by
  have h := Nat.choose_succ_right_eq 112 97
  norm_num only [choose112_97] at h
  omega

private theorem choose112_99 : Nat.choose 112 99 = 33976189889821200 := by
  have h := Nat.choose_succ_right_eq 112 98
  norm_num only [choose112_98] at h
  omega

private theorem choose112_100 : Nat.choose 112 100 = 4416904685676756 := by
  have h := Nat.choose_succ_right_eq 112 99
  norm_num only [choose112_99] at h
  omega

private theorem choose112_101 : Nat.choose 112 101 = 524780754733872 := by
  have h := Nat.choose_succ_right_eq 112 100
  norm_num only [choose112_100] at h
  omega

private theorem choose112_102 : Nat.choose 112 102 = 56594002961496 := by
  have h := Nat.choose_succ_right_eq 112 101
  norm_num only [choose112_101] at h
  omega

private theorem choose112_103 : Nat.choose 112 103 = 5494563394320 := by
  have h := Nat.choose_succ_right_eq 112 102
  norm_num only [choose112_102] at h
  omega

private theorem choose112_104 : Nat.choose 112 104 = 475491062970 := by
  have h := Nat.choose_succ_right_eq 112 103
  norm_num only [choose112_103] at h
  omega

private theorem choose112_105 : Nat.choose 112 105 = 36227890512 := by
  have h := Nat.choose_succ_right_eq 112 104
  norm_num only [choose112_104] at h
  omega

private theorem choose112_106 : Nat.choose 112 106 = 2392407864 := by
  have h := Nat.choose_succ_right_eq 112 105
  norm_num only [choose112_105] at h
  omega

private theorem choose112_107 : Nat.choose 112 107 = 134153712 := by
  have h := Nat.choose_succ_right_eq 112 106
  norm_num only [choose112_106] at h
  omega

private theorem choose112_108 : Nat.choose 112 108 = 6210820 := by
  have h := Nat.choose_succ_right_eq 112 107
  norm_num only [choose112_107] at h
  omega

private theorem choose112_109 : Nat.choose 112 109 = 227920 := by
  have h := Nat.choose_succ_right_eq 112 108
  norm_num only [choose112_108] at h
  omega

private theorem choose112_110 : Nat.choose 112 110 = 6216 := by
  have h := Nat.choose_succ_right_eq 112 109
  norm_num only [choose112_109] at h
  omega

private theorem choose112_111 : Nat.choose 112 111 = 112 := by
  have h := Nat.choose_succ_right_eq 112 110
  norm_num only [choose112_110] at h
  omega

private theorem choose112_112 : Nat.choose 112 112 = 1 := by
  have h := Nat.choose_succ_right_eq 112 111
  norm_num only [choose112_111] at h
  omega

private theorem euler112_coeff_0 : (eulerNumerator 112).coeff 0 = (5192296858534827628530496329220095 : ℤ) := by
  rw [euler_coeff_zero]
  norm_num

private theorem euler112_coeff_1 : (eulerNumerator 112).coeff 1 = (-5192296858534827628530496329219983 : ℤ) := by
  change (eulerNumerator 112).coeff (0 + 1) = _
  rw [euler_coeff_succ, choose112_1, euler112_coeff_0]
  norm_num

private theorem euler112_coeff_2 : (eulerNumerator 112).coeff 2 = (5192296858534827628530496329213767 : ℤ) := by
  change (eulerNumerator 112).coeff (1 + 1) = _
  rw [euler_coeff_succ, choose112_2, euler112_coeff_1]
  norm_num

private theorem euler112_coeff_3 : (eulerNumerator 112).coeff 3 = (-5192296858534827628530496328985847 : ℤ) := by
  change (eulerNumerator 112).coeff (2 + 1) = _
  rw [euler_coeff_succ, choose112_3, euler112_coeff_2]
  norm_num

private theorem euler112_coeff_4 : (eulerNumerator 112).coeff 4 = (5192296858534827628530496322775027 : ℤ) := by
  change (eulerNumerator 112).coeff (3 + 1) = _
  rw [euler_coeff_succ, choose112_4, euler112_coeff_3]
  norm_num

private theorem euler112_coeff_5 : (eulerNumerator 112).coeff 5 = (-5192296858534827628530496188621315 : ℤ) := by
  change (eulerNumerator 112).coeff (4 + 1) = _
  rw [euler_coeff_succ, choose112_5, euler112_coeff_4]
  norm_num

private theorem euler112_coeff_6 : (eulerNumerator 112).coeff 6 = (5192296858534827628530493796213451 : ℤ) := by
  change (eulerNumerator 112).coeff (5 + 1) = _
  rw [euler_coeff_succ, choose112_6, euler112_coeff_5]
  norm_num

private theorem euler112_coeff_7 : (eulerNumerator 112).coeff 7 = (-5192296858534827628530457568322939 : ℤ) := by
  change (eulerNumerator 112).coeff (6 + 1) = _
  rw [euler_coeff_succ, choose112_7, euler112_coeff_6]
  norm_num

private theorem euler112_coeff_8 : (eulerNumerator 112).coeff 8 = (5192296858534827628529982077259969 : ℤ) := by
  change (eulerNumerator 112).coeff (7 + 1) = _
  rw [euler_coeff_succ, choose112_8, euler112_coeff_7]
  norm_num

private theorem euler112_coeff_9 : (eulerNumerator 112).coeff 9 = (-5192296858534827628524487513865649 : ℤ) := by
  change (eulerNumerator 112).coeff (8 + 1) = _
  rw [euler_coeff_succ, choose112_9, euler112_coeff_8]
  norm_num

private theorem euler112_coeff_10 : (eulerNumerator 112).coeff 10 = (5192296858534827628467893510904153 : ℤ) := by
  change (eulerNumerator 112).coeff (9 + 1) = _
  rw [euler_coeff_succ, choose112_10, euler112_coeff_9]
  norm_num

private theorem euler112_coeff_11 : (eulerNumerator 112).coeff 11 = (-5192296858534827627943112756170281 : ℤ) := by
  change (eulerNumerator 112).coeff (10 + 1) = _
  rw [euler_coeff_succ, choose112_11, euler112_coeff_10]
  norm_num

private theorem euler112_coeff_12 : (eulerNumerator 112).coeff 12 = (5192296858534827623526208070493525 : ℤ) := by
  change (eulerNumerator 112).coeff (11 + 1) = _
  rw [euler_coeff_succ, choose112_12, euler112_coeff_11]
  norm_num

private theorem euler112_coeff_13 : (eulerNumerator 112).coeff 13 = (-5192296858534827589550018180672325 : ℤ) := by
  change (eulerNumerator 112).coeff (12 + 1) = _
  rw [euler_coeff_succ, choose112_13, euler112_coeff_12]
  norm_num

private theorem euler112_coeff_14 : (eulerNumerator 112).coeff 14 = (5192296858534827349289818245508125 : ℤ) := by
  change (eulerNumerator 112).coeff (13 + 1) = _
  rw [euler_coeff_succ, choose112_14, euler112_coeff_13]
  norm_num

private theorem euler112_coeff_15 : (eulerNumerator 112).coeff 15 = (-5192296858534825779589845335768685 : ℤ) := by
  change (eulerNumerator 112).coeff (14 + 1) = _
  rw [euler_coeff_succ, choose112_15, euler112_coeff_14]
  norm_num

private theorem euler112_coeff_16 : (eulerNumerator 112).coeff 16 = (5192296858534816263283759570473330 : ℤ) := by
  change (eulerNumerator 112).coeff (15 + 1) = _
  rw [euler_coeff_succ, choose112_16, euler112_coeff_15]
  norm_num

private theorem euler112_coeff_17 : (eulerNumerator 112).coeff 17 = (-5192296858534762524143510542923090 : ℤ) := by
  change (eulerNumerator 112).coeff (16 + 1) = _
  rw [euler_coeff_succ, choose112_17, euler112_coeff_16]
  norm_num

private theorem euler112_coeff_18 : (eulerNumerator 112).coeff 18 = (5192296858534478900903307341963490 : ℤ) := by
  change (eulerNumerator 112).coeff (17 + 1) = _
  rw [euler_coeff_succ, choose112_18, euler112_coeff_17]
  norm_num

private theorem euler112_coeff_19 : (eulerNumerator 112).coeff 19 = (-5192296858533075712241249400373890 : ℤ) := by
  change (eulerNumerator 112).coeff (18 + 1) = _
  rw [euler_coeff_succ, choose112_19, euler112_coeff_18]
  norm_num

private theorem euler112_coeff_20 : (eulerNumerator 112).coeff 20 = (5192296858526550884962679971982250 : ℤ) := by
  change (eulerNumerator 112).coeff (19 + 1) = _
  rw [euler_coeff_succ, choose112_20, euler112_coeff_19]
  norm_num

private theorem euler112_coeff_21 : (eulerNumerator 112).coeff 21 = (-5192296858497965927361328190456970 : ℤ) := by
  change (eulerNumerator 112).coeff (20 + 1) = _
  rw [euler_coeff_succ, choose112_21, euler112_coeff_20]
  norm_num

private theorem euler112_coeff_22 : (eulerNumerator 112).coeff 22 = (5192296858379728148192100366875130 : ℤ) := by
  change (eulerNumerator 112).coeff (21 + 1) = _
  rw [euler_coeff_succ, choose112_22, euler112_coeff_21]
  norm_num

private theorem euler112_coeff_23 : (eulerNumerator 112).coeff 23 = (-5192296857917058577529904535467930 : ℤ) := by
  change (eulerNumerator 112).coeff (22 + 1) = _
  rw [euler_coeff_succ, choose112_23, euler112_coeff_22]
  norm_num

private theorem euler112_coeff_24 : (eulerNumerator 112).coeff 24 = (5192296856201325586324261660666230 : ℤ) := by
  change (eulerNumerator 112).coeff (23 + 1) = _
  rw [euler_coeff_succ, choose112_24, euler112_coeff_23]
  norm_num

private theorem euler112_coeff_25 : (eulerNumerator 112).coeff 25 = (-5192296850161945457280398741364246 : ℤ) := by
  change (eulerNumerator 112).coeff (24 + 1) = _
  rw [euler_coeff_succ, choose112_25, euler112_coeff_24]
  norm_num

private theorem euler112_coeff_26 : (eulerNumerator 112).coeff 26 = (5192296829953250410095165126776838 : ℤ) := by
  change (eulerNumerator 112).coeff (25 + 1) = _
  rw [euler_coeff_succ, choose112_26, euler112_coeff_25]
  norm_num

private theorem euler112_coeff_27 : (eulerNumerator 112).coeff 27 = (-5192296765584814333875532132165094 : ℤ) := by
  change (eulerNumerator 112).coeff (26 + 1) = _
  rw [euler_coeff_succ, choose112_27, euler112_coeff_26]
  norm_num

private theorem euler112_coeff_28 : (eulerNumerator 112).coeff 28 = (5192296570180633388208789112808014 : ℤ) := by
  change (eulerNumerator 112).coeff (27 + 1) = _
  rw [euler_coeff_succ, choose112_28, euler112_coeff_27]
  norm_num

private theorem euler112_coeff_29 : (eulerNumerator 112).coeff 29 = (-5192296004182316166277533470532334 : ℤ) := by
  change (eulerNumerator 112).coeff (28 + 1) = _
  rw [euler_coeff_succ, choose112_29, euler112_coeff_28]
  norm_num

private theorem euler112_coeff_30 : (eulerNumerator 112).coeff 30 = (5192294438253638518934392860236286 : ℤ) := by
  change (eulerNumerator 112).coeff (29 + 1) = _
  rw [euler_coeff_succ, choose112_30, euler112_coeff_29]
  norm_num

private theorem euler112_coeff_31 : (eulerNumerator 112).coeff 31 = (-5192290296119717000155762858808030 : ℤ) := by
  change (eulerNumerator 112).coeff (30 + 1) = _
  rw [euler_coeff_succ, choose112_31, euler112_coeff_30]
  norm_num

private theorem euler112_coeff_32 : (eulerNumerator 112).coeff 32 = (5192279811343228155747355667692757 : ℤ) := by
  change (eulerNumerator 112).coeff (31 + 1) = _
  rw [euler_coeff_succ, choose112_32, euler112_coeff_31]
  norm_num

private theorem euler112_coeff_33 : (eulerNumerator 112).coeff 33 = (-5192254393703255199605762477110277 : ℤ) := by
  change (eulerNumerator 112).coeff (32 + 1) = _
  rw [euler_coeff_succ, choose112_33, euler112_coeff_32]
  norm_num

private theorem euler112_coeff_34 : (eulerNumerator 112).coeff 34 = (5192195335069200389747354769580397 : ℤ) := by
  change (eulerNumerator 112).coeff (33 + 1) = _
  rw [euler_coeff_succ, choose112_34, euler112_coeff_33]
  norm_num

private theorem euler112_coeff_35 : (eulerNumerator 112).coeff 35 = (-5192063718684735384920046164228093 : ℤ) := by
  change (eulerNumerator 112).coeff (34 + 1) = _
  rw [euler_coeff_succ, choose112_35, euler112_coeff_34]
  norm_num

private theorem euler112_coeff_36 : (eulerNumerator 112).coeff 36 = (5191782205862407457928302758335665 : ℤ) := by
  change (eulerNumerator 112).coeff (35 + 1) = _
  rw [euler_coeff_succ, choose112_36, euler112_coeff_35]
  norm_num

private theorem euler112_coeff_37 : (eulerNumerator 112).coeff 37 = (-5191203963308436580864181167853921 : ℤ) := by
  change (eulerNumerator 112).coeff (36 + 1) = _
  rw [euler_coeff_succ, choose112_37, euler112_coeff_36]
  norm_num

private theorem euler112_coeff_38 : (eulerNumerator 112).coeff 38 = (5190062695109809849816572765587321 : ℤ) := by
  change (eulerNumerator 112).coeff (37 + 1) = _
  rw [euler_coeff_succ, choose112_38, euler112_coeff_37]
  norm_num

private theorem euler112_coeff_39 : (eulerNumerator 112).coeff 39 = (-5187897211861133488341623489491721 : ℤ) := by
  change (eulerNumerator 112).coeff (38 + 1) = _
  rw [euler_coeff_succ, choose112_39, euler112_coeff_38]
  norm_num

private theorem euler112_coeff_40 : (eulerNumerator 112).coeff 40 = (5183945204932299128649841060617251 : ℤ) := by
  change (eulerNumerator 112).coeff (39 + 1) = _
  rw [euler_coeff_succ, choose112_40, euler112_coeff_39]
  norm_num

private theorem euler112_coeff_41 : (eulerNumerator 112).coeff 41 = (-5177005095203614399435003624545011 : ℤ) := by
  change (eulerNumerator 112).coeff (40 + 1) = _
  rw [euler_coeff_succ, choose112_41, euler112_coeff_40]
  norm_num

private theorem euler112_coeff_42 : (eulerNumerator 112).coeff 42 = (5165273004947980690524207006422891 : ℤ) := by
  change (eulerNumerator 112).coeff (41 + 1) = _
  rw [euler_coeff_succ, choose112_42, euler112_coeff_41]
  norm_num

private theorem euler112_coeff_43 : (eulerNumerator 112).coeff 43 = (-5146174253369042094622910186224091 : ℤ) := by
  change (eulerNumerator 112).coeff (42 + 1) = _
  rw [euler_coeff_succ, choose112_43, euler112_coeff_42]
  norm_num

private theorem euler112_coeff_44 : (eulerNumerator 112).coeff 44 = (5116223938392979296504967445457791 : ℤ) := by
  change (eulerNumerator 112).coeff (43 + 1) = _
  rw [euler_coeff_succ, choose112_44, euler112_coeff_43]
  norm_num

private theorem euler112_coeff_45 : (eulerNumerator 112).coeff 45 = (-5070965684651373290460076192744271 : ℤ) := by
  change (eulerNumerator 112).coeff (44 + 1) = _
  rw [euler_coeff_succ, choose112_45, euler112_coeff_44]
  norm_num

private theorem euler112_coeff_46 : (eulerNumerator 112).coeff 46 = (5005046054201642803394691107270231 : ℤ) := by
  change (eulerNumerator 112).coeff (45 + 1) = _
  rw [euler_coeff_succ, choose112_46, euler112_coeff_45]
  norm_num

private theorem euler112_coeff_47 : (eulerNumerator 112).coeff 47 = (-4912478062506276587515639710647111 : ℤ) := by
  change (eulerNumerator 112).coeff (46 + 1) = _
  rw [euler_coeff_succ, choose112_47, euler112_coeff_46]
  norm_num

private theorem euler112_coeff_48 : (eulerNumerator 112).coeff 48 = (4787125573752134836846090944386636 : ℤ) := by
  change (eulerNumerator 112).coeff (47 + 1) = _
  rw [euler_coeff_succ, choose112_48, euler112_coeff_47]
  norm_num

private theorem euler112_coeff_49 : (eulerNumerator 112).coeff 49 = (-4623399874154888468624639494577036 : ℤ) := by
  change (eulerNumerator 112).coeff (48 + 1) = _
  rw [euler_coeff_succ, choose112_49, euler112_coeff_48]
  norm_num

private theorem euler112_coeff_50 : (eulerNumerator 112).coeff 50 = (4417105492662358044665610667816940 : ℤ) := by
  change (eulerNumerator 112).coeff (49 + 1) = _
  rw [euler_coeff_succ, choose112_50, euler112_coeff_49]
  norm_num

private theorem euler112_coeff_51 : (eulerNumerator 112).coeff 51 = (-4166316244573399490048752094108588 : ℤ) := by
  change (eulerNumerator 112).coeff (50 + 1) = _
  rw [euler_coeff_succ, choose112_51, euler112_coeff_50]
  norm_num

private theorem euler112_coeff_52 : (eulerNumerator 112).coeff 52 = (3872121165084428877902052613412252 : ℤ) := by
  change (eulerNumerator 112).coeff (51 + 1) = _
  rw [euler_coeff_succ, choose112_52, euler112_coeff_51]
  norm_num

private theorem euler112_coeff_53 : (eulerNumerator 112).coeff 53 = (-3539070131700688562264279616397532 : ℤ) := by
  change (eulerNumerator 112).coeff (52 + 1) = _
  rw [euler_coeff_succ, choose112_53, euler112_coeff_52]
  norm_num

private theorem euler112_coeff_54 : (eulerNumerator 112).coeff 54 = (3175181039670305624808194304844412 : ℤ) := by
  change (eulerNumerator 112).coeff (53 + 1) = _
  rw [euler_coeff_succ, choose112_54, euler112_coeff_53]
  norm_num

private theorem euler112_coeff_55 : (eulerNumerator 112).coeff 55 = (-2791443451710992708945413430842940 : ℤ) := by
  change (eulerNumerator 112).coeff (54 + 1) = _
  rw [euler_coeff_succ, choose112_55, euler112_coeff_54]
  norm_num

private theorem euler112_coeff_56 : (eulerNumerator 112).coeff 56 = (2400853406823834919585082898377156 : ℤ) := by
  change (eulerNumerator 112).coeff (55 + 1) = _
  rw [euler_coeff_succ, choose112_56, euler112_coeff_55]
  norm_num

private theorem euler112_coeff_57 : (eulerNumerator 112).coeff 57 = (-2017115818864522003722302024375684 : ℤ) := by
  change (eulerNumerator 112).coeff (56 + 1) = _
  rw [euler_coeff_succ, choose112_57, euler112_coeff_56]
  norm_num

private theorem euler112_coeff_58 : (eulerNumerator 112).coeff 58 = (1653226726834139066266216712822564 : ℤ) := by
  change (eulerNumerator 112).coeff (57 + 1) = _
  rw [euler_coeff_succ, choose112_58, euler112_coeff_57]
  norm_num

private theorem euler112_coeff_59 : (eulerNumerator 112).coeff 59 = (-1320175693450398750628443715807844 : ℤ) := by
  change (eulerNumerator 112).coeff (58 + 1) = _
  rw [euler_coeff_succ, choose112_59, euler112_coeff_58]
  norm_num

private theorem euler112_coeff_60 : (eulerNumerator 112).coeff 60 = (1025980613961428138481744235111508 : ℤ) := by
  change (eulerNumerator 112).coeff (59 + 1) = _
  rw [euler_coeff_succ, choose112_60, euler112_coeff_59]
  norm_num

private theorem euler112_coeff_61 : (eulerNumerator 112).coeff 61 = (-775191365872469583864885661403156 : ℤ) := by
  change (eulerNumerator 112).coeff (60 + 1) = _
  rw [euler_coeff_succ, choose112_61, euler112_coeff_60]
  norm_num

private theorem euler112_coeff_62 : (eulerNumerator 112).coeff 62 = (568896984379939159905856834643060 : ℤ) := by
  change (eulerNumerator 112).coeff (61 + 1) = _
  rw [euler_coeff_succ, choose112_62, euler112_coeff_61]
  norm_num

private theorem euler112_coeff_63 : (eulerNumerator 112).coeff 63 = (-405171284782692791684405384833460 : ℤ) := by
  change (eulerNumerator 112).coeff (62 + 1) = _
  rw [euler_coeff_succ, choose112_63, euler112_coeff_62]
  norm_num

private theorem euler112_coeff_64 : (eulerNumerator 112).coeff 64 = (279818796028551041014856618572985 : ℤ) := by
  change (eulerNumerator 112).coeff (63 + 1) = _
  rw [euler_coeff_succ, choose112_64, euler112_coeff_63]
  norm_num

private theorem euler112_coeff_65 : (eulerNumerator 112).coeff 65 = (-187250804333184825135805221949865 : ℤ) := by
  change (eulerNumerator 112).coeff (64 + 1) = _
  rw [euler_coeff_succ, choose112_65, euler112_coeff_64]
  norm_num

private theorem euler112_coeff_66 : (eulerNumerator 112).coeff 66 = (121331173883454338070420136475825 : ℤ) := by
  change (eulerNumerator 112).coeff (65 + 1) = _
  rw [euler_coeff_succ, choose112_66, euler112_coeff_65]
  norm_num

private theorem euler112_coeff_67 : (eulerNumerator 112).coeff 67 = (-76072920141848332025528883762305 : ℤ) := by
  change (eulerNumerator 112).coeff (66 + 1) = _
  rw [euler_coeff_succ, choose112_67, euler112_coeff_66]
  norm_num

private theorem euler112_coeff_68 : (eulerNumerator 112).coeff 68 = (46122605165785533907586142996005 : ℤ) := by
  change (eulerNumerator 112).coeff (67 + 1) = _
  rw [euler_coeff_succ, choose112_68, euler112_coeff_67]
  norm_num

private theorem euler112_coeff_69 : (eulerNumerator 112).coeff 69 = (-27023853586846938006289322797205 : ℤ) := by
  change (eulerNumerator 112).coeff (68 + 1) = _
  rw [euler_coeff_succ, choose112_69, euler112_coeff_68]
  norm_num

private theorem euler112_coeff_70 : (eulerNumerator 112).coeff 70 = (15291763331213229095492704675085 : ℤ) := by
  change (eulerNumerator 112).coeff (69 + 1) = _
  rw [euler_coeff_succ, choose112_70, euler112_coeff_69]
  norm_num

private theorem euler112_coeff_71 : (eulerNumerator 112).coeff 71 = (-8351653602528499880655268602845 : ℤ) := by
  change (eulerNumerator 112).coeff (70 + 1) = _
  rw [euler_coeff_succ, choose112_71, euler112_coeff_70]
  norm_num

private theorem euler112_coeff_72 : (eulerNumerator 112).coeff 72 = (4399646673694140188872839728375 : ℤ) := by
  change (eulerNumerator 112).coeff (71 + 1) = _
  rw [euler_coeff_succ, choose112_72, euler112_coeff_71]
  norm_num

private theorem euler112_coeff_73 : (eulerNumerator 112).coeff 73 = (-2234163425017778713923563632775 : ℤ) := by
  change (eulerNumerator 112).coeff (72 + 1) = _
  rw [euler_coeff_succ, choose112_73, euler112_coeff_72]
  norm_num

private theorem euler112_coeff_74 : (eulerNumerator 112).coeff 74 = (1092895226391047666315161366175 : ℤ) := by
  change (eulerNumerator 112).coeff (73 + 1) = _
  rw [euler_coeff_succ, choose112_74, euler112_coeff_73]
  norm_num

private theorem euler112_coeff_75 : (eulerNumerator 112).coeff 75 = (-514652672420170602193570884431 : ℤ) := by
  change (eulerNumerator 112).coeff (74 + 1) = _
  rw [euler_coeff_succ, choose112_75, euler112_coeff_74]
  norm_num

private theorem euler112_coeff_76 : (eulerNumerator 112).coeff 76 = (233139850092243610450164992003 : ℤ) := by
  change (eulerNumerator 112).coeff (75 + 1) = _
  rw [euler_coeff_succ, choose112_76, euler112_coeff_75]
  norm_num

private theorem euler112_coeff_77 : (eulerNumerator 112).coeff 77 = (-101523465627238783141559639699 : ℤ) := by
  change (eulerNumerator 112).coeff (76 + 1) = _
  rw [euler_coeff_succ, choose112_77, euler112_coeff_76]
  norm_num

private theorem euler112_coeff_78 : (eulerNumerator 112).coeff 78 = (42464831572428924733852109819 : ℤ) := by
  change (eulerNumerator 112).coeff (77 + 1) = _
  rw [euler_coeff_succ, choose112_78, euler112_coeff_77]
  norm_num

private theorem euler112_coeff_79 : (eulerNumerator 112).coeff 79 = (-17047191599472783140661527339 : ℤ) := by
  change (eulerNumerator 112).coeff (78 + 1) = _
  rw [euler_coeff_succ, choose112_79, euler112_coeff_78]
  norm_num

private theorem euler112_coeff_80 : (eulerNumerator 112).coeff 80 = (6562415110628374733470412066 : ℤ) := by
  change (eulerNumerator 112).coeff (79 + 1) = _
  rw [euler_coeff_succ, choose112_80, euler112_coeff_79]
  norm_num

private theorem euler112_coeff_81 : (eulerNumerator 112).coeff 81 = (-2420281189109596103468983810 : ℤ) := by
  change (eulerNumerator 112).coeff (80 + 1) = _
  rw [euler_coeff_succ, choose112_81, euler112_coeff_80]
  norm_num

private theorem euler112_coeff_82 : (eulerNumerator 112).coeff 82 = (854352511462252962858687762 : ℤ) := by
  change (eulerNumerator 112).coeff (81 + 1) = _
  rw [euler_coeff_succ, choose112_82, euler112_coeff_81]
  norm_num

private theorem euler112_coeff_83 : (eulerNumerator 112).coeff 83 = (-288354194240321707216412082 : ℤ) := by
  change (eulerNumerator 112).coeff (82 + 1) = _
  rw [euler_coeff_succ, choose112_83, euler112_coeff_82]
  norm_num

private theorem euler112_coeff_84 : (eulerNumerator 112).coeff 84 = (92950013294654964197055002 : ℤ) := by
  change (eulerNumerator 112).coeff (83 + 1) = _
  rw [euler_coeff_succ, choose112_84, euler112_coeff_83]
  norm_num

private theorem euler112_coeff_85 : (eulerNumerator 112).coeff 85 = (-28581577218435331202443258 : ℤ) := by
  change (eulerNumerator 112).coeff (84 + 1) = _
  rw [euler_coeff_succ, choose112_85, euler112_coeff_84]
  norm_num

private theorem euler112_coeff_86 : (eulerNumerator 112).coeff 86 = (8372882171250097587855850 : ℤ) := by
  change (eulerNumerator 112).coeff (85 + 1) = _
  rw [euler_coeff_succ, choose112_86, euler112_coeff_85]
  norm_num

private theorem euler112_coeff_87 : (eulerNumerator 112).coeff 87 = (-2333502042206234668553866 : ℤ) := by
  change (eulerNumerator 112).coeff (86 + 1) = _
  rw [euler_coeff_succ, choose112_87, euler112_coeff_86]
  norm_num

private theorem euler112_coeff_88 : (eulerNumerator 112).coeff 88 = (617769051000591793752166 : ℤ) := by
  change (eulerNumerator 112).coeff (87 + 1) = _
  rw [euler_coeff_succ, choose112_88, euler112_coeff_87]
  norm_num

private theorem euler112_coeff_89 : (eulerNumerator 112).coeff 89 = (-155099480338395962344966 : ℤ) := by
  change (eulerNumerator 112).coeff (88 + 1) = _
  rw [euler_coeff_succ, choose112_89, euler112_coeff_88]
  norm_num

private theorem euler112_coeff_90 : (eulerNumerator 112).coeff 90 = (36861701169168138763126 : ℤ) := by
  change (eulerNumerator 112).coeff (89 + 1) = _
  rw [euler_coeff_succ, choose112_90, euler112_coeff_89]
  norm_num

private theorem euler112_coeff_91 : (eulerNumerator 112).coeff 91 = (-8276743567816357237846 : ℤ) := by
  change (eulerNumerator 112).coeff (90 + 1) = _
  rw [euler_coeff_succ, choose112_91, euler112_coeff_90]
  norm_num

private theorem euler112_coeff_92 : (eulerNumerator 112).coeff 92 = (1751916289246928846206 : ℤ) := by
  change (eulerNumerator 112).coeff (91 + 1) = _
  rw [euler_coeff_succ, choose112_92, euler112_coeff_91]
  norm_num

private theorem euler112_coeff_93 : (eulerNumerator 112).coeff 93 = (-348727627188987256606 : ℤ) := by
  change (eulerNumerator 112).coeff (92 + 1) = _
  rw [euler_coeff_succ, choose112_93, euler112_coeff_92]
  norm_num

private theorem euler112_coeff_94 : (eulerNumerator 112).coeff 94 = (65104386985786297006 : ℤ) := by
  change (eulerNumerator 112).coeff (93 + 1) = _
  rw [euler_coeff_succ, choose112_94, euler112_coeff_93]
  norm_num

private theorem euler112_coeff_95 : (eulerNumerator 112).coeff 95 = (-11365246736758746766 : ℤ) := by
  change (eulerNumerator 112).coeff (94 + 1) = _
  rw [euler_coeff_succ, choose112_95, euler112_coeff_94]
  norm_num

private theorem euler112_coeff_96 : (eulerNumerator 112).coeff 96 = (1848940650993451411 : ℤ) := by
  change (eulerNumerator 112).coeff (95 + 1) = _
  rw [euler_coeff_succ, choose112_96, euler112_coeff_95]
  norm_num

private theorem euler112_coeff_97 : (eulerNumerator 112).coeff 97 = (-279240678083711971 : ℤ) := by
  change (eulerNumerator 112).coeff (96 + 1) = _
  rw [euler_coeff_succ, choose112_97, euler112_coeff_96]
  norm_num

private theorem euler112_coeff_98 : (eulerNumerator 112).coeff 98 = (38980478148547771 : ℤ) := by
  change (eulerNumerator 112).coeff (97 + 1) = _
  rw [euler_coeff_succ, choose112_98, euler112_coeff_97]
  norm_num

private theorem euler112_coeff_99 : (eulerNumerator 112).coeff 99 = (-5004288258726571 : ℤ) := by
  change (eulerNumerator 112).coeff (98 + 1) = _
  rw [euler_coeff_succ, choose112_99, euler112_coeff_98]
  norm_num

private theorem euler112_coeff_100 : (eulerNumerator 112).coeff 100 = (587383573049815 : ℤ) := by
  change (eulerNumerator 112).coeff (99 + 1) = _
  rw [euler_coeff_succ, choose112_100, euler112_coeff_99]
  norm_num

private theorem euler112_coeff_101 : (eulerNumerator 112).coeff 101 = (-62602818315943 : ℤ) := by
  change (eulerNumerator 112).coeff (100 + 1) = _
  rw [euler_coeff_succ, choose112_101, euler112_coeff_100]
  norm_num

private theorem euler112_coeff_102 : (eulerNumerator 112).coeff 102 = (6008815354447 : ℤ) := by
  change (eulerNumerator 112).coeff (101 + 1) = _
  rw [euler_coeff_succ, choose112_102, euler112_coeff_101]
  norm_num

private theorem euler112_coeff_103 : (eulerNumerator 112).coeff 103 = (-514251960127 : ℤ) := by
  change (eulerNumerator 112).coeff (102 + 1) = _
  rw [euler_coeff_succ, choose112_103, euler112_coeff_102]
  norm_num

private theorem euler112_coeff_104 : (eulerNumerator 112).coeff 104 = (38760897157 : ℤ) := by
  change (eulerNumerator 112).coeff (103 + 1) = _
  rw [euler_coeff_succ, choose112_104, euler112_coeff_103]
  norm_num

private theorem euler112_coeff_105 : (eulerNumerator 112).coeff 105 = (-2533006645 : ℤ) := by
  change (eulerNumerator 112).coeff (104 + 1) = _
  rw [euler_coeff_succ, choose112_105, euler112_coeff_104]
  norm_num

private theorem euler112_coeff_106 : (eulerNumerator 112).coeff 106 = (140598781 : ℤ) := by
  change (eulerNumerator 112).coeff (105 + 1) = _
  rw [euler_coeff_succ, choose112_106, euler112_coeff_105]
  norm_num

private theorem euler112_coeff_107 : (eulerNumerator 112).coeff 107 = (-6445069 : ℤ) := by
  change (eulerNumerator 112).coeff (106 + 1) = _
  rw [euler_coeff_succ, choose112_107, euler112_coeff_106]
  norm_num

private theorem euler112_coeff_108 : (eulerNumerator 112).coeff 108 = (234249 : ℤ) := by
  change (eulerNumerator 112).coeff (107 + 1) = _
  rw [euler_coeff_succ, choose112_108, euler112_coeff_107]
  norm_num

private theorem euler112_coeff_109 : (eulerNumerator 112).coeff 109 = (-6329 : ℤ) := by
  change (eulerNumerator 112).coeff (108 + 1) = _
  rw [euler_coeff_succ, choose112_109, euler112_coeff_108]
  norm_num

private theorem euler112_coeff_110 : (eulerNumerator 112).coeff 110 = (113 : ℤ) := by
  change (eulerNumerator 112).coeff (109 + 1) = _
  rw [euler_coeff_succ, choose112_110, euler112_coeff_109]
  norm_num

private theorem euler112_coeff_111 : (eulerNumerator 112).coeff 111 = (-1 : ℤ) := by
  change (eulerNumerator 112).coeff (110 + 1) = _
  rw [euler_coeff_succ, choose112_111, euler112_coeff_110]
  norm_num

private theorem euler112_coeff_112 : (eulerNumerator 112).coeff 112 = (0 : ℤ) := by
  change (eulerNumerator 112).coeff (111 + 1) = _
  rw [euler_coeff_succ, choose112_112, euler112_coeff_111]
  norm_num

theorem euler112_finiteMoment :
    finiteMoment (eulerNumerator 112) 113 =
      (3993661202031262530551161989344308263337206946786898714707866398251392398083847387925066126477040273614212671974245294214055675990873471234992667358072323071272639556355381276798185178466713706400653783129173646745749568584692006704713982521410191214013986252176273099762621572290929882554826287887438240455288873178352275902072342967958312343973924977613332684236733467622037 : ℚ) /
      774890145631524430516544003136033154680382140626430951414022048640139401048225655330576404143903349577590762638791992122929058801968898722567724461253748120788194015334323028336898817016438793401239312976999199927516491945092072868888206133237582303341611907138323468132882002391254748654172703677857210831189537055409316246323200000000000000 := by
  norm_num [finiteMoment, Finset.sum_range_succ,
    euler112_coeff_0,
    euler112_coeff_1,
    euler112_coeff_2,
    euler112_coeff_3,
    euler112_coeff_4,
    euler112_coeff_5,
    euler112_coeff_6,
    euler112_coeff_7,
    euler112_coeff_8,
    euler112_coeff_9,
    euler112_coeff_10,
    euler112_coeff_11,
    euler112_coeff_12,
    euler112_coeff_13,
    euler112_coeff_14,
    euler112_coeff_15,
    euler112_coeff_16,
    euler112_coeff_17,
    euler112_coeff_18,
    euler112_coeff_19,
    euler112_coeff_20,
    euler112_coeff_21,
    euler112_coeff_22,
    euler112_coeff_23,
    euler112_coeff_24,
    euler112_coeff_25,
    euler112_coeff_26,
    euler112_coeff_27,
    euler112_coeff_28,
    euler112_coeff_29,
    euler112_coeff_30,
    euler112_coeff_31,
    euler112_coeff_32,
    euler112_coeff_33,
    euler112_coeff_34,
    euler112_coeff_35,
    euler112_coeff_36,
    euler112_coeff_37,
    euler112_coeff_38,
    euler112_coeff_39,
    euler112_coeff_40,
    euler112_coeff_41,
    euler112_coeff_42,
    euler112_coeff_43,
    euler112_coeff_44,
    euler112_coeff_45,
    euler112_coeff_46,
    euler112_coeff_47,
    euler112_coeff_48,
    euler112_coeff_49,
    euler112_coeff_50,
    euler112_coeff_51,
    euler112_coeff_52,
    euler112_coeff_53,
    euler112_coeff_54,
    euler112_coeff_55,
    euler112_coeff_56,
    euler112_coeff_57,
    euler112_coeff_58,
    euler112_coeff_59,
    euler112_coeff_60,
    euler112_coeff_61,
    euler112_coeff_62,
    euler112_coeff_63,
    euler112_coeff_64,
    euler112_coeff_65,
    euler112_coeff_66,
    euler112_coeff_67,
    euler112_coeff_68,
    euler112_coeff_69,
    euler112_coeff_70,
    euler112_coeff_71,
    euler112_coeff_72,
    euler112_coeff_73,
    euler112_coeff_74,
    euler112_coeff_75,
    euler112_coeff_76,
    euler112_coeff_77,
    euler112_coeff_78,
    euler112_coeff_79,
    euler112_coeff_80,
    euler112_coeff_81,
    euler112_coeff_82,
    euler112_coeff_83,
    euler112_coeff_84,
    euler112_coeff_85,
    euler112_coeff_86,
    euler112_coeff_87,
    euler112_coeff_88,
    euler112_coeff_89,
    euler112_coeff_90,
    euler112_coeff_91,
    euler112_coeff_92,
    euler112_coeff_93,
    euler112_coeff_94,
    euler112_coeff_95,
    euler112_coeff_96,
    euler112_coeff_97,
    euler112_coeff_98,
    euler112_coeff_99,
    euler112_coeff_100,
    euler112_coeff_101,
    euler112_coeff_102,
    euler112_coeff_103,
    euler112_coeff_104,
    euler112_coeff_105,
    euler112_coeff_106,
    euler112_coeff_107,
    euler112_coeff_108,
    euler112_coeff_109,
    euler112_coeff_110,
    euler112_coeff_111,
    euler112_coeff_112]

theorem eulerApprox112_exact :
    eulerApprox 112 =
      (3993661202031262530551161989344308263337206946786898714707866398251392398083847387925066126477040273614212671974245294214055675990873471234992667358072323071272639556355381276798185178466713706400653783129173646745749568584692006704713982521410191214013986252176273099762621572290929882554826287887438240455288873178352275902072342967958312343973924977613332684236733467622037 : ℚ) /
      4023459668872159385281049895505530458141403524950596804280234087279480410679041360710980046536367859698053680863060778080433595579680111291796501966098538121834978296686298573808666763357198884739384973875020040654592801782034600622180159204012546279664239045069316398824520620174948297630004591563255082444966164839714217492281723375834104986191486216083551027200000000000000 := by
  unfold eulerApprox
  rw [euler112_finiteMoment]
  norm_num

/-- The lower endpoint of the Euler interval lies inside the certified window. -/
theorem euler112_window_lower :
    windowLower ≤ (64 / 63 : ℚ) * eulerApprox 112 := by
  rw [eulerApprox112_exact]
  norm_num [windowLower]

/-- The entire analytic Euler remainder also fits inside the certified window. -/
theorem euler112_window_upper :
    (64 / 63 : ℚ) * (eulerApprox 112 + 1 / (2 : ℚ) ^ 112) ≤ windowUpper := by
  rw [eulerApprox112_exact]
  norm_num [windowUpper]

end Zeta7Chain
