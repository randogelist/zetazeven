import Zeta7Chain.Pencil
import Mathlib.LinearAlgebra.Matrix.Notation
import Mathlib.Data.Real.Basic
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.GCD
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Push

/-!
Exact finite-dimensional witness certificates for the corrected zeta(7) chain.

This module verifies the integer matrix arithmetic and the resulting affine
identities.  It does not identify this matrix pencil with an analytic integral.
All numerical certificates below are checked by Lean's kernel through `norm_num`.
-/

namespace Zeta7Chain

open scoped BigOperators

def witnessD : ℤ := 214990848

/-- The fixed integer numerator matrix in the pencil `X I - A / D`. -/
def witnessA : Matrix (Fin 5) (Fin 5) ℤ :=
  !![0, -35831808, -18195840, -12146944, -9112395;
     -35831808, 214990848, -559872, -304512, -205924;
     -18195840, -559872, 216670464, -49152, -28950;
     -12146944, -304512, -49152, 216768768, -8748;
     -9112395, -205924, -28950, -8748, 216781890]

/-- The certificate matrix agrees entrywise with the general moment formula. -/
theorem witnessA_rat :
    (fun i j => (witnessA i j : ℚ)) = momentIntegerMatrix5 := by
  ext i j
  fin_cases i <;> fin_cases j <;> norm_num [witnessA, momentIntegerMatrix5]

theorem momentShift_four_witness : momentShift 4 =
    (1 / (witnessD : ℚ)) • (fun i j => (witnessA i j : ℚ)) := by
  rw [witnessA_rat]
  ext i j
  have h := congrArg (fun B : Matrix (Fin 5) (Fin 5) ℚ => B i j) momentShift_four
  norm_num [Matrix.smul_apply, witnessD] at h ⊢
  exact h

def normSq (c : Fin 5 → ℤ) : ℤ := ∑ i, c i ^ 2

def rationalNumerator (c : Fin 5 → ℤ) : ℤ :=
  ∑ i, ∑ j, c i * witnessA i j * c j

/-- The finite matrix-pencil value associated to a coefficient vector. -/
noncomputable def affineWitness (c : Fin 5 → ℤ) (X : ℝ) : ℝ :=
  (normSq c : ℝ) * X - (rationalNumerator c : ℝ) / (witnessD : ℝ)

def strongP : ℤ := 8600205557893300
def strongQ : ℤ := 8528994616054931
def strongScale : ℤ := 366995056839462583402911951394058537813564

/-- Coefficients of the cubic witness, padded with its zero quartic coefficient. -/
def strongCoeffs : Fin 5 → ℤ :=
  ![324604532957945743900781409,
    -10506564735871898311799191101,
    41588993887250059870506122711,
    -35916029578684544952430498491,
    0]

theorem strong_normSq : normSq strongCoeffs = strongQ * strongScale := by
  norm_num [normSq, strongCoeffs, strongQ, strongScale, Fin.sum_univ_succ]

theorem strong_rationalNumerator :
    rationalNumerator strongCoeffs = witnessD * strongP * strongScale := by
  norm_num [rationalNumerator, strongCoeffs, witnessA, witnessD,
    strongP, strongScale, Fin.sum_univ_succ]

theorem strong_coprime : Int.gcd strongP strongQ = 1 := by
  norm_num [strongP, strongQ]

/-- A coprime coefficient pair certifies that the coefficient vector is primitive. -/
theorem strong_coefficients_coprime :
    Int.gcd (strongCoeffs 2) (strongCoeffs 3) = 1 := by
  change Int.gcd 41588993887250059870506122711 (-35916029578684544952430498491) = 1
  norm_num

theorem strongScale_pos : 0 < strongScale := by
  norm_num [strongScale]

/-- Exact integer isotropy for the rational root `strongP / strongQ`. -/
theorem strong_isotropic :
    witnessD * strongP * normSq strongCoeffs -
      strongQ * rationalNumerator strongCoeffs = 0 := by
  rw [strong_normSq, strong_rationalNumerator]
  ring

/-- The certificate gives its claimed affine linear form for every real input. -/
theorem strong_affine_identity (X : ℝ) :
    affineWitness strongCoeffs X =
      (strongScale : ℝ) * ((strongQ : ℝ) * X - (strongP : ℝ)) := by
  rw [affineWitness, strong_normSq, strong_rationalNumerator]
  norm_num [witnessD, strongQ, strongP, strongScale]
  ring

/-- The initial small polynomial is `x - 2 x^2`. -/
def seedCoeffs : Fin 5 → ℤ := ![0, 1, -2, 0, 0]

theorem seed_normSq : normSq seedCoeffs = 5 := by
  norm_num [normSq, seedCoeffs, Fin.sum_univ_succ]

theorem seed_rationalNumerator : rationalNumerator seedCoeffs = 1083912192 := by
  norm_num [rationalNumerator, seedCoeffs, witnessA, Fin.sum_univ_succ]

theorem seed_integer_certificate :
    24 * normSq seedCoeffs = 120 ∧
      24 * rationalNumerator seedCoeffs = witnessD * 121 := by
  norm_num [seed_normSq, seed_rationalNumerator, witnessD]

theorem seed_affine_identity (X : ℝ) :
    affineWitness seedCoeffs X = (1 / 24 : ℝ) * (120 * X - 121) := by
  norm_num [affineWitness, seed_normSq, seed_rationalNumerator, witnessD]
  ring

end Zeta7Chain
