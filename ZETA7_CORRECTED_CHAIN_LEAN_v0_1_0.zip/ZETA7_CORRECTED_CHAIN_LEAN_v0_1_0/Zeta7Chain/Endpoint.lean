import Zeta7Chain.FiniteBounds
import Zeta7Chain.Obstruction

namespace Zeta7Chain

/-- The finite seed is proved; an all-state halving law is still required. -/
theorem ZETA7_IRRATIONAL_OF_HALVING
    (next : Coefficients → Coefficients) (hnext : HalvingLaw zeta7 next) :
    Irrational zeta7 :=
  irrational_of_admitted_halving next strongCoeffs strong_zeta7_admissible hnext

/-- Both the universal lift and the infinite approximation supply are premises. -/
theorem ZETA7_IRRATIONAL_OF_LIFT_AND_EXHAUSTION
    (hlift : UniversalQuarticLift) (happrox : ApproximationExhaustion zeta7) :
    Irrational zeta7 :=
  ZETA7_IRRATIONAL_OF_EXHAUSTION
    (witness_exhaustion_of_lift_and_approximants hlift happrox)

end Zeta7Chain
