@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "PACKAGE=ZETA7_CORRECTED_CHAIN_LEAN_v0_1_0"
if not exist "logs" mkdir "logs"
echo PACKAGE=!PACKAGE!
echo RUNNER=NATIVE_WINDOWS_LEAN_433
set "TOOLCHAIN=%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0"
if defined ZETA7_TOOLCHAIN set "TOOLCHAIN=!ZETA7_TOOLCHAIN!"
set "LEAN_EXE=!TOOLCHAIN!\bin\lean.exe"
set "LEAN_SYSROOT=!TOOLCHAIN!"
if not exist "!LEAN_EXE!" (
  echo LEAN_EXE_NOT_FOUND=!LEAN_EXE!
  exit /b 1
)
"!LEAN_EXE!" --version > "logs\version.log" 2>&1
if errorlevel 1 (
  type "logs\version.log"
  exit /b 1
)
type "logs\version.log"
findstr /C:"version 4.33.0" "logs\version.log" >nul
if errorlevel 1 (
  echo LEAN_VERSION_MISMATCH=EXPECTED_4.33.0
  exit /b 1
)
set "CACHE_ROOT=%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1"
if defined ZETA7_CACHE_ROOT set "CACHE_ROOT=!ZETA7_CACHE_ROOT!"
if not exist "!CACHE_ROOT!\.lake\packages\mathlib\.lake\build\lib\lean\Mathlib.olean" (
  echo MATHLIB_CACHE_NOT_FOUND=!CACHE_ROOT!
  exit /b 1
)
set "LEAN_PATH=!TOOLCHAIN!\lib\lean;%CD%"
if exist "!CACHE_ROOT!\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;!CACHE_ROOT!\.lake\build\lib\lean"
for /d %%D in ("!CACHE_ROOT!\.lake\packages\*") do (
  if exist "%%~fD\.lake\build\lib\lean" set "LEAN_PATH=!LEAN_PATH!;%%~fD\.lake\build\lib\lean"
)
echo NETWORK=NOT_USED
echo IMPORT_ROOTS=EXACT_PACKAGE_BUILD_DIRECTORIES
findstr /I /R /C:"\<sorry\>" /C:"\<admit\>" /C:"\<axiom\>" /C:"\<native_decide\>" /C:"\<unsafe\>" /C:"\<implemented_by\>" "Zeta7Chain\*.lean" > "logs\source_scan.log"
if errorlevel 2 (
  echo SOURCE_SCAN=ERROR
  exit /b 1
)
if not errorlevel 1 (
  type "logs\source_scan.log"
  echo SOURCE_SCAN=FAIL
  exit /b 1
)
echo SOURCE_SCAN=PASS
set "MODULES=Pencil Witness Normalization Closure NativeZeta FiniteWindow Readout EulerSupport EulerPolynomial EulerBound EulerArithmetic Obstruction FiniteBounds Endpoint Audit"
for %%F in (!MODULES!) do (
  if exist "Zeta7Chain\%%F.olean" del "Zeta7Chain\%%F.olean"
)
for %%F in (!MODULES!) do (
  echo CHECK=Zeta7Chain\%%F.lean
  "!LEAN_EXE!" -j 1 -o "Zeta7Chain\%%F.olean" "Zeta7Chain\%%F.lean" > "logs\%%F.log" 2>&1
  set "RESULT=!ERRORLEVEL!"
  type "logs\%%F.log"
  if not "!RESULT!"=="0" (
    echo CHECK_FAIL=%%F
    echo RUN=FAIL
    exit /b 1
  )
  findstr /I /C:"sorryAx" /C:"Lean.ofReduceBool" "logs\%%F.log" >nul
  if errorlevel 2 (
    echo AXIOM_AUDIT=ERROR_IN_%%F
    exit /b 1
  )
  if not errorlevel 1 (
    echo AXIOM_AUDIT=FAIL_IN_%%F
    exit /b 1
  )
  echo CHECK_PASS=%%F
)
echo FINITE_NATIVE_ZETA7_CERTIFICATE=PROVED
echo CUBIC_OBSTRUCTION=PROVED
echo IRRATIONALITY_ENDPOINT=CONDITIONAL
echo INFINITE_EXHAUSTION=NOT_SUPPLIED
echo ALL_STATE_HALVING_LAW=NOT_SUPPLIED
echo RUN=PASS
exit /b 0
