# Corrected zeta(7) chain — Lean 4.33

This package formalizes the exact finite certificate, primitive normalization,
the cubic obstruction at 17295/17152, and conditional irrationality endpoints.
It does **not** prove that zeta(7) is irrational. The infinite exhaustion or
successor hypothesis remains explicit in the endpoint's type.

## Native Windows replay

Extract the ZIP, open its folder, and run `run.cmd`. It uses the existing native
Lean 4.33 and Mathlib cache; no downloads, Lake, Python, PowerShell, or WSL are
needed. From the Downloads folder, a single command is:

```cmd
tar -xf ZETA7_CORRECTED_CHAIN_LEAN_v0_1_0.zip && call ZETA7_CORRECTED_CHAIN_LEAN_v0_1_0\run.cmd
```

Default locations:

* Lean: `%USERPROFILE%\.elan\toolchains\leanprover--lean4---v4.33.0`
* Cache: `%USERPROFILE%\lean-native\awpi_phi_rh_lean_sieved_v0_1_1`

Set `ZETA7_TOOLCHAIN` and/or `ZETA7_CACHE_ROOT` before running to use another
existing installation. Import roots are the actual `.lake\build\lib\lean`
directories. The runner rebuilds every supplied module in dependency order and
writes logs into `logs`. It stops at the first failure.

The package's local replay uses Lean 4.33.0 and Mathlib commit
`db584cd6d46c92f209a44c0f1c829460d327499d`. A Windows replay has not been performed
in this environment. An incompatible precompiled cache must be replaced by a
matching one; the runner does not download or modify your cache.

## What the chain proves

| Module | Checked content |
| --- | --- |
| `Pencil` | Rational moment-pencil definition, symmetry, coefficient Gram matrix, basis-change determinant law, and real splitting of the canonical symmetric characteristic polynomial. |
| `Witness` | Exact integer matrix and cubic coefficient vector; squared norm, quadratic numerator, coprimality, and the resulting affine identity. |
| `Normalization` | GCD reduction to primitive integer forms, positive denominator, coprimality, and invariance under a common positive integer scale. |
| `NativeZeta` | The real target is `(riemannZeta (7 : Complex)).re`, identified with its convergent Dirichlet series. |
| `EulerSupport`, `EulerPolynomial`, `EulerBound` | Positive sevenfold grid moments and native eta convergence yield an unconditional Euler interval for that actual zeta value. |
| `EulerArithmetic`, `FiniteWindow`, `FiniteBounds` | Exact 112-step rational arithmetic, the certified zeta interval, positive primitive error below 1/(2e16), the billionfold finite comparison, and exclusion of denominators at most 2e16. |
| `Obstruction` | Integer and rational descent for the unit classes modulo 8; exact diagonalization; no nonzero cubic coefficient vector at the root 17295/17152. |
| `Closure`, `Readout`, `Endpoint` | Arbitrarily small positive integer forms imply irrationality; coefficient readout and halving-orbit versions preserve their unproved infinite premises. |
| `Audit` | Printed endpoint types and transitive axiom dependencies. |

The canonical pencil is `X * I - R`. Its rational entries are

* diagonal: `X - H_r^(7)`;
* off diagonal: `(H_r^(6) - H_s^(6)) / (6 * (r - s))`.

For a nonzero coefficient vector `c : Fin 5 -> Int`, set `S = sum c_i^2`,
`T = c^T A c`, and `D = 214990848`. The primitive readout divides `D*S` and `T`
by their integer GCD, giving `q > 0`, `gcd(q,p) = 1`, and error `q*zeta7-p`.
The strong vector has zero quartic coefficient, so this particular witness is
cubic even though the readout allows degree four.

The exact checked finite result is

```text
0 < 8528994616054931 * zeta7 - 8600205557893300
  < 1 / 20000000000000000.
```

The native value lies in the rational interval

```text
1.008349277381922826839797549849796
  <= zeta7 <=
1.008349277381922826839797549849797.
```

These are rational inequalities checked by Lean, not floating-point estimates.
The analytic bound is valid at every Euler depth; only its depth-112 arithmetic
instance is expanded into a finite certificate.

## The remaining infinite input

The main endpoint is precisely:

```lean
ZETA7_IRRATIONAL_OF_EXHAUSTION
  (h : WitnessExhaustion zeta7) : Irrational zeta7
```

Here `WitnessExhaustion zeta7` says that for **every** natural number `n`, there
is a nonzero coefficient vector with positive primitive error below `2^(-n)`.
The package proves one excellent finite witness, not this universal statement.

Alternatively, `ZETA7_IRRATIONAL_OF_HALVING next hnext` uses the proved strong
seed and a supplied law that `next` preserves admissibility and halves the
primitive error at every admissible state. No such `next` and law are supplied.

`UniversalQuarticLift` is only a proposition defining the Meyer-lifting
interface. `ZETA7_IRRATIONAL_OF_LIFT_AND_EXHAUSTION` requires both a proof of
that interface and an infinite supply of reduced rational approximants. It
does not manufacture the approximation supply from lifting.

## Formalization boundaries

* The rational moment formula and its matrix consequences are checked. Its
  identification with the paper's logarithmic double integral is not proved
  here. The Euler certificate reaches actual zeta(7) independently through
  finite positive grid means and eta convergence.
* Positivity of the coefficient Gram matrix does not assert positivity of the
  full affine pencil at zeta(7).
* Real spectral splitting is proved for the canonical symmetric pencil. A
  theorem covering every rectangular compression as a generalized eigenvalue
  problem is not supplied.
* The concrete cubic obstruction is checked. The full dense family of bad
  cubic roots is not formalized in this package.
* The Meyer/Cassels universal lifting and height bounds, and the beta-family
  primitive-growth no-go argument, remain outside this Lean package.
* Neither finite improvement nor a numerical root search proves exhaustion.

## Verification and provenance

All supplied proofs are replayed from source. The source check rejects
`sorry`, `admit`, new `axiom` declarations, and `native_decide`. The endpoint
axiom audit permits Lean's standard `propext`, `Classical.choice`, and
`Quot.sound`; it rejects `sorryAx` and `Lean.ofReduceBool`.
Some preserved proofs emit style warnings about unused tactics, variables, or
simplification arguments. These warnings do not bypass proof checking.

`EulerSupport.lean` consolidates the proved dependencies of
`PolynomialGridBridge` and `NativeEtaSeven` from
`CHEBYSHEV_MASTERTIER_LEAN_v0_1_43_OMEGA7_ONE_DIMENSIONAL_REDUCTION`.
Original namespaces are retained and scopes are closed between source modules.
The bundle is rechecked in this package; it is not an opaque imported proof.

See `validation/` for the local replay log and source hashes. The ZIP intentionally
contains source and runners, not platform-specific compiled `.olean` files.
